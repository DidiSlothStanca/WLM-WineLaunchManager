#pragma once

#include <QString>

#include <optional>

// Prefix sharing between runners (Wine / Proton GE / Proton-CachyOS).
//
// Wine uses WINEPREFIX = <dir with drive_c>.
// Proton uses STEAM_COMPAT_DATA_PATH = <compat dir> and keeps the real Wine
// prefix in <compat dir>/pfx.
//
// To let ONE prefix (saves, registry, installed apps) be used by every runner
// without copying or overwriting anything:
//   - a Proton compat dir is used by Wine through <compat dir>/pfx;
//   - a vanilla Wine prefix is used by Proton through a small compat dir under
//     ~/wlm/compat/<code> whose "pfx" is a symlink to the real prefix.
// Nothing inside the prefix is ever copied, so switching runner never touches
// the game progress.
namespace prefixlink {

enum class Kind {
    NotAPrefix,   // no drive_c found (empty / unrelated folder)
    WinePrefix,   // <dir>/drive_c
    ProtonCompat, // <dir>/pfx/drive_c
};

Kind classify(const QString& path);

// Folder that really holds drive_c for any prefix path (itself for a Wine
// prefix, <dir>/pfx for a Proton compat dir, the path unchanged otherwise).
QString winePrefixDir(const QString& anyPath);

struct Detected {
    Kind kind = Kind::NotAPrefix;
    QString path; // Wine prefix dir, or Proton compat dir
};

// Walk up from an .exe looking for the prefix it is installed in, even when the
// prefix is not in WLM's registry (e.g. a game installed from another launcher).
std::optional<Detected> detectFromExe(const QString& exePath);

// Path that must be put in the launch script for `runner` so it uses the
// prefix stored at `anyPath` (creates the ~/wlm/compat link when Proton has to
// use a vanilla Wine prefix). Empty string + *error on failure.
QString pathForRunner(const QString& runner, const QString& anyPath, const QString& code,
                      QString* error = nullptr);

struct Resolved {
    bool ok = false;
    QString code;
    QString path; // value for RunnerChoice::prefixPath
    QString error;
};

// Use the EXISTING prefix at `anyPath` with `runner`. Registers it (reusing its
// code when already known) and never modifies its content.
Resolved useExisting(const QString& runner, const QString& anyPath,
                     const QString& preferredCode = {}, const QString& protonName = {},
                     const QString& protonPath = {});

// Create a NEW prefix folder at exactly `path` for `runner` and register it.
Resolved createNew(const QString& runner, const QString& path, const QString& preferredCode = {},
                   const QString& protonName = {}, const QString& protonPath = {});

// Registry code that does not clash with a DIFFERENT physical prefix of the
// same runner.
QString uniqueCode(const QString& runner, const QString& desired, const QString& physicalWineDir);

// Readable code derived from a folder name ("My Prefix" -> "My_Prefix").
QString suggestCode(const QString& path);

// After a prefix folder moved: re-point ~/wlm/compat/*/pfx links.
void retargetCompatLinks(const QString& oldPath, const QString& newPath);

QString canonical(const QString& path);

} // namespace prefixlink
