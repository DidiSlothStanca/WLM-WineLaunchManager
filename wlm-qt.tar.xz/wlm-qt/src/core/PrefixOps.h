#pragma once

#include <QJsonObject>
#include <QList>
#include <QString>
#include <QStringList>

#include <optional>

// Prefix bookkeeping + filesystem helpers used by the Prefix Configuration
// Manager and the Add-Game flow. Ports the corresponding launcher.py helpers:
// list_all_known_prefixes, find_owning_prefix, relink_scripts_after_prefix_move,
// gather_prefix_backup_info, compute_total_size.
namespace prefixops {

QString runnerDisplayName(const QString& runnerKey);

struct PrefixInfo {
    QString runner; // wine | protonge | protoncachyos
    QString code;
    QString path;
    QString protonName;
    QString protonPath;
    QStringList games;

    QString key() const { return runner + QLatin1Char(':') + code; }
};

// Every prefix known from prefix_registry.json plus folders found under the
// default/custom prefix roots, each with the games that use it. Sorted by
// (runner, code).
QList<PrefixInfo> allKnownPrefixes();

// The prefix that physically contains `exePath`, if any.
std::optional<PrefixInfo> findOwningPrefix(const QString& exePath);

// Rewrite every script of a prefix after its folder moved; returns the script
// names that were rewritten.
QStringList relinkScriptsAfterMove(const QString& runner, const QString& code,
                                   const QString& oldPath, const QString& newPath);

// Point every game of prefix (runner, oldCode) at another, already existing
// prefix and rewrite their scripts. Nothing inside any prefix is touched.
QStringList repointGames(const QString& runner, const QString& oldCode,
                         const QString& newCode, const QString& newPath);

// The "wine" binary inside a Proton build (files/bin/wine64, dist/bin/wine, ...).
QString findProtonWineBinary(const QString& protonScriptPath);

// One game linked to a prefix, as needed for backup/restore.
struct GameBackupInfo {
    QString scriptName;
    QString folderPath;
    QString exePath;
    QString relativeExe;
    QString relativeToPrefix;
    QString iconPath;
    QString launchOptions;
    QString comment;
    bool insidePrefix = false;
    bool hasIcon = false;
    bool missing = false;
};

QList<GameBackupInfo> gatherBackupInfo(const PrefixInfo& entry);

// Recursive total size (bytes) of files/folders; ignores errors.
qint64 computeTotalSize(const QStringList& paths);

// Read manifest.json out of a .tar.gz backup. Returns an empty object and sets
// *error on failure.
QJsonObject readBackupManifest(const QString& archivePath, QString* error);

// Delete a prefix folder and every launcher game using it. `removedInside`
// receives the names whose files were deleted along with the prefix.
bool removePrefix(const PrefixInfo& entry, QStringList* removedInside, QString* error);

} // namespace prefixops
