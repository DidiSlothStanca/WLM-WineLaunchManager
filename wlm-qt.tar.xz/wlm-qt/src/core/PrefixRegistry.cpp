#include "core/PrefixRegistry.h"

#include "core/JsonIO.h"
#include "core/Paths.h"
#include "core/RunnerConfig.h"

#include <QDir>
#include <QFileInfo>
#include <QJsonValue>

namespace prefixreg {

QString defaultRoot(const QString& runnerKey)
{
    if (runnerKey == QLatin1String("protonge"))
        return paths::protonGEPrefixes();
    if (runnerKey == QLatin1String("protoncachyos"))
        return paths::protonCachyOSPrefixes();
    return paths::winePrefixes();
}

QString generateNextPrefixCode(const QString& runnerKey)
{
    QList<int> numbers;

    const QJsonObject runnerCfg = runnerconfig::load();
    for (auto it = runnerCfg.constBegin(); it != runnerCfg.constEnd(); ++it) {
        if (!it.value().isObject())
            continue;
        const QJsonObject entry = it.value().toObject();
        if (entry.value(QStringLiteral("runner")).toString() != runnerKey)
            continue;
        const QString code = entry.value(QStringLiteral("prefix_code")).toString();
        if (code.startsWith(QLatin1String("GAME"))) {
            bool ok = false;
            const int n = code.mid(4).toInt(&ok);
            if (ok)
                numbers.append(n);
        }
    }

    // Codes already registered for this runner (e.g. prefixes shared with a game
    // that now uses another runner) must not be handed out again.
    const QJsonObject reg = loadRegistry();
    const QString regPrefix = runnerKey + QLatin1Char(':');
    for (auto it = reg.constBegin(); it != reg.constEnd(); ++it) {
        if (!it.key().startsWith(regPrefix))
            continue;
        const QString code = it.key().mid(regPrefix.size());
        if (code.startsWith(QLatin1String("GAME"))) {
            bool ok = false;
            const int n = code.mid(4).toInt(&ok);
            if (ok)
                numbers.append(n);
        }
    }

    const QString root = getPrefixBaseDir(runnerKey);
    QDir dir(root);
    if (dir.exists()) {
        const QStringList entries = dir.entryList(QDir::Dirs | QDir::NoDotAndDotDot);
        for (const QString& name : entries) {
            if (name.startsWith(QLatin1String("GAME"))) {
                bool ok = false;
                const int n = name.mid(4).toInt(&ok);
                if (ok)
                    numbers.append(n);
            }
        }
    }

    int maxNum = 0;
    for (int n : numbers)
        maxNum = qMax(maxNum, n);
    return QStringLiteral("GAME%1").arg(maxNum + 1, 3, 10, QLatin1Char('0'));
}

QString getPrefixBaseDir(const QString& runnerKey)
{
    const QJsonObject cfg = jsonio::readObject(paths::prefixLocationConfig());
    const QString custom = cfg.value(runnerKey).toString();
    if (!custom.isEmpty()) {
        QDir dir(custom);
        if (dir.exists() || dir.mkpath(QStringLiteral(".")))
            return custom;
        return defaultRoot(runnerKey);
    }
    return defaultRoot(runnerKey);
}

void setPrefixBaseDir(const QString& runnerKey, const QString& path)
{
    QJsonObject cfg = jsonio::readObject(paths::prefixLocationConfig());
    cfg.insert(runnerKey, path);
    jsonio::writeObjectAtomic(paths::prefixLocationConfig(), cfg);
}

void resetPrefixBaseDir(const QString& runnerKey)
{
    QJsonObject cfg = jsonio::readObject(paths::prefixLocationConfig());
    if (cfg.contains(runnerKey)) {
        cfg.remove(runnerKey);
        jsonio::writeObjectAtomic(paths::prefixLocationConfig(), cfg);
    }
}

QJsonObject loadRegistry()
{
    return jsonio::readObject(paths::prefixRegistry());
}

void saveRegistry(const QJsonObject& reg)
{
    jsonio::writeObjectAtomic(paths::prefixRegistry(), reg);
}

void recordPrefixUsage(const QString& runnerKey, const QString& prefixCode,
                       const QString& prefixPath, const QString& protonName,
                       const QString& protonPath)
{
    QJsonObject reg = loadRegistry();

    QJsonObject entry;
    entry.insert(QStringLiteral("runner"), runnerKey);
    entry.insert(QStringLiteral("prefix_code"), prefixCode);
    entry.insert(QStringLiteral("prefix_path"), prefixPath);
    entry.insert(QStringLiteral("proton_name"),
                 protonName.isEmpty() ? QJsonValue() : QJsonValue(protonName));
    entry.insert(QStringLiteral("proton_path"),
                 protonPath.isEmpty() ? QJsonValue() : QJsonValue(protonPath));

    reg.insert(runnerKey + QLatin1Char(':') + prefixCode, entry);
    saveRegistry(reg);
}

void updateRegistryPrefixPath(const QString& runnerKey, const QString& prefixCode,
                              const QString& newPath)
{
    QJsonObject reg = loadRegistry();
    const QString key = runnerKey + QLatin1Char(':') + prefixCode;

    if (reg.contains(key) && reg.value(key).isObject()) {
        QJsonObject entry = reg.value(key).toObject();
        entry.insert(QStringLiteral("prefix_path"), newPath);
        reg.insert(key, entry);
    } else {
        QJsonObject entry;
        entry.insert(QStringLiteral("runner"), runnerKey);
        entry.insert(QStringLiteral("prefix_code"), prefixCode);
        entry.insert(QStringLiteral("prefix_path"), newPath);
        entry.insert(QStringLiteral("proton_name"), QJsonValue());
        entry.insert(QStringLiteral("proton_path"), QJsonValue());
        reg.insert(key, entry);
    }
    saveRegistry(reg);
}

} // namespace prefixreg
