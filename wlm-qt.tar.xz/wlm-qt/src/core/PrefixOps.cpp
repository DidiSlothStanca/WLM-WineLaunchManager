#include "core/PrefixOps.h"

#include "core/JsonIO.h"
#include "core/Paths.h"
#include "core/PrefixLink.h"
#include "core/PrefixRegistry.h"
#include "core/RunnerConfig.h"
#include "core/Shortcut.h"

#include <QDir>
#include <QDirIterator>
#include <QFile>
#include <QFileInfo>
#include <QHash>
#include <QJsonArray>
#include <QJsonDocument>
#include <QProcess>
#include <QSet>

#include <algorithm>

namespace prefixops {

namespace {

const QStringList kRunners = {QStringLiteral("wine"), QStringLiteral("protonge"),
                              QStringLiteral("protoncachyos")};

QString canon(const QString& path)
{
    const QString c = QFileInfo(path).canonicalFilePath();
    return c.isEmpty() ? QFileInfo(path).absoluteFilePath() : c;
}

// Relative path of `child` under `base`, or nullopt when not inside.
std::optional<QString> relativeUnder(const QString& base, const QString& child)
{
    QString b = QDir::cleanPath(base);
    const QString c = QDir::cleanPath(child);
    if (c == b)
        return QString();
    if (c.startsWith(b + QLatin1Char('/')))
        return c.mid(b.size() + 1);
    return std::nullopt;
}

QString locationConfigValue(const QJsonObject& loc, const QString& runner)
{
    return loc.value(runner).toString();
}

// (runner, baseDir) pairs to scan: the WLM defaults plus any custom location.
QList<QPair<QString, QString>> scanRoots()
{
    QList<QPair<QString, QString>> roots;
    for (const QString& r : kRunners)
        roots.append({r, prefixreg::defaultRoot(r)});

    const QJsonObject loc = jsonio::readObject(paths::prefixLocationConfig());
    for (const QString& r : kRunners) {
        const QString custom = locationConfigValue(loc, r);
        if (!custom.isEmpty())
            roots.append({r, custom});
    }
    return roots;
}

QJsonObject registryEntry(const QJsonObject& reg, const QString& runner, const QString& code)
{
    return reg.value(runner + QLatin1Char(':') + code).toObject();
}

} // namespace

QString runnerDisplayName(const QString& runnerKey)
{
    if (runnerKey == QLatin1String("protonge"))
        return QStringLiteral("Proton GE");
    if (runnerKey == QLatin1String("protoncachyos"))
        return QStringLiteral("Proton-CachyOS");
    if (runnerKey == QLatin1String("wine"))
        return QStringLiteral("Wine");
    return runnerKey;
}

QList<PrefixInfo> allKnownPrefixes()
{
    QHash<QString, PrefixInfo> result;

    const QJsonObject reg = prefixreg::loadRegistry();
    for (auto it = reg.constBegin(); it != reg.constEnd(); ++it) {
        const QJsonObject entry = it.value().toObject();
        const QString p = entry.value(QStringLiteral("prefix_path")).toString();
        const QString r = entry.value(QStringLiteral("runner")).toString();
        const QString c = entry.value(QStringLiteral("prefix_code")).toString();
        if (p.isEmpty() || r.isEmpty() || c.isEmpty())
            continue;
        PrefixInfo info;
        info.runner = r;
        info.code = c;
        info.path = p;
        info.protonName = entry.value(QStringLiteral("proton_name")).toString();
        info.protonPath = entry.value(QStringLiteral("proton_path")).toString();
        result.insert(info.key(), info);
    }

    for (const auto& root : scanRoots()) {
        QDir dir(root.second);
        if (!dir.exists())
            continue;
        for (const QFileInfo& fi : dir.entryInfoList(QDir::Dirs | QDir::NoDotAndDotDot)) {
            PrefixInfo info;
            info.runner = root.first;
            info.code = fi.fileName();
            info.path = fi.filePath();
            if (!result.contains(info.key()))
                result.insert(info.key(), info);
        }
    }

    // Attach games from runner_config.json.
    const QJsonObject games = runnerconfig::load();
    for (auto it = games.constBegin(); it != games.constEnd(); ++it) {
        const QJsonObject cfg = it.value().toObject();
        const QString r = cfg.value(QStringLiteral("runner")).toString();
        const QString c = cfg.value(QStringLiteral("prefix_code")).toString();
        if (r.isEmpty() || c.isEmpty())
            continue;
        const QString k = r + QLatin1Char(':') + c;
        if (result.contains(k))
            result[k].games.append(it.key());
    }

    QList<PrefixInfo> list = result.values();
    for (PrefixInfo& info : list)
        info.games.sort();
    std::sort(list.begin(), list.end(), [](const PrefixInfo& a, const PrefixInfo& b) {
        if (a.runner != b.runner)
            return a.runner < b.runner;
        return a.code < b.code;
    });
    return list;
}

std::optional<PrefixInfo> findOwningPrefix(const QString& exePath)
{
    const QString exe = canon(exePath);
    const QJsonObject reg = prefixreg::loadRegistry();

    QList<PrefixInfo> candidates;
    QSet<QString> knownPaths;
    for (auto it = reg.constBegin(); it != reg.constEnd(); ++it) {
        const QJsonObject entry = it.value().toObject();
        const QString p = entry.value(QStringLiteral("prefix_path")).toString();
        const QString r = entry.value(QStringLiteral("runner")).toString();
        const QString c = entry.value(QStringLiteral("prefix_code")).toString();
        if (p.isEmpty() || r.isEmpty() || c.isEmpty())
            continue;
        PrefixInfo info;
        info.runner = r;
        info.code = c;
        info.path = p;
        info.protonName = entry.value(QStringLiteral("proton_name")).toString();
        info.protonPath = entry.value(QStringLiteral("proton_path")).toString();
        if (QFileInfo(p).exists())
            knownPaths.insert(canon(p));
        candidates.append(info);
    }

    for (const auto& root : scanRoots()) {
        QDir dir(root.second);
        if (!dir.exists())
            continue;
        for (const QFileInfo& fi : dir.entryInfoList(QDir::Dirs | QDir::NoDotAndDotDot)) {
            if (knownPaths.contains(canon(fi.filePath())))
                continue;
            PrefixInfo info;
            info.runner = root.first;
            info.code = fi.fileName();
            info.path = fi.filePath();
            candidates.append(info);
        }
    }

    for (const PrefixInfo& info : candidates) {
        if (info.path.isEmpty())
            continue;
        // Match the prefix folder itself AND the real Wine prefix behind it (a
        // Proton compat dir that links to a shared prefix does not physically
        // contain the game's files).
        std::optional<QString> ignored = relativeUnder(canon(info.path), exe);
        if (!ignored.has_value())
            ignored = relativeUnder(canon(prefixlink::winePrefixDir(info.path)), exe);
        if (ignored.has_value()) {
            PrefixInfo found = info;
            const QJsonObject re = registryEntry(reg, info.runner, info.code);
            found.protonName = re.value(QStringLiteral("proton_name")).toString();
            found.protonPath = re.value(QStringLiteral("proton_path")).toString();
            found.path = canon(info.path);
            return found;
        }
    }
    return std::nullopt;
}

QStringList relinkScriptsAfterMove(const QString& runner, const QString& code,
                                   const QString& oldPath, const QString& newPath)
{
    // `oldPath` may already be gone, so it is only cleaned/resolved best-effort.
    const QString oldResolved = canon(oldPath);
    const QString newResolved = QDir::cleanPath(newPath);

    auto mapPath = [&](const QString& p) -> std::optional<QString> {
        if (p.isEmpty())
            return std::nullopt;
        for (const QString& base : {oldResolved, QDir::cleanPath(oldPath)}) {
            if (const auto rel = relativeUnder(base, QDir::cleanPath(p)))
                return rel->isEmpty() ? newResolved : newResolved + QLatin1Char('/') + *rel;
        }
        return std::nullopt;
    };

    QJsonObject runnerCfg = runnerconfig::load();
    bool changed = false;
    QStringList updated;

    for (auto it = runnerCfg.begin(); it != runnerCfg.end(); ++it) {
        QJsonObject cfg = it.value().toObject();

        const QString scriptPath =
            paths::bashlaunch() + QLatin1Char('/') + it.key() + QStringLiteral(".sh");
        const QString folderStr = shortcut::extractFolderPath(scriptPath);
        const QString exeStr = shortcut::extractExePath(scriptPath);

        const bool sameEntry = cfg.value(QStringLiteral("runner")).toString() == runner
            && cfg.value(QStringLiteral("prefix_code")).toString() == code;
        const auto newPrefixPath = mapPath(cfg.value(QStringLiteral("prefix_path")).toString());
        const auto newFolder = mapPath(folderStr);
        const auto newExe = mapPath(exeStr);

        // A game is affected when it uses this prefix (same runner+code), points
        // into the moved folder (e.g. a Wine game sharing a Proton prefix) or
        // its files live inside the moved folder (game seen through a compat link).
        if (!sameEntry && !newPrefixPath && !newFolder && !newExe)
            continue;

        // A Proton entry that only links (pfx symlink) to a shared prefix keeps its
        // own compat dir; the link itself is retargeted below.
        const bool isCompatLink =
            QFileInfo(cfg.value(QStringLiteral("prefix_path")).toString() + QStringLiteral("/pfx"))
                .isSymLink();
        if (sameEntry && !isCompatLink)
            cfg[QStringLiteral("prefix_path")] = newResolved;
        else if (newPrefixPath)
            cfg[QStringLiteral("prefix_path")] = *newPrefixPath;
        it.value() = cfg;
        changed = true;

        if (!QFileInfo::exists(scriptPath) || folderStr.isEmpty() || exeStr.isEmpty())
            continue;

        const QString content = shortcut::buildScriptContent(newFolder.value_or(folderStr),
                                                             newExe.value_or(exeStr), cfg);
        QFile f(scriptPath);
        if (f.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate)) {
            f.write(content.toUtf8());
            f.close();
            QFile::setPermissions(scriptPath,
                                  QFileDevice::ReadOwner | QFileDevice::WriteOwner
                                      | QFileDevice::ExeOwner | QFileDevice::ReadGroup
                                      | QFileDevice::ExeGroup | QFileDevice::ReadOther
                                      | QFileDevice::ExeOther);
            updated.append(it.key());
        }
    }

    if (changed)
        runnerconfig::save(runnerCfg);

    // Keep the registry in step: every prefix registered inside the moved folder.
    QJsonObject reg = prefixreg::loadRegistry();
    bool regChanged = false;
    for (auto it = reg.begin(); it != reg.end(); ++it) {
        QJsonObject e = it.value().toObject();
        if (const auto np = mapPath(e.value(QStringLiteral("prefix_path")).toString())) {
            e[QStringLiteral("prefix_path")] = *np;
            it.value() = e;
            regChanged = true;
        }
    }
    if (regChanged)
        prefixreg::saveRegistry(reg);

    // ~/wlm/compat/*/pfx links that pointed into the old folder.
    prefixlink::retargetCompatLinks(oldResolved, newResolved);
    return updated;
}

QStringList repointGames(const QString& runner, const QString& oldCode,
                         const QString& newCode, const QString& newPath)
{
    QJsonObject runnerCfg = runnerconfig::load();
    QStringList updated;
    bool changed = false;

    for (auto it = runnerCfg.begin(); it != runnerCfg.end(); ++it) {
        QJsonObject cfg = it.value().toObject();
        if (cfg.value(QStringLiteral("runner")).toString() != runner
            || cfg.value(QStringLiteral("prefix_code")).toString() != oldCode)
            continue;

        cfg[QStringLiteral("prefix_code")] = newCode;
        cfg[QStringLiteral("prefix_path")] = newPath;
        it.value() = cfg;
        changed = true;

        const QString scriptPath =
            paths::bashlaunch() + QLatin1Char('/') + it.key() + QStringLiteral(".sh");
        const QString folderStr = shortcut::extractFolderPath(scriptPath);
        const QString exeStr = shortcut::extractExePath(scriptPath);
        if (folderStr.isEmpty() || exeStr.isEmpty())
            continue;

        QFile f(scriptPath);
        if (f.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate)) {
            f.write(shortcut::buildScriptContent(folderStr, exeStr, cfg).toUtf8());
            f.close();
            QFile::setPermissions(scriptPath,
                                  QFileDevice::ReadOwner | QFileDevice::WriteOwner
                                      | QFileDevice::ExeOwner | QFileDevice::ReadGroup
                                      | QFileDevice::ExeGroup | QFileDevice::ReadOther
                                      | QFileDevice::ExeOther);
            updated.append(it.key());
        }
    }
    if (changed)
        runnerconfig::save(runnerCfg);
    return updated;
}

QString findProtonWineBinary(const QString& protonScriptPath)
{
    const QString root = QFileInfo(protonScriptPath).absolutePath();
    const QStringList candidates = {
        root + QStringLiteral("/files/bin/wine64"),
        root + QStringLiteral("/files/bin/wine"),
        root + QStringLiteral("/dist/bin/wine64"),
        root + QStringLiteral("/dist/bin/wine"),
    };
    for (const QString& c : candidates) {
        if (QFileInfo::exists(c))
            return c;
    }
    return QString();
}

QList<GameBackupInfo> gatherBackupInfo(const PrefixInfo& entry)
{
    const QString prefixResolved = canon(entry.path);

    QList<GameBackupInfo> out;
    for (const QString& scriptName : entry.games) {
        const QString scriptPath =
            paths::bashlaunch() + QLatin1Char('/') + scriptName + QStringLiteral(".sh");
        const QString folderStr = shortcut::extractFolderPath(scriptPath);
        const QString exeStr = shortcut::extractExePath(scriptPath);

        GameBackupInfo g;
        g.scriptName = scriptName;
        g.folderPath = folderStr;
        g.exePath = exeStr;

        if (!folderStr.isEmpty() && !exeStr.isEmpty()) {
            if (const auto rel = relativeUnder(canon(folderStr), canon(exeStr)))
                g.relativeExe = *rel;
        }

        if (!folderStr.isEmpty() && QFileInfo(folderStr).isDir()) {
            if (const auto rel = relativeUnder(prefixResolved, canon(folderStr))) {
                g.relativeToPrefix = *rel;
                g.insidePrefix = true;
            }
        }

        const RunnerChoice choice = runnerconfig::get(scriptName);
        g.launchOptions = choice.launchOptions;
        g.comment = choice.comment;
        g.iconPath = paths::icons() + QLatin1Char('/') + scriptName + QStringLiteral(".png");
        g.hasIcon = QFileInfo(g.iconPath).isFile();
        g.missing = !(!folderStr.isEmpty() && QFileInfo(folderStr).isDir());
        out.append(g);
    }
    return out;
}

qint64 computeTotalSize(const QStringList& paths)
{
    qint64 total = 0;
    for (const QString& p : paths) {
        if (p.isEmpty())
            continue;
        const QFileInfo fi(p);
        if (fi.isFile()) {
            total += fi.size();
        } else if (fi.isDir()) {
            QDirIterator it(p, QDir::Files | QDir::Hidden | QDir::NoDotAndDotDot,
                            QDirIterator::Subdirectories);
            while (it.hasNext()) {
                it.next();
                total += it.fileInfo().size();
            }
        }
    }
    return total;
}

QJsonObject readBackupManifest(const QString& archivePath, QString* error)
{
    QProcess proc;
    proc.setProgram(QStringLiteral("tar"));
    proc.setArguments({QStringLiteral("-xzf"), archivePath, QStringLiteral("-O"),
                       QStringLiteral("manifest.json")});
    proc.start();
    if (!proc.waitForFinished(60000)) {
        proc.kill();
        if (error)
            *error = QStringLiteral("Timed out reading the backup manifest.");
        return {};
    }
    if (proc.exitCode() != 0) {
        if (error)
            *error = QStringLiteral("manifest.json not found inside the archive.");
        return {};
    }
    QJsonParseError perr{};
    const QJsonDocument doc = QJsonDocument::fromJson(proc.readAllStandardOutput(), &perr);
    if (perr.error != QJsonParseError::NoError || !doc.isObject()) {
        if (error)
            *error = QStringLiteral("The backup manifest is not valid JSON.");
        return {};
    }
    return doc.object();
}

bool removePrefix(const PrefixInfo& entry, QStringList* removedInside, QString* error)
{
    // Determine which games live inside the prefix (their files get deleted too)
    // before removing any script.
    QStringList inside;
    for (const QString& name : entry.games) {
        const QString scriptPath =
            paths::bashlaunch() + QLatin1Char('/') + name + QStringLiteral(".sh");
        const QString folder = shortcut::extractFolderPath(scriptPath);
        if (!folder.isEmpty() && relativeUnder(canon(entry.path), canon(folder)).has_value())
            inside.append(name);
    }
    if (removedInside)
        *removedInside = inside;

    QDir prefixDir(entry.path);
    if (prefixDir.exists()) {
        if (!prefixDir.removeRecursively()) {
            if (error)
                *error = QStringLiteral("Failed to delete prefix folder: %1").arg(entry.path);
            return false;
        }
    }

    for (const QString& name : entry.games) {
        QFile::remove(paths::bashlaunch() + QLatin1Char('/') + name + QStringLiteral(".sh"));
        QFile::remove(paths::icons() + QLatin1Char('/') + name + QStringLiteral(".png"));
        runnerconfig::remove(name);
    }

    QJsonObject reg = prefixreg::loadRegistry();
    reg.remove(entry.key());
    prefixreg::saveRegistry(reg);
    return true;
}

} // namespace prefixops
