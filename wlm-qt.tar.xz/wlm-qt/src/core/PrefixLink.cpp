#include "core/PrefixLink.h"

#include "core/JsonIO.h"
#include "core/Paths.h"
#include "core/PrefixRegistry.h"
#include "core/RunnerConfig.h"

#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QJsonObject>

namespace prefixlink {

namespace {

bool isProton(const QString& runner)
{
    return runner == QLatin1String("protonge") || runner == QLatin1String("protoncachyos");
}

QString sanitizeCode(const QString& in)
{
    QString out;
    for (const QChar& c : in) {
        if (c.isLetterOrNumber() || c == QLatin1Char('_') || c == QLatin1Char('-'))
            out.append(c);
        else if (c == QLatin1Char(' ') || c == QLatin1Char('.'))
            out.append(QLatin1Char('_'));
    }
    while (out.startsWith(QLatin1Char('_')))
        out.remove(0, 1);
    return out;
}

// Is `child` equal to or inside `base`? Returns the relative part.
std::optional<QString> relativeUnder(const QString& base, const QString& child)
{
    const QString b = QDir::cleanPath(base);
    const QString c = QDir::cleanPath(child);
    if (c == b)
        return QString();
    if (c.startsWith(b + QLatin1Char('/')))
        return c.mid(b.size() + 1);
    return std::nullopt;
}

} // namespace

QString canonical(const QString& path)
{
    if (path.isEmpty())
        return {};
    const QString c = QFileInfo(path).canonicalFilePath();
    return c.isEmpty() ? QDir::cleanPath(QFileInfo(path).absoluteFilePath()) : c;
}

Kind classify(const QString& path)
{
    if (path.isEmpty() || !QFileInfo(path).isDir())
        return Kind::NotAPrefix;
    // QFileInfo::exists() follows symlinks, so a pfx -> /real/prefix link works.
    if (QFileInfo::exists(path + QStringLiteral("/drive_c")))
        return Kind::WinePrefix;
    if (QFileInfo::exists(path + QStringLiteral("/pfx/drive_c")))
        return Kind::ProtonCompat;
    return Kind::NotAPrefix;
}

QString winePrefixDir(const QString& anyPath)
{
    if (classify(anyPath) == Kind::ProtonCompat)
        return anyPath + QStringLiteral("/pfx");
    return anyPath;
}

std::optional<Detected> detectFromExe(const QString& exePath)
{
    QString cur = canonical(QFileInfo(exePath).absolutePath());
    while (!cur.isEmpty() && cur != QLatin1String("/")) {
        if (QFileInfo(cur).fileName().compare(QLatin1String("drive_c"), Qt::CaseInsensitive) == 0) {
            const QString parent = QFileInfo(cur).absolutePath();
            if (QFileInfo(parent).fileName() == QLatin1String("pfx")) {
                const QString grand = QFileInfo(parent).absolutePath();
                if (classify(grand) == Kind::ProtonCompat)
                    return Detected{Kind::ProtonCompat, grand};
            }
            if (classify(parent) == Kind::WinePrefix)
                return Detected{Kind::WinePrefix, parent};
        }
        const QString up = QFileInfo(cur).absolutePath();
        if (up == cur)
            break;
        cur = up;
    }
    return std::nullopt;
}

QString suggestCode(const QString& path)
{
    QString name = QFileInfo(QDir::cleanPath(path)).fileName();
    // A proton compat dir called "pfx" is named after its parent folder.
    if (name == QLatin1String("pfx"))
        name = QFileInfo(QFileInfo(path).absolutePath()).fileName();
    QString code = sanitizeCode(name);
    if (code.isEmpty())
        code = QStringLiteral("PREFIX");
    return code;
}

QString uniqueCode(const QString& runner, const QString& desired, const QString& physicalWineDir)
{
    const QJsonObject reg = prefixreg::loadRegistry();
    const QJsonObject games = runnerconfig::load();

    auto clash = [&](const QString& cand) {
        // Registry entry for this runner + code pointing to a different prefix?
        const QJsonObject e = reg.value(runner + QLatin1Char(':') + cand).toObject();
        if (!e.isEmpty()) {
            const QString p = e.value(QStringLiteral("prefix_path")).toString();
            if (!p.isEmpty() && canonical(winePrefixDir(p)) != physicalWineDir)
                return true;
        }
        // A game that already uses runner + code for a different prefix?
        for (auto it = games.constBegin(); it != games.constEnd(); ++it) {
            const QJsonObject g = it.value().toObject();
            if (g.value(QStringLiteral("runner")).toString() != runner
                || g.value(QStringLiteral("prefix_code")).toString() != cand)
                continue;
            const QString p = g.value(QStringLiteral("prefix_path")).toString();
            if (!p.isEmpty() && canonical(winePrefixDir(p)) != physicalWineDir)
                return true;
        }
        return false;
    };

    const QString base = desired.isEmpty() ? QStringLiteral("PREFIX") : desired;
    QString cand = base;
    for (int i = 2; clash(cand); ++i)
        cand = base + QLatin1Char('_') + QString::number(i);
    return cand;
}

QString pathForRunner(const QString& runner, const QString& anyPath, const QString& code,
                      QString* error)
{
    const Kind kind = classify(anyPath);

    if (!isProton(runner))
        return winePrefixDir(anyPath);

    // Proton: a compat dir (or a brand new folder) can be used directly.
    if (kind != Kind::WinePrefix)
        return anyPath;

    // Vanilla Wine prefix -> small compat dir whose "pfx" links to the real prefix.
    const QString target = canonical(anyPath);
    QString base = sanitizeCode(code);
    if (base.isEmpty())
        base = suggestCode(anyPath);

    QDir().mkpath(paths::compat());
    for (int i = 0; i < 1000; ++i) {
        const QString name = i == 0 ? base : base + QLatin1Char('_') + QString::number(i + 1);
        const QString dir = paths::compat() + QLatin1Char('/') + name;
        const QString link = dir + QStringLiteral("/pfx");
        const QFileInfo li(link);

        if (!QFileInfo::exists(dir)) {
            if (!QDir().mkpath(dir) || !QFile::link(target, link)) {
                if (error)
                    *error = QStringLiteral("Could not create link %1 -> %2").arg(link, target);
                return {};
            }
            return dir;
        }
        if (li.isSymLink()) {
            if (li.exists() && canonical(link) == target)
                return dir;           // already linked to this prefix
            if (!li.exists()) {       // dangling (prefix moved) -> repair
                QFile::remove(link);
                if (QFile::link(target, link))
                    return dir;
            }
        }
        // Real folder or link to another prefix: try the next name.
    }
    if (error)
        *error = QStringLiteral("Could not find a free compat folder under %1").arg(paths::compat());
    return {};
}

Resolved useExisting(const QString& runner, const QString& anyPath, const QString& preferredCode,
                     const QString& protonName, const QString& protonPath)
{
    Resolved r;
    if (!QFileInfo(anyPath).isDir()) {
        r.error = QStringLiteral("Prefix folder not found: %1").arg(anyPath);
        return r;
    }
    const QString wineCanon = canonical(winePrefixDir(anyPath));
    const QString wantedCode = preferredCode.isEmpty() ? suggestCode(anyPath) : preferredCode;
    r.code = uniqueCode(runner, wantedCode, wineCanon);

    QString err;
    r.path = pathForRunner(runner, anyPath, r.code, &err);
    if (r.path.isEmpty()) {
        r.error = err;
        return r;
    }
    prefixreg::recordPrefixUsage(runner, r.code, r.path, protonName, protonPath);
    r.ok = true;
    return r;
}

Resolved createNew(const QString& runner, const QString& path, const QString& preferredCode,
                   const QString& protonName, const QString& protonPath)
{
    Resolved r;
    if (!QDir().mkpath(path)) {
        r.error = QStringLiteral("Could not create folder: %1").arg(path);
        return r;
    }
    const QString wantedCode = preferredCode.isEmpty() ? suggestCode(path) : preferredCode;
    r.code = uniqueCode(runner, wantedCode, canonical(path));
    r.path = QDir::cleanPath(path);
    prefixreg::recordPrefixUsage(runner, r.code, r.path, protonName, protonPath);
    r.ok = true;
    return r;
}

void retargetCompatLinks(const QString& oldPath, const QString& newPath)
{
    const QString oldClean = QDir::cleanPath(oldPath);
    const QString newClean = QDir::cleanPath(newPath);

    const QDir compatDir(paths::compat());
    for (const QFileInfo& fi : compatDir.entryInfoList(QDir::Dirs | QDir::NoDotAndDotDot)) {
        const QString link = fi.filePath() + QStringLiteral("/pfx");
        const QFileInfo li(link);
        if (!li.isSymLink())
            continue;
        const QString cur = QDir::cleanPath(li.symLinkTarget());
        const auto rel = relativeUnder(oldClean, cur);
        if (!rel.has_value())
            continue;
        const QString next = rel->isEmpty() ? newClean : newClean + QLatin1Char('/') + *rel;
        QFile::remove(link);
        QFile::link(next, link);
    }
}

} // namespace prefixlink
