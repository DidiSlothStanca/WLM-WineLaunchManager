#pragma once

#include "core/Proton.h"
#include "core/RunnerConfig.h"

#include <QDialog>

#include <optional>

class QCheckBox;
class QComboBox;
class QLabel;
class QLineEdit;
class QRadioButton;
class QStackedWidget;

// Port of ask_runner_choice(): pick Wine / Proton GE / Proton-CachyOS, choose a
// prefix, and edit launch options + a comment. Executes as a modal dialog and
// exposes the resulting RunnerChoice via choice().
class RunnerDialog : public QDialog {
    Q_OBJECT
public:
    RunnerDialog(QWidget* parent, const QString& gameTitle, const QString& existingName,
                 bool forSetup = false);

    std::optional<RunnerChoice> choice() const { return m_choice; }

signals:
    // Emitted when the user clicks "Saves..." (only offered once the game has a
    // prefix, i.e. it has been launched before). The parent opens the non-modal
    // Save Manager on top of this dialog.
    void savesRequested();

private:
    // What the user picked for the prefix of one runner page.
    struct PrefixSel {
        enum Mode {
            Auto,        // keep the game's current prefix (shared across runners) or make a new default one
            UseExisting, // use an existing prefix folder picked with Browse
            CreateNew,   // create a new prefix at `path`
        };
        Mode mode = Auto;
        QString path;
        QString code;
    };

    void buildUi();
    void updateRunnerPage();
    void browsePrefix(int idx);
    void useDefaultPrefix(int idx);
    void acceptChoice();

    bool hasExistingPrefix() const;
    bool keepExistingPrefix() const;

    // Resolve (and create/register/link) the prefix for runner page `idx`.
    // Never copies or overwrites the content of an existing prefix.
    bool resolvePrefix(int idx, const Proton::Build& build, QString* code, QString* path,
                       QString* error);
    QString infoTextFor(int idx) const;

    static QString runnerKeyAt(int idx);

    QString m_existingName;
    QString m_gameTitle;
    bool m_forSetup = false;
    std::optional<RunnerChoice> m_choice;
    RunnerChoice m_existing;

    QList<Proton::Build> m_geBuilds;
    QList<Proton::Build> m_cachyBuilds;

    QRadioButton* m_wineRadio = nullptr;
    QRadioButton* m_geRadio = nullptr;
    QRadioButton* m_cachyRadio = nullptr;
    QStackedWidget* m_pages = nullptr;

    // Wine page
    QCheckBox* m_wineUsePrefix = nullptr;

    // Proton pages
    QComboBox* m_geCombo = nullptr;
    QComboBox* m_cachyCombo = nullptr;

    // One info label per runner page: 0 = wine, 1 = Proton GE, 2 = Proton-CachyOS.
    QLabel* m_info[3] = {nullptr, nullptr, nullptr};
    PrefixSel m_sel[3];

    // Keep the game's current prefix when the runner / Proton build changes.
    QCheckBox* m_keepPrefix = nullptr;

    QLineEdit* m_launchOptions = nullptr;
    QLineEdit* m_comment = nullptr;
};
