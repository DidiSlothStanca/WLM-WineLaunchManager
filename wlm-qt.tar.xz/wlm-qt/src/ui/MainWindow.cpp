#include "ui/MainWindow.h"

#include "core/AppConfig.h"
#include "core/CoverFetcher.h"
#include "core/CoverStore.h"
#include "core/GameLauncher.h"
#include "core/Paths.h"
#include "core/PrefixOps.h"
#include "core/PrefixRegistry.h"
#include "core/ProcessUtils.h"
#include "core/Proton.h"
#include "core/RunnerConfig.h"
#include "core/Shortcut.h"
#include "core/ThemeManager.h"
#include "core/Version.h"
#include "ui/GogStoreDialog.h"
#include "ui/DownloadManagerDialog.h"
#include "ui/HudConfigDialog.h"
#include "ui/LibraryGrid.h"
#include "ui/LogWindow.h"
#include "ui/AddShortcutDialog.h"
#include "ui/PrefixPicker.h"
#include "ui/PrefixManagerDialog.h"
#include "ui/ProtonDownloadDialog.h"
#include "ui/RunnerDialog.h"
#include "ui/SaveManagerDialog.h"
#include "ui/TaskLogWindow.h"

#include "core/ArchiveExtractor.h"
#include "core/PrefixLink.h"
#include "core/SetupRunner.h"

#include <QAbstractAnimation>
#include <QCloseEvent>
#include <QComboBox>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QFormLayout>
#include <QFrame>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QIcon>
#include <QImage>
#include <QInputDialog>
#include <QIntValidator>
#include <QKeyEvent>
#include <QLabel>
#include <QLineEdit>
#include <QMessageBox>
#include <QMouseEvent>
#include <QPainter>
#include <QPainterPath>
#include <QPixmap>
#include <QPropertyAnimation>
#include <QProcess>
#include <QPushButton>
#include <QScrollArea>
#include <QEasingCurve>
#include <QShowEvent>
#include <QSignalBlocker>
#include <QSlider>
#include <QSplitter>
#include <QStackedWidget>
#include <QStyle>
#include <QTimer>
#include <QToolButton>
#include <QTreeWidget>
#include <QVBoxLayout>
#include <QWidget>
#include <QResizeEvent>
#include <QMenu>
#include <QQueue>
#include <QDesktopServices>

#include <algorithm>
#include <functional>

namespace {

constexpr int kIconSize = 250;   // stored icon size (px)
constexpr int kIconWidth = 190;  // displayed size in the detail panel
constexpr int kIconHeight = 190;

QLabel* mutedLabel(const QString& text)
{
    auto* l = new QLabel(text);
    l->setProperty("muted", true);
    return l;
}

QPushButton* makeButton(const QString& text, const QString& objectName = {})
{
    auto* b = new QPushButton(text);
    if (!objectName.isEmpty())
        b->setObjectName(objectName);
    b->setCursor(Qt::PointingHandCursor);
    return b;
}

// Crop pixmap to 1:1 (square), centered.
static QPixmap cropToSquare(const QPixmap& src)
{
    if (src.isNull())
        return src;
    const int size = qMin(src.width(), src.height());
    const int cropX = (src.width() - size) / 2;
    const int cropY = (src.height() - size) / 2;
    return src.copy(cropX, cropY, size, size);
}

QPixmap roundedPixmap(const QPixmap& src, int radius)
{
    if (src.isNull())
        return src;
    QPixmap out(src.size());
    out.fill(Qt::transparent);
    QPainter painter(&out);
    painter.setRenderHint(QPainter::Antialiasing, true);
    QPainterPath path;
    path.addRoundedRect(QRectF(0, 0, src.width(), src.height()), radius, radius);
    painter.setClipPath(path);
    painter.drawPixmap(0, 0, src);
    return out;
}

// xdg-open a folder using a clean child environment.
bool openInFileManager(const QString& path)
{
    QProcess p;
    p.setProgram(QStringLiteral("xdg-open"));
    p.setArguments({path});
    p.setProcessEnvironment(procutil::cleanEnvironment());
    return p.startDetached();
}

QString humanSize(qint64 bytes)
{
    const double kb = bytes / 1024.0;
    const double mb = kb / 1024.0;
    if (mb > 1)
        return QStringLiteral("%1 MB").arg(mb, 0, 'f', 2);
    if (kb > 1)
        return QStringLiteral("%1 KB").arg(kb, 0, 'f', 2);
    return QStringLiteral("%1 bytes").arg(bytes);
}

} // namespace

MainWindow::MainWindow(AppConfig& config, ThemeManager* theme, QWidget* parent)
    : QMainWindow(parent)
    , m_config(config)
    , m_theme(theme)
    , m_launcher(new GameLauncher(this))
{
    setWindowTitle(QStringLiteral("Wine Launch Manager %1").arg(WLM_VERSION));
    setMinimumSize(720, 480);

    m_coverStore = new covers::CoverStore(paths::root());
    m_coverFetcher = new CoverFetcher(m_coverStore, this);
    {
        const covers::ViewConfig cfg = covers::loadViewConfig(paths::libraryViewConfig());
        m_viewMode = cfg.view;
        m_cardWidth = cfg.cardWidth;
    }

    buildUi();
    restoreGeometryFromConfig();
    refreshList(false);
    setViewMode(m_viewMode);

    connect(m_theme, &ThemeManager::themeChanged, this, [this](const QString&) {
        if (m_libraryGrid)
            m_libraryGrid->setTheme(m_theme->current());
    });

    m_saveTimer = new QTimer(this);
    m_saveTimer->setSingleShot(true);
    m_saveTimer->setInterval(600);
    connect(m_saveTimer, &QTimer::timeout, this, &MainWindow::persistWindow);

    updateDetail();
}

MainWindow::~MainWindow()
{
    delete m_coverStore;
}

void MainWindow::buildUi()
{
    auto* central = new QWidget(this);
    auto* rootLayout = new QVBoxLayout(central);
    rootLayout->setContentsMargins(0, 0, 0, 0);
    rootLayout->setSpacing(0);

    // ---- Header -----------------------------------------------------------
    auto* header = new QFrame;
    header->setObjectName(QStringLiteral("Toolbar"));
    auto* headerLayout = new QHBoxLayout(header);
    headerLayout->setContentsMargins(16, 10, 16, 10);
    headerLayout->setSpacing(10);

    m_menuBtn = new QToolButton;
    m_menuBtn->setObjectName(QStringLiteral("MenuToggle"));
    m_menuBtn->setText(QStringLiteral("\u2630"));
    m_menuBtn->setToolTip(tr("Menu"));
    m_menuBtn->setCursor(Qt::PointingHandCursor);
    m_menuBtn->setCheckable(true);
    m_menuBtn->setMinimumSize(QSize(44, 44));
    m_menuBtn->setIconSize(QSize(28, 28));
    connect(m_menuBtn, &QToolButton::clicked, this, &MainWindow::toggleSidePanel);
    headerLayout->addWidget(m_menuBtn);

    auto* title = new QLabel(QStringLiteral("Wine Launch Manager"));
    QFont tf = title->font();
    tf.setPointSize(tf.pointSize() + 4);
    tf.setBold(true);
    title->setFont(tf);
    headerLayout->addWidget(title);
    headerLayout->addStretch(1);
    rootLayout->addWidget(header);

    // ---- Toolbar ----------------------------------------------------------
    auto* toolbar = new QFrame;
    toolbar->setObjectName(QStringLiteral("Toolbar"));
    auto* toolbarLayout = new QHBoxLayout(toolbar);
    toolbarLayout->setContentsMargins(16, 10, 16, 4);
    toolbarLayout->setSpacing(8);

    m_search = new QLineEdit;
    m_search->setPlaceholderText(QStringLiteral("Search games...   (Ctrl+F)"));
    m_search->setClearButtonEnabled(true);
    m_search->setMinimumWidth(320);
    toolbarLayout->addWidget(m_search);
    toolbarLayout->addStretch(1);
    // Refresh button (icon + "Refresh" label), sits to the LEFT of "GOG Store".
    auto* refreshButton = makeButton(tr("Refresh"));
    refreshButton->setIcon(style()->standardIcon(QStyle::SP_BrowserReload));
    refreshButton->setIconSize(QSize(16, 16));
    refreshButton->setToolTip(tr("Refresh List"));
    connect(refreshButton, &QPushButton::clicked, this, [this] { refreshList(); });
    toolbarLayout->addWidget(refreshButton);

    toolbarLayout->addWidget(makeButton(QStringLiteral("GOG Store")));
    toolbarLayout->addWidget(makeButton(QStringLiteral("Install Apps")));
    toolbarLayout->addWidget(makeButton(QStringLiteral("+  Add Game"), QStringLiteral("Accent")));
    rootLayout->addWidget(toolbar);

    // Wire toolbar buttons (created above via makeButton without refs; find them).
    const QList<QPushButton*> toolbarButtons = toolbar->findChildren<QPushButton*>();
    for (QPushButton* b : toolbarButtons) {
        if (b->text().contains(QStringLiteral("Add Game")))
            connect(b, &QPushButton::clicked, this, &MainWindow::addGame);
        else if (b->text() == QLatin1String("Install Apps"))
            connect(b, &QPushButton::clicked, this, &MainWindow::installApps);
        else if (b->text() == QLatin1String("GOG Store"))
            connect(b, &QPushButton::clicked, this, &MainWindow::openGogStore);
    }

    // ---- Split view -------------------------------------------------------
    m_splitter = new QSplitter(Qt::Horizontal);
    m_splitter->setChildrenCollapsible(false);
    m_splitter->setHandleWidth(6);
    m_splitter->addWidget(buildLibraryPanel());
    m_splitter->addWidget(buildDetailPanel());
    m_splitter->setStretchFactor(0, 3);
    m_splitter->setStretchFactor(1, 2);
    connect(m_splitter, &QSplitter::splitterMoved, this, &MainWindow::onSplitterMoved);
    rootLayout->addWidget(m_splitter, 1);

    rootLayout->addWidget(buildFooter());

    setCentralWidget(central);

    buildSidePanel(central);

    m_searchTimer = new QTimer(this);
    m_searchTimer->setSingleShot(true);
    m_searchTimer->setInterval(150);
    connect(m_searchTimer, &QTimer::timeout, this, [this] { refreshList(true); });
    connect(m_search, &QLineEdit::textChanged, this, [this] { m_searchTimer->start(); });
}

void MainWindow::buildSidePanel(QWidget* central)
{
    // Scrim: semi-transparent overlay behind the panel; clicking it closes the panel.
    m_sideScrim = new QWidget(central);
    m_sideScrim->setObjectName(QStringLiteral("SideScrim"));
    m_sideScrim->setAttribute(Qt::WA_StyledBackground, true);
    m_sideScrim->hide();
    m_sideScrim->installEventFilter(this);

    // Panel: sliding drawer docked to the left edge. Its width follows the UI
    // zoom so menu entries keep fitting when text is enlarged.
    m_sidePanel = new QFrame(central);
    m_sidePanel->setObjectName(QStringLiteral("SidePanel"));
    m_sidePanel->setFixedWidth(qRound(280.0 * m_theme->fontScalePercent() / 100.0));
    m_sidePanel->hide();
    m_sidePanel->installEventFilter(this);

    // The menu contents live inside a scroll area so every entry (including the
    // zoom slider) stays reachable even when the UI is enlarged.
    auto* scroll = new QScrollArea(m_sidePanel);
    scroll->setObjectName(QStringLiteral("SideScroll"));
    scroll->setWidgetResizable(true);
    scroll->setFrameShape(QFrame::NoFrame);
    scroll->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    scroll->viewport()->setAutoFillBackground(false);

    auto* content = new QWidget;
    content->setObjectName(QStringLiteral("SideScrollContent"));
    auto* lay = new QVBoxLayout(content);
    lay->setContentsMargins(14, 16, 14, 16);
    lay->setSpacing(2);
    scroll->setWidget(content);

    auto* panelLay = new QVBoxLayout(m_sidePanel);
    panelLay->setContentsMargins(0, 0, 0, 0);
    panelLay->setSpacing(0);
    panelLay->addWidget(scroll);

    auto* title = new QLabel(tr("Menu"));
    QFont tf = title->font();
    tf.setBold(true);
    tf.setPointSize(tf.pointSize() + 1);
    title->setFont(tf);
    title->setObjectName(QStringLiteral("SideTitle"));
    lay->addWidget(title);
    lay->addSpacing(10);

    auto addSection = [lay](const QString& text) {
        auto* s = new QLabel(text);
        s->setObjectName(QStringLiteral("SideSection"));
        s->setContentsMargins(0, 8, 0, 2);
        lay->addWidget(s);
    };

    auto addItem = [this, lay](const QString& text, const std::function<void()>& fn) {
        auto* b = makeButton(text, QStringLiteral("SideItem"));
        b->setAutoDefault(false);
        b->setDefault(false);
        connect(b, &QPushButton::clicked, this, [this, fn] {
            if (fn)
                fn();
            hideSidePanel();
        });
        lay->addWidget(b);
        m_sideItems.append(b);
    };

    addSection(tr("LOGS & PREFIX"));
    addItem(tr("View Logs"), [this] { viewLogs(); });
    addItem(tr("Prefix Configuration Manager..."),
            [this] { openPrefixManager(); });

    addSection(tr("WINE"));
    addItem(tr("Wine Configuration (winecfg)"), [this] {
        QProcess p;
        p.setProgram(QStringLiteral("winecfg"));
        p.setProcessEnvironment(procutil::cleanEnvironment());
        if (p.startDetached())
            setStatus(tr("Opening Wine Configuration..."),
                      m_theme->current().textSecondary.name());
        else
            setStatus(tr("Error: Wine command not found."),
                      m_theme->current().danger.name());
    });
    addItem(tr("Open Wine Prefix Folder"), [this] {
        QString prefix = qEnvironmentVariable("WINEPREFIX");
        if (prefix.isEmpty())
            prefix = QDir::homePath() + QStringLiteral("/.wine");
        if (QFileInfo(prefix).isDir())
            openInFileManager(prefix);
        else
            setStatus(tr("Wine Prefix folder not found: %1").arg(prefix),
                      m_theme->current().danger.name());
    });

    addSection(tr("PROTON GE"));
    addItem(tr("Extract Proton GE Archive..."),
            [this] { extractProtonArchive(false); });
    addItem(tr("Download ProtonGE Online..."),
            [this] { openProtonDownload(false); });
    addItem(tr("Open Proton GE Folder"), [this] {
        openInFileManager(paths::protonGE());
    });

    addSection(tr("PROTON-CACHYOS"));
    addItem(tr("Extract Proton-CachyOS Archive..."),
            [this] { extractProtonArchive(true); });
    addItem(tr("Download Proton-CachyOS Online..."),
            [this] { openProtonDownload(true); });
    addItem(tr("Open Proton-CachyOS Folder"), [this] {
        openInFileManager(paths::protonCachyOS());
    });

    // Live UI zoom: drag the slider or type a percentage to resize the whole
    // interface (10-200%).
    addSection(tr("RESIZE SCREEN"));
    auto* zoomRow = new QWidget(content);
    auto* zoomRowLayout = new QHBoxLayout(zoomRow);
    zoomRowLayout->setContentsMargins(4, 0, 4, 6);
    zoomRowLayout->setSpacing(8);

    m_zoomSlider = new QSlider(Qt::Horizontal, zoomRow);
    m_zoomSlider->setRange(10, 200);
    m_zoomSlider->setValue(m_theme->fontScalePercent());
    m_zoomSlider->setSingleStep(5);
    m_zoomSlider->setPageStep(10);
    m_zoomSlider->setToolTip(tr("Resize the interface (10-200%)"));

    m_zoomEdit = new QLineEdit(zoomRow);
    m_zoomEdit->setObjectName(QStringLiteral("ZoomInput"));
    m_zoomEdit->setValidator(new QIntValidator(10, 200, m_zoomEdit));
    m_zoomEdit->setText(QString::number(m_theme->fontScalePercent()));
    m_zoomEdit->setFixedWidth(48);
    m_zoomEdit->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
    m_zoomEdit->setToolTip(tr("Type a percentage (10-200) and press Enter"));

    auto* zoomPercent = new QLabel(QStringLiteral("%"), zoomRow);
    zoomPercent->setProperty("muted", true);

    zoomRowLayout->addWidget(m_zoomSlider, 1);
    zoomRowLayout->addWidget(m_zoomEdit);
    zoomRowLayout->addWidget(zoomPercent);
    lay->addWidget(zoomRow);

    connect(m_zoomSlider, &QSlider::valueChanged, this, &MainWindow::applyZoomPercent);
    // Commit typed values on Enter or when the field loses focus.
    connect(m_zoomEdit, &QLineEdit::editingFinished, this, [this] {
        if (m_zoomEdit)
            applyZoomPercent(m_zoomEdit->text().toInt());
    });

    lay->addStretch(1);

    auto* version = mutedLabel(QStringLiteral("WLM-Qt V.%1").arg(WLM_VERSION));
    lay->addWidget(version);
    auto* devLabel = mutedLabel(QStringLiteral("%1\n%2")
                                    .arg(QLatin1String(WLM_DEVELOPER),
                                         QLatin1String(WLM_DEVELOPER_ABBR)));
    QFont df = devLabel->font();
    df.setPointSize(df.pointSize() - 1);
    devLabel->setFont(df);
    lay->addWidget(devLabel);
}

void MainWindow::toggleSidePanel()
{
    if (m_sideVisible)
        hideSidePanel();
    else
        showSidePanel();
}

void MainWindow::showSidePanel()
{
    if (!m_sidePanel || !m_sideScrim || m_sideVisible)
        return;
    QWidget* central = centralWidget();
    if (!central)
        return;

    m_sideScrim->setGeometry(central->rect());
    m_sideScrim->show();
    m_sideScrim->raise();

    const int w = m_sidePanel->width();
    const int h = central->height();
    m_sidePanel->setGeometry(QRect(-w, 0, w, h));
    m_sidePanel->show();
    m_sidePanel->raise();

    auto* anim = new QPropertyAnimation(m_sidePanel, "geometry", this);
    anim->setDuration(200);
    anim->setEasingCurve(QEasingCurve::OutCubic);
    anim->setStartValue(QRect(-w, 0, w, h));
    anim->setEndValue(QRect(0, 0, w, h));
    anim->start(QAbstractAnimation::DeleteWhenStopped);

    m_sideVisible = true;
    if (m_menuBtn)
        m_menuBtn->setChecked(true);
    m_sidePanel->setFocus(Qt::PopupFocusReason);
}

void MainWindow::hideSidePanel()
{
    if (!m_sidePanel || !m_sideScrim || !m_sideVisible)
        return;
    const QRect g = m_sidePanel->geometry();
    auto* anim = new QPropertyAnimation(m_sidePanel, "geometry", this);
    anim->setDuration(160);
    anim->setEasingCurve(QEasingCurve::InCubic);
    anim->setStartValue(g);
    anim->setEndValue(QRect(-g.width(), g.y(), g.width(), g.height()));
    connect(anim, &QPropertyAnimation::finished, this, [this] {
        m_sidePanel->hide();
        m_sideScrim->hide();
    });
    anim->start(QAbstractAnimation::DeleteWhenStopped);

    m_sideVisible = false;
    if (m_menuBtn)
        m_menuBtn->setChecked(false);
}

void MainWindow::applyZoomPercent(int percent)
{
    const int value = qBound(10, percent, 200);
    m_theme->setFontScalePercent(value);
    if (m_sidePanel)
        m_sidePanel->setFixedWidth(qRound(280.0 * value / 100.0));
    if (m_libraryGrid)
        m_libraryGrid->setScale(value / 100.0);

    // Keep the slider and the text box in sync without recursion.
    if (m_zoomSlider && m_zoomSlider->value() != value) {
        const QSignalBlocker block(m_zoomSlider);
        m_zoomSlider->setValue(value);
    }
    if (m_zoomEdit && m_zoomEdit->text().toInt() != value) {
        const QSignalBlocker block(m_zoomEdit);
        m_zoomEdit->setText(QString::number(value));
    }

    WindowGeometry g = m_config.window();
    g.zoom = value;
    m_config.setWindow(g);
    if (m_saveTimer)
        m_saveTimer->start();
}

QWidget* MainWindow::buildLibraryPanel()
{
    auto* panel = new QWidget;
    auto* layout = new QVBoxLayout(panel);
    layout->setContentsMargins(16, 12, 8, 14);
    layout->setSpacing(8);

    auto* controls = new QHBoxLayout;
    auto* heading = new QLabel(QStringLiteral("Library"));
    QFont hf = heading->font();
    hf.setPointSize(hf.pointSize() + 1);
    hf.setBold(true);
    heading->setFont(hf);
    controls->addWidget(heading);

    m_countLabel = mutedLabel(QString());
    controls->addWidget(m_countLabel);
    controls->addStretch(1);

    controls->addWidget(mutedLabel(QStringLiteral("Sort")));
    m_sortCombo = new QComboBox;
    m_sortCombo->addItems({QStringLiteral("A-Z"), QStringLiteral("Z-A")});
    m_sortCombo->setFixedWidth(70);
    connect(m_sortCombo, &QComboBox::currentIndexChanged, this,
            [this] { onSortChanged(); });
    controls->addWidget(m_sortCombo);

    m_gridBtn = makeButton(QStringLiteral("Grid"));
    m_listBtn = makeButton(QStringLiteral("List"));
    m_gridBtn->setCheckable(true);
    m_listBtn->setCheckable(true);
    connect(m_gridBtn, &QPushButton::clicked, this, [this] { setViewMode(QStringLiteral("grid")); });
    connect(m_listBtn, &QPushButton::clicked, this, [this] { setViewMode(QStringLiteral("list")); });
    controls->addWidget(m_gridBtn);
    controls->addWidget(m_listBtn);
    layout->addLayout(controls);

    // Card-size row: only shown in Grid mode.
    m_viewFrame = new QWidget;
    auto* viewRow = new QHBoxLayout(m_viewFrame);
    viewRow->setContentsMargins(0, 0, 0, 0);
    viewRow->setSpacing(8);
    viewRow->addWidget(mutedLabel(QStringLiteral("Card size")));
    m_sizeCombo = new QComboBox;
    m_sizeCombo->addItems(covers::cardSizes().keys());
    for (auto it = covers::cardSizes().constBegin(); it != covers::cardSizes().constEnd(); ++it) {
        if (it.value() == m_cardWidth) {
            m_sizeCombo->setCurrentText(it.key());
            break;
        }
    }
    connect(m_sizeCombo, &QComboBox::currentTextChanged, this,
            [this] { onCardSizeChanged(); });
    viewRow->addWidget(m_sizeCombo);
    viewRow->addStretch(1);
    auto* fetchBtn = makeButton(QStringLiteral("Fetch Covers"));
    connect(fetchBtn, &QPushButton::clicked, this, &MainWindow::fetchCovers);
    viewRow->addWidget(fetchBtn);
    layout->addWidget(m_viewFrame);

    // List (tree) and Grid are stacked so switching is instant.
    m_libraryStack = new QStackedWidget;

    m_tree = new QTreeWidget;
    m_tree->setColumnCount(3);
    m_tree->setHeaderLabels({QStringLiteral("#"), QStringLiteral("GAME"), QStringLiteral("SOURCE")});
    m_tree->setRootIsDecorated(false);
    m_tree->setAllColumnsShowFocus(true);
    m_tree->setUniformRowHeights(true);
    // Responsive columns: "#" and "SOURCE" size to their content while "GAME"
    // stretches to fill the remaining width, so the table follows the window.
    QHeaderView* treeHeader = m_tree->header();
    treeHeader->setStretchLastSection(false);
    treeHeader->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    treeHeader->setSectionResizeMode(1, QHeaderView::Stretch);
    treeHeader->setSectionResizeMode(2, QHeaderView::ResizeToContents);
    treeHeader->setMinimumSectionSize(40);
    m_tree->setSelectionMode(QAbstractItemView::SingleSelection);
    connect(m_tree, &QTreeWidget::currentItemChanged, this,
            [this](QTreeWidgetItem*, QTreeWidgetItem*) { onSelectionChanged(); });
    connect(m_tree, &QTreeWidget::itemDoubleClicked, this,
            [this](QTreeWidgetItem*, int) { play(); });
    m_libraryStack->addWidget(m_tree);

    m_libraryGrid = new LibraryGrid(m_coverStore, m_coverFetcher, this);
    m_libraryGrid->setCardWidth(m_cardWidth);
    m_libraryGrid->setScale(m_theme->fontScalePercent() / 100.0);
    m_libraryGrid->setTheme(m_theme->current());
    m_libraryGrid->setSourceOf(
        [this](const QString& n) { return runnerconfig::gameSource(n).source; });
    connect(m_libraryGrid, &LibraryGrid::selected, this,
            [this](const QString& name) { selectName(name); });
    connect(m_libraryGrid, &LibraryGrid::deselected, this, [this] {
        {
            const QSignalBlocker blocker(m_tree);
            m_tree->setCurrentItem(nullptr);
            m_tree->clearSelection();
        }
        updateDetail();
    });
    connect(m_libraryGrid, &LibraryGrid::activated, this, [this](const QString&) { play(); });
    connect(m_libraryGrid, &LibraryGrid::statusMessage, this,
            [this](const QString& text, const QString& color) { setStatus(text, color); });
    connect(m_libraryGrid, &LibraryGrid::uninstallRequested, this,
            [this](const QString& name) {
                // Use the existing removeGame logic but with the specific name
                const auto choice = QMessageBox::question(
                    this, tr("Confirm"), tr("Are you sure you want to uninstall '%1'?").arg(name));
                if (choice != QMessageBox::Yes)
                    return;

                QFile::remove(paths::bashlaunch() + QLatin1Char('/') + name + QStringLiteral(".sh"));
                QFile::remove(paths::icons() + QLatin1Char('/') + name + QStringLiteral(".png"));
                runnerconfig::remove(name);
                if (m_coverStore)
                    m_coverStore->forget(name);

                refreshList(false);
                m_titleLabel->setText(QStringLiteral("No Game Selected"));
                m_iconLabel->setPixmap(QPixmap());
                m_iconLabel->setText(QStringLiteral("No cover"));
                setStatus(tr("Uninstalled: %1").arg(name), m_theme->current().warning.name());
            });
    m_libraryStack->addWidget(m_libraryGrid);

    layout->addWidget(m_libraryStack, 1);

    return panel;
}

QWidget* MainWindow::buildDetailPanel()
{
    auto* panel = new QWidget;
    auto* layout = new QVBoxLayout(panel);
    layout->setContentsMargins(8, 12, 16, 14);
    layout->setSpacing(12);

    auto* card = new QFrame;
    card->setObjectName(QStringLiteral("Card"));
    auto* cardLayout = new QVBoxLayout(card);
    cardLayout->setContentsMargins(16, 16, 16, 16);
    cardLayout->setSpacing(10);

    m_iconLabel = new QLabel(QStringLiteral("No cover"));
    m_iconLabel->setAlignment(Qt::AlignCenter);
    m_iconLabel->setFixedSize(kIconWidth, kIconHeight);
    m_iconLabel->setProperty("muted", true);
    m_iconLabel->setProperty("cover", false);
    m_iconLabel->setContextMenuPolicy(Qt::CustomContextMenu);
    m_iconLabel->setObjectName(QStringLiteral("CoverLabel"));
    connect(m_iconLabel, &QLabel::customContextMenuRequested, this, &MainWindow::showCoverContextMenu);
    cardLayout->addWidget(m_iconLabel, 0, Qt::AlignHCenter);

    m_titleLabel = new QLabel(QStringLiteral("No Game Selected"));
    m_titleLabel->setAlignment(Qt::AlignCenter);
    m_titleLabel->setWordWrap(true);
    QFont titleFont = m_titleLabel->font();
    titleFont.setPointSize(titleFont.pointSize() + 3);
    titleFont.setBold(true);
    m_titleLabel->setFont(titleFont);
    cardLayout->addWidget(m_titleLabel);

    auto* infoForm = new QFormLayout;
    infoForm->setLabelAlignment(Qt::AlignLeft);
    infoForm->setFormAlignment(Qt::AlignLeft | Qt::AlignTop);
    auto makeValue = [] {
        auto* l = new QLabel(QStringLiteral("-"));
        l->setWordWrap(true);
        return l;
    };
    m_sourceValue = makeValue();
    m_locationValue = makeValue();
    m_modifiedValue = makeValue();
    m_sizeValue = makeValue();
    infoForm->addRow(mutedLabel(QStringLiteral("Source")), m_sourceValue);
    infoForm->addRow(mutedLabel(QStringLiteral("Location")), m_locationValue);
    infoForm->addRow(mutedLabel(QStringLiteral("Modified")), m_modifiedValue);
    infoForm->addRow(mutedLabel(QStringLiteral("Size")), m_sizeValue);
    cardLayout->addLayout(infoForm);
    cardLayout->addStretch(1);
    layout->addWidget(card, 1);

    // Launch row
    auto* launchRow = new QHBoxLayout;
    launchRow->addWidget(mutedLabel(QStringLiteral("Launch")));
    m_launchMode = new QComboBox;
    m_launchMode->addItems({QStringLiteral("Normal"), QStringLiteral("GalliumHUD"),
                            QStringLiteral("VulkanHUD"), QStringLiteral("MangoHud-GL"),
                            QStringLiteral("Mangohud")});
    launchRow->addWidget(m_launchMode, 1);
    auto* hudBtn = makeButton(QStringLiteral("Config HUD"));
    connect(hudBtn, &QPushButton::clicked, this, &MainWindow::openHudConfig);
    launchRow->addWidget(hudBtn);
    layout->addLayout(launchRow);

    auto* playBtn = makeButton(QStringLiteral("\u25B6  Play"), QStringLiteral("Accent"));
    playBtn->setMinimumHeight(38);
    connect(playBtn, &QPushButton::clicked, this, &MainWindow::play);
    layout->addWidget(playBtn);
    m_actionButtons.append(playBtn);

    auto* actionRow = new QHBoxLayout;
    auto* renameBtn = makeButton(QStringLiteral("Rename"));
    auto* iconBtn = makeButton(QStringLiteral("Icon"));
    auto* folderBtn = makeButton(QStringLiteral("Folder"));
    auto* logsBtn = makeButton(QStringLiteral("Logs"));
    auto* removeBtn = makeButton(QStringLiteral("Remove"), QStringLiteral("Danger"));
    connect(renameBtn, &QPushButton::clicked, this, &MainWindow::renameGame);
    connect(iconBtn, &QPushButton::clicked, this, &MainWindow::changeIcon);
    connect(folderBtn, &QPushButton::clicked, this, &MainWindow::openFolder);
    connect(logsBtn, &QPushButton::clicked, this, &MainWindow::viewLogs);
    connect(removeBtn, &QPushButton::clicked, this, &MainWindow::removeGame);
    actionRow->addWidget(renameBtn);
    actionRow->addWidget(iconBtn);
    actionRow->addWidget(folderBtn);
    actionRow->addWidget(logsBtn);
    actionRow->addWidget(removeBtn);
    layout->addLayout(actionRow);
    m_actionButtons << renameBtn << iconBtn << folderBtn << logsBtn << removeBtn;

    return panel;
}

QWidget* MainWindow::buildFooter()
{
    auto* footer = new QFrame;
    footer->setObjectName(QStringLiteral("Footer"));
    auto* layout = new QHBoxLayout(footer);
    layout->setContentsMargins(16, 6, 16, 6);
    layout->setSpacing(8);

    m_status = mutedLabel(QStringLiteral("Ready"));
    layout->addWidget(m_status, 1);

    layout->addWidget(mutedLabel(QStringLiteral("Theme")));
    m_themeCombo = new QComboBox;
    for (const Theme& t : ThemeManager::themes())
        m_themeCombo->addItem(t.name, t.id);
    const int idx = m_themeCombo->findData(m_config.theme());
    m_themeCombo->setCurrentIndex(idx >= 0 ? idx : 0);
    connect(m_themeCombo, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, &MainWindow::onThemeSelected);
    layout->addWidget(m_themeCombo);

    return footer;
}

void MainWindow::refreshList(bool keepSelection)
{
    const QString previous = keepSelection ? currentName() : QString();

    QStringList names;
    QDir dir(paths::bashlaunch());
    const QStringList files = dir.entryList({QStringLiteral("*.sh")}, QDir::Files);
    for (const QString& f : files)
        names << QFileInfo(f).completeBaseName();

    std::sort(names.begin(), names.end(), [](const QString& a, const QString& b) {
        return a.compare(b, Qt::CaseInsensitive) < 0;
    });

    const int total = names.size();
    const QString query = m_search ? m_search->text().trimmed().toLower() : QString();
    if (!query.isEmpty())
        names.erase(std::remove_if(names.begin(), names.end(),
                                   [&query](const QString& n) {
                                       return !n.toLower().contains(query);
                                   }),
                    names.end());

    if (m_sortCombo && m_sortCombo->currentText() == QLatin1String("Z-A"))
        std::reverse(names.begin(), names.end());

    {
        const QSignalBlocker blocker(m_tree);
        m_tree->clear();
        int index = 1;
        for (const QString& name : names) {
            const runnerconfig::GameSource src = runnerconfig::gameSource(name);
            const QString sourceLabel = src.source == QLatin1String("gog")
                ? QStringLiteral("GOG") : QStringLiteral("Non-GOG");
            auto* item = new QTreeWidgetItem(m_tree);
            item->setText(0, QString::number(index++));
            item->setText(1, name);
            item->setText(2, sourceLabel);
            item->setTextAlignment(0, Qt::AlignCenter);
            item->setTextAlignment(2, Qt::AlignCenter);
            item->setData(1, Qt::UserRole, name);
        }
    }

    if (m_countLabel) {
        const int shown = names.size();
        m_countLabel->setText(!query.isEmpty()
            ? tr("%1 of %2 games").arg(shown).arg(total)
            : (total == 1 ? tr("%1 game").arg(total) : tr("%1 games").arg(total)));
    }

    if (m_libraryGrid)
        m_libraryGrid->setItems(names);

    if (!previous.isEmpty() && names.contains(previous))
        selectName(previous);
    else if (m_tree->topLevelItemCount() > 0)
        m_tree->setCurrentItem(m_tree->topLevelItem(0));

    updateDetail();
}

QString MainWindow::currentName() const
{
    QTreeWidgetItem* item = m_tree->currentItem();
    if (!item)
        return {};
    return item->data(1, Qt::UserRole).toString();
}

void MainWindow::selectName(const QString& name)
{
    for (int i = 0; i < m_tree->topLevelItemCount(); ++i) {
        QTreeWidgetItem* item = m_tree->topLevelItem(i);
        if (item->data(1, Qt::UserRole).toString() == name) {
            m_tree->setCurrentItem(item);
            m_tree->scrollToItem(item);
            return;
        }
    }
}

void MainWindow::onSelectionChanged()
{
    if (m_libraryGrid)
        m_libraryGrid->highlight(m_tree->currentItem() ? currentName() : QString());
    updateDetail();
}

void MainWindow::onSortChanged()
{
    refreshList(true);
}

void MainWindow::setViewMode(const QString& mode)
{
    QString m = mode;
    if (m != QLatin1String("grid"))
        m = QStringLiteral("list");
    if (m == QLatin1String("grid") && !m_libraryGrid)
        m = QStringLiteral("list");

    m_viewMode = m;
    if (m_libraryStack && m_tree && m_libraryGrid) {
        const bool grid = (m == QLatin1String("grid"));
        m_libraryStack->setCurrentWidget(grid ? static_cast<QWidget*>(m_libraryGrid) : m_tree);
        if (m_viewFrame)
            m_viewFrame->setVisible(grid);
        if (m_gridBtn)
            m_gridBtn->setChecked(grid);
        if (m_listBtn)
            m_listBtn->setChecked(!grid);

        const QString on = QStringLiteral("Accent");
        const QString off = QStringLiteral("ViewToggle");
        m_gridBtn->setObjectName(grid ? on : off);
        m_listBtn->setObjectName(grid ? off : on);
        for (QPushButton* b : {m_gridBtn, m_listBtn}) {
            b->style()->unpolish(b);
            b->style()->polish(b);
        }
        if (grid)
            m_libraryGrid->highlight(currentName());
    }
    saveViewConfig();
}

void MainWindow::onCardSizeChanged()
{
    if (!m_sizeCombo)
        return;
    const int width = covers::cardSizes().value(m_sizeCombo->currentText(), 200);
    m_cardWidth = width;
    if (m_libraryGrid)
        m_libraryGrid->setCardWidth(width);
    saveViewConfig();
}

void MainWindow::fetchCovers()
{
    if (!m_libraryGrid)
        return;
    const int n = m_libraryGrid->fetchMissing();
    setStatus(n ? tr("Looking for %1 cover(s) online...").arg(n)
                : tr("All games already have a cover"),
              m_theme->current().textSecondary.name());
}

void MainWindow::saveViewConfig()
{
    covers::ViewConfig cfg;
    cfg.view = m_viewMode;
    cfg.cardWidth = m_cardWidth;
    covers::saveViewConfig(paths::libraryViewConfig(), cfg);
}

void MainWindow::updateDetail()
{
    const QString name = currentName();
    const bool hasSelection = !name.isEmpty();
    for (QPushButton* b : m_actionButtons)
        b->setEnabled(hasSelection);

    if (!hasSelection) {
        m_titleLabel->setText(QStringLiteral("No Game Selected"));
        m_iconLabel->setPixmap(QPixmap());
        m_iconLabel->setText(QStringLiteral("No cover"));
        m_sourceValue->setText(QStringLiteral("-"));
        m_locationValue->setText(QStringLiteral("-"));
        m_modifiedValue->setText(QStringLiteral("-"));
        m_sizeValue->setText(QStringLiteral("-"));
        return;
    }

    m_titleLabel->setText(name);
    loadIcon(name);

    const QString scriptPath = paths::bashlaunch() + QLatin1Char('/') + name + QStringLiteral(".sh");
    const QFileInfo fi(scriptPath);
    if (fi.exists()) {
        m_modifiedValue->setText(fi.lastModified().toString(QStringLiteral("yyyy-MM-dd HH:mm:ss")));
        m_sizeValue->setText(humanSize(fi.size()));
        const QString folder = shortcut::extractFolderPath(scriptPath);
        m_locationValue->setText(folder.isEmpty() ? QStringLiteral("-") : folder);
    } else {
        m_modifiedValue->setText(QStringLiteral("-"));
        m_sizeValue->setText(QStringLiteral("-"));
        m_locationValue->setText(tr("Script file missing"));
    }

    const runnerconfig::GameSource src = runnerconfig::gameSource(name);
    if (src.source == QLatin1String("gog")) {
        m_sourceValue->setText(src.gogId.isEmpty()
            ? QStringLiteral("GOG")
            : QStringLiteral("GOG (id %1)").arg(src.gogId));
    } else {
        m_sourceValue->setText(QStringLiteral("Non-GOG (added manually / other installer)"));
    }
}

void MainWindow::loadIcon(const QString& name)
{
    QPixmap pix;
    bool loaded = false;

    // 1. Check icons folder (manual covers).
    QString iconPath = paths::icons() + QLatin1Char('/') + name + QStringLiteral(".png");
    pix.load(iconPath);
    if (!pix.isNull()) {
        loaded = true;
    }

    // 2. Check GOG covers folder (for GOG games).
    if (!loaded) {
        const runnerconfig::GameSource src = runnerconfig::gameSource(name);
        if (src.source == QLatin1String("gog") && !src.gogId.isEmpty()) {
            const QString gogCoverPath = paths::gogCovers() + QLatin1Char('/') + src.gogId + QStringLiteral(".jpg");
            pix.load(gogCoverPath);
            if (!pix.isNull()) {
                loaded = true;
            }
        }
    }

    // 3. Check covers folder (CoverStore).
    if (!loaded) {
        if (m_coverStore && m_coverStore->has(name)) {
            pix.load(m_coverStore->path(name));
            if (!pix.isNull()) {
                loaded = true;
            }
        }
    }

    // 4. If still not loaded, try CoverFetcher to fetch it.
    if (!loaded && m_coverFetcher) {
        // Try to get GOG ID for better cover fetching
        QString gogId;
        const runnerconfig::GameSource src = runnerconfig::gameSource(name);
        if (src.source == QLatin1String("gog") && !src.gogId.isEmpty()) {
            gogId = src.gogId;
        }
        m_coverFetcher->ensure(name, true, gogId);
        // Show placeholder while fetching.
        m_iconLabel->setPixmap(QPixmap());
        m_iconLabel->setText(QStringLiteral("Loading cover..."));
        // Connect coverReady signal to reload icon when fetched.
        disconnect(m_coverFetcher, &CoverFetcher::coverReady, this, nullptr);
        connect(m_coverFetcher, &CoverFetcher::coverReady, this,
                [this, name](const QString& fetchedName, bool hasCover) {
                    if (fetchedName == name && hasCover) {
                        loadIcon(name);
                    } else if (fetchedName == name && !hasCover) {
                        m_iconLabel->setPixmap(QPixmap());
                        m_iconLabel->setText(QStringLiteral("No cover"));
                    }
                });
        return;
    }

    if (!loaded) {
        m_iconLabel->setPixmap(QPixmap());
        m_iconLabel->setText(QStringLiteral("No cover"));
        m_iconLabel->setProperty("cover", false);
        m_iconLabel->style()->unpolish(m_iconLabel);
        m_iconLabel->style()->polish(m_iconLabel);
        return;
    }

    // Crop to square (1:1) first, then scale to display size.
    pix = cropToSquare(pix);
    pix = pix.scaled(kIconWidth, kIconHeight, Qt::KeepAspectRatio, Qt::SmoothTransformation);
    m_iconLabel->setText(QString());
    m_iconLabel->setPixmap(roundedPixmap(pix, 16));
    m_iconLabel->setProperty("cover", true);
    m_iconLabel->style()->unpolish(m_iconLabel);
    m_iconLabel->style()->polish(m_iconLabel);
}

void MainWindow::setStatus(const QString& text, const QString& color)
{
    if (!m_status)
        return;
    m_status->setText(text);
    m_status->setStyleSheet(color.isEmpty() ? QString() : QStringLiteral("color:%1;").arg(color));
}

void MainWindow::addGame()
{
    const QString exe = QFileDialog::getOpenFileName(
        this, tr("Select Windows Executable (.exe)"), QDir::homePath(),
        tr("Executable Files (*.exe);;All Files (*)"));
    if (exe.isEmpty())
        return;

    const QFileInfo exeInfo(exe);
    QString suggested = exeInfo.completeBaseName();

    QString safeName;
    while (true) {
        bool ok = false;
        const QString input = QInputDialog::getText(
            this, tr("Rename Script"), tr("Enter script name (for display):"),
            QLineEdit::Normal, suggested, &ok);
        if (!ok || input.isEmpty())
            return;

        safeName = shortcut::sanitizeName(input);
        if (safeName.isEmpty()) {
            QMessageBox::critical(this, tr("Error"), tr("Invalid script name."));
            return;
        }

        const QString scriptPath =
            paths::bashlaunch() + QLatin1Char('/') + safeName + QStringLiteral(".sh");
        if (QFileInfo::exists(scriptPath)) {
            const auto choice = QMessageBox::warning(
                this, tr("Name Already Exists"),
                tr("A game named '%1' already exists.\n\n"
                   "Yes = Replace it (its old launch script & runner settings will be overwritten)\n"
                   "No = Enter a different name instead\n"
                   "Cancel = Don't add this game").arg(safeName),
                QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel);
            if (choice == QMessageBox::Cancel)
                return;
            if (choice == QMessageBox::No) {
                suggested = safeName;
                continue;
            }
        }
        break;
    }

    const QString folder = QFileInfo(exe).absolutePath();
    const QString folderResolved = QFileInfo(folder).canonicalFilePath().isEmpty()
        ? QFileInfo(folder).absoluteFilePath() : QFileInfo(folder).canonicalFilePath();
    const QString exeResolved = QFileInfo(exe).canonicalFilePath().isEmpty()
        ? QFileInfo(exe).absoluteFilePath() : QFileInfo(exe).canonicalFilePath();

    const QString scriptPath =
        paths::bashlaunch() + QLatin1Char('/') + safeName + QStringLiteral(".sh");

    // Prefix: by default the one the game is installed in (the game's own
    // location), found through WLM's registry or by looking for drive_c around
    // the exe. The user can instead create a new prefix (WLM folder or a custom
    // location) or use another existing one, before the game is added.
    const auto owning = prefixops::findOwningPrefix(exeResolved);
    QString detectedPath;
    if (!owning) {
        if (const auto det = prefixlink::detectFromExe(exeResolved))
            detectedPath = det->path;
    }

    PrefixSelectDialog prefixDlg(this, safeName, owning, detectedPath);
    if (prefixDlg.exec() != QDialog::Accepted) {
        setStatus(tr("Add game cancelled."), m_theme->current().textSecondary.name());
        return;
    }
    RunnerChoice cfg = prefixDlg.choice();

    // GOG games keep their marker so Save Manager / cloud sync keep working.
    const QString gid = shortcut::detectGogId(exeResolved);
    if (!gid.isEmpty()) {
        cfg.source = QStringLiteral("gog");
        cfg.gogId = gid;
    }

    const QString content = shortcut::buildScriptContent(folderResolved, exeResolved, cfg.toJson());
    {
        QFile f(scriptPath);
        if (!f.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate)) {
            setStatus(tr("Error creating script: %1").arg(scriptPath),
                      m_theme->current().danger.name());
            return;
        }
        f.write(content.toUtf8());
        f.close();
        QFile::setPermissions(scriptPath,
                              QFileDevice::ReadOwner | QFileDevice::WriteOwner
                                  | QFileDevice::ExeOwner | QFileDevice::ReadGroup
                                  | QFileDevice::ExeGroup | QFileDevice::ReadOther
                                  | QFileDevice::ExeOther);
    }

    const bool plainWine = cfg.runner == QLatin1String("wine") && cfg.prefixPath.isEmpty()
        && cfg.source.isEmpty();
    if (plainWine)
        runnerconfig::remove(safeName);
    else
        runnerconfig::set(safeName, cfg);

    refreshList(true);
    selectName(safeName);
    setStatus(tr("Added: %1 (%2)").arg(safeName, prefixDlg.summary()),
              m_theme->current().success.name());
}

void MainWindow::removeGame()
{
    const QString name = currentName();
    if (name.isEmpty()) {
        setStatus(tr("Please select a game first"));
        return;
    }

    const auto choice = QMessageBox::question(
        this, tr("Confirm"), tr("Are you sure you want to remove '%1'?").arg(name));
    if (choice != QMessageBox::Yes)
        return;

    QFile::remove(paths::bashlaunch() + QLatin1Char('/') + name + QStringLiteral(".sh"));
    QFile::remove(paths::icons() + QLatin1Char('/') + name + QStringLiteral(".png"));
    runnerconfig::remove(name);
    if (m_coverStore)
        m_coverStore->forget(name);

    refreshList(false);
    m_titleLabel->setText(QStringLiteral("No Game Selected"));
    m_iconLabel->setPixmap(QPixmap());
    m_iconLabel->setText(QStringLiteral("No cover"));
    setStatus(tr("Removed: %1").arg(name), m_theme->current().warning.name());
}

void MainWindow::showCoverContextMenu(const QPoint& pos)
{
    const QString name = currentName();
    if (name.isEmpty())
        return;

    QMenu menu(this);
    menu.setObjectName(QStringLiteral("CoverContextMenu"));

    // Add selection animation
    QPropertyAnimation* anim = new QPropertyAnimation(m_iconLabel, "geometry", this);
    anim->setDuration(150);
    anim->setEasingCurve(QEasingCurve::OutCubic);
    const QRect startRect = m_iconLabel->geometry();
    const QRect endRect = startRect.adjusted(-2, -2, 2, 2);
    anim->setStartValue(startRect);
    anim->setEndValue(endRect);
    anim->start(QAbstractAnimation::DeleteWhenStopped);

    auto* downloadCoverAct = menu.addAction(tr("Download Cover"));
    connect(downloadCoverAct, &QAction::triggered, this, &MainWindow::downloadCover);

    auto* removeCoverAct = menu.addAction(tr("Remove Cover"));
    connect(removeCoverAct, &QAction::triggered, this, &MainWindow::removeCover);

    menu.addSeparator();

    auto* uninstallAct = menu.addAction(tr("Uninstall Game"));
    uninstallAct->setObjectName(QStringLiteral("DangerAction"));
    connect(uninstallAct, &QAction::triggered, this, &MainWindow::uninstallGame);

    menu.exec(m_iconLabel->mapToGlobal(pos));
}

void MainWindow::downloadCover()
{
    const QString name = currentName();
    if (name.isEmpty())
        return;

    if (m_coverFetcher) {
        setStatus(tr("Downloading cover for '%1'...").arg(currentName()));
        m_coverFetcher->ensure(currentName(), true);
    }
}

void MainWindow::removeCover()
{
    const QString name = currentName();
    if (name.isEmpty())
        return;

    const auto choice = QMessageBox::question(
        this, tr("Confirm"), tr("Remove cover for '%1'?").arg(currentName()));
    if (choice != QMessageBox::Yes)
        return;

    if (m_coverStore) {
        m_coverStore->forget(currentName());
    }
    loadIcon(currentName());
    setStatus(tr("Cover removed for '%1'").arg(currentName()), m_theme->current().warning.name());
}

void MainWindow::uninstallGame()
{
    removeGame();
}

void MainWindow::processDownloadQueue()
{
    if (m_downloadQueue.isEmpty() || m_isInstalling)
        return;

    const QString title = m_downloadQueue.dequeue();
    m_currentInstalling = title;
    m_isInstalling = true;

    // Find the download item and start setup
    DownloadManager* dm = DownloadManager::instance();
    const auto items = dm->items();
    for (const auto& item : items) {
        if (item.title == title && item.status == DownloadManager::Status::Completed
            && !item.startSetupAfterDownload) {
            // Trigger the install via DownloadManagerDialog's logic
            // We'll emit a signal that DownloadManagerDialog can handle
            emit startQueuedInstall(title);
            break;
        }
    }
}

void MainWindow::onDownloadQueueInstallFinished(const QString& title, bool success)
{
    m_isInstalling = false;
    m_currentInstalling.clear();

    if (success) {
        setStatus(tr("Installed: %1").arg(title), m_theme->current().success.name());
    } else {
        setStatus(tr("Install failed: %1").arg(title), m_theme->current().danger.name());
    }

    // Process next in queue
    processDownloadQueue();
}

void MainWindow::renameGame()
{
    const QString oldName = currentName();
    if (oldName.isEmpty()) {
        setStatus(tr("Please select a game first"));
        return;
    }

    bool ok = false;
    const QString input = QInputDialog::getText(this, tr("Rename Script"),
                                                tr("Enter new script name:"),
                                                QLineEdit::Normal, oldName, &ok);
    if (!ok || input.isEmpty() || input == oldName)
        return;

    const QString newName = shortcut::sanitizeName(input);
    if (newName.isEmpty()) {
        QMessageBox::critical(this, tr("Error"), tr("Invalid new script name."));
        return;
    }

    const QString oldPath = paths::bashlaunch() + QLatin1Char('/') + oldName + QStringLiteral(".sh");
    const QString newPath = paths::bashlaunch() + QLatin1Char('/') + newName + QStringLiteral(".sh");
    if (QFileInfo::exists(newPath)) {
        QMessageBox::critical(this, tr("Error"),
                              tr("Script '%1' already exists.").arg(newName));
        return;
    }

    if (!QFile::rename(oldPath, newPath)) {
        setStatus(tr("Error renaming script."), m_theme->current().danger.name());
        return;
    }

    const QString oldIcon = paths::icons() + QLatin1Char('/') + oldName + QStringLiteral(".png");
    const QString newIcon = paths::icons() + QLatin1Char('/') + newName + QStringLiteral(".png");
    if (QFileInfo::exists(oldIcon))
        QFile::rename(oldIcon, newIcon);

    runnerconfig::rename(oldName, newName);
    if (m_coverStore)
        m_coverStore->rename(oldName, newName);

    refreshList(true);
    selectName(newName);
    setStatus(tr("Renamed to: %1").arg(newName), m_theme->current().success.name());
}

void MainWindow::changeIcon()
{
    const QString name = currentName();
    if (name.isEmpty()) {
        setStatus(tr("Please select a game first"));
        return;
    }

    const QString path = QFileDialog::getOpenFileName(
        this, tr("Select Icon"), QDir::homePath(),
        tr("Image Files (*.png *.jpg *.jpeg *.ico *.bmp);;All Files (*)"));
    if (path.isEmpty())
        return;

    QImage image(path);
    if (image.isNull()) {
        QMessageBox::critical(this, tr("Error"), tr("Failed to process image."));
        return;
    }
    image = image.convertToFormat(QImage::Format_ARGB32);
    const int side = qMin(image.width(), image.height());
    const int left = (image.width() - side) / 2;
    const int top = (image.height() - side) / 2;
    image = image.copy(left, top, side, side)
                .scaled(kIconSize, kIconSize, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);

    const QString iconPath = paths::icons() + QLatin1Char('/') + name + QStringLiteral(".png");
    if (!image.save(iconPath, "PNG")) {
        QMessageBox::critical(this, tr("Error"), tr("Failed to save icon."));
        return;
    }
    loadIcon(name);
    setStatus(tr("Icon updated for %1").arg(name), m_theme->current().success.name());
}

void MainWindow::openFolder()
{
    const QString name = currentName();
    if (name.isEmpty()) {
        setStatus(tr("Please select a game first"));
        return;
    }

    const QString scriptPath = paths::bashlaunch() + QLatin1Char('/') + name + QStringLiteral(".sh");
    const QString folder = shortcut::extractFolderPath(scriptPath);
    if (!folder.isEmpty() && QFileInfo(folder).isDir()) {
        openInFileManager(folder);
        setStatus(tr("Opening folder for %1...").arg(name));
    } else {
        setStatus(tr("Error: Invalid folder path in script for %1.").arg(name),
                  m_theme->current().danger.name());
    }
}

void MainWindow::play()
{
    const QString name = currentName();
    if (name.isEmpty()) {
        setStatus(tr("Please select a game first"));
        return;
    }

    const QString scriptPath = paths::bashlaunch() + QLatin1Char('/') + name + QStringLiteral(".sh");
    if (!QFileInfo::exists(scriptPath)) {
        setStatus(tr("Error: Script file not found: %1.sh").arg(name),
                  m_theme->current().danger.name());
        return;
    }

    RunnerDialog dialog(this, name, name, false);
    connect(&dialog, &RunnerDialog::savesRequested, this,
            [this, &dialog, name] { openSaveManager(name, &dialog); });
    if (dialog.exec() != QDialog::Accepted) {
        setStatus(tr("Launch cancelled."));
        return;
    }
    const std::optional<RunnerChoice> choiceOpt = dialog.choice();
    if (!choiceOpt.has_value())
        return;

    const QString exe = shortcut::extractExePath(scriptPath);
    const QString folder = shortcut::extractFolderPath(scriptPath);
    if (exe.isEmpty() || folder.isEmpty()) {
        setStatus(tr("Error: Could not read exe/folder path from script."),
                  m_theme->current().danger.name());
        return;
    }

    RunnerChoice choice = *choiceOpt;
    // Preserve the GOG marker across runner changes.
    const RunnerChoice previous = runnerconfig::get(name);
    if (choice.source.isEmpty())
        choice.source = previous.source;
    if (choice.gogId.isEmpty())
        choice.gogId = previous.gogId;

    const QString content = shortcut::buildScriptContent(folder, exe, choice.toJson());
    QFile f(scriptPath);
    if (!f.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate)) {
        setStatus(tr("Error updating script for runner."), m_theme->current().danger.name());
        return;
    }
    f.write(content.toUtf8());
    f.close();

    runnerconfig::set(name, choice);

    QFile::setPermissions(scriptPath,
                          QFileDevice::ReadOwner | QFileDevice::WriteOwner | QFileDevice::ExeOwner
                              | QFileDevice::ReadGroup | QFileDevice::ExeGroup
                              | QFileDevice::ReadOther | QFileDevice::ExeOther);

    const QString launchMode = m_launchMode ? m_launchMode->currentText() : QStringLiteral("Normal");
    QString error;
    if (!m_launcher->launch(name, scriptPath, launchMode, &error)) {
        setStatus(tr("Error launching script: %1").arg(error), m_theme->current().danger.name());
        return;
    }

    QString runnerLabel;
    if (choice.runner == QLatin1String("protonge"))
        runnerLabel = QStringLiteral("Proton GE (%1)").arg(choice.prefixCode);
    else if (choice.runner == QLatin1String("protoncachyos"))
        runnerLabel = QStringLiteral("Proton-CachyOS (%1)").arg(choice.prefixCode);
    else if (!choice.prefixCode.isEmpty())
        runnerLabel = QStringLiteral("Wine (%1)").arg(choice.prefixCode);
    else
        runnerLabel = QStringLiteral("Wine");

    setStatus(tr("Launching %1 via %2 in %3 mode...").arg(name, runnerLabel, launchMode),
              m_theme->current().success.name());
}

void MainWindow::viewLogs()
{
    const QString name = currentName();
    if (name.isEmpty()) {
        setStatus(tr("Please select a game first"));
        return;
    }

    LogWindow* existing = m_logWindows.value(name, nullptr);
    if (existing) {
        existing->show();
        existing->raise();
        existing->activateWindow();
        return;
    }

    auto* win = new LogWindow(m_launcher, name, this);
    win->setAttribute(Qt::WA_DeleteOnClose);
    m_logWindows.insert(name, win);
    connect(win, &QObject::destroyed, this, [this, name] { m_logWindows.remove(name); });
    win->show();
}

void MainWindow::installApps()
{
    const QString exe = QFileDialog::getOpenFileName(
        this, tr("Select Setup Executable (.exe)"), QDir::homePath(),
        tr("Executable Files (*.exe);;All Files (*)"));
    if (exe.isEmpty())
        return;

    RunnerDialog dialog(this, QString(), QString(), true);
    if (dialog.exec() != QDialog::Accepted) {
        setStatus(tr("Setup cancelled."), m_theme->current().textSecondary.name());
        return;
    }
    const std::optional<RunnerChoice> choiceOpt = dialog.choice();
    if (!choiceOpt.has_value())
        return;
    const RunnerChoice choice = *choiceOpt;

    auto* runner = new SetupRunner(this);
    QString error;
    if (!runner->start(exe, choice, {}, {}, &error)) {
        runner->deleteLater();
        setStatus(tr("Error running setup: %1").arg(error), m_theme->current().danger.name());
        return;
    }

    setStatus(tr("Running setup for %1...").arg(QFileInfo(exe).fileName()),
              m_theme->current().textSecondary.name());
    connect(runner, &SetupRunner::finished, this,
            [this, runner, choice](const SetupResult& result) {
                runner->deleteLater();
                finishManualInstall(choice, result);
            });
}

// Main thread: tambahkan hasil install manual ke daftar game. Installer GOG
// (ada goggame-*.info) langsung otomatis; installer lain minta konfirmasi dulu
// karena exe-nya hanya bisa ditebak. Port of _finish_manual_install().
void MainWindow::finishManualInstall(const RunnerChoice& choice, const SetupResult& result)
{
    if (result.found) {
        const installwatch::GogGameFound& found = *result.found;
        const QString suggested = found.name.isEmpty()
            ? QFileInfo(found.exe).completeBaseName() : found.name;
        const QString finalName = shortcut::addGameShortcut(
            suggested, found.exe, choice, found.hasIcon ? found.icon : QString(),
            found.workdir);
        if (finalName.isEmpty()) {
            setStatus(tr("Could not add shortcut: the launch script could not be written."),
                      m_theme->current().danger.name());
            return;
        }
        refreshList(true);
        selectName(finalName);
        setStatus(tr("Setup finished - '%1' was added to the launcher.").arg(finalName),
                  m_theme->current().success.name());
        return;
    }

    if (result.exitCode && *result.exitCode != 0) {
        setStatus(tr("Setup closed (exit code %1) - no shortcut was added.")
                      .arg(*result.exitCode),
                  m_theme->current().textSecondary.name());
        return;
    }
    if (result.candidates.isEmpty()) {
        setStatus(tr("Setup finished - no new game detected, so no shortcut was added."),
                  m_theme->current().textSecondary.name());
        return;
    }

    const QString defaultName = QFileInfo(result.candidates.first().gameDir).fileName();
    AddShortcutDialog dlg(result.candidates, result.driveC, defaultName, this);
    if (dlg.exec() != QDialog::Accepted) {
        setStatus(tr("Setup finished - no shortcut added."),
                  m_theme->current().textSecondary.name());
        return;
    }
    const QString finalName =
        shortcut::addGameShortcut(dlg.chosenName(), dlg.chosenExe(), choice);
    if (finalName.isEmpty()) {
        setStatus(tr("Could not add shortcut: the launch script could not be written."),
                  m_theme->current().danger.name());
        return;
    }
    refreshList(true);
    selectName(finalName);
    setStatus(tr("Setup finished - '%1' was added to the launcher.").arg(finalName),
              m_theme->current().success.name());
}

void MainWindow::openHudConfig()
{
    HudConfigDialog dlg(this);
    connect(&dlg, &HudConfigDialog::statusMessage, this,
            [this](const QString& text, bool success) {
                setStatus(text, success ? m_theme->current().success.name()
                                        : m_theme->current().danger.name());
            });
    dlg.exec();
}

void MainWindow::openProtonDownload(bool cachyos)
{
    auto* dialog = new ProtonDownloadDialog(cachyos, this);
    dialog->setAttribute(Qt::WA_DeleteOnClose);
    connect(dialog, &ProtonDownloadDialog::statusMessage, this,
            [this](const QString& text, bool success) {
                setStatus(text, success ? m_theme->current().success.name()
                                        : m_theme->current().danger.name());
            });
    dialog->show();
    dialog->raise();
    dialog->activateWindow();
}

void MainWindow::extractProtonArchive(bool cachyos)
{
    const QString label = cachyos ? QStringLiteral("Proton-CachyOS") : QStringLiteral("Proton GE");
    const QString archive = QFileDialog::getOpenFileName(
        this, tr("Select %1 Archive").arg(label), QDir::homePath(),
        tr("%1 Archive (*.tar.gz *.tar.xz *.tgz *.zip);;All Files (*)").arg(label));
    if (archive.isEmpty())
        return;

    const QString target = cachyos ? paths::protonCachyOS() : paths::protonGE();
    auto* win = new TaskLogWindow(tr("Extracting %1").arg(label), this, false);
    win->setAttribute(Qt::WA_DeleteOnClose);
    auto* extractor = new ArchiveExtractor(win);
    connect(extractor, &ArchiveExtractor::line, win, &TaskLogWindow::appendLine);
    connect(extractor, &ArchiveExtractor::finished, win,
            [this, win, label, target](bool ok, const QString& err) {
                win->appendLine(QString());
                if (ok) {
                    win->appendLine(tr("%1 successfully extracted to %2").arg(label, target));
                    win->markFinished();
                    setStatus(tr("%1 successfully extracted to %2").arg(label, target),
                              m_theme->current().success.name());
                    QMessageBox::information(win, tr("Done"),
                        tr("%1 successfully extracted to the WLM directory:\n%2")
                            .arg(label, target));
                } else {
                    win->appendLine(tr("ERROR: %1").arg(err));
                    win->markFinished();
                    setStatus(tr("Error extracting %1: %2").arg(label, err),
                              m_theme->current().danger.name());
                    QMessageBox::critical(win, tr("Error"),
                        tr("Failed to extract archive:\n%1").arg(err));
                }
            });
    win->show();
    extractor->extract(archive, target);
}

void MainWindow::openPrefixManager()
{
    auto* dialog = new PrefixManagerDialog(this);
    dialog->setAttribute(Qt::WA_DeleteOnClose);
    connect(dialog, &PrefixManagerDialog::statusMessage, this,
            [this](const QString& text, bool success) {
                setStatus(text, success ? m_theme->current().success.name()
                                        : m_theme->current().danger.name());
            });
    connect(dialog, &PrefixManagerDialog::dataChanged, this,
            [this] { refreshList(); });
    dialog->show();
    dialog->raise();
    dialog->activateWindow();
}

void MainWindow::openGogStore()
{
    if (!m_gogStore) {
        m_gogStore = new GogStoreDialog(this);
        m_gogStore->setAttribute(Qt::WA_DeleteOnClose);
        connect(m_gogStore, &QObject::destroyed, this, [this] { m_gogStore = nullptr; });
        connect(m_gogStore, &GogStoreDialog::statusMessage, this,
                [this](const QString& text, bool success) {
                    setStatus(text, success ? m_theme->current().success.name()
                                            : m_theme->current().danger.name());
                });
        connect(m_gogStore, &GogStoreDialog::downloadCompleted, this,
                [this](const QString& title) {
                    setStatus(tr("Downloaded: %1").arg(title),
                              m_theme->current().success.name());
                    refreshList(false);
                });
        connect(m_gogStore, &GogStoreDialog::gameInstalled, this,
                [this] {
                    refreshList(false);
                });
    }
    m_gogStore->show();
    m_gogStore->raise();
    m_gogStore->activateWindow();
}

void MainWindow::openDownloadManager()
{
    auto* dlg = new DownloadManagerDialog(this);
    dlg->setAttribute(Qt::WA_DeleteOnClose);
    connect(dlg, &DownloadManagerDialog::installCompleted, this, [this] {
        refreshList(false);
    });
    connect(dlg, &DownloadManagerDialog::downloadCompleted, this, [this](const QString& title) {
        setStatus(tr("Downloaded: %1").arg(title),
                  m_theme->current().success.name());
        refreshList(false);
    });
    connect(dlg, &DownloadManagerDialog::statusMessage, this,
            [this](const QString& text, bool success) {
                setStatus(text, success ? m_theme->current().success.name()
                                        : m_theme->current().danger.name());
            });
    dlg->show();
    dlg->raise();
    dlg->activateWindow();
}

void MainWindow::openSaveManager(const QString& name, QWidget* parentForDialog)
{
    if (name.isEmpty())
        return;

    // Reuse an already-open Save Manager window for this game.
    if (SaveManagerDialog* existing = m_saveDialogs.value(name)) {
        existing->show();
        existing->raise();
        existing->activateWindow();
        return;
    }

    const QString scriptPath =
        paths::bashlaunch() + QLatin1Char('/') + name + QStringLiteral(".sh");
    const QString exe = shortcut::extractExePath(scriptPath);
    const RunnerChoice choice = runnerconfig::get(name);

    auto* dlg = new SaveManagerDialog(
        parentForDialog ? parentForDialog : this, name, exe, choice,
        [this, name] { return m_launcher->isRunning(name); });
    dlg->setAttribute(Qt::WA_DeleteOnClose);
    m_saveDialogs.insert(name, dlg);
    connect(dlg, &QObject::destroyed, this,
            [this, name] { m_saveDialogs.remove(name); });
    connect(dlg, &SaveManagerDialog::statusMessage, this,
            [this](const QString& text, bool success) {
                setStatus(text, success ? m_theme->current().success.name()
                                        : m_theme->current().danger.name());
            });
    dlg->show();
    dlg->raise();
    dlg->activateWindow();
}

void MainWindow::onThemeSelected(int index)
{
    if (index < 0)
        return;
    const QString id = m_themeCombo->itemData(index).toString();
    if (id == m_theme->currentId())
        return;
    m_theme->apply(id);
    m_config.setTheme(id);
    m_config.saveTheme();
    setStatus(tr("Changed to %1 theme").arg(m_theme->current().name));
}

void MainWindow::restoreGeometryFromConfig()
{
    const WindowGeometry& g = m_config.window();
    m_lastNormalSize = g.size;
    if (g.hasPosition()) {
        m_lastNormalPos = g.position;
        move(g.toPoint());
    }
    resize(g.toSize());
    if (g.maximized)
        setWindowState(windowState() | Qt::WindowMaximized);
}

void MainWindow::showEvent(QShowEvent* event)
{
    QMainWindow::showEvent(event);
    if (!m_shown) {
        m_shown = true;
        QTimer::singleShot(0, this, &MainWindow::restoreSash);
        QTimer::singleShot(200, this, &MainWindow::restoreSash);
    }
}

void MainWindow::restoreSash()
{
    const int saved = m_config.window().sash;
    if (saved <= 0 || m_sashRestored || !m_splitter)
        return;
    const int total = m_splitter->width();
    if (total < 200)
        return;
    const int left = qBound(200, saved, total - 200);
    m_splitter->setSizes({left, total - left});
    m_sashRestored = true;
}

void MainWindow::onSplitterMoved()
{
    if (m_saveTimer)
        m_saveTimer->start();
}

void MainWindow::persistWindow()
{
    WindowGeometry g = m_config.window();

    if (!isMaximized() && !isFullScreen()) {
        m_lastNormalSize = QStringLiteral("%1x%2").arg(width()).arg(height());
        m_lastNormalPos = QStringLiteral("+%1+%2").arg(x()).arg(y());
    }
    if (!m_lastNormalSize.isEmpty())
        g.size = m_lastNormalSize;
    if (!m_lastNormalPos.isEmpty())
        g.position = m_lastNormalPos;
    g.maximized = isMaximized();

    if (m_splitter) {
        const QList<int> sizes = m_splitter->sizes();
        if (!sizes.isEmpty() && sizes.first() > 0)
            g.sash = sizes.first();
    }

    m_config.setWindow(g);
    m_config.saveWindow();
}

void MainWindow::closeEvent(QCloseEvent* event)
{
    if (m_saveTimer)
        m_saveTimer->stop();
    persistWindow();
    QMainWindow::closeEvent(event);
}

void MainWindow::resizeEvent(QResizeEvent* event)
{
    QMainWindow::resizeEvent(event);
    if (!centralWidget())
        return;
    const QRect cr = centralWidget()->rect();
    if (m_sideScrim && m_sideScrim->isVisible())
        m_sideScrim->setGeometry(cr);
    if (m_sidePanel && m_sidePanel->isVisible()) {
        const QRect g = m_sidePanel->geometry();
        m_sidePanel->setGeometry(g.x(), 0, g.width(), cr.height());
    }
}

bool MainWindow::eventFilter(QObject* obj, QEvent* event)
{
    if (obj == m_sideScrim && event->type() == QEvent::MouseButtonPress) {
        hideSidePanel();
        return true;
    }
    if (obj == m_sidePanel && event->type() == QEvent::KeyPress) {
        auto* ke = static_cast<QKeyEvent*>(event);
        if (ke->key() == Qt::Key_Escape) {
            hideSidePanel();
            return true;
        }
    }
    return QMainWindow::eventFilter(obj, event);
}
