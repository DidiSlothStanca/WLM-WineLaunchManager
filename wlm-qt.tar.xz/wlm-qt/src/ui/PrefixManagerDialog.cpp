#include "ui/PrefixManagerDialog.h"

#include "core/PrefixLink.h"
#include "ui/PrefixPicker.h"

#include "core/WindowState.h"

#include "core/Paths.h"
#include "core/PrefixRegistry.h"
#include "core/PrefixTasks.h"
#include "core/ProcessUtils.h"
#include "core/Proton.h"
#include "core/ProtonManager.h" // protonutil::humanSize
#include "core/RunnerConfig.h"
#include "core/Shortcut.h"
#include "ui/LogWindow.h"
#include "ui/RestoreBackupDialog.h"
#include "ui/TaskLogWindow.h"
#include "ui/WinetricksDialog.h"

#include <QAbstractItemView>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileDialog>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QInputDialog>
#include <QJsonArray>
#include <QLabel>
#include <QMessageBox>
#include <QProcess>
#include <QProcessEnvironment>
#include <QPushButton>
#include <QSet>
#include <QTreeWidget>
#include <QVBoxLayout>

namespace {

bool detachWithEnv(const QProcessEnvironment& env, const QString& program,
                   const QStringList& args)
{
    QStringList envArgs;
    for (const QString& key : env.keys())
        envArgs << key + QLatin1Char('=') + env.value(key);
    QStringList finalArgs = envArgs;
    finalArgs << program;
    finalArgs << args;
    return QProcess::startDetached(QStringLiteral("/usr/bin/env"), finalArgs);
}

} // namespace

PrefixManagerDialog::PrefixManagerDialog(QWidget* parent)
    : QDialog(parent)
    , m_launcher(new GameLauncher(this))
{
    setWindowTitle(tr("Prefix Configuration Manager"));
    resize(1000, 560);
    setMinimumSize(680, 420);
    setWindowFlags(windowFlags() | Qt::Window);
    new WindowStateHelper(this, QStringLiteral("prefix_manager"), QSize(1000, 560), QSize(680, 420));
    buildUi();
    refreshList();
}

void PrefixManagerDialog::buildUi()
{
    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(15, 15, 15, 15);
    root->setSpacing(8);

    auto* topBar = new QHBoxLayout;
    topBar->addWidget(new QLabel(tr("Select a prefix to configure "
                                    "(winecfg / explorer / uninstaller / winetricks):")),
                      1);
    auto* showLogsBtn = new QPushButton(tr("Show Logs"));
    showLogsBtn->setFixedWidth(110);
    auto* refreshBtn = new QPushButton(tr("Refresh"));
    refreshBtn->setFixedWidth(90);
    topBar->addWidget(showLogsBtn);
    topBar->addWidget(refreshBtn);
    root->addLayout(topBar);

    m_empty = new QLabel(tr("No prefixes found yet. A prefix is created the first time\n"
                            "you PLAY or run APPS SETUP for a game via Wine/Proton."));
    m_empty->setProperty("muted", true);
    m_empty->hide();
    root->addWidget(m_empty);

    m_tree = new QTreeWidget;
    m_tree->setRootIsDecorated(false);
    m_tree->setAllColumnsShowFocus(true);
    m_tree->setUniformRowHeights(true);
    m_tree->setSelectionMode(QAbstractItemView::SingleSelection);
    m_tree->setAlternatingRowColors(true);
    m_tree->setColumnCount(5);
    m_tree->setHeaderLabels({tr("Runner"), tr("Prefix Code"), tr("Game(s)"),
                             tr("Proton Version"), tr("Location")});
    m_tree->setColumnWidth(0, 110);
    m_tree->setColumnWidth(1, 110);
    m_tree->setColumnWidth(2, 240);
    m_tree->setColumnWidth(3, 170);
    m_tree->header()->setStretchLastSection(true);
    root->addWidget(m_tree, 1);

    auto* row1 = new QHBoxLayout;
    row1->addStretch(1);
    auto* winecfgBtn = new QPushButton(tr("Winecfg"));
    auto* explorerBtn = new QPushButton(tr("Explorer"));
    auto* uninstallerBtn = new QPushButton(tr("Uninstaller"));
    auto* winetricksBtn = new QPushButton(tr("Winetricks..."));
    auto* openFolderBtn = new QPushButton(tr("Open Folder"));
    auto* moveBtn = new QPushButton(tr("Move Prefix..."));
    for (QPushButton* b : {winecfgBtn, explorerBtn, uninstallerBtn, winetricksBtn, openFolderBtn,
                           moveBtn})
        row1->addWidget(b);
    row1->addStretch(1);
    root->addLayout(row1);

    auto* row2 = new QHBoxLayout;
    row2->addStretch(1);
    auto* backupBtn = new QPushButton(tr("Backup Apps"));
    auto* restoreBtn = new QPushButton(tr("Restore Apps"));
    auto* removeBtn = new QPushButton(tr("Remove Apps"));
    for (QPushButton* b : {backupBtn, restoreBtn, removeBtn})
        row2->addWidget(b);
    row2->addStretch(1);
    root->addLayout(row2);

    connect(refreshBtn, &QPushButton::clicked, this, &PrefixManagerDialog::refreshList);
    connect(showLogsBtn, &QPushButton::clicked, this, &PrefixManagerDialog::showLogs);
    connect(winecfgBtn, &QPushButton::clicked, this, [this] {
        if (auto e = selected())
            runTool(*e, QStringLiteral("winecfg"));
    });
    connect(explorerBtn, &QPushButton::clicked, this, [this] {
        if (auto e = selected())
            runTool(*e, QStringLiteral("explorer"));
    });
    connect(uninstallerBtn, &QPushButton::clicked, this, [this] {
        if (auto e = selected())
            runTool(*e, QStringLiteral("uninstaller"));
    });
    connect(winetricksBtn, &QPushButton::clicked, this, [this] {
        if (auto e = selected())
            openWinetricks(*e);
    });
    connect(openFolderBtn, &QPushButton::clicked, this, [this] {
        if (auto e = selected())
            openFolder(*e);
    });
    connect(moveBtn, &QPushButton::clicked, this, [this] {
        if (auto e = selected())
            movePrefix(*e);
    });
    connect(backupBtn, &QPushButton::clicked, this, [this] {
        if (auto e = selected())
            backupPrefix(*e);
    });
    connect(restoreBtn, &QPushButton::clicked, this, &PrefixManagerDialog::restoreBackup);
    connect(removeBtn, &QPushButton::clicked, this, [this] {
        if (auto e = selected())
            removePrefixEntry(*e);
    });
}

void PrefixManagerDialog::refreshList()
{
    const QString keepKey = selected() ? selected()->key() : QString();

    m_tree->clear();
    m_prefixes = prefixops::allKnownPrefixes();

    for (const prefixops::PrefixInfo& e : m_prefixes) {
        auto* item = new QTreeWidgetItem(m_tree);
        item->setText(0, prefixops::runnerDisplayName(e.runner));
        item->setText(1, e.code);
        item->setText(2, e.games.isEmpty() ? QStringLiteral("-")
                                           : e.games.join(QStringLiteral(", ")));
        item->setText(3, e.protonName.isEmpty() ? QStringLiteral("-") : e.protonName);
        item->setText(4, e.path);
        item->setData(0, Qt::UserRole, e.key());
        if (e.key() == keepKey)
            m_tree->setCurrentItem(item);
    }

    m_empty->setVisible(m_prefixes.isEmpty());
}

std::optional<prefixops::PrefixInfo> PrefixManagerDialog::selected() const
{
    QTreeWidgetItem* item = m_tree->currentItem();
    if (!item)
        return std::nullopt;
    const QString key = item->data(0, Qt::UserRole).toString();
    for (const prefixops::PrefixInfo& e : m_prefixes) {
        if (e.key() == key)
            return e;
    }
    return std::nullopt;
}

bool PrefixManagerDialog::resolveProton(prefixops::PrefixInfo& entry)
{
    if (entry.runner == QLatin1String("wine"))
        return true;
    if (!entry.protonPath.isEmpty() && QFileInfo::exists(entry.protonPath))
        return true;

    const QString label = entry.runner == QLatin1String("protonge")
        ? QStringLiteral("Proton GE")
        : QStringLiteral("Proton-CachyOS");
    const QList<Proton::Build> installs = entry.runner == QLatin1String("protonge")
        ? Proton::findProtonGEInstallations()
        : Proton::findProtonCachyOSInstallations();
    if (installs.isEmpty()) {
        QMessageBox::critical(this, tr("Error"),
                              tr("No %1 build found.\nExtract one first via Settings.").arg(label));
        return false;
    }

    QStringList names;
    for (const Proton::Build& b : installs)
        names << b.name;
    bool ok = false;
    const QString chosen = QInputDialog::getItem(
        this, tr("Select %1 Build").arg(label),
        tr("This prefix has no %1 version recorded yet.\nSelect the build to use for it:")
            .arg(label),
        names, 0, false, &ok);
    if (!ok || chosen.isEmpty())
        return false;

    for (const Proton::Build& b : installs) {
        if (b.name == chosen) {
            entry.protonName = b.name;
            entry.protonPath = b.path;
            break;
        }
    }

    prefixreg::recordPrefixUsage(entry.runner, entry.code, entry.path, entry.protonName,
                                 entry.protonPath);
    return true;
}

void PrefixManagerDialog::runTool(prefixops::PrefixInfo entry, const QString& tool)
{
    if (!QFileInfo(entry.path).isDir()) {
        QMessageBox::critical(this, tr("Error"),
                              tr("Prefix folder not found on disk:\n%1").arg(entry.path));
        return;
    }

    QProcessEnvironment env = procutil::cleanEnvironment();
    QString program;
    QStringList args;

    if (entry.runner == QLatin1String("wine")) {
        env.insert(QStringLiteral("WINEPREFIX"), entry.path);
        if (tool == QLatin1String("winecfg")) {
            program = QStringLiteral("winecfg");
        } else {
            program = QStringLiteral("wine");
            args << tool;
        }
    } else {
        if (!resolveProton(entry))
            return;
        env.insert(QStringLiteral("STEAM_COMPAT_DATA_PATH"), entry.path);
        env.insert(QStringLiteral("STEAM_COMPAT_CLIENT_INSTALL_PATH"),
                   Proton::findSteamInstallPath());
        program = entry.protonPath;
        args << QStringLiteral("run") << tool;
    }

    if (!detachWithEnv(env, program, args)) {
        QMessageBox::critical(this, tr("Error"),
                              tr("Command not found: %1").arg(program));
        emit statusMessage(tr("Error: runner command not found."), false);
        return;
    }

    const QString label = tool == QLatin1String("winecfg") ? tr("Wine Configuration")
                          : tool == QLatin1String("explorer") ? tr("Wine Explorer")
                                                              : tr("Uninstaller");
    emit statusMessage(tr("Opening %1 for prefix %2 (%3)...")
                           .arg(label, entry.code, prefixops::runnerDisplayName(entry.runner)),
                       true);
}

void PrefixManagerDialog::openWinetricks(prefixops::PrefixInfo entry)
{
    if (!QFileInfo(entry.path).isDir()) {
        QMessageBox::critical(this, tr("Error"),
                              tr("Prefix folder not found on disk:\n%1").arg(entry.path));
        return;
    }

    auto run = [this, entry](const QStringList& verbs) {
        if (entry.runner != QLatin1String("wine")) {
            const QString pfx = entry.path + QStringLiteral("/pfx");
            if (!QFileInfo(pfx).isDir()) {
                QMessageBox::critical(
                    this, tr("Error"),
                    tr("This prefix doesn't have a Wine prefix yet ('pfx' folder missing):\n%1\n\n"
                       "Run the game/app via PLAY first, then try Winetricks again.")
                        .arg(pfx));
                return;
            }
            prefixops::PrefixInfo work = entry;
            if (!resolveProton(work))
                return;
            const QString wineBin = prefixops::findProtonWineBinary(work.protonPath);
            if (wineBin.isEmpty()) {
                QMessageBox::critical(this, tr("Error"),
                                      tr("Could not find the 'wine' binary inside this build:\n%1")
                                          .arg(work.protonPath));
                return;
            }
            QProcessEnvironment env = procutil::cleanEnvironment();
            env.insert(QStringLiteral("WINE"), wineBin);
            const QString wineserver = QFileInfo(wineBin).absolutePath() + QStringLiteral("/wineserver");
            if (QFileInfo::exists(wineserver))
                env.insert(QStringLiteral("WINESERVER"), wineserver);
            env.insert(QStringLiteral("WINEPREFIX"), pfx);

            const QString task = QStringLiteral("winetricks-%1-%2").arg(work.runner, work.code);
            QString error;
            if (!m_launcher->launchCommand(task, QStringLiteral("winetricks"), verbs, env,
                                           QDir::homePath(), &error)) {
                QMessageBox::critical(this, tr("Error"),
                                      tr("Failed to launch Winetricks:\n%1").arg(error));
                return;
            }
            auto* log = new LogWindow(m_launcher, task, this);
            log->setAttribute(Qt::WA_DeleteOnClose);
            log->show();
            log->raise();
            emit statusMessage(tr("Running Winetricks for prefix %1...").arg(work.code), true);
        } else {
            QProcessEnvironment env = procutil::cleanEnvironment();
            env.insert(QStringLiteral("WINEPREFIX"), entry.path);
            const QString task = QStringLiteral("winetricks-wine-%1").arg(entry.code);
            QString error;
            if (!m_launcher->launchCommand(task, QStringLiteral("winetricks"), verbs, env,
                                           QDir::homePath(), &error)) {
                QMessageBox::critical(this, tr("Error"),
                                      tr("Failed to launch Winetricks:\n%1").arg(error));
                return;
            }
            auto* log = new LogWindow(m_launcher, task, this);
            log->setAttribute(Qt::WA_DeleteOnClose);
            log->show();
            log->raise();
            emit statusMessage(tr("Running Winetricks for prefix %1...").arg(entry.code), true);
        }
    };

    WinetricksDialog dlg(entry.code, this);
    connect(&dlg, &WinetricksDialog::runRequested, this, run);
    connect(&dlg, &WinetricksDialog::interactiveRequested, this,
            [run] { run(QStringList()); });
    dlg.exec();
}

void PrefixManagerDialog::openFolder(const prefixops::PrefixInfo& entry)
{
    if (!QFileInfo(entry.path).isDir()) {
        QMessageBox::critical(this, tr("Error"), tr("Folder not found:\n%1").arg(entry.path));
        return;
    }
    QProcess::startDetached(QStringLiteral("xdg-open"), {entry.path});
}

void PrefixManagerDialog::backupPrefix(const prefixops::PrefixInfo& entry)
{
    if (m_taskBusy) {
        QMessageBox::warning(this, tr("Backup/Restore Busy"),
                             tr("A backup/restore is already running (%1).").arg(m_taskLabel));
        return;
    }
    if (!QFileInfo(entry.path).isDir()) {
        QMessageBox::critical(this, tr("Error"),
                              tr("Prefix folder not found on disk:\n%1").arg(entry.path));
        return;
    }

    QList<prefixops::GameBackupInfo> games = prefixops::gatherBackupInfo(entry);

    QStringList lines;
    lines << tr("Prefix: %1 (%2)").arg(entry.code, prefixops::runnerDisplayName(entry.runner));
    lines << tr("Location: %1").arg(entry.path) << QString();
    if (!games.isEmpty()) {
        lines << tr("Game(s) that will be included:");
        for (const auto& g : games) {
            QString tag;
            if (g.missing)
                tag = tr("  (folder not found on disk - will be SKIPPED)");
            else if (g.insidePrefix)
                tag = tr("  (already inside the prefix - no extra space needed)");
            else
                tag = tr("  (backed up separately)");
            lines << QStringLiteral("  - %1%2").arg(g.scriptName, tag);
        }
    } else {
        lines << tr("No game is currently linked to this prefix - only the prefix itself "
                    "will be backed up.");
    }
    lines << QString() << tr("This can take a while and produce a large file. Continue?");

    if (QMessageBox::question(this, tr("Confirm Backup"), lines.join(QLatin1Char('\n')))
        != QMessageBox::Yes)
        return;

    const QString defaultName = QStringLiteral("backup_%1_%2.tar.gz")
                                    .arg(entry.code,
                                         QDateTime::currentDateTime().toString(
                                             QStringLiteral("yyyyMMdd_hhmmss")));
    const QString dest = QFileDialog::getSaveFileName(
        this, tr("Save Backup As"), QDir::homePath() + QLatin1Char('/') + defaultName,
        tr("Backup Archive (*.tar.gz);;All Files (*)"));
    if (dest.isEmpty())
        return;

    QList<prefixops::GameBackupInfo> present;
    QStringList sizePaths = {entry.path};
    for (const auto& g : games) {
        if (g.missing)
            continue;
        present.append(g);
        if (!g.insidePrefix)
            sizePaths << g.folderPath;
        if (g.hasIcon)
            sizePaths << g.iconPath;
    }
    const qint64 total = prefixops::computeTotalSize(sizePaths);

    auto* win = new TaskLogWindow(tr("Backup - %1").arg(entry.code), this, false, true);
    win->setAttribute(Qt::WA_DeleteOnClose);
    auto* task = new BackupTask(win);

    m_taskBusy = true;
    m_taskLabel = tr("Backup - %1").arg(entry.code);
    m_taskWindow = win;

    connect(task, &BackupTask::line, win, &TaskLogWindow::appendLine);
    connect(task, &BackupTask::progress, win, &TaskLogWindow::setProgress);
    connect(win, &TaskLogWindow::cancelRequested, task, &BackupTask::cancel);
    connect(task, &BackupTask::finished, this,
            [this, win, entry](bool ok, const QString& error, bool cancelled) {
                win->markFinished();
                m_taskBusy = false;
                m_taskWindow = nullptr;
                if (cancelled) {
                    emit statusMessage(tr("Backup of '%1' cancelled.").arg(entry.code), false);
                } else if (ok) {
                    emit statusMessage(tr("Backup of '%1' completed.").arg(entry.code), true);
                } else {
                    QMessageBox::critical(win, tr("Backup Failed"),
                                          tr("Backup failed:\n%1").arg(error));
                    emit statusMessage(tr("Backup failed: %1").arg(error), false);
                }
            });

    win->show();
    task->start(entry, present, dest, total);
}

void PrefixManagerDialog::restoreBackup()
{
    if (m_taskBusy) {
        QMessageBox::warning(this, tr("Backup/Restore Busy"),
                             tr("A backup/restore is already running (%1).").arg(m_taskLabel));
        return;
    }

    const QString archive = QFileDialog::getOpenFileName(
        this, tr("Select Backup Archive"), QDir::homePath(),
        tr("Backup Archive (*.tar.gz *.tgz);;All Files (*)"));
    if (archive.isEmpty())
        return;

    QString error;
    const QJsonObject manifest = prefixops::readBackupManifest(archive, &error);
    if (!error.isEmpty()) {
        QMessageBox::critical(this, tr("Error"),
                              tr("Could not read the backup:\n%1").arg(error));
        return;
    }

    const QString runner = manifest.value(QStringLiteral("runner")).toString();
    const QString origCode = manifest.value(QStringLiteral("prefix_code")).toString();
    if (runner.isEmpty() || origCode.isEmpty()) {
        QMessageBox::critical(this, tr("Error"), tr("The backup manifest is missing information."));
        return;
    }

    QStringList insideNames, externalNames;
    for (const QJsonValue& v : manifest.value(QStringLiteral("games")).toArray()) {
        const QJsonObject g = v.toObject();
        const QString name = g.value(QStringLiteral("script_name")).toString();
        if (g.value(QStringLiteral("inside_prefix")).toBool())
            insideNames << name;
        else
            externalNames << name;
    }

    QSet<QString> knownCodes;
    const QJsonObject rc = runnerconfig::load();
    for (auto it = rc.constBegin(); it != rc.constEnd(); ++it)
        knownCodes.insert(it.value().toObject().value(QStringLiteral("prefix_code")).toString());
    const QJsonObject reg = prefixreg::loadRegistry();
    for (auto it = reg.constBegin(); it != reg.constEnd(); ++it)
        knownCodes.insert(it.value().toObject().value(QStringLiteral("prefix_code")).toString());

    const QString suggested = knownCodes.contains(origCode)
        ? prefixreg::generateNextPrefixCode(runner)
        : origCode;

    RestoreBackupDialog dlg(QFileInfo(archive).fileName(),
                            prefixops::runnerDisplayName(runner), insideNames, externalNames,
                            suggested, origCode, prefixreg::getPrefixBaseDir(runner), this);
    if (dlg.exec() != QDialog::Accepted)
        return;

    const QString prefixCode = dlg.prefixCode();
    const QString targetPrefix = dlg.prefixDestBase() + QLatin1Char('/') + prefixCode;
    const QString gamesDest = dlg.gamesDestBase();

    // Conflict checks.
    QStringList conflicting;
    for (const QJsonValue& v : manifest.value(QStringLiteral("games")).toArray()) {
        const QString name = v.toObject().value(QStringLiteral("script_name")).toString();
        if (QFileInfo::exists(paths::bashlaunch() + QLatin1Char('/') + name + QStringLiteral(".sh")))
            conflicting << name;
    }
    if (!conflicting.isEmpty()
        && QMessageBox::question(this, tr("Replace Existing Game(s)?"),
                                 tr("The following game(s) already exist and will be REPLACED:\n\n"
                                    "  - %1\n\nReplace them?")
                                     .arg(conflicting.join(QStringLiteral("\n  - "))))
               != QMessageBox::Yes)
        return;

    if (QFileInfo(targetPrefix).isDir()
        && !QDir(targetPrefix).entryList(QDir::AllEntries | QDir::NoDotAndDotDot).isEmpty()
        && QMessageBox::question(this, tr("Replace Existing Prefix?"),
                                 tr("A prefix folder already exists at:\n%1\n\n"
                                    "Its contents will be REPLACED. Continue?")
                                     .arg(targetPrefix))
               != QMessageBox::Yes)
        return;

    auto* win = new TaskLogWindow(tr("Restore - %1").arg(prefixCode), this, false, true);
    win->setAttribute(Qt::WA_DeleteOnClose);
    auto* task = new RestoreTask(win);

    m_taskBusy = true;
    m_taskLabel = tr("Restore - %1").arg(prefixCode);
    m_taskWindow = win;

    connect(task, &RestoreTask::line, win, &TaskLogWindow::appendLine);
    connect(task, &RestoreTask::progress, win, &TaskLogWindow::setProgress);
    connect(win, &TaskLogWindow::cancelRequested, task, &RestoreTask::cancel);
    connect(task, &RestoreTask::finished, this,
            [this, win, prefixCode](bool ok, const QString& err, bool cancelled) {
                win->markFinished();
                m_taskBusy = false;
                m_taskWindow = nullptr;
                if (cancelled) {
                    emit statusMessage(tr("Restore of '%1' cancelled.").arg(prefixCode), false);
                } else if (ok) {
                    emit statusMessage(tr("Restore of '%1' completed.").arg(prefixCode), true);
                    refreshList();
                    emit dataChanged();
                } else {
                    QMessageBox::critical(win, tr("Restore Failed"),
                                          tr("Restore failed:\n%1").arg(err));
                    emit statusMessage(tr("Restore failed: %1").arg(err), false);
                }
            });

    win->show();
    task->start(archive, manifest, runner, prefixCode, targetPrefix, gamesDest, 0);
}

void PrefixManagerDialog::removePrefixEntry(prefixops::PrefixInfo entry)
{
    QStringList inside, outside;
    for (const QString& name : entry.games) {
        const QString scriptPath =
            paths::bashlaunch() + QLatin1Char('/') + name + QStringLiteral(".sh");
        const QString folder = shortcut::extractFolderPath(scriptPath);
        bool isInside = false;
        if (!folder.isEmpty()) {
            const QString fr = QDir::cleanPath(QFileInfo(folder).canonicalFilePath().isEmpty()
                                                   ? QFileInfo(folder).absoluteFilePath()
                                                   : QFileInfo(folder).canonicalFilePath());
            QString pr = QDir::cleanPath(entry.path);
            if (fr == pr || fr.startsWith(pr + QLatin1Char('/')))
                isInside = true;
        }
        (isInside ? inside : outside).append(name);
    }

    QStringList lines;
    lines << tr("Prefix: %1 (%2)").arg(entry.code, prefixops::runnerDisplayName(entry.runner));
    lines << tr("Location: %1").arg(entry.path) << QString();
    if (!entry.games.isEmpty()) {
        lines << tr("The following game(s)/app(s) using this prefix will be removed:");
        for (const QString& name : entry.games) {
            const QString tag = inside.contains(name)
                ? tr("  (installed inside this prefix - its files will also be DELETED)")
                : tr("  (files elsewhere are kept - only removed from the launcher)");
            lines << QStringLiteral("  - %1%2").arg(name, tag);
        }
        lines << QString();
    } else {
        lines << tr("No game/app is currently linked to this prefix.") << QString();
    }
    lines << tr("This will permanently delete the prefix folder from disk. "
                "This cannot be undone.\n\nContinue?");

    if (QMessageBox::question(this, tr("Remove Prefix & Game(s)?"), lines.join(QLatin1Char('\n')))
        != QMessageBox::Yes)
        return;

    if (!inside.isEmpty()
        && QMessageBox::question(this, tr("Confirm File Deletion"),
                                 tr("This will PERMANENTLY DELETE the installed files for:\n\n"
                                    "  - %1\n\nAre you absolutely sure?")
                                     .arg(inside.join(QStringLiteral("\n  - "))))
               != QMessageBox::Yes)
        return;

    QString error;
    if (!prefixops::removePrefix(entry, nullptr, &error)) {
        QMessageBox::critical(this, tr("Error"), error);
        return;
    }

    emit statusMessage(tr("Removed prefix '%1' and %2 game(s)/app(s).")
                           .arg(entry.code)
                           .arg(entry.games.size()),
                       true);
    refreshList();
    emit dataChanged();
}

void PrefixManagerDialog::movePrefix(const prefixops::PrefixInfo& selectedEntry)
{
    prefixops::PrefixInfo entry = selectedEntry;

    if (!QFileInfo(entry.path).isDir()) {
        QMessageBox::critical(this, tr("Error"),
                              tr("Prefix folder not found on disk:\n%1").arg(entry.path));
        return;
    }

    // A Proton entry that only links to a shared prefix: the real prefix is what
    // moves (every runner using it keeps working, links are updated).
    const QFileInfo pfxLink(entry.path + QStringLiteral("/pfx"));
    if (pfxLink.isSymLink() && pfxLink.exists()) {
        entry.path = prefixlink::canonical(entry.path + QStringLiteral("/pfx"));
        QMessageBox::information(
            this, tr("Shared Prefix"),
            tr("This runner uses a prefix shared with other runners, stored at:\n%1\n\n"
               "That prefix will be moved and every game using it is updated.")
                .arg(entry.path));
    }

    // Same chooser as "Browse Other Folder/Disk..." when launching a game:
    // use an existing prefix, or put the (moved) prefix in a chosen place.
    const prefixpicker::Pick pick = prefixpicker::pickFolder(
        this, tr("Choose New Location for Prefix %1").arg(entry.code),
        QFileInfo(entry.path).absolutePath(), entry.code);
    if (pick.action == prefixpicker::Action::Cancel)
        return;

    if (pick.action == prefixpicker::Action::UseExisting) {
        useExistingPrefixInstead(selectedEntry, pick.folder);
        return;
    }

    const QString newPath = QDir::cleanPath(
        pick.action == prefixpicker::Action::UseFolderAsNew
            ? pick.folder
            : pick.folder + QLatin1Char('/') + entry.code);

    if (newPath == QDir::cleanPath(entry.path)) {
        QMessageBox::information(this, tr("Info"), tr("The prefix is already in this location."));
        return;
    }
    if (newPath.startsWith(prefixlink::canonical(entry.path) + QLatin1Char('/'))) {
        QMessageBox::critical(this, tr("Error"),
                              tr("A prefix cannot be moved into itself."));
        return;
    }
    if (pick.action == prefixpicker::Action::NewSubfolder && QFileInfo::exists(newPath)) {
        QMessageBox::critical(this, tr("Error"),
                              tr("A folder named '%1' already exists in that location.")
                                  .arg(entry.code));
        return;
    }

    if (QMessageBox::question(this, tr("Confirm Move"),
                              tr("Move prefix '%1' to:\n%2\n\n"
                                 "Make sure the game using this prefix is not running.\n"
                                 "This may take a while. Continue?")
                                  .arg(entry.code, newPath))
        != QMessageBox::Yes)
        return;

    auto* win = new TaskLogWindow(tr("Moving Prefix"), this);
    win->setAttribute(Qt::WA_DeleteOnClose);
    auto* task = new MoveTask(win);
    connect(task, &MoveTask::line, win, &TaskLogWindow::appendLine);
    connect(task, &MoveTask::finished, this,
            [this, win, entry](bool ok, const QString& error, const QStringList& relinked) {
                win->markFinished();
                if (!ok) {
                    QMessageBox::critical(win, tr("Error"),
                                          tr("Failed to move prefix:\n%1").arg(error));
                    emit statusMessage(tr("Error moving prefix: %1").arg(error), false);
                    return;
                }
                QString msg = tr("Prefix '%1' moved.").arg(entry.code);
                if (!relinked.isEmpty())
                    msg = tr("Prefix moved - relinked %1 game(s): %2")
                              .arg(relinked.size())
                              .arg(relinked.join(QStringLiteral(", ")));
                emit statusMessage(msg, true);
                refreshList();
                emit dataChanged();
            });
    win->show();
    task->start(entry.path, newPath, entry.runner, entry.code);
}

// Point the games of `entry` at an EXISTING prefix instead of moving files. The
// old prefix stays on disk untouched; nothing inside either prefix is copied or
// overwritten.
void PrefixManagerDialog::useExistingPrefixInstead(const prefixops::PrefixInfo& entry,
                                                   const QString& folder)
{
    if (prefixlink::canonical(prefixlink::winePrefixDir(folder))
        == prefixlink::canonical(prefixlink::winePrefixDir(entry.path))) {
        QMessageBox::information(this, tr("Info"), tr("The prefix is already in this location."));
        return;
    }

    if (QMessageBox::question(
            this, tr("Use Existing Prefix"),
            tr("The game(s) of prefix '%1' will use the existing prefix at:\n%2\n\n"
               "Nothing is moved, copied or overwritten - the old prefix stays on disk.\n"
               "Make sure the game is not running. Continue?")
                .arg(entry.code, folder))
        != QMessageBox::Yes)
        return;

    const prefixlink::Resolved r = prefixlink::useExisting(entry.runner, folder, {},
                                                           entry.protonName, entry.protonPath);
    if (!r.ok) {
        QMessageBox::critical(this, tr("Error"), r.error);
        emit statusMessage(tr("Error: %1").arg(r.error), false);
        return;
    }

    const QStringList updated = prefixops::repointGames(entry.runner, entry.code, r.code, r.path);
    emit statusMessage(tr("Now using prefix '%1' - relinked %2 game(s).")
                           .arg(r.code)
                           .arg(updated.size()),
                       true);
    refreshList();
    emit dataChanged();
}

void PrefixManagerDialog::showLogs()
{
    if (!m_taskWindow) {
        QMessageBox::information(this, tr("Show Logs"),
                                 tr("No backup or restore process is currently running."));
        return;
    }
    m_taskWindow->show();
    m_taskWindow->raise();
    m_taskWindow->activateWindow();
}
