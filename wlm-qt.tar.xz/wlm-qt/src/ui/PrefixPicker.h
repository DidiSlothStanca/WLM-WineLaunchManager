#pragma once

#include "core/Proton.h"
#include "core/PrefixOps.h"
#include "core/RunnerConfig.h"

#include <QDialog>
#include <QList>
#include <optional>

class QComboBox;
class QLabel;
class QRadioButton;
class QPushButton;

// Shared "choose a prefix folder" behaviour used by the Launch (Runner) dialog,
// the Add Game dialog and "Move Prefix" in the Prefix Configuration Manager.
//
// After the user browses to a folder WLM asks what to do with it instead of
// blindly creating a prefix inside it:
//   - the folder already is a Wine/Proton prefix -> use it as-is (saves,
//     configuration and installed apps are kept), or pick another folder;
//   - the folder is not a prefix -> create the new prefix right there (when the
//     folder is empty) or in a new sub-folder, or pick another folder.
namespace prefixpicker {

enum class Action {
    Cancel,
    UseExisting,    // `folder` is an existing prefix: use it as it is
    UseFolderAsNew, // create the new prefix directly in `folder`
    NewSubfolder,   // create the new prefix in `folder/<subfolderName>`
};

struct Pick {
    Action action = Action::Cancel;
    QString folder;
};

Pick pickFolder(QWidget* parent, const QString& title, const QString& startDir,
                const QString& subfolderName);

} // namespace prefixpicker

// Asked when a game is added manually: which runner and prefix should it use?
// The prefix the game is installed in is pre-selected when one is found, but the
// user can also create a brand new (optionally custom location) prefix first.
class PrefixSelectDialog : public QDialog {
    Q_OBJECT
public:
    // `owner`: prefix already registered in WLM that contains the exe (if any).
    // `detected`: unregistered prefix folder found around the exe (if any).
    PrefixSelectDialog(QWidget* parent, const QString& gameName,
                       const std::optional<prefixops::PrefixInfo>& owner,
                       const QString& detectedPrefixPath);

    // Final choice (runner, Proton build, prefix code/path). Valid after accept().
    RunnerChoice choice() const { return m_choice; }
    QString summary() const { return m_summary; }

private:
    void onRunnerChanged();
    void refreshLabels();
    void browseCustom();
    void acceptSelection();

    struct Custom {
        prefixpicker::Action action = prefixpicker::Action::Cancel;
        QString folder;
    };

    QString runnerKey() const;
    std::optional<Proton::Build> selectedBuild() const;

    std::optional<prefixops::PrefixInfo> m_owner;
    QString m_detected; // unregistered prefix path around the exe
    QString m_existingPath; // prefix to reuse for the first radio (owner or detected)
    QString m_existingCode;

    QList<Proton::Build> m_geBuilds;
    QList<Proton::Build> m_cachyBuilds;

    QComboBox* m_runnerCombo = nullptr;
    QComboBox* m_buildCombo = nullptr;
    QLabel* m_buildLabel = nullptr;

    QRadioButton* m_useFound = nullptr;
    QRadioButton* m_useSystem = nullptr;
    QRadioButton* m_newDefault = nullptr;
    QRadioButton* m_custom = nullptr;
    QLabel* m_foundInfo = nullptr;
    QLabel* m_defaultInfo = nullptr;
    QLabel* m_customInfo = nullptr;
    QPushButton* m_browseBtn = nullptr;

    Custom m_customPick;
    RunnerChoice m_choice;
    QString m_summary;
};
