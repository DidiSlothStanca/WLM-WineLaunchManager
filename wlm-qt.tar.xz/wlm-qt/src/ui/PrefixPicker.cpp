#include "ui/PrefixPicker.h"

#include "core/PrefixLink.h"
#include "core/PrefixRegistry.h"

#include <QComboBox>
#include <QDir>
#include <QFileDialog>
#include <QFileInfo>
#include <QHBoxLayout>
#include <QLabel>
#include <QMessageBox>
#include <QPushButton>
#include <QRadioButton>
#include <QVBoxLayout>

namespace prefixpicker {

Pick pickFolder(QWidget* parent, const QString& title, const QString& startDir,
                const QString& subfolderName)
{
    QString start = startDir;
    while (true) {
        const QString chosen = QFileDialog::getExistingDirectory(
            parent, title, start.isEmpty() ? QDir::homePath() : start);
        if (chosen.isEmpty())
            return {};
        start = chosen;

        const prefixlink::Kind kind = prefixlink::classify(chosen);

        QMessageBox box(parent);
        box.setIcon(QMessageBox::Question);
        box.setWindowTitle(QObject::tr("Prefix Folder"));

        QPushButton* useBtn = nullptr;
        QPushButton* hereBtn = nullptr;
        QPushButton* subBtn = nullptr;

        if (kind != prefixlink::Kind::NotAPrefix) {
            box.setText(QObject::tr("This folder already is a Wine/Proton prefix:\n%1\n\n"
                                    "Use it as it is? Its saves, configuration and installed "
                                    "apps are kept and nothing is overwritten.")
                            .arg(chosen));
            useBtn = box.addButton(QObject::tr("Use This Prefix"), QMessageBox::AcceptRole);
        } else {
            const bool empty = QDir(chosen).isEmpty(QDir::AllEntries | QDir::NoDotAndDotDot
                                                    | QDir::Hidden);
            box.setText(QObject::tr("This folder is not a prefix yet:\n%1\n\n"
                                    "Create a new prefix for the game here?")
                            .arg(chosen));
            if (empty)
                hereBtn = box.addButton(QObject::tr("Create New Prefix Here"),
                                        QMessageBox::AcceptRole);
            subBtn = box.addButton(QObject::tr("Create New Prefix in Sub-folder '%1'")
                                       .arg(subfolderName),
                                   QMessageBox::AcceptRole);
        }
        QPushButton* otherBtn =
            box.addButton(QObject::tr("Choose Another Folder"), QMessageBox::ActionRole);
        box.addButton(QMessageBox::Cancel);
        box.exec();

        QAbstractButton* clicked = box.clickedButton();
        if (clicked == otherBtn)
            continue;
        if (useBtn && clicked == useBtn)
            return {Action::UseExisting, chosen};
        if (hereBtn && clicked == hereBtn)
            return {Action::UseFolderAsNew, chosen};
        if (subBtn && clicked == subBtn)
            return {Action::NewSubfolder, chosen};
        return {};
    }
}

} // namespace prefixpicker

// ---------------------------------------------------------------------------
// PrefixSelectDialog
// ---------------------------------------------------------------------------

namespace {

QLabel* mutedLabel(const QString& text)
{
    auto* l = new QLabel(text);
    l->setProperty("muted", true);
    l->setWordWrap(true);
    return l;
}

} // namespace

PrefixSelectDialog::PrefixSelectDialog(QWidget* parent, const QString& gameName,
                                       const std::optional<prefixops::PrefixInfo>& owner,
                                       const QString& detectedPrefixPath)
    : QDialog(parent)
    , m_owner(owner)
    , m_detected(detectedPrefixPath)
{
    setWindowTitle(tr("Prefix for New Game"));
    setModal(true);
    setWindowFlags(windowFlags() | Qt::Window);

    m_geBuilds = Proton::findProtonGEInstallations();
    m_cachyBuilds = Proton::findProtonCachyOSInstallations();

    if (m_owner) {
        m_existingPath = m_owner->path;
        m_existingCode = m_owner->code;
    } else if (!m_detected.isEmpty()) {
        m_existingPath = m_detected;
    }

    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(15, 15, 15, 15);
    root->setSpacing(8);

    auto* title = new QLabel(tr("Which prefix should '%1' use?").arg(gameName));
    QFont f = title->font();
    f.setBold(true);
    title->setFont(f);
    title->setWordWrap(true);
    root->addWidget(title);

    // --- runner ---
    root->addWidget(mutedLabel(tr("Runner:")));
    m_runnerCombo = new QComboBox;
    m_runnerCombo->addItem(tr("Wine (Vanilla)"), QStringLiteral("wine"));
    m_runnerCombo->addItem(tr("Proton GE"), QStringLiteral("protonge"));
    m_runnerCombo->addItem(tr("Proton-CachyOS"), QStringLiteral("protoncachyos"));
    root->addWidget(m_runnerCombo);

    m_buildLabel = mutedLabel(tr("Proton version:"));
    m_buildCombo = new QComboBox;
    root->addWidget(m_buildLabel);
    root->addWidget(m_buildCombo);

    // --- prefix choices ---
    root->addWidget(mutedLabel(tr("Prefix:")));

    m_useFound = new QRadioButton(m_owner ? tr("Use the prefix this game is installed in")
                                          : tr("Use the prefix found around the game"));
    m_foundInfo = mutedLabel(QString());
    m_useSystem = new QRadioButton(tr("System default Wine prefix (~/.wine)"));
    m_newDefault = new QRadioButton(tr("Create a new prefix in the WLM folder"));
    m_defaultInfo = mutedLabel(QString());
    m_custom = new QRadioButton(tr("Create a new prefix / use an existing prefix elsewhere"));
    m_customInfo = mutedLabel(QString());
    m_browseBtn = new QPushButton(tr("Browse Other Folder/Disk..."));

    root->addWidget(m_useFound);
    root->addWidget(m_foundInfo);
    root->addWidget(m_useSystem);
    root->addWidget(m_newDefault);
    root->addWidget(m_defaultInfo);
    root->addWidget(m_custom);
    root->addWidget(m_customInfo);
    root->addWidget(m_browseBtn, 0, Qt::AlignLeft);

    const bool haveFound = !m_existingPath.isEmpty();
    m_useFound->setVisible(haveFound);
    m_foundInfo->setVisible(haveFound);

    auto* buttons = new QHBoxLayout;
    buttons->addStretch(1);
    auto* okBtn = new QPushButton(tr("Add Game"));
    okBtn->setObjectName(QStringLiteral("Accent"));
    auto* cancelBtn = new QPushButton(tr("Cancel"));
    buttons->addWidget(okBtn);
    buttons->addWidget(cancelBtn);
    root->addLayout(buttons);

    // Pre-select runner from a registered owner.
    if (m_owner) {
        const int idx = m_runnerCombo->findData(m_owner->runner);
        if (idx >= 0)
            m_runnerCombo->setCurrentIndex(idx);
    }
    onRunnerChanged();

    if (haveFound)
        m_useFound->setChecked(true);
    else
        m_newDefault->setChecked(true);

    connect(m_runnerCombo, QOverload<int>::of(&QComboBox::currentIndexChanged), this,
            [this] { onRunnerChanged(); });
    connect(m_browseBtn, &QPushButton::clicked, this, &PrefixSelectDialog::browseCustom);
    connect(okBtn, &QPushButton::clicked, this, &PrefixSelectDialog::acceptSelection);
    connect(cancelBtn, &QPushButton::clicked, this, &QDialog::reject);
}

QString PrefixSelectDialog::runnerKey() const
{
    return m_runnerCombo->currentData().toString();
}

std::optional<Proton::Build> PrefixSelectDialog::selectedBuild() const
{
    const QString key = runnerKey();
    if (key == QLatin1String("wine"))
        return std::nullopt;
    const QList<Proton::Build>& builds = key == QLatin1String("protonge") ? m_geBuilds : m_cachyBuilds;
    const int idx = m_buildCombo->currentIndex();
    if (idx < 0 || idx >= builds.size())
        return std::nullopt;
    return builds.at(idx);
}

void PrefixSelectDialog::onRunnerChanged()
{
    const QString key = runnerKey();
    const bool proton = key != QLatin1String("wine");

    m_buildCombo->clear();
    if (proton) {
        const QList<Proton::Build>& builds =
            key == QLatin1String("protonge") ? m_geBuilds : m_cachyBuilds;
        for (const Proton::Build& b : builds)
            m_buildCombo->addItem(b.name);
        if (builds.isEmpty())
            m_buildCombo->addItem(tr("(None yet - Extract via Settings menu)"));
        else if (m_owner && m_owner->runner == key && !m_owner->protonName.isEmpty()) {
            const int idx = m_buildCombo->findText(m_owner->protonName);
            if (idx >= 0)
                m_buildCombo->setCurrentIndex(idx);
        }
    }
    m_buildLabel->setVisible(proton);
    m_buildCombo->setVisible(proton);

    // "System default" only exists for vanilla Wine.
    m_useSystem->setVisible(!proton);
    if (proton && m_useSystem->isChecked())
        m_newDefault->setChecked(true);

    refreshLabels();
}

void PrefixSelectDialog::refreshLabels()
{
    const QString key = runnerKey();
    m_foundInfo->setText(tr("Location: %1\nSaves and settings of apps already installed there "
                            "are kept.").arg(m_existingPath));
    m_defaultInfo->setText(tr("A new prefix will be created automatically in:\n%1 (e.g. %2)")
                               .arg(prefixreg::getPrefixBaseDir(key),
                                    prefixreg::generateNextPrefixCode(key)));

    switch (m_customPick.action) {
    case prefixpicker::Action::UseExisting:
        m_customInfo->setText(tr("Use existing prefix:\n%1").arg(m_customPick.folder));
        break;
    case prefixpicker::Action::UseFolderAsNew:
        m_customInfo->setText(tr("New prefix will be created in:\n%1").arg(m_customPick.folder));
        break;
    case prefixpicker::Action::NewSubfolder:
        m_customInfo->setText(
            tr("New prefix will be created inside:\n%1").arg(m_customPick.folder));
        break;
    case prefixpicker::Action::Cancel:
        m_customInfo->setText(tr("Not chosen yet - click Browse."));
        break;
    }
}

void PrefixSelectDialog::browseCustom()
{
    const QString key = runnerKey();
    const prefixpicker::Pick pick = prefixpicker::pickFolder(
        this, tr("Choose Prefix Folder"), prefixreg::getPrefixBaseDir(key),
        prefixreg::generateNextPrefixCode(key));
    if (pick.action == prefixpicker::Action::Cancel)
        return;
    m_customPick.action = pick.action;
    m_customPick.folder = pick.folder;
    m_custom->setChecked(true);
    refreshLabels();
}

void PrefixSelectDialog::acceptSelection()
{
    const QString key = runnerKey();
    const bool proton = key != QLatin1String("wine");

    std::optional<Proton::Build> build;
    if (proton) {
        build = selectedBuild();
        if (!build) {
            QMessageBox::warning(this, tr("Error"),
                                 tr("No Proton build found. Extract one first via the Settings menu."));
            return;
        }
    }
    const QString pn = build ? build->name : QString();
    const QString pp = build ? build->path : QString();

    RunnerChoice c;
    c.runner = key;
    c.protonName = pn;
    c.protonPath = pp;

    if (!m_useSystem->isHidden() && m_useSystem->isChecked()) {
        // No explicit prefix: plain `wine` with the system default.
        m_choice = c;
        m_summary = tr("system default Wine prefix");
        accept();
        return;
    }

    prefixlink::Resolved r;
    if (!m_useFound->isHidden() && m_useFound->isChecked()) {
        const QString preferred = (m_owner && m_owner->runner == key) ? m_existingCode : QString();
        r = prefixlink::useExisting(key, m_existingPath, preferred, pn, pp);
    } else if (m_custom->isChecked()) {
        switch (m_customPick.action) {
        case prefixpicker::Action::UseExisting:
            r = prefixlink::useExisting(key, m_customPick.folder, {}, pn, pp);
            break;
        case prefixpicker::Action::UseFolderAsNew:
            r = prefixlink::createNew(key, m_customPick.folder, {}, pn, pp);
            break;
        case prefixpicker::Action::NewSubfolder: {
            const QString code = prefixreg::generateNextPrefixCode(key);
            r = prefixlink::createNew(key, QDir(m_customPick.folder).filePath(code), code, pn, pp);
            break;
        }
        case prefixpicker::Action::Cancel:
            QMessageBox::information(this, tr("Prefix"),
                                     tr("Click \"Browse Other Folder/Disk...\" to choose a folder first."));
            return;
        }
    } else {
        const QString code = prefixreg::generateNextPrefixCode(key);
        r = prefixlink::createNew(key, QDir(prefixreg::getPrefixBaseDir(key)).filePath(code),
                                  code, pn, pp);
    }

    if (!r.ok) {
        QMessageBox::critical(this, tr("Error"), r.error);
        return;
    }
    c.prefixCode = r.code;
    c.prefixPath = r.path;
    m_choice = c;
    m_summary = tr("prefix %1").arg(r.code);
    accept();
}
