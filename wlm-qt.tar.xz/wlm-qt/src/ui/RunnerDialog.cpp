#include "ui/RunnerDialog.h"

#include "core/PrefixLink.h"
#include "core/PrefixRegistry.h"
#include "ui/PrefixPicker.h"

#include <QCheckBox>
#include <QComboBox>
#include <QDir>
#include <QFileInfo>
#include <QFrame>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QMessageBox>
#include <QPushButton>
#include <QRadioButton>
#include <QStackedWidget>
#include <QVBoxLayout>

namespace {

QFrame* makeSeparator()
{
    auto* line = new QFrame;
    line->setFrameShape(QFrame::HLine);
    line->setFrameShadow(QFrame::Plain);
    return line;
}

QLabel* mutedLabel(const QString& text)
{
    auto* l = new QLabel(text);
    l->setProperty("muted", true);
    l->setWordWrap(true);
    return l;
}

} // namespace

QString RunnerDialog::runnerKeyAt(int idx)
{
    switch (idx) {
    case 1:  return QStringLiteral("protonge");
    case 2:  return QStringLiteral("protoncachyos");
    default: return QStringLiteral("wine");
    }
}

RunnerDialog::RunnerDialog(QWidget* parent, const QString& gameTitle,
                           const QString& existingName, bool forSetup)
    : QDialog(parent)
    , m_existingName(existingName)
    , m_gameTitle(gameTitle)
    , m_forSetup(forSetup)
{
    setWindowTitle(forSetup ? tr("Select Runner - Setup") : tr("Select Runner - Play"));
    setWindowFlags(windowFlags() | Qt::Window);

    if (!m_existingName.isEmpty())
        m_existing = runnerconfig::get(m_existingName);

    m_geBuilds = Proton::findProtonGEInstallations();
    m_cachyBuilds = Proton::findProtonCachyOSInstallations();

    buildUi();
    updateRunnerPage();
}

bool RunnerDialog::hasExistingPrefix() const
{
    return !m_existing.prefixCode.isEmpty() && !m_existing.prefixPath.isEmpty();
}

bool RunnerDialog::keepExistingPrefix() const
{
    return hasExistingPrefix() && m_keepPrefix && m_keepPrefix->isChecked();
}

void RunnerDialog::buildUi()
{
    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(15, 15, 15, 15);
    root->setSpacing(8);

    const QString title = m_gameTitle.isEmpty()
        ? tr("Select Runner - Game:")
        : tr("Select Runner - %1:").arg(m_gameTitle);
    auto* titleLabel = new QLabel(title);
    titleLabel->setWordWrap(true);
    QFont f = titleLabel->font();
    f.setBold(true);
    titleLabel->setFont(f);
    root->addWidget(titleLabel);

    // --- runner radios ---
    auto* radioRow = new QHBoxLayout;
    m_wineRadio = new QRadioButton(tr("Wine (Vanilla)"));
    m_geRadio = new QRadioButton(tr("Proton GE"));
    m_cachyRadio = new QRadioButton(tr("Proton-CachyOS"));
    radioRow->addWidget(m_wineRadio);
    radioRow->addWidget(m_geRadio);
    radioRow->addWidget(m_cachyRadio);
    radioRow->addStretch(1);
    root->addLayout(radioRow);

    if (m_geBuilds.isEmpty())
        m_geRadio->setEnabled(false);
    if (m_cachyBuilds.isEmpty())
        m_cachyRadio->setEnabled(false);

    // --- keep current prefix (only when the game already has one) ---
    m_keepPrefix = new QCheckBox(
        tr("Keep this game's current prefix when changing runner / Proton version\n"
           "(saves and settings are shared - nothing is copied or overwritten)"));
    m_keepPrefix->setChecked(true);
    m_keepPrefix->setVisible(hasExistingPrefix());
    root->addWidget(m_keepPrefix);

    // --- stacked runner pages ---
    m_pages = new QStackedWidget;
    root->addWidget(m_pages);

    auto makeButtons = [this](int idx, QVBoxLayout* pageLayout) {
        auto* row = new QHBoxLayout;
        auto* browse = new QPushButton(tr("Browse Other Folder/Disk..."));
        auto* def = new QPushButton(tr("Use Default (WLM Folder)"));
        row->addWidget(browse);
        row->addWidget(def);
        row->addStretch(1);
        pageLayout->addLayout(row);
        connect(browse, &QPushButton::clicked, this, [this, idx] { browsePrefix(idx); });
        connect(def, &QPushButton::clicked, this, [this, idx] { useDefaultPrefix(idx); });
    };

    // Wine page
    auto* winePage = new QWidget;
    auto* wineLayout = new QVBoxLayout(winePage);
    wineLayout->setContentsMargins(0, 4, 0, 4);
    m_wineUsePrefix = new QCheckBox(
        tr("Use an isolated prefix for this game (avoids buildup in home folder)"));
    m_info[0] = mutedLabel(QString());
    wineLayout->addWidget(m_wineUsePrefix);
    wineLayout->addWidget(m_info[0]);
    makeButtons(0, wineLayout);
    wineLayout->addStretch(1);
    m_pages->addWidget(winePage);

    // Proton GE page
    auto* gePage = new QWidget;
    auto* geLayout = new QVBoxLayout(gePage);
    geLayout->setContentsMargins(0, 4, 0, 4);
    geLayout->addWidget(mutedLabel(tr("Proton GE Version:")));
    m_geCombo = new QComboBox;
    for (const Proton::Build& b : m_geBuilds)
        m_geCombo->addItem(b.name);
    if (m_geBuilds.isEmpty())
        m_geCombo->addItem(tr("(None yet - Extract via Settings menu)"));
    geLayout->addWidget(m_geCombo);
    m_info[1] = mutedLabel(QString());
    geLayout->addWidget(m_info[1]);
    makeButtons(1, geLayout);
    geLayout->addStretch(1);
    m_pages->addWidget(gePage);

    // Proton-CachyOS page
    auto* cachyPage = new QWidget;
    auto* cachyLayout = new QVBoxLayout(cachyPage);
    cachyLayout->setContentsMargins(0, 4, 0, 4);
    cachyLayout->addWidget(mutedLabel(tr("Proton-CachyOS Version:")));
    m_cachyCombo = new QComboBox;
    for (const Proton::Build& b : m_cachyBuilds)
        m_cachyCombo->addItem(b.name);
    if (m_cachyBuilds.isEmpty())
        m_cachyCombo->addItem(tr("(None yet - Extract via Settings menu)"));
    cachyLayout->addWidget(m_cachyCombo);
    m_info[2] = mutedLabel(QString());
    cachyLayout->addWidget(m_info[2]);
    makeButtons(2, cachyLayout);
    cachyLayout->addStretch(1);
    m_pages->addWidget(cachyPage);

    // Preselect combo entries matching the existing config.
    if (m_existing.runner == QLatin1String("protonge") && !m_existing.protonName.isEmpty()) {
        const int idx = m_geCombo->findText(m_existing.protonName);
        if (idx >= 0)
            m_geCombo->setCurrentIndex(idx);
    }
    if (m_existing.runner == QLatin1String("protoncachyos") && !m_existing.protonName.isEmpty()) {
        const int idx = m_cachyCombo->findText(m_existing.protonName);
        if (idx >= 0)
            m_cachyCombo->setCurrentIndex(idx);
    }

    root->addWidget(makeSeparator());

    root->addWidget(mutedLabel(tr("Launch Options / Environment Variable (optional):")));
    m_launchOptions = new QLineEdit;
    m_launchOptions->setText(m_existing.launchOptions);
    root->addWidget(m_launchOptions);
    root->addWidget(mutedLabel(tr("Example: PROTON_USE_WINED3D=1 MANGOHUD=1")));

    root->addWidget(mutedLabel(tr("Comment (optional):")));
    m_comment = new QLineEdit;
    m_comment->setText(m_existing.comment);
    root->addWidget(m_comment);

    auto* buttonRow = new QHBoxLayout;
    auto* cancelBtn = new QPushButton(tr("Cancel"));
    auto* savesBtn = new QPushButton(tr("Saves..."));
    auto* okBtn = new QPushButton(tr("OK"));
    okBtn->setObjectName(QStringLiteral("Accent"));
    // Saves only makes sense once the game has a prefix (i.e. it was launched at
    // least once) - mirrors the Python play dialog.
    savesBtn->setVisible(!m_forSetup && !m_existingName.isEmpty()
                         && !m_existing.prefixPath.isEmpty());
    buttonRow->addWidget(cancelBtn);
    buttonRow->addWidget(savesBtn);
    buttonRow->addStretch(1);
    buttonRow->addWidget(okBtn);
    root->addLayout(buttonRow);
    connect(savesBtn, &QPushButton::clicked, this, &RunnerDialog::savesRequested);

    // --- signals ---
    connect(m_wineRadio, &QRadioButton::toggled, this, &RunnerDialog::updateRunnerPage);
    connect(m_geRadio, &QRadioButton::toggled, this, &RunnerDialog::updateRunnerPage);
    connect(m_cachyRadio, &QRadioButton::toggled, this, &RunnerDialog::updateRunnerPage);
    connect(m_wineUsePrefix, &QCheckBox::toggled, this, &RunnerDialog::updateRunnerPage);
    connect(m_keepPrefix, &QCheckBox::toggled, this, &RunnerDialog::updateRunnerPage);

    connect(cancelBtn, &QPushButton::clicked, this, &QDialog::reject);
    connect(okBtn, &QPushButton::clicked, this, &RunnerDialog::acceptChoice);

    // Initial runner selection.
    const bool geAvailable = !m_geBuilds.isEmpty();
    const bool cachyAvailable = !m_cachyBuilds.isEmpty();
    if (m_existing.runner == QLatin1String("protonge") && geAvailable)
        m_geRadio->setChecked(true);
    else if (m_existing.runner == QLatin1String("protoncachyos") && cachyAvailable)
        m_cachyRadio->setChecked(true);
    else
        m_wineRadio->setChecked(true);

    // Wine needs an explicit prefix whenever the game already has one (own or
    // shared from a Proton runner), otherwise it would fall back to ~/.wine.
    m_wineUsePrefix->setChecked(hasExistingPrefix());
}

QString RunnerDialog::infoTextFor(int idx) const
{
    const QString key = runnerKeyAt(idx);
    const PrefixSel& s = m_sel[idx];

    if (s.mode == PrefixSel::UseExisting)
        return tr("Using existing prefix (content is kept as it is):\n%1").arg(s.path);
    if (s.mode == PrefixSel::CreateNew)
        return tr("A new prefix will be created at:\n%1").arg(s.path);

    if (keepExistingPrefix()) {
        if (m_existing.runner == key) {
            return tr("Prefix: %1 (used previously, kept consistent)\nLocation: %2")
                .arg(m_existing.prefixCode, m_existing.prefixPath);
        }
        return tr("Prefix %1 is SHARED with this runner - saves and settings stay the same,\n"
                  "nothing is copied or overwritten.\nLocation: %2")
            .arg(m_existing.prefixCode, prefixlink::winePrefixDir(m_existing.prefixPath));
    }

    return tr("A new prefix will be created automatically at:\n%1 (e.g. %2)")
        .arg(prefixreg::getPrefixBaseDir(key), prefixreg::generateNextPrefixCode(key));
}

void RunnerDialog::updateRunnerPage()
{
    if (m_wineRadio->isChecked())
        m_pages->setCurrentIndex(0);
    else if (m_geRadio->isChecked())
        m_pages->setCurrentIndex(1);
    else
        m_pages->setCurrentIndex(2);

    for (int i = 0; i < 3; ++i)
        m_info[i]->setText(infoTextFor(i));
    m_info[0]->setVisible(m_wineUsePrefix->isChecked());
}

void RunnerDialog::browsePrefix(int idx)
{
    const QString key = runnerKeyAt(idx);
    const QString label = idx == 0 ? tr("Wine") : idx == 1 ? tr("Proton GE") : tr("Proton-CachyOS");

    // Start where the game's prefix (or the default base) lives.
    QString start = prefixreg::getPrefixBaseDir(key);
    if (hasExistingPrefix())
        start = QFileInfo(m_existing.prefixPath).absolutePath();

    const QString subCode = prefixreg::generateNextPrefixCode(key);
    const prefixpicker::Pick pick = prefixpicker::pickFolder(
        this, tr("Choose Prefix Folder - %1").arg(label), start, subCode);

    PrefixSel sel;
    switch (pick.action) {
    case prefixpicker::Action::Cancel:
        return;
    case prefixpicker::Action::UseExisting:
        sel.mode = PrefixSel::UseExisting;
        sel.path = pick.folder;
        break;
    case prefixpicker::Action::UseFolderAsNew:
        sel.mode = PrefixSel::CreateNew;
        sel.path = pick.folder;
        sel.code = prefixlink::suggestCode(pick.folder);
        break;
    case prefixpicker::Action::NewSubfolder:
        sel.mode = PrefixSel::CreateNew;
        sel.code = subCode;
        sel.path = QDir(pick.folder).filePath(subCode);
        break;
    }
    m_sel[idx] = sel;
    if (idx == 0)
        m_wineUsePrefix->setChecked(true);
    updateRunnerPage();
}

void RunnerDialog::useDefaultPrefix(int idx)
{
    // Back to automatic: keep the game's own prefix, or a new one in the WLM folder.
    prefixreg::resetPrefixBaseDir(runnerKeyAt(idx));
    m_sel[idx] = PrefixSel();
    if (idx == 0 && !hasExistingPrefix())
        m_wineUsePrefix->setChecked(true);
    updateRunnerPage();
}

bool RunnerDialog::resolvePrefix(int idx, const Proton::Build& build, QString* code,
                                 QString* path, QString* error)
{
    const QString key = runnerKeyAt(idx);
    const PrefixSel& s = m_sel[idx];

    prefixlink::Resolved r;
    if (s.mode == PrefixSel::UseExisting) {
        r = prefixlink::useExisting(key, s.path, {}, build.name, build.path);
    } else if (s.mode == PrefixSel::CreateNew) {
        r = prefixlink::createNew(key, s.path, s.code, build.name, build.path);
    } else if (keepExistingPrefix()) {
        if (m_existing.runner == key) {
            // Same runner family: identical prefix, only the Proton build may change.
            QDir().mkpath(m_existing.prefixPath);
            prefixreg::recordPrefixUsage(key, m_existing.prefixCode, m_existing.prefixPath,
                                         build.name, build.path);
            r.ok = true;
            r.code = m_existing.prefixCode;
            r.path = m_existing.prefixPath;
        } else {
            // Different runner: share the very same prefix (no copy, no overwrite).
            QString source = m_existing.prefixPath;
            const bool fromProton = m_existing.runner == QLatin1String("protonge")
                || m_existing.runner == QLatin1String("protoncachyos");
            if (key == QLatin1String("wine") && fromProton
                && prefixlink::classify(source) == prefixlink::Kind::NotAPrefix) {
                // Proton prefix that was never started: Wine gets its pfx folder.
                source += QStringLiteral("/pfx");
                QDir().mkpath(source);
            }
            r = prefixlink::useExisting(key, source, m_existing.prefixCode, build.name, build.path);
        }
    } else {
        const QString newCode = prefixreg::generateNextPrefixCode(key);
        r = prefixlink::createNew(key, QDir(prefixreg::getPrefixBaseDir(key)).filePath(newCode),
                                  newCode, build.name, build.path);
    }

    if (!r.ok) {
        if (error)
            *error = r.error;
        return false;
    }
    *code = r.code;
    *path = r.path;
    return true;
}

void RunnerDialog::acceptChoice()
{
    RunnerChoice c;
    c.launchOptions = m_launchOptions->text().trimmed();
    c.comment = m_comment->text().trimmed();

    if (m_wineRadio->isChecked()) {
        c.runner = QStringLiteral("wine");
        if (m_wineUsePrefix->isChecked()) {
            QString code, path, error;
            if (!resolvePrefix(0, {}, &code, &path, &error)) {
                QMessageBox::critical(this, tr("Error"), error);
                return;
            }
            c.prefixCode = code;
            c.prefixPath = path;
        }
        m_choice = c;
        accept();
        return;
    }

    const bool ge = m_geRadio->isChecked();
    const QString runnerKey = ge ? QStringLiteral("protonge") : QStringLiteral("protoncachyos");
    const QString label = ge ? tr("Proton GE") : tr("Proton-CachyOS");
    const QList<Proton::Build>& builds = ge ? m_geBuilds : m_cachyBuilds;

    if (builds.isEmpty()) {
        QMessageBox::warning(this, tr("Error"),
                             tr("%1 not found. Extract it first via the Settings menu.").arg(label));
        return;
    }

    const int idx = ge ? m_geCombo->currentIndex() : m_cachyCombo->currentIndex();
    if (idx < 0 || idx >= builds.size())
        return;
    const Proton::Build build = builds.at(idx);

    QString code, path, error;
    if (!resolvePrefix(ge ? 1 : 2, build, &code, &path, &error)) {
        QMessageBox::critical(this, tr("Error"), error);
        return;
    }

    c.runner = runnerKey;
    c.protonName = build.name;
    c.protonPath = build.path;
    c.prefixCode = code;
    c.prefixPath = path;
    m_choice = c;
    accept();
}
