#!/usr/bin/env bash
# Build wlm-qt and package it as a .deb (no AppImage / RPM).
# Usage: packaging/build-deb.sh
set -euo pipefail

cd "$(dirname "$0")/.."
VERSION="$(grep -m1 -oP 'VERSION\s+\K[0-9]+\.[0-9]+\.[0-9]+' CMakeLists.txt)"
DEB_VERSION="${VERSION}~beta"          # 0.4.8-Beta  ->  0.4.8~beta
ARCH="$(dpkg --print-architecture)"
STAGE="$PWD/build-deb/pkg"

rm -rf build-deb && mkdir -p build-deb
cmake -S . -B build-deb/build -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=/usr
cmake --build build-deb/build
DESTDIR="$STAGE" cmake --install build-deb/build

mkdir -p "$STAGE/usr/share/applications" "$STAGE/DEBIAN"
cat > "$STAGE/usr/share/applications/wlm-qt.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=Wine Launch Manager
Comment=Launch games with Wine, Proton GE and Proton-CachyOS
Exec=wlm-qt
Icon=wine
Terminal=false
Categories=Game;
DESK

cat > "$STAGE/DEBIAN/control" <<CTL
Package: wlm-qt
Version: ${DEB_VERSION}
Section: games
Priority: optional
Architecture: ${ARCH}
Depends: libqt6core6, libqt6gui6, libqt6widgets6, libqt6network6, zlib1g
Recommends: wine, winetricks, libqt6webenginewidgets6
Maintainer: Didi Sloth Stanca
Description: Wine Launch Manager (Qt/C++) ${VERSION}-Beta
 Game launcher for Wine, Proton GE and Proton-CachyOS with shared prefixes.
CTL

dpkg-deb --build --root-owner-group "$STAGE" "build-deb/wlm-qt_${DEB_VERSION}_${ARCH}.deb"
echo "Done: build-deb/wlm-qt_${DEB_VERSION}_${ARCH}.deb"
