#include "ui/GogCoverGrid.h"

#include "core/Paths.h"

#include <QColor>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QFont>
#include <QIcon>
#include <QImage>
#include <QListWidget>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QPainter>
#include <QPixmap>
#include <QRegularExpression>
#include <QResizeEvent>
#include <QScrollBar>
#include <QVBoxLayout>

GogCoverGrid::GogCoverGrid(gog::GogClient* client, const gog::Config& cfg, QWidget* parent)
    : QWidget(parent)
    , m_client(client)
    , m_cfg(cfg)
    , m_nam(new QNetworkAccessManager(this))
{
    m_cardW = qBound(120, cfg.cardWidth, 400);
    m_cardH = qMax(80, int(m_cardW * cfg.coverRatio));

    auto* layout = new QVBoxLayout(this);
    layout->setContentsMargins(0, 0, 0, 0);

    m_list = new QListWidget(this);
    m_list->setViewMode(QListView::IconMode);
    m_list->setMovement(QListView::Static);
    m_list->setResizeMode(QListWidget::Adjust);
    m_list->setWordWrap(true);
    m_list->setSpacing(8);
    m_list->setSelectionMode(QAbstractItemView::SingleSelection);
    m_list->setIconSize(QSize(m_cardW, m_cardH));
    m_list->setGridSize(QSize(m_cardW + 28, m_cardH + 52));
    layout->addWidget(m_list);

    connect(m_list, &QListWidget::itemDoubleClicked, this,
            [this](QListWidgetItem*) { emit activated(); });
    connect(m_list->verticalScrollBar(), &QScrollBar::valueChanged, this,
            [this](int) { scheduleVisible(); });
}

QString GogCoverGrid::coverBaseUrl(const QString& image) const
{
    QString s = image.trimmed();
    if (s.isEmpty())
        return {};
    if (s.startsWith(QStringLiteral("//")))
        s = QStringLiteral("https:") + s;
    else if (s.startsWith(QStringLiteral("http://")))
        s = QStringLiteral("https://") + s.mid(7);
    else if (!s.startsWith(QStringLiteral("https://")))
        s = QStringLiteral("https://images.gog.com/") + QString(s).remove(QRegularExpression(QStringLiteral("^/+")));
    static const QRegularExpression ext(
        QStringLiteral("\\.(?:jpe?g|png|webp)$"),
        QRegularExpression::CaseInsensitiveOption);
    return QString(s).remove(ext);
}

void GogCoverGrid::setGames(const QVector<gog::Game>& games)
{
    m_games = games;
    m_indexById.clear();
    for (int i = 0; i < m_games.size(); ++i)
        m_indexById.insert(m_games.at(i).id, i);
    rebuildGrid();
}

QPixmap GogCoverGrid::placeholder(const QString& title) const
{
    QPixmap px(m_cardW, m_cardH);
    px.fill(QColor(60, 66, 78));
    const QString letter = title.trimmed().isEmpty() ? QStringLiteral("?")
                                                     : title.trimmed().left(1).toUpper();
    QPainter p(&px);
    p.setPen(QColor(210, 214, 222));
    QFont f = p.font();
    f.setPointSize(qMax(14, m_cardH / 4));
    f.setBold(true);
    p.setFont(f);
    p.drawText(px.rect(), Qt::AlignCenter, letter);
    return px;
}

void GogCoverGrid::rebuildGrid()
{
    m_list->clear();
    m_queued.clear();
    m_loading.clear();
    m_queue.clear();
    m_active = 0;

    for (const gog::Game& g : m_games) {
        auto* item = new QListWidgetItem(g.title, m_list);
        item->setData(Qt::UserRole, g.id);
        item->setData(Qt::UserRole + 1, g.image);
        item->setData(Qt::UserRole + 2, false);
        item->setTextAlignment(Qt::AlignHCenter | Qt::AlignTop);
        item->setToolTip(g.title);
        item->setIcon(QIcon(placeholder(g.title)));
    }
    scheduleVisible();
}

void GogCoverGrid::setFilter(const QString& needle)
{
    const QString n = needle.trimmed().toLower();
    for (int i = 0; i < m_list->count(); ++i) {
        QListWidgetItem* item = m_list->item(i);
        item->setHidden(!(n.isEmpty() || item->text().toLower().contains(n)));
    }
    scheduleVisible();
}

QString GogCoverGrid::selectedId() const
{
    const QList<QListWidgetItem*> sel = m_list->selectedItems();
    return sel.isEmpty() ? QString() : sel.first()->data(Qt::UserRole).toString();
}

void GogCoverGrid::selectById(const QString& id)
{
    for (int i = 0; i < m_list->count(); ++i) {
        QListWidgetItem* item = m_list->item(i);
        if (item->data(Qt::UserRole).toString() == id) {
            item->setSelected(true);
            m_list->scrollToItem(item);
            break;
        }
    }
}

void GogCoverGrid::clearSelection()
{
    m_list->clearSelection();
}

void GogCoverGrid::resizeEvent(QResizeEvent* event)
{
    QWidget::resizeEvent(event);
    scheduleVisible();
}

void GogCoverGrid::scheduleVisible()
{
    if (m_games.isEmpty())
        return;
    const QRect viewport = m_list->viewport()->rect();
    for (int i = 0; i < m_list->count(); ++i) {
        QListWidgetItem* item = m_list->item(i);
        if (item->isHidden() || item->data(Qt::UserRole + 2).toBool())
            continue;
        const QString id = item->data(Qt::UserRole).toString();
        if (m_queued.contains(id) || m_loading.contains(id))
            continue;
        if (!m_list->visualItemRect(item).intersects(viewport))
            continue;
        m_queue.append(id);
        m_queued.insert(id);
    }
    pump();
}

void GogCoverGrid::pump()
{
    while (m_active < 4 && !m_queue.isEmpty()) {
        const QString id = m_queue.takeFirst();
        m_queued.remove(id);
        if (m_loading.contains(id))
            continue;
        const auto it = m_indexById.constFind(id);
        if (it == m_indexById.constEnd())
            continue;
        m_loading.insert(id);
        ++m_active;
        fetchCover(m_games.at(*it), 0);
    }
}

bool GogCoverGrid::loadCached(const gog::Game& game, QPixmap* out)
{
    const QString path = paths::gogCovers() + QLatin1Char('/') + game.id + QStringLiteral(".jpg");
    if (!QFileInfo::exists(path))
        return false;
    QPixmap px;
    if (!px.load(path))
        return false;
    *out = px;
    return true;
}

void GogCoverGrid::markResolved(const QString& id)
{
    if (QListWidgetItem* item = m_list->item(m_indexById.value(id)))
        item->setData(Qt::UserRole + 2, true);
    m_loading.remove(id);
    --m_active;
    pump();
}

void GogCoverGrid::fetchCover(const gog::Game& game, int suffixIndex)
{
    const QString id = game.id;

    if (suffixIndex == 0) {
        QPixmap cached;
        if (loadCached(game, &cached)) {
            if (QListWidgetItem* item = m_list->item(m_indexById.value(id)))
                applyIcon(item, cached);
            markResolved(id);
            return;
        }
    }

    QStringList suffixes = m_cfg.coverSuffixes;
    if (suffixes.isEmpty())
        suffixes << QStringLiteral(".jpg");

    const QString base = coverBaseUrl(game.image);
    if (base.isEmpty() || suffixIndex >= suffixes.size()) {
        markResolved(id);
        return;
    }

    const QString suffix = suffixes.at(suffixIndex);
    QNetworkRequest req{QUrl(base + suffix)};
    req.setHeader(QNetworkRequest::UserAgentHeader, m_cfg.userAgent);
    req.setAttribute(QNetworkRequest::RedirectPolicyAttribute,
                     QNetworkRequest::NoLessSafeRedirectPolicy);
    req.setTransferTimeout(15000);
    QNetworkReply* reply = m_nam->get(req);

    connect(reply, &QNetworkReply::finished, this, [this, reply, game, suffixIndex, suffix] {
        reply->deleteLater();
        const QByteArray data =
            reply->error() == QNetworkReply::NoError ? reply->readAll() : QByteArray();
        QPixmap px;
        if (!data.isEmpty())
            px.loadFromData(data);

        if (px.isNull()) {
            fetchCover(game, suffixIndex + 1);
            return;
        }

        if (data.size() <= 8 * 1024 * 1024) {
            // Cache a small JPEG (max 420x420, quality 88) like load_cover() does.
            const QString dir = paths::gogCovers();
            QDir().mkpath(dir);
            const QString cachePath =
                dir + QLatin1Char('/') + game.id + QStringLiteral(".jpg");
            const QString tmpPath = cachePath + QStringLiteral(".tmp");
            QImage img = px.toImage();
            if (img.width() > 420 || img.height() > 420)
                img = img.scaled(420, 420, Qt::KeepAspectRatio, Qt::SmoothTransformation);
            if (img.save(tmpPath, "JPEG", 88)) {
                QFile::remove(cachePath);
                QFile::rename(tmpPath, cachePath);
            }
        }
        if (QListWidgetItem* item = m_list->item(m_indexById.value(game.id)))
            applyIcon(item, px);
        markResolved(game.id);
    });
}

void GogCoverGrid::applyIcon(QListWidgetItem* item, const QPixmap& px)
{
    if (!item)
        return;
    QPixmap scaled = px.scaled(m_cardW, m_cardH, Qt::KeepAspectRatioByExpanding,
                               Qt::SmoothTransformation);
    if (scaled.width() > m_cardW || scaled.height() > m_cardH) {
        const int x = qMax(0, (scaled.width() - m_cardW) / 2);
        const int y = qMax(0, (scaled.height() - m_cardH) / 2);
        scaled = scaled.copy(x, y, m_cardW, m_cardH);
    }
    item->setIcon(QIcon(scaled));
    item->setData(Qt::UserRole + 2, true);
}
