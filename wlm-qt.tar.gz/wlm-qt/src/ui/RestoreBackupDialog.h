#pragma once

#include <QDialog>
#include <QString>
#include <QStringList>

class QLineEdit;

// Collects the prefix code + destination folders before a backup is restored.
// Port of the inline "Restore Backup" Toplevel in open_restore_backup_dialog().
class RestoreBackupDialog : public QDialog {
    Q_OBJECT
public:
    RestoreBackupDialog(const QString& archiveName, const QString& runnerLabel,
                        const QStringList& insideGames, const QStringList& externalGames,
                        const QString& suggestedCode, const QString& originalCode,
                        const QString& defaultPrefixRoot, QWidget* parent);

    QString prefixCode() const;
    QString prefixDestBase() const;
    QString gamesDestBase() const;

private:
    void buildUi(const QString& archiveName, const QString& runnerLabel,
                 const QStringList& insideGames, const QStringList& externalGames,
                 const QString& suggestedCode, const QString& originalCode,
                 const QString& defaultPrefixRoot);

    QLineEdit* m_code = nullptr;
    QLineEdit* m_prefixDest = nullptr;
    QLineEdit* m_gamesDest = nullptr;
    bool m_hasExternal = false;
};
