#include "ui/LogWindow.h"

#include "core/WindowState.h"

#include "core/GameLauncher.h"

#include <QDesktopServices>
#include <QFile>
#include <QHBoxLayout>
#include <QLabel>
#include <QPlainTextEdit>
#include <QPushButton>
#include <QScrollBar>
#include <QStyle>
#include <QTextCursor>
#include <QUrl>
#include <QVBoxLayout>

LogWindow::LogWindow(GameLauncher* launcher, const QString& name, QWidget* parent)
    : QDialog(parent)
    , m_launcher(launcher)
    , m_name(name)
{
    setWindowTitle(tr("Logs - %1").arg(name));
    resize(800, 500);
    setMinimumSize(400, 250);
    setWindowFlags(windowFlags() | Qt::Window);
    new WindowStateHelper(this, QStringLiteral("log"), QSize(800, 500), QSize(400, 250));

    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(10, 8, 10, 10);
    root->setSpacing(8);

    auto* topBar = new QHBoxLayout;
    auto* title = new QLabel(name);
    QFont tf = title->font();
    tf.setBold(true);
    title->setFont(tf);

    const bool live = launcher->isRunning(name);
    const QString logPath = launcher->logFilePath(name);

    m_state = new QLabel(live ? tr("Running (live)") : tr("Not running (last saved log)"));
    if (live) {
        QPalette p = m_state->palette();
        // Use the theme highlight for "live"; success colour is theme-dependent and
        // applied via the global stylesheet elsewhere, so keep it simple here.
        p.setColor(QPalette::WindowText, QColor(0x34, 0xd3, 0x99));
        m_state->setPalette(p);
    } else {
        m_state->setProperty("muted", true);
    }

    topBar->addWidget(title);
    topBar->addStretch(1);
    topBar->addWidget(m_state);
    root->addLayout(topBar);

    m_view = new QPlainTextEdit;
    m_view->setReadOnly(true);
    m_view->setLineWrapMode(QPlainTextEdit::NoWrap);
    QFont mono(QStringLiteral("Courier"));
    mono.setStyleHint(QFont::TypeWriter);
    mono.setPointSize(9);
    m_view->setFont(mono);
    root->addWidget(m_view, 1);

    auto* bottomBar = new QHBoxLayout;
    auto* clearBtn = new QPushButton(tr("Clear View"));
    auto* openBtn = new QPushButton(tr("Open Log File"));
    bottomBar->addWidget(clearBtn);
    bottomBar->addWidget(openBtn);
    bottomBar->addStretch(1);
    root->addLayout(bottomBar);

    // Initial content: live buffer if any, otherwise the saved log file.
    if (launcher->hasEntry(name) && !launcher->isFinished(name)) {
        const QStringList buf = launcher->buffer(name);
        m_view->setPlainText(buf.isEmpty() ? tr("(waiting for output...)\n")
                                           : buf.join(QLatin1Char('\n')));
    } else if (QFile::exists(logPath)) {
        QFile f(logPath);
        if (f.open(QIODevice::ReadOnly | QIODevice::Text))
            m_view->setPlainText(QString::fromUtf8(f.readAll()));
    } else {
        m_view->setPlainText(tr("(No logs yet - launch this game at least once first)\n"));
    }
    m_view->verticalScrollBar()->setValue(m_view->verticalScrollBar()->maximum());

    connect(clearBtn, &QPushButton::clicked, m_view, &QPlainTextEdit::clear);
    connect(openBtn, &QPushButton::clicked, this, [logPath] {
        if (QFile::exists(logPath))
            QDesktopServices::openUrl(QUrl::fromLocalFile(logPath));
    });

    connect(m_launcher, &GameLauncher::outputAppended, this, &LogWindow::onOutput);
    connect(m_launcher, &GameLauncher::processFinished, this, &LogWindow::onFinished);
}

void LogWindow::appendText(const QString& text)
{
    QScrollBar* sb = m_view->verticalScrollBar();
    const bool wasAtBottom = sb->value() >= sb->maximum() - 2;
    m_view->moveCursor(QTextCursor::End);
    m_view->insertPlainText(text);
    m_view->moveCursor(QTextCursor::End);
    if (wasAtBottom)
        sb->setValue(sb->maximum());
}

void LogWindow::onOutput(const QString& name, const QString& text)
{
    if (name == m_name)
        appendText(text);
}

void LogWindow::onFinished(const QString& name, int exitCode)
{
    Q_UNUSED(exitCode);
    if (name != m_name)
        return;
    if (m_state) {
        m_state->setText(tr("Finished"));
        m_state->setProperty("muted", true);
        m_state->style()->unpolish(m_state);
        m_state->style()->polish(m_state);
    }
}
