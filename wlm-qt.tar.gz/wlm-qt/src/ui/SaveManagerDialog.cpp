#include "ui/SaveManagerDialog.h"

#include "core/Paths.h"

#include <QCloseEvent>
#include <QDesktopServices>
#include <QDir>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QGroupBox>
#include <QGuiApplication>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QLabel>
#include <QMessageBox>
#include <QMoveEvent>
#include <QPlainTextEdit>
#include <QPushButton>
#include <QRegularExpression>
#include <QResizeEvent>
#include <QScreen>
#include <QScrollArea>
#include <QScrollBar>
#include <QShowEvent>
#include <QTimer>
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QUrl>
#include <QVBoxLayout>

#include <algorithm>

namespace {

QLabel* mutedLabel(const QString& text)
{
    auto* l = new QLabel(text);
    l->setProperty("muted", true);
    l->setWordWrap(true);
    return l;
}

void openLocalFolder(const QString& path)
{
    QDir().mkpath(path);
    QDesktopServices::openUrl(QUrl::fromLocalFile(path));
}

void centerOnScreen(QWidget* w)
{
    QScreen* screen = w->screen();
    if (!screen)
        screen = QGuiApplication::primaryScreen();
    if (!screen)
        return;
    const QRect avail = screen->availableGeometry();
    const QSize sz = w->frameSize().isValid() ? w->frameSize() : w->size();
    const int x = avail.x() + qMax(0, (avail.width() - sz.width()) / 2);
    const int y = avail.y() + qMax(0, (avail.height() - sz.height()) / 2);
    w->move(x, y);
}

} // namespace

SaveManagerDialog::SaveManagerDialog(QWidget* parent, const QString& gameName,
                                     const QString& exePath, const RunnerChoice& choice,
                                     std::function<bool()> isRunning)
    : QDialog(parent)
    , m_name(gameName)
    , m_exePath(exePath)
    , m_choice(choice)
    , m_isRunning(std::move(isRunning))
{
    setWindowTitle(tr("Save Manager - %1").arg(gameName));
    setWindowFlags(windowFlags() | Qt::Window);

    m_ctx.name = gameName;
    m_ctx.exePath = exePath;
    m_ctx.dataDir = paths::root();
    m_ctx.choice = m_choice;
    const QPair<QString, QJsonObject> found = gogsaves::findGogGameInfo(exePath);
    m_ctx.infoPath = found.first;
    m_ctx.info = found.second;
    m_isGogCloud = !m_ctx.info.isEmpty()
        && !m_ctx.info.value(QStringLiteral("clientId")).toVariant().toString().isEmpty();

    m_client = new gogsaves::Client(this);

    // Restore the last normal size / maximized state from gog_ui.json "saves".
    int w = 780;
    int h = 700;
    const QJsonObject saved =
        gogsaves::readUiSection(paths::root(), QStringLiteral("saves"));
    static const QRegularExpression sizeRe(QStringLiteral("^(\\d+)x(\\d+)$"));
    const QRegularExpressionMatch m =
        sizeRe.match(saved.value(QStringLiteral("size")).toString());
    if (m.hasMatch()) {
        w = m.captured(1).toInt();
        h = m.captured(2).toInt();
    }
    m_savedMaximized = saved.value(QStringLiteral("maximized")).toBool();
    w = qMax(680, w);
    h = qMax(600, h);
    m_normalSize = QSize(w, h);
    resize(w, h);
    setMinimumSize(680, 600);

    m_saveTimer = new QTimer(this);
    m_saveTimer->setSingleShot(true);
    m_saveTimer->setInterval(700);
    connect(m_saveTimer, &QTimer::timeout, this, &SaveManagerDialog::saveWindowState);

    buildUi();

    refreshBackups();
    refreshLocations(true);
}

SaveManagerDialog::~SaveManagerDialog() = default;

void SaveManagerDialog::buildUi()
{
    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(0, 0, 0, 0);

    auto* scroll = new QScrollArea(this);
    scroll->setWidgetResizable(true);
    scroll->setFrameShape(QFrame::NoFrame);
    root->addWidget(scroll);

    auto* content = new QWidget;
    auto* v = new QVBoxLayout(content);
    v->setContentsMargins(12, 12, 12, 12);
    v->setSpacing(8);

    auto* title = new QLabel(m_name);
    QFont tf = title->font();
    tf.setBold(true);
    title->setFont(tf);
    v->addWidget(title);

    const bool gog = m_choice.source == QLatin1String("gog") || !m_ctx.info.isEmpty();
    const QString srcText = !gog
        ? tr("Non-GOG game - local backup only")
        : (m_isGogCloud ? tr("GOG game - cloud saves available to check")
                        : tr("GOG game - no Galaxy client id found, cloud disabled"));
    v->addWidget(mutedLabel(srcText));

    // ---- Save folders ------------------------------------------------------
    auto* locGroup = new QGroupBox(tr("Save folders"));
    auto* locLay = new QVBoxLayout(locGroup);
    m_locTree = new QTreeWidget;
    m_locTree->setColumnCount(3);
    m_locTree->setHeaderLabels({tr("Name"), tr("Folder"), tr("Files")});
    m_locTree->setRootIsDecorated(false);
    m_locTree->setUniformRowHeights(true);
    m_locTree->setSelectionMode(QAbstractItemView::SingleSelection);
    m_locTree->setFixedHeight(150);
    m_locTree->header()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    m_locTree->header()->setSectionResizeMode(1, QHeaderView::Stretch);
    m_locTree->header()->setSectionResizeMode(2, QHeaderView::ResizeToContents);
    locLay->addWidget(m_locTree);

    auto* locBtns = new QHBoxLayout;
    auto* addBtn = new QPushButton(tr("Add Folder..."));
    auto* remBtn = new QPushButton(tr("Remove Folder"));
    auto* openBtn = new QPushButton(tr("Open Folder"));
    locBtns->addWidget(addBtn);
    locBtns->addWidget(remBtn);
    locBtns->addWidget(openBtn);
    locBtns->addStretch(1);
    locLay->addLayout(locBtns);
    connect(addBtn, &QPushButton::clicked, this, &SaveManagerDialog::doAddFolder);
    connect(remBtn, &QPushButton::clicked, this, &SaveManagerDialog::doRemoveFolder);
    connect(openBtn, &QPushButton::clicked, this, &SaveManagerDialog::doOpenFolder);

    // ---- Local backups ----
    auto* bkGroup = new QGroupBox(tr("Local backups"));
    auto* bkLay = new QVBoxLayout(bkGroup);
    m_bkTree = new QTreeWidget;
    m_bkTree->setColumnCount(3);
    m_bkTree->setHeaderLabels({tr("When"), tr("Note"), tr("Size")});
    m_bkTree->setRootIsDecorated(false);
    m_bkTree->setUniformRowHeights(true);
    m_bkTree->setSelectionMode(QAbstractItemView::SingleSelection);
    m_bkTree->setFixedHeight(170);
    m_bkTree->header()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    m_bkTree->header()->setSectionResizeMode(1, QHeaderView::Stretch);
    m_bkTree->header()->setSectionResizeMode(2, QHeaderView::ResizeToContents);
    bkLay->addWidget(m_bkTree);

    auto* bkBtns = new QHBoxLayout;
    m_backupBtn = new QPushButton(tr("Backup Now"));
    m_restoreBtn = new QPushButton(tr("Restore..."));
    auto* delBtn = new QPushButton(tr("Delete"));
    auto* openBkBtn = new QPushButton(tr("Open Backups Folder"));
    bkBtns->addWidget(m_backupBtn);
    bkBtns->addWidget(m_restoreBtn);
    bkBtns->addWidget(delBtn);
    bkBtns->addWidget(openBkBtn);
    bkBtns->addStretch(1);
    bkLay->addLayout(bkBtns);
    connect(m_backupBtn, &QPushButton::clicked, this, &SaveManagerDialog::doBackup);
    connect(m_restoreBtn, &QPushButton::clicked, this, &SaveManagerDialog::doRestore);
    connect(delBtn, &QPushButton::clicked, this, &SaveManagerDialog::doDeleteBackup);
    connect(openBkBtn, &QPushButton::clicked, this,
            &SaveManagerDialog::doOpenBackupsFolder);

    // ---- GOG cloud saves ----
    auto* cloudGroup = new QGroupBox(tr("GOG cloud saves"));
    auto* cloudLay = new QVBoxLayout(cloudGroup);
    const QString cloudText = m_isGogCloud
        ? tr("Check Cloud compares your cloud saves with the local files (changes "
             "nothing). Download & Overwrite replaces local saves with the cloud "
             "copy. Upload to Cloud replaces the cloud saves with the local copy.")
        : tr("Only GOG games installed by a GOG installer (with a goggame-*.info "
             "file) can use GOG cloud saves.");
    cloudLay->addWidget(mutedLabel(cloudText));

    auto* cloudBtns = new QHBoxLayout;
    m_checkBtn = new QPushButton(tr("Check Cloud"));
    m_downloadBtn = new QPushButton(tr("Download & Overwrite"));
    m_uploadBtn = new QPushButton(tr("Upload to Cloud"));
    cloudBtns->addWidget(m_checkBtn);
    cloudBtns->addWidget(m_downloadBtn);
    cloudBtns->addWidget(m_uploadBtn);
    cloudBtns->addStretch(1);
    cloudLay->addLayout(cloudBtns);
    connect(m_checkBtn, &QPushButton::clicked, this, &SaveManagerDialog::doCheckCloud);
    connect(m_downloadBtn, &QPushButton::clicked, this,
            &SaveManagerDialog::doDownloadCloud);
    connect(m_uploadBtn, &QPushButton::clicked, this, &SaveManagerDialog::doUploadCloud);
    m_checkBtn->setEnabled(m_isGogCloud);
    m_downloadBtn->setEnabled(m_isGogCloud);
    m_uploadBtn->setEnabled(m_isGogCloud);

    // ---- Log ----
    auto* logGroup = new QGroupBox(tr("Log"));
    auto* logLay = new QVBoxLayout(logGroup);
    m_logView = new QPlainTextEdit;
    m_logView->setReadOnly(true);
    m_logView->setMinimumHeight(150);
    QFont mono(QStringLiteral("Courier"));
    mono.setStyleHint(QFont::TypeWriter);
    mono.setPointSize(9);
    m_logView->setFont(mono);
    logLay->addWidget(m_logView);

    auto* closeRow = new QHBoxLayout;
    closeRow->addStretch(1);
    auto* closeBtn = new QPushButton(tr("Close"));
    closeBtn->setObjectName(QStringLiteral("Accent"));
    connect(closeBtn, &QPushButton::clicked, this, &QDialog::close);
    closeRow->addWidget(closeBtn);

    v->addWidget(locGroup);
    v->addWidget(bkGroup);
    v->addWidget(cloudGroup);
    v->addWidget(logGroup);
    v->addLayout(closeRow);

    scroll->setWidget(content);
}

void SaveManagerDialog::showEvent(QShowEvent* event)
{
    QDialog::showEvent(event);
    if (m_geometryReady)
        return;
    m_geometryReady = true;
    if (m_savedMaximized) {
        showMaximized();
    } else {
        centerOnScreen(this);
    }
}

void SaveManagerDialog::closeEvent(QCloseEvent* event)
{
    saveWindowState();
    QDialog::closeEvent(event);
}

void SaveManagerDialog::resizeEvent(QResizeEvent* event)
{
    QDialog::resizeEvent(event);
    if (!isMaximized() && event->size().width() > 100 && event->size().height() > 100)
        m_normalSize = event->size();
    scheduleSave();
}

void SaveManagerDialog::moveEvent(QMoveEvent* event)
{
    QDialog::moveEvent(event);
    scheduleSave();
}

void SaveManagerDialog::scheduleSave()
{
    if (!m_geometryReady || !m_saveTimer)
        return;
    m_saveTimer->start();
}

void SaveManagerDialog::saveWindowState()
{
    const QSize sz = (!isMaximized() && size().width() > 100 && size().height() > 100)
        ? size()
        : m_normalSize;
    if (sz.width() > 100 && sz.height() > 100)
        m_normalSize = sz;

    QJsonObject data;
    data.insert(QStringLiteral("maximized"), isMaximized());
    data.insert(QStringLiteral("size"),
                QStringLiteral("%1x%2").arg(m_normalSize.width()).arg(m_normalSize.height()));
    gogsaves::writeUiSection(paths::root(), QStringLiteral("saves"), data);
}

void SaveManagerDialog::log(const QString& text)
{
    if (!m_logView)
        return;
    m_logView->appendPlainText(text);
    m_logView->verticalScrollBar()->setValue(m_logView->verticalScrollBar()->maximum());
}

void SaveManagerDialog::setBusy(bool busy)
{
    m_busy = busy;
    if (m_backupBtn)
        m_backupBtn->setEnabled(!busy);
    if (m_restoreBtn)
        m_restoreBtn->setEnabled(!busy);
    if (m_checkBtn)
        m_checkBtn->setEnabled(!busy && m_isGogCloud);
    if (m_downloadBtn)
        m_downloadBtn->setEnabled(!busy && m_isGogCloud);
    if (m_uploadBtn)
        m_uploadBtn->setEnabled(!busy && m_isGogCloud);
}

void SaveManagerDialog::refreshLocations(bool refresh)
{
    m_client->buildTargets(
        m_ctx, refresh, [this](const QString& text) { log(text); },
        [this](const QVector<gogsaves::Target>& targets) {
            m_targets = targets;
            m_locTree->clear();
            for (const gogsaves::Target& t : targets) {
                auto* item = new QTreeWidgetItem(m_locTree);
                const bool has = t.hasPath();
                const int n = has ? gogsaves::listFiles(t.path).size() : 0;
                const QString shown = has
                    ? t.path
                    : QStringLiteral("(%1) %2")
                          .arg(t.note.isEmpty() ? tr("not found") : t.note, t.macro);
                item->setText(0, t.kind == QLatin1String("custom")
                                     ? t.name + QStringLiteral(" *")
                                     : t.name);
                item->setText(1, shown);
                item->setText(2, QString::number(n));
            }
            if (m_targets.isEmpty())
                log(tr("No save folders known yet. Use 'Add Folder' to add one manually."));
        });
}

void SaveManagerDialog::refreshBackups()
{
    m_backups = gogsaves::listBackups(paths::root(), m_name);
    m_bkTree->clear();
    for (const gogsaves::Backup& b : m_backups) {
        auto* item = new QTreeWidgetItem(m_bkTree);
        item->setText(0, b.when);
        item->setText(1, b.note);
        item->setText(2, gogsaves::humanSize(b.size));
    }
}

int SaveManagerDialog::selectedTargetIndex() const
{
    QTreeWidgetItem* item = m_locTree->currentItem();
    if (!item)
        return -1;
    const int row = m_locTree->indexOfTopLevelItem(item);
    return (row >= 0 && row < m_targets.size()) ? row : -1;
}

int SaveManagerDialog::selectedBackupIndex() const
{
    QTreeWidgetItem* item = m_bkTree->currentItem();
    if (!item)
        return -1;
    const int row = m_bkTree->indexOfTopLevelItem(item);
    return (row >= 0 && row < m_backups.size()) ? row : -1;
}

bool SaveManagerDialog::gameRunning() const
{
    return m_isRunning ? m_isRunning() : false;
}

void SaveManagerDialog::showInfo(const QString& text)
{
    QMessageBox::information(this, tr("Save Manager"), text);
}

void SaveManagerDialog::showWarning(const QString& text)
{
    QMessageBox::warning(this, tr("Save Manager"), text);
}

void SaveManagerDialog::doAddFolder()
{
    QString start = QDir::homePath();
    if (!m_targets.isEmpty() && m_targets.first().hasPath())
        start = QFileInfo(m_targets.first().path).absolutePath();
    const QString dir = QFileDialog::getExistingDirectory(
        this, tr("Select a save game folder"), start);
    if (dir.isEmpty())
        return;
    QStringList folders = gogsaves::loadCustomFolders(paths::root(), m_name);
    if (!folders.contains(dir)) {
        folders.append(dir);
        gogsaves::saveCustomFolders(paths::root(), m_name, folders);
    }
    refreshLocations(false);
}

void SaveManagerDialog::doRemoveFolder()
{
    const int idx = selectedTargetIndex();
    if (idx < 0 || m_targets.at(idx).kind != QLatin1String("custom")) {
        showInfo(tr("Select a folder you added manually (marked with *)."));
        return;
    }
    const QString path = m_targets.at(idx).path;
    QStringList folders = gogsaves::loadCustomFolders(paths::root(), m_name);
    folders.removeAll(path);
    gogsaves::saveCustomFolders(paths::root(), m_name, folders);
    refreshLocations(false);
}

void SaveManagerDialog::doOpenFolder()
{
    const int idx = selectedTargetIndex();
    if (idx >= 0 && m_targets.at(idx).hasPath()
        && QFileInfo(m_targets.at(idx).path).isDir()) {
        openLocalFolder(m_targets.at(idx).path);
    } else {
        showInfo(tr("Select an existing save folder first."));
    }
}

void SaveManagerDialog::doBackup()
{
    if (m_busy)
        return;
    setBusy(true);
    log(tr("Creating backup..."));
    m_client->makeBackup(
        paths::root(), m_name, m_targets, QStringLiteral("manual"),
        [this](const QString& path, int count, const QString& err) {
            setBusy(false);
            refreshBackups();
            if (!err.isEmpty()) {
                log(tr("Backup failed: %1").arg(err));
                emit statusMessage(tr("Save backup failed: %1").arg(err), false);
            } else {
                const QString fileName = QFileInfo(path).fileName();
                log(tr("Backup created: %1 (%2 file(s))").arg(fileName).arg(count));
                emit statusMessage(tr("Save backup created: %1").arg(fileName), true);
            }
        });
}

void SaveManagerDialog::doRestore()
{
    const int idx = selectedBackupIndex();
    if (idx < 0) {
        showInfo(tr("Select a backup first."));
        return;
    }
    const gogsaves::Backup backup = m_backups.at(idx);
    if (gameRunning()) {
        showWarning(tr("The game is running. Close it before restoring saves."));
        return;
    }
    QMessageBox box(this);
    box.setIcon(QMessageBox::Warning);
    box.setWindowTitle(tr("Restore backup - WARNING"));
    box.setText(tr("Restoring '%1' will OVERWRITE the current save files that have the "
                   "same names.\n\nFiles that are not in the backup are left alone. A "
                   "safety backup of the current saves is created first.\n\nContinue?")
                    .arg(backup.when));
    box.setStandardButtons(QMessageBox::Ok | QMessageBox::Cancel);
    box.setDefaultButton(QMessageBox::Cancel);
    if (box.exec() != QMessageBox::Ok)
        return;

    setBusy(true);
    const QVector<gogsaves::Target> targets = m_targets;
    m_client->makeBackup(
        paths::root(), m_name, targets, QStringLiteral("before-restore"),
        [this, backup, targets](const QString&, int, const QString& backupErr) {
            if (!backupErr.isEmpty())
                log(tr("No safety backup created: %1").arg(backupErr));
            m_client->restoreBackup(
                backup.path, targets, [this](const QString& t) { log(t); },
                [this, backup](int count, const QString& err) {
                    setBusy(false);
                    refreshBackups();
                    refreshLocations(false);
                    if (!err.isEmpty()) {
                        log(tr("Restore failed: %1").arg(err));
                        emit statusMessage(tr("Save restore failed: %1").arg(err), false);
                    } else {
                        log(tr("Restored %1 file(s) from %2.").arg(count).arg(backup.when));
                        emit statusMessage(tr("Restored %1 save file(s).").arg(count), true);
                    }
                });
        });
}

void SaveManagerDialog::doDeleteBackup()
{
    const int idx = selectedBackupIndex();
    if (idx < 0)
        return;
    const gogsaves::Backup backup = m_backups.at(idx);
    if (QMessageBox::question(this, tr("Save Manager"),
                              tr("Delete backup '%1'?").arg(backup.when))
        != QMessageBox::Yes)
        return;
    QFile::remove(backup.path);
    refreshBackups();
}

void SaveManagerDialog::doOpenBackupsFolder()
{
    openLocalFolder(gogsaves::backupsDir(paths::root(), m_name));
}

void SaveManagerDialog::describePlan(const gogsaves::Plan& plan,
                                     gogsaves::Summary& summary)
{
    summary = gogsaves::summarize(plan);
    QString line =
        tr("Cloud: %1 file(s). Identical to local: %2 | would overwrite: %3 (newer "
           "locally: %4) | new: %5")
            .arg(plan.totalCloud)
            .arg(summary.same)
            .arg(summary.overwrite)
            .arg(summary.newerLocal)
            .arg(summary.newCount);
    if (plan.skipped)
        line += tr(" | outside known folders: %1").arg(plan.skipped);
    log(line);
}

void SaveManagerDialog::doCheckCloud()
{
    if (m_busy)
        return;
    setBusy(true);
    m_client->planCloudDownload(
        m_ctx, [this](const QString& t) { log(t); },
        [this](const gogsaves::Plan& plan, const QString& err) {
            setBusy(false);
            if (!err.isEmpty()) {
                log(tr("Cloud check failed: %1").arg(err));
                emit statusMessage(tr("GOG cloud check failed: %1").arg(err), false);
                return;
            }
            gogsaves::Summary summary;
            describePlan(plan, summary);
        });
}

void SaveManagerDialog::doUploadCloud()
{
    if (m_busy)
        return;
    if (gameRunning()) {
        showWarning(
            tr("The game is running. Close it before uploading cloud saves."));
        return;
    }
    setBusy(true);
    m_client->planCloudUpload(
        m_ctx, [this](const QString& t) { log(t); },
        [this](const gogsaves::UploadPlan& plan, const QString& err) {
            if (!err.isEmpty()) {
                setBusy(false);
                log(tr("Cloud upload check failed: %1").arg(err));
                emit statusMessage(tr("GOG cloud upload failed: %1").arg(err), false);
                return;
            }
            const int uploadCount = plan.items.size();
            const int overwrite = static_cast<int>(std::count_if(
                plan.items.cbegin(), plan.items.cend(),
                [](const gogsaves::UploadItem& i) {
                    return i.status == QLatin1String("overwrite");
                }));
            const int newerCloud = static_cast<int>(std::count_if(
                plan.items.cbegin(), plan.items.cend(),
                [](const gogsaves::UploadItem& i) { return i.newerCloud; }));
            log(tr("Local: %1 file(s). Identical to cloud: %2 | will upload: %3 "
                   "(overwrite %4, new %5)")
                    .arg(plan.totalLocal)
                    .arg(plan.skipped)
                    .arg(uploadCount)
                    .arg(overwrite)
                    .arg(uploadCount - overwrite));
            if (uploadCount == 0) {
                setBusy(false);
                log(tr("Nothing to upload - local saves already match the cloud."));
                return;
            }
            QString warn =
                tr("Uploading will OVERWRITE the cloud save files with the copy on "
                   "this PC.\n\n  - %1 file(s) will be uploaded (%2 overwrite, %3 new)")
                    .arg(uploadCount)
                    .arg(overwrite)
                    .arg(uploadCount - overwrite);
            if (newerCloud)
                warn += tr("\n  - !! %1 of them are NEWER in the cloud than on this PC "
                           "!!")
                            .arg(newerCloud);
            warn += tr("\n  - Files that exist only in the cloud are NOT deleted\n\n"
                       "Your local saves are NOT modified by this.\nMake sure the "
                       "game is closed.\n\nContinue?");
            QMessageBox box(this);
            box.setIcon(QMessageBox::Warning);
            box.setWindowTitle(tr("Upload cloud saves - WARNING"));
            box.setText(warn);
            box.setStandardButtons(QMessageBox::Ok | QMessageBox::Cancel);
            box.setDefaultButton(QMessageBox::Cancel);
            if (box.exec() != QMessageBox::Ok) {
                setBusy(false);
                log(tr("Upload cancelled."));
                return;
            }
            log(tr("Uploading cloud saves..."));
            m_client->executeUpload(
                plan, [this](const QString& t) { log(t); },
                [this](int uploaded, int failed, const QString& e) {
                    setBusy(false);
                    refreshLocations(false);
                    if (!e.isEmpty()) {
                        log(tr("Upload failed: %1").arg(e));
                        emit statusMessage(tr("GOG cloud upload failed: %1").arg(e),
                                           false);
                    } else {
                        log(tr("Done: %1 uploaded, %2 failed.").arg(uploaded).arg(failed));
                        emit statusMessage(
                            tr("GOG cloud upload done: %1 uploaded, %2 failed.")
                                .arg(uploaded)
                                .arg(failed),
                            failed == 0);
                    }
                });
        });
}

void SaveManagerDialog::doDownloadCloud()
{
    if (m_busy)
        return;
    if (gameRunning()) {
        showWarning(
            tr("The game is running. Close it before downloading cloud saves."));
        return;
    }
    setBusy(true);
    m_client->planCloudDownload(
        m_ctx, [this](const QString& t) { log(t); },
        [this](const gogsaves::Plan& plan, const QString& err) {
            if (!err.isEmpty()) {
                setBusy(false);
                log(tr("Cloud check failed: %1").arg(err));
                emit statusMessage(tr("GOG cloud check failed: %1").arg(err), false);
                return;
            }
            gogsaves::Summary summary;
            describePlan(plan, summary);
            if (summary.newCount + summary.overwrite == 0) {
                setBusy(false);
                log(tr("Nothing to download - local saves already match the cloud."));
                return;
            }
            QString warn = tr("Downloading will OVERWRITE local save files with the "
                              "cloud copy.\n\n  - %1 file(s) will be overwritten")
                               .arg(summary.overwrite);
            if (summary.newerLocal)
                warn += tr("  (!! %1 of them are NEWER on this PC than in the "
                           "cloud !!)")
                            .arg(summary.newerLocal);
            warn += tr("\n  - %1 new file(s) will be created\n  - %2 will be "
                       "downloaded\n")
                        .arg(summary.newCount)
                        .arg(gogsaves::humanSize(summary.bytes));
            warn += tr("  - Files that exist only on this PC are NOT deleted\n\n"
                       "Your current local saves are backed up first, so you can undo "
                       "this from 'Local backups'.\nMake sure the game is closed.\n\n"
                       "Continue?");

            QMessageBox box(this);
            box.setIcon(QMessageBox::Warning);
            box.setWindowTitle(tr("Download cloud saves - WARNING"));
            box.setText(warn);
            box.setStandardButtons(QMessageBox::Ok | QMessageBox::Cancel);
            box.setDefaultButton(QMessageBox::Cancel);
            if (box.exec() != QMessageBox::Ok) {
                setBusy(false);
                log(tr("Download cancelled."));
                return;
            }

            bool skipNewerLocal = false;
            if (summary.newerLocal) {
                const QMessageBox::StandardButton answer = QMessageBox::question(
                    this, tr("Keep newer local saves?"),
                    tr("%1 local file(s) are newer than the cloud copy.\n\n"
                       "Yes = keep those local files (download only the rest)\n"
                       "No = overwrite them too")
                        .arg(summary.newerLocal));
                skipNewerLocal = (answer == QMessageBox::Yes);
            }

            log(tr("Downloading cloud saves..."));
            m_client->executeDownload(
                m_ctx, plan, [this](const QString& t) { log(t); }, skipNewerLocal,
                [this](int downloaded, int skipped, int failed, const QString& e) {
                    setBusy(false);
                    refreshBackups();
                    refreshLocations(false);
                    if (!e.isEmpty()) {
                        log(tr("Download failed: %1").arg(e));
                        emit statusMessage(tr("GOG cloud download failed: %1").arg(e),
                                           false);
                    } else {
                        log(tr("Done: %1 downloaded, %2 skipped, %3 failed.")
                                .arg(downloaded)
                                .arg(skipped)
                                .arg(failed));
                        emit statusMessage(
                            tr("GOG cloud download done: %1 downloaded, %2 failed.")
                                .arg(downloaded)
                                .arg(failed),
                            failed == 0);
                    }
                });
        });
}
