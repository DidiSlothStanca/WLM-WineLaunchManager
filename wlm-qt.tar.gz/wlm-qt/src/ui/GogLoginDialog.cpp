#include "ui/GogLoginDialog.h"

#include "core/WindowState.h"

#include <QDesktopServices>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QShowEvent>
#include <QVBoxLayout>

#ifdef WLM_HAVE_WEBENGINE
#include <QWebEngineNewWindowRequest>
#include <QWebEnginePage>
#include <QWebEngineProfile>
#include <QWebEngineView>
#endif

#include <cstdio>

namespace {

#ifdef WLM_HAVE_WEBENGINE

// Modern Chrome UA — Google rejects older versions with "browser not secure".
const char kChromeUserAgent[] =
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

// Redirect popups (window.open / target=_blank) into the same view.
const char kPopupFixJs[] = R"JS(
(function () {
  if (window.__wlmFix) return;
  window.__wlmFix = true;
  window.open = function (u) { if (u) { location.href = u; } return null; };
  document.addEventListener('click', function (e) {
    var a = e.target && e.target.closest ? e.target.closest('a[target=_blank]') : null;
    if (a && a.href) { e.preventDefault(); location.href = a.href; }
  }, true);
  document.addEventListener('submit', function (e) {
    if (e.target && e.target.target === '_blank') { e.target.target = '_self'; }
  }, true);
})();
)JS";

bool isBlockedUrl(const QString& url)
{
    return url.contains(QLatin1String("disallowed_useragent"))
        || url.contains(QLatin1String("/signin/rejected"));
}

// Filter harmless console noise from GOG's page (CORS telemetry, WebGPU,
// Permissions-Policy) so the terminal stays clean.
bool shouldSuppressConsole(const QString& message)
{
    static const char* kNoise[] = {
        "insights-collector.gog.com",
        "CORS policy",
        "Cannot send event page_visited",
        "recaptcha-setup",
        "Message action or data is missing",
        "Received message from source not matching",
        "requestStorageAccess",
        "firstIframeLoad",
        "registerGamepadSelectableElements",
        "contentLoaded",
        "inputBlured",
        "ch-ua-form-factors",
        "WebGPU Context Provider",
        "Failed to create WebGPU",
        "Permissions-Policy header",
    };
    for (const char* n : kNoise) {
        if (message.contains(QLatin1String(n)))
            return true;
    }
    return false;
}

// Custom page that filters console noise from GOG's analytics/telemetry.
class LoginPage : public QWebEnginePage {
public:
    LoginPage(QWebEngineProfile* profile, QObject* parent)
        : QWebEnginePage(profile, parent)
    {}

protected:
    void javaScriptConsoleMessage(JavaScriptConsoleMessageLevel level,
                                  const QString& message, int lineNumber,
                                  const QString& sourceID) override
    {
        Q_UNUSED(level);
        Q_UNUSED(lineNumber);
        Q_UNUSED(sourceID);
        if (shouldSuppressConsole(message))
            return; // drop noise
        // Forward anything unexpected to stderr for debugging.
        fprintf(stderr, "[GOG page] %s\n", qPrintable(message));
    }
};

#endif // WLM_HAVE_WEBENGINE

} // namespace

GogLoginDialog::GogLoginDialog(gog::GogClient* client, const gog::Config& cfg, QWidget* parent)
    : QDialog(parent)
    , m_client(client)
    , m_cfg(cfg)
{
    setWindowTitle(tr("GOG Login"));
    setMinimumSize(760, 560);
    setWindowFlags(windowFlags() | Qt::Window
                   | Qt::WindowMinMaxButtonsHint
                   | Qt::WindowCloseButtonHint
                   | Qt::WindowSystemMenuHint);
    new WindowStateHelper(this, QStringLiteral("gog_login"), QSize(760, 560));

    auto* layout = new QVBoxLayout(this);
    layout->setContentsMargins(14, 14, 14, 14);
    layout->setSpacing(8);

    auto* info = new QLabel(
        tr("Sign in to your GOG account below. Your password is only ever typed on "
           "GOG's own page — this launcher never sees it."),
        this);
    info->setWordWrap(true);
    layout->addWidget(info);

#ifdef WLM_HAVE_WEBENGINE
    auto* profile = new QWebEngineProfile(this);
    profile->setHttpUserAgent(QString::fromLatin1(kChromeUserAgent));

    m_view = new QWebEngineView(this);
    auto* page = new LoginPage(profile, m_view);

    connect(page, &QWebEnginePage::newWindowRequested, this,
            [this](QWebEngineNewWindowRequest& request) {
                if (m_view)
                    request.openIn(m_view->page());
            });
    connect(m_view, &QWebEngineView::loadFinished, this, [this](bool ok) {
        if (!m_view)
            return;
        if (ok)
            m_view->page()->runJavaScript(QString::fromLatin1(kPopupFixJs));
    });
    connect(m_view, &QWebEngineView::urlChanged, this,
            [this](const QUrl& url) { handleUrl(url.toString()); });

    m_view->setMinimumHeight(340);
    m_view->setPage(page);
    m_view->setUrl(QUrl(gog::loginUrl(m_cfg)));
    layout->addWidget(m_view, 1);
#endif

    auto* manualLabel = new QLabel(
        tr("If the page above does not work, log in with your normal browser and paste "
           "the resulting address (or just its code= value) here:"),
        this);
    manualLabel->setWordWrap(true);
    layout->addWidget(manualLabel);

    m_manual = new QLineEdit(this);
    m_manual->setPlaceholderText(tr("https://embed.gog.com/on_login_success?...&code=..."));
    layout->addWidget(m_manual);

    auto* row = new QHBoxLayout;
    auto* openBtn = new QPushButton(tr("Open login page in browser"), this);
    openBtn->setObjectName(QStringLiteral("Accent"));
    connect(openBtn, &QPushButton::clicked, this, [this] {
        QDesktopServices::openUrl(QUrl(gog::loginUrl(m_cfg)));
    });
    row->addWidget(openBtn);

    auto* finishBtn = new QPushButton(tr("Finish login"), this);
    connect(finishBtn, &QPushButton::clicked, this, [this] {
        const QString code = gog::extractCode(m_manual->text());
        if (code.isEmpty()) {
            setStatus(tr("That does not look like a GOG redirect URL or code."), true);
            return;
        }
        finishWithCode(code);
    });
    row->addWidget(finishBtn);
    row->addStretch(1);
    layout->addLayout(row);

    m_status = new QLabel(this);
    m_status->setWordWrap(true);
    layout->addWidget(m_status);
}

void GogLoginDialog::showEvent(QShowEvent* event)
{
    QDialog::showEvent(event);
    raise();
    activateWindow();
}

void GogLoginDialog::handleUrl(const QString& url)
{
    if (m_loggedIn)
        return;

    const QString code = gog::extractCode(url);
    if (!code.isEmpty()) {
        finishWithCode(code);
        return;
    }

#ifdef WLM_HAVE_WEBENGINE
    if (isBlockedUrl(url)) {
        setStatus(tr("The provider refused to sign in from the embedded browser. "
                     "Use \"Open login page in browser\" and paste the address here."),
                  true);
    }
#else
    Q_UNUSED(url);
#endif
}

void GogLoginDialog::finishWithCode(const QString& code)
{
    setStatus(tr("Signing in..."), false);
    m_client->exchangeCode(m_cfg, code, [this](bool ok, const QString& err) {
        if (!isVisible())
            return;
        if (ok) {
            m_loggedIn = true;
            setStatus(tr("Login successful."), false);
            accept();
        } else {
            setStatus(tr("Login failed: %1").arg(err), true);
        }
    });
}

void GogLoginDialog::setStatus(const QString& text, bool error)
{
    if (m_status) {
        m_status->setText(text);
        m_status->setStyleSheet(error ? QStringLiteral("color:#c0392b;") : QString());
    }
}
