#pragma once

#include "core/GogSaves.h"
#include "core/RunnerConfig.h"

#include <QDialog>
#include <QSize>
#include <QString>
#include <QVector>

#include <functional>

class QCloseEvent;
class QLabel;
class QPlainTextEdit;
class QPushButton;
class QTimer;
class QTreeWidget;

// Save Manager window: local save backup/restore (tar.gz) plus GOG cloud save
// check / download / upload. Port of gog_saves.open_dialog() (+ cloud upload,
// which the Python version did not have).
//
// The window is non-modal (opened on top of the Play dialog) and all network /
// archive work is event-driven through gogsaves::Client.
class SaveManagerDialog : public QDialog {
    Q_OBJECT
public:
    SaveManagerDialog(QWidget* parent, const QString& gameName, const QString& exePath,
                      const RunnerChoice& choice, std::function<bool()> isRunning);
    ~SaveManagerDialog() override;

signals:
    void statusMessage(const QString& text, bool success);

protected:
    void showEvent(QShowEvent* event) override;
    void closeEvent(QCloseEvent* event) override;
    void resizeEvent(QResizeEvent* event) override;
    void moveEvent(QMoveEvent* event) override;

private:
    void buildUi();
    void log(const QString& text);
    void setBusy(bool busy);
    void refreshLocations(bool refresh);
    void refreshBackups();
    void scheduleSave();
    void saveWindowState();

    void doBackup();
    void doRestore();
    void doDeleteBackup();
    void doOpenBackupsFolder();
    void doAddFolder();
    void doRemoveFolder();
    void doOpenFolder();
    void doCheckCloud();
    void doDownloadCloud();
    void doUploadCloud();
    void describePlan(const gogsaves::Plan& plan, gogsaves::Summary& summary);

    int selectedTargetIndex() const;
    int selectedBackupIndex() const;
    bool gameRunning() const;
    void showInfo(const QString& text);
    void showWarning(const QString& text);

    QString m_name;
    QString m_exePath;
    RunnerChoice m_choice;
    std::function<bool()> m_isRunning;
    gogsaves::Context m_ctx;
    bool m_isGogCloud = false;

    gogsaves::Client* m_client = nullptr;
    QVector<gogsaves::Target> m_targets;
    QVector<gogsaves::Backup> m_backups;
    bool m_busy = false;

    QTreeWidget* m_locTree = nullptr;
    QTreeWidget* m_bkTree = nullptr;
    QPlainTextEdit* m_logView = nullptr;

    QPushButton* m_backupBtn = nullptr;
    QPushButton* m_restoreBtn = nullptr;
    QPushButton* m_checkBtn = nullptr;
    QPushButton* m_downloadBtn = nullptr;
    QPushButton* m_uploadBtn = nullptr;

    // Window geometry (persisted in gog_ui.json under "saves").
    bool m_geometryReady = false;
    bool m_savedMaximized = false;
    QSize m_normalSize;
    QTimer* m_saveTimer = nullptr;
};
