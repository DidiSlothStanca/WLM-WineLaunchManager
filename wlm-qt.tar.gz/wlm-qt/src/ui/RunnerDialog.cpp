#include "ui/RunnerDialog.h"

#include "core/PrefixRegistry.h"

#include <QCheckBox>
#include <QComboBox>
#include <QDir>
#include <QFileDialog>
#include <QFrame>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QMessageBox>
#include <QPushButton>
#include <QRadioButton>
#include <QStackedWidget>
#include <QVBoxLayout>

namespace {

QFrame* makeSeparator()
{
    auto* line = new QFrame;
    line->setFrameShape(QFrame::HLine);
    line->setFrameShadow(QFrame::Plain);
    return line;
}

QLabel* mutedLabel(const QString& text)
{
    auto* l = new QLabel(text);
    l->setProperty("muted", true);
    l->setWordWrap(true);
    return l;
}

} // namespace

RunnerDialog::RunnerDialog(QWidget* parent, const QString& gameTitle,
                           const QString& existingName, bool forSetup)
    : QDialog(parent)
    , m_existingName(existingName)
    , m_gameTitle(gameTitle)
    , m_forSetup(forSetup)
{
    setWindowTitle(forSetup ? tr("Select Runner - Setup") : tr("Select Runner - Play"));
    setWindowFlags(windowFlags() | Qt::Window);

    if (!m_existingName.isEmpty())
        m_existing = runnerconfig::get(m_existingName);

    m_geBuilds = Proton::findProtonGEInstallations();
    m_cachyBuilds = Proton::findProtonCachyOSInstallations();
    m_wineBase = prefixreg::getPrefixBaseDir(QStringLiteral("wine"));
    m_geBase = prefixreg::getPrefixBaseDir(QStringLiteral("protonge"));
    m_cachyBase = prefixreg::getPrefixBaseDir(QStringLiteral("protoncachyos"));

    buildUi();
    updateRunnerPage();
}

void RunnerDialog::buildUi()
{
    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(15, 15, 15, 15);
    root->setSpacing(8);

    const QString title = m_gameTitle.isEmpty()
        ? tr("Select Runner - Game:")
        : tr("Select Runner - %1:").arg(m_gameTitle);
    auto* titleLabel = new QLabel(title);
    titleLabel->setWordWrap(true);
    QFont f = titleLabel->font();
    f.setBold(true);
    titleLabel->setFont(f);
    root->addWidget(titleLabel);

    // --- runner radios ---
    auto* radioRow = new QHBoxLayout;
    m_wineRadio = new QRadioButton(tr("Wine (Vanilla)"));
    m_geRadio = new QRadioButton(tr("Proton GE"));
    m_cachyRadio = new QRadioButton(tr("Proton-CachyOS"));
    radioRow->addWidget(m_wineRadio);
    radioRow->addWidget(m_geRadio);
    radioRow->addWidget(m_cachyRadio);
    radioRow->addStretch(1);
    root->addLayout(radioRow);

    if (m_geBuilds.isEmpty())
        m_geRadio->setEnabled(false);
    if (m_cachyBuilds.isEmpty())
        m_cachyRadio->setEnabled(false);

    // --- stacked runner pages ---
    m_pages = new QStackedWidget;
    root->addWidget(m_pages);

    // Wine page
    auto* winePage = new QWidget;
    auto* wineLayout = new QVBoxLayout(winePage);
    wineLayout->setContentsMargins(0, 4, 0, 4);
    m_wineUsePrefix = new QCheckBox(
        tr("Use an isolated prefix for this game (avoids buildup in home folder)"));
    m_wineInfo = mutedLabel(QString());
    auto* wineButtons = new QHBoxLayout;
    auto* wineBrowse = new QPushButton(tr("Browse Other Folder/Disk..."));
    auto* wineDefault = new QPushButton(tr("Use Default (WLM Folder)"));
    wineButtons->addWidget(wineBrowse);
    wineButtons->addWidget(wineDefault);
    wineButtons->addStretch(1);
    wineLayout->addWidget(m_wineUsePrefix);
    wineLayout->addWidget(m_wineInfo);
    wineLayout->addLayout(wineButtons);
    wineLayout->addStretch(1);
    m_pages->addWidget(winePage);

    // Proton GE page
    auto* gePage = new QWidget;
    auto* geLayout = new QVBoxLayout(gePage);
    geLayout->setContentsMargins(0, 4, 0, 4);
    geLayout->addWidget(mutedLabel(tr("Proton GE Version:")));
    m_geCombo = new QComboBox;
    for (const Proton::Build& b : m_geBuilds)
        m_geCombo->addItem(b.name);
    if (m_geBuilds.isEmpty())
        m_geCombo->addItem(tr("(None yet - Extract via Settings menu)"));
    geLayout->addWidget(m_geCombo);
    m_geInfo = mutedLabel(QString());
    geLayout->addWidget(m_geInfo);
    auto* geButtons = new QHBoxLayout;
    auto* geBrowse = new QPushButton(tr("Browse Other Folder/Disk..."));
    auto* geDefault = new QPushButton(tr("Use Default (WLM Folder)"));
    geButtons->addWidget(geBrowse);
    geButtons->addWidget(geDefault);
    geButtons->addStretch(1);
    geLayout->addLayout(geButtons);
    geLayout->addStretch(1);
    m_pages->addWidget(gePage);

    // Proton-CachyOS page
    auto* cachyPage = new QWidget;
    auto* cachyLayout = new QVBoxLayout(cachyPage);
    cachyLayout->setContentsMargins(0, 4, 0, 4);
    cachyLayout->addWidget(mutedLabel(tr("Proton-CachyOS Version:")));
    m_cachyCombo = new QComboBox;
    for (const Proton::Build& b : m_cachyBuilds)
        m_cachyCombo->addItem(b.name);
    if (m_cachyBuilds.isEmpty())
        m_cachyCombo->addItem(tr("(None yet - Extract via Settings menu)"));
    cachyLayout->addWidget(m_cachyCombo);
    m_cachyInfo = mutedLabel(QString());
    cachyLayout->addWidget(m_cachyInfo);
    auto* cachyButtons = new QHBoxLayout;
    auto* cachyBrowse = new QPushButton(tr("Browse Other Folder/Disk..."));
    auto* cachyDefault = new QPushButton(tr("Use Default (WLM Folder)"));
    cachyButtons->addWidget(cachyBrowse);
    cachyButtons->addWidget(cachyDefault);
    cachyButtons->addStretch(1);
    cachyLayout->addLayout(cachyButtons);
    cachyLayout->addStretch(1);
    m_pages->addWidget(cachyPage);

    // Preselect combo entries matching the existing config.
    if (m_existing.runner == QLatin1String("protonge") && !m_existing.protonName.isEmpty()) {
        const int idx = m_geCombo->findText(m_existing.protonName);
        if (idx >= 0)
            m_geCombo->setCurrentIndex(idx);
    }
    if (m_existing.runner == QLatin1String("protoncachyos") && !m_existing.protonName.isEmpty()) {
        const int idx = m_cachyCombo->findText(m_existing.protonName);
        if (idx >= 0)
            m_cachyCombo->setCurrentIndex(idx);
    }

    root->addWidget(makeSeparator());

    root->addWidget(mutedLabel(tr("Launch Options / Environment Variable (optional):")));
    m_launchOptions = new QLineEdit;
    m_launchOptions->setText(m_existing.launchOptions);
    root->addWidget(m_launchOptions);
    root->addWidget(mutedLabel(tr("Example: PROTON_USE_WINED3D=1 MANGOHUD=1")));

    root->addWidget(mutedLabel(tr("Comment (optional):")));
    m_comment = new QLineEdit;
    m_comment->setText(m_existing.comment);
    root->addWidget(m_comment);

    auto* buttonRow = new QHBoxLayout;
    auto* cancelBtn = new QPushButton(tr("Cancel"));
    auto* savesBtn = new QPushButton(tr("Saves..."));
    auto* okBtn = new QPushButton(tr("OK"));
    okBtn->setObjectName(QStringLiteral("Accent"));
    // Saves only makes sense once the game has a prefix (i.e. it was launched at
    // least once) - mirrors the Python play dialog.
    savesBtn->setVisible(!m_forSetup && !m_existingName.isEmpty()
                         && !m_existing.prefixPath.isEmpty());
    buttonRow->addWidget(cancelBtn);
    buttonRow->addWidget(savesBtn);
    buttonRow->addStretch(1);
    buttonRow->addWidget(okBtn);
    root->addLayout(buttonRow);
    connect(savesBtn, &QPushButton::clicked, this, &RunnerDialog::savesRequested);

    // --- signals ---
    connect(m_wineRadio, &QRadioButton::toggled, this, &RunnerDialog::updateRunnerPage);
    connect(m_geRadio, &QRadioButton::toggled, this, &RunnerDialog::updateRunnerPage);
    connect(m_cachyRadio, &QRadioButton::toggled, this, &RunnerDialog::updateRunnerPage);
    connect(m_wineUsePrefix, &QCheckBox::toggled, this, &RunnerDialog::updateRunnerPage);

    connect(wineBrowse, &QPushButton::clicked, this,
            [this] { browseBaseDir(QStringLiteral("wine"), tr("Wine")); });
    connect(wineDefault, &QPushButton::clicked, this,
            [this] { useDefaultBaseDir(QStringLiteral("wine")); });
    connect(geBrowse, &QPushButton::clicked, this,
            [this] { browseBaseDir(QStringLiteral("protonge"), tr("Proton GE")); });
    connect(geDefault, &QPushButton::clicked, this,
            [this] { useDefaultBaseDir(QStringLiteral("protonge")); });
    connect(cachyBrowse, &QPushButton::clicked, this,
            [this] { browseBaseDir(QStringLiteral("protoncachyos"), tr("Proton-CachyOS")); });
    connect(cachyDefault, &QPushButton::clicked, this,
            [this] { useDefaultBaseDir(QStringLiteral("protoncachyos")); });

    connect(cancelBtn, &QPushButton::clicked, this, &QDialog::reject);
    connect(okBtn, &QPushButton::clicked, this, &RunnerDialog::acceptChoice);

    // Initial runner selection.
    const bool geAvailable = !m_geBuilds.isEmpty();
    const bool cachyAvailable = !m_cachyBuilds.isEmpty();
    if (m_existing.runner == QLatin1String("protonge") && geAvailable)
        m_geRadio->setChecked(true);
    else if (m_existing.runner == QLatin1String("protoncachyos") && cachyAvailable)
        m_cachyRadio->setChecked(true);
    else
        m_wineRadio->setChecked(true);

    m_wineUsePrefix->setChecked(m_existing.runner == QLatin1String("wine")
                                && !m_existing.prefixPath.isEmpty());
}

void RunnerDialog::updateRunnerPage()
{
    if (m_wineRadio->isChecked())
        m_pages->setCurrentIndex(0);
    else if (m_geRadio->isChecked())
        m_pages->setCurrentIndex(1);
    else
        m_pages->setCurrentIndex(2);

    auto prefixText = [this](const QString& runnerKey, const QString& base) {
        if (m_existing.runner == runnerKey && !m_existing.prefixCode.isEmpty()
            && !m_existing.prefixPath.isEmpty()) {
            return tr("Prefix: %1 (used previously, kept consistent)\nLocation: %2")
                .arg(m_existing.prefixCode, m_existing.prefixPath);
        }
        return tr("A new prefix will be created automatically at:\n%1 (e.g. GAME001)").arg(base);
    };

    m_wineInfo->setVisible(m_wineUsePrefix->isChecked());
    m_wineInfo->setText(prefixText(QStringLiteral("wine"), m_wineBase));
    m_geInfo->setText(prefixText(QStringLiteral("protonge"), m_geBase));
    m_cachyInfo->setText(prefixText(QStringLiteral("protoncachyos"), m_cachyBase));
}

void RunnerDialog::browseBaseDir(const QString& runnerKey, const QString& title)
{
    QString* base = nullptr;
    if (runnerKey == QLatin1String("wine"))
        base = &m_wineBase;
    else if (runnerKey == QLatin1String("protonge"))
        base = &m_geBase;
    else
        base = &m_cachyBase;

    const QString initial = *base;
    const QString chosen = QFileDialog::getExistingDirectory(
        this, tr("Choose Default Location for New %1 Prefixes").arg(title), initial);
    if (!chosen.isEmpty()) {
        *base = chosen;
        prefixreg::setPrefixBaseDir(runnerKey, chosen);
        updateRunnerPage();
    }
}

void RunnerDialog::useDefaultBaseDir(const QString& runnerKey)
{
    prefixreg::resetPrefixBaseDir(runnerKey);
    if (runnerKey == QLatin1String("wine"))
        m_wineBase = prefixreg::defaultRoot(runnerKey);
    else if (runnerKey == QLatin1String("protonge"))
        m_geBase = prefixreg::defaultRoot(runnerKey);
    else
        m_cachyBase = prefixreg::defaultRoot(runnerKey);
    updateRunnerPage();
}

QString RunnerDialog::prefixCodeFor(const QString& runnerKey, QString* pathOut,
                                    const QString& baseDir) const
{
    if (m_existing.runner == runnerKey && !m_existing.prefixCode.isEmpty()
        && !m_existing.prefixPath.isEmpty()) {
        *pathOut = m_existing.prefixPath;
        return m_existing.prefixCode;
    }
    const QString code = prefixreg::generateNextPrefixCode(runnerKey);
    *pathOut = QDir(baseDir).filePath(code);
    return code;
}

void RunnerDialog::acceptChoice()
{
    RunnerChoice c;
    c.launchOptions = m_launchOptions->text().trimmed();
    c.comment = m_comment->text().trimmed();

    if (m_wineRadio->isChecked()) {
        c.runner = QStringLiteral("wine");
        if (m_wineUsePrefix->isChecked()) {
            QString path;
            const QString code = prefixCodeFor(QStringLiteral("wine"), &path, m_wineBase);
            QDir().mkpath(path);
            prefixreg::recordPrefixUsage(QStringLiteral("wine"), code, path);
            c.prefixCode = code;
            c.prefixPath = path;
        }
        m_choice = c;
        accept();
        return;
    }

    const bool ge = m_geRadio->isChecked();
    const QString runnerKey = ge ? QStringLiteral("protonge") : QStringLiteral("protoncachyos");
    const QString label = ge ? tr("Proton GE") : tr("Proton-CachyOS");
    const QList<Proton::Build>& builds = ge ? m_geBuilds : m_cachyBuilds;

    if (builds.isEmpty()) {
        QMessageBox::warning(this, tr("Error"),
                             tr("%1 not found. Extract it first via the Settings menu.").arg(label));
        return;
    }

    const int idx = ge ? m_geCombo->currentIndex() : m_cachyCombo->currentIndex();
    if (idx < 0 || idx >= builds.size())
        return;
    const Proton::Build build = builds.at(idx);

    QString path;
    const QString base = ge ? m_geBase : m_cachyBase;
    const QString code = prefixCodeFor(runnerKey, &path, base);
    QDir().mkpath(path);
    prefixreg::recordPrefixUsage(runnerKey, code, path, build.name, build.path);

    c.runner = runnerKey;
    c.protonName = build.name;
    c.protonPath = build.path;
    c.prefixCode = code;
    c.prefixPath = path;
    m_choice = c;
    accept();
}
