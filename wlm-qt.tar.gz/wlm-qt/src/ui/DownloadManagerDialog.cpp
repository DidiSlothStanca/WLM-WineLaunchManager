#include "ui/DownloadManagerDialog.h"

#include "core/Paths.h"
#include "core/SetupRunner.h"
#include "core/Shortcut.h"
#include "core/WindowState.h"

#include "ui/RunnerDialog.h"

#include <QDateTime>
#include <QDir>
#include <QFileDialog>
#include <QFileInfo>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QLabel>
#include <QMessageBox>
#include <QProcess>
#include <QProgressBar>
#include <QPushButton>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QTimer>
#include <QVBoxLayout>

namespace {

QString statusText(DownloadManager::Status s)
{
    switch (s) {
    case DownloadManager::Status::Queued:     return QObject::tr("Queued");
    case DownloadManager::Status::Downloading: return QObject::tr("Downloading");
    case DownloadManager::Status::Paused:     return QObject::tr("Paused");
    case DownloadManager::Status::Completed:  return QObject::tr("Completed");
    case DownloadManager::Status::Failed:     return QObject::tr("Failed");
    case DownloadManager::Status::Cancelled:  return QObject::tr("Cancelled");
    }
    return {};
}

QString humanSize(qint64 bytes)
{
    const double kb = bytes / 1024.0;
    const double mb = kb / 1024.0;
    const double gb = mb / 1024.0;
    if (gb >= 1) return QStringLiteral("%1 GB").arg(gb, 0, 'f', 2);
    if (mb >= 1) return QStringLiteral("%1 MB").arg(mb, 0, 'f', 2);
    if (kb >= 1) return QStringLiteral("%1 KB").arg(kb, 0, 'f', 1);
    return QStringLiteral("%1 bytes").arg(bytes);
}

} // namespace

DownloadManagerDialog::DownloadManagerDialog(QWidget* parent)
    : QDialog(parent)
{
    setWindowTitle(tr("List Download"));
    setMinimumSize(800, 500);
    setWindowFlags(windowFlags() | Qt::Window
                   | Qt::WindowMinMaxButtonsHint
                   | Qt::WindowCloseButtonHint
                   | Qt::WindowSystemMenuHint);
    new WindowStateHelper(this, QStringLiteral("download_manager"), QSize(800, 500), QSize(500, 350));

    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(15, 15, 15, 15);
    root->setSpacing(10);

    // Header row.
    auto* headerRow = new QHBoxLayout;
    auto* headerLabel = new QLabel(tr("Downloads"));
    QFont hf = headerLabel->font();
    hf.setPointSize(hf.pointSize() + 2);
    hf.setBold(true);
    headerLabel->setFont(hf);
    headerLabel->setObjectName(QStringLiteral("SideTitle"));
    headerRow->addWidget(headerLabel);
    headerRow->addStretch(1);

    m_clearBtn = new QPushButton(tr("Clear Finished"), this);
    m_clearBtn->setObjectName(QStringLiteral("Danger"));
    connect(m_clearBtn, &QPushButton::clicked, this, &DownloadManagerDialog::onClearFinished);
    headerRow->addWidget(m_clearBtn);
    root->addLayout(headerRow);

    // Download table (grid).
    m_table = new QTableWidget(this);
    m_table->setColumnCount(8);
    m_table->setHorizontalHeaderLabels({
        tr("#"), tr("Title"), tr("Category"), tr("Progress"), tr("Speed"), tr("Status"), tr("Size"), tr("Setup")
    });
    m_table->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_table->setSelectionMode(QAbstractItemView::SingleSelection);
    m_table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_table->verticalHeader()->setVisible(false);

    // Responsive columns: stretch to fill, resize to content.
    m_table->horizontalHeader()->setStretchLastSection(true);
    m_table->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents); // #
    m_table->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch);           // Title
    m_table->horizontalHeader()->setSectionResizeMode(2, QHeaderView::ResizeToContents); // Category
    m_table->horizontalHeader()->setSectionResizeMode(3, QHeaderView::ResizeToContents); // Progress
    m_table->horizontalHeader()->setSectionResizeMode(4, QHeaderView::ResizeToContents); // Speed
    m_table->horizontalHeader()->setSectionResizeMode(5, QHeaderView::ResizeToContents); // Status
    m_table->horizontalHeader()->setSectionResizeMode(6, QHeaderView::ResizeToContents); // Size
    m_table->horizontalHeader()->setSectionResizeMode(7, QHeaderView::ResizeToContents); // Setup
    connect(m_table, &QTableWidget::itemSelectionChanged, this, [this] {
        auto items = m_table->selectedItems();
        if (!items.isEmpty()) {
            m_selectedId = items.first()->data(Qt::UserRole).toInt();
        } else {
            m_selectedId = -1;
        }
        refresh();
    });
    root->addWidget(m_table, 1);

    m_emptyLabel = new QLabel(tr("No downloads yet."), this);
    m_emptyLabel->setAlignment(Qt::AlignCenter);
    m_emptyLabel->setObjectName(QStringLiteral("SideSection"));
    m_emptyLabel->hide();
    root->addWidget(m_emptyLabel);

    // Control buttons.
    auto* btnRow = new QHBoxLayout;

    m_pauseBtn = new QPushButton(tr("Pause"), this);
    connect(m_pauseBtn, &QPushButton::clicked, this, &DownloadManagerDialog::onPauseClicked);
    btnRow->addWidget(m_pauseBtn);

    m_resumeBtn = new QPushButton(tr("Resume"), this);
    connect(m_resumeBtn, &QPushButton::clicked, this, &DownloadManagerDialog::onResumeClicked);
    btnRow->addWidget(m_resumeBtn);

    m_cancelBtn = new QPushButton(tr("Cancel"), this);
    m_cancelBtn->setObjectName(QStringLiteral("Danger"));
    connect(m_cancelBtn, &QPushButton::clicked, this, &DownloadManagerDialog::onCancelClicked);
    btnRow->addWidget(m_cancelBtn);

    m_removeBtn = new QPushButton(tr("Remove"), this);
    connect(m_removeBtn, &QPushButton::clicked, this, &DownloadManagerDialog::onRemoveClicked);
    btnRow->addWidget(m_removeBtn);

    m_openFolderBtn = new QPushButton(tr("Open Folder"), this);
    connect(m_openFolderBtn, &QPushButton::clicked, this, &DownloadManagerDialog::onOpenFolder);
    btnRow->addWidget(m_openFolderBtn);

    btnRow->addStretch(1);

    m_closeBtn = new QPushButton(tr("Close"), this);
    connect(m_closeBtn, &QPushButton::clicked, this, &DownloadManagerDialog::accept);
    btnRow->addWidget(m_closeBtn);

    root->addLayout(btnRow);

    // Auto-refresh timer (updates progress every second) - single shot to avoid reentrancy.
    m_refreshTimer = new QTimer(this);
    m_refreshTimer->setSingleShot(true);
    m_refreshTimer->setInterval(1000);
    connect(m_refreshTimer, &QTimer::timeout, this, &DownloadManagerDialog::refresh);
}

void DownloadManagerDialog::showEvent(QShowEvent* event)
{
    QDialog::showEvent(event);
    refresh();
    // Timer will be restarted at the end of refresh()
}

void DownloadManagerDialog::refresh()
{
    // Block table signals during rebuild to avoid triggering itemSelectionChanged.
    m_table->blockSignals(true);

    DownloadManager* dm = DownloadManager::instance();
    const QVector<DownloadManager::Item> all = dm->items();

    // Save current selection before rebuilding table.
    const int prevSelectedId = m_selectedId;

    m_table->setRowCount(0);
    m_emptyLabel->setVisible(all.isEmpty());

    int row = 0;
    int selectedRow = -1;
    for (const auto& item : all) {
        m_table->insertRow(row);

        // # column.
        auto* numItem = new QTableWidgetItem(QString::number(item.id));
        numItem->setData(Qt::UserRole, item.id);
        m_table->setItem(row, 0, numItem);

        // Title.
        m_table->setItem(row, 1, new QTableWidgetItem(item.title));

        // Category (ProtonGE, GOG, etc.).
        m_table->setItem(row, 2, new QTableWidgetItem(item.category));

        // Progress bar.
        auto* bar = new QProgressBar();
        bar->setRange(0, 100);
        bar->setValue(item.progress > 0 ? item.progress : 0);
        bar->setTextVisible(true);
        bar->setFormat(item.progress >= 0 ? QStringLiteral("%1%").arg(item.progress) : QString());
        m_table->setCellWidget(row, 3, bar);

        // Speed (calculate from progress change - simplified).
        QString speedText;
        if (item.status == DownloadManager::Status::Downloading && item.totalSize > 0) {
            speedText = QStringLiteral("%1/s").arg(humanSize(item.downloadedSize / qMax(1, item.startedAt.secsTo(QDateTime::currentDateTime()))));
        } else if (item.status == DownloadManager::Status::Paused) {
            speedText = QStringLiteral("0 B/s");
        } else {
            speedText = QStringLiteral("-");
        }
        m_table->setItem(row, 4, new QTableWidgetItem(speedText));

        // Status.
        m_table->setItem(row, 5, new QTableWidgetItem(statusText(item.status)));

        // Size.
        QString sizeText;
        if (item.totalSize > 0) {
            sizeText = QStringLiteral("%1 / %2")
                           .arg(humanSize(item.downloadedSize), humanSize(item.totalSize));
        } else {
            sizeText = humanSize(item.downloadedSize);
        }
        m_table->setItem(row, 6, new QTableWidgetItem(sizeText));

        // Setup column - Start Setup button for completed downloads without auto-install.
        if (item.status == DownloadManager::Status::Completed
            && !item.startSetupAfterDownload
            && !item.destPath.isEmpty()
            && QFileInfo(item.destPath).dir().exists()) {
            auto* setupBtn = new QPushButton(tr("Start Setup"), m_table);
            setupBtn->setObjectName(QStringLiteral("SmallAccent"));
            setupBtn->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
            setupBtn->adjustSize(); // Size to content
            setupBtn->setMinimumWidth(setupBtn->sizeHint().width() + 8);
            setupBtn->setProperty("downloadId", item.id);
            setupBtn->setProperty("destPath", item.destPath);
            setupBtn->setProperty("gameTitle", item.title);
            setupBtn->setProperty("gameId", item.id);
            connect(setupBtn, &QPushButton::clicked, this, [this, setupBtn] {
                const int dlId = setupBtn->property("downloadId").toInt();
                const QString destPath = setupBtn->property("destPath").toString();
                const QString gameTitle = setupBtn->property("gameTitle").toString();
                const QString gameId = setupBtn->property("gameId").toString();
                onStartSetupClicked(dlId, destPath, gameTitle, gameId);
            });
            m_table->setCellWidget(row, 7, setupBtn);
            // Adjust row height to fit button.
            m_table->setRowHeight(row, qMax(m_table->rowHeight(row), setupBtn->sizeHint().height() + 4));
        } else {
            // Empty cell for other statuses.
            m_table->setItem(row, 7, new QTableWidgetItem(QString()));
        }

        // Track which row matches previous selection.
        if (item.id == prevSelectedId) {
            selectedRow = row;
        }

        row++;
    }

    // Restore selection if the previously selected item still exists.
    if (selectedRow >= 0) {
        m_table->selectRow(selectedRow);
        m_selectedId = prevSelectedId;
    } else if (prevSelectedId >= 0) {
        // Previously selected item no longer exists.
        m_selectedId = -1;
    }

    m_table->blockSignals(false);

    // Update button states based on selected item.
    bool isDownload = false, isPaused = false, isFailed = false, isDone = false;
    bool hasDest = false;
    for (const auto& item : all) {
        if (item.id != m_selectedId) continue;
        if (item.status == DownloadManager::Status::Downloading) isDownload = true;
        if (item.status == DownloadManager::Status::Paused) isPaused = true;
        if (item.status == DownloadManager::Status::Failed) isFailed = true;
        if (item.status == DownloadManager::Status::Completed) isDone = true;
        if (!item.destPath.isEmpty() && QFileInfo(item.destPath).dir().exists())
            hasDest = true;
        break;
    }
    m_pauseBtn->setEnabled(isDownload);
    m_resumeBtn->setEnabled(isPaused || isFailed);
    m_cancelBtn->setEnabled(isDownload || isPaused);
    m_removeBtn->setEnabled(isDone || isPaused || isFailed);
    m_openFolderBtn->setEnabled(hasDest || isDone);

    // Restart single-shot timer for next auto-refresh.
    m_refreshTimer->start();
}

void DownloadManagerDialog::onPauseClicked()
{
    if (m_selectedId >= 0)
        DownloadManager::instance()->pauseDownload(m_selectedId);
}

void DownloadManagerDialog::onResumeClicked()
{
    if (m_selectedId >= 0)
        DownloadManager::instance()->resumeDownload(m_selectedId);
}

void DownloadManagerDialog::onCancelClicked()
{
    if (m_selectedId >= 0)
        DownloadManager::instance()->cancelDownload(m_selectedId);
}

void DownloadManagerDialog::onClearFinished()
{
    DownloadManager::instance()->clearFinished();
    DownloadManager::instance()->resetNextId();
    refresh();
}

void DownloadManagerDialog::onOpenFolder()
{
    for (const auto& item : DownloadManager::instance()->items()) {
        if (item.id != m_selectedId) continue;
        QDir dir(item.destPath);
        if (dir.exists()) {
            QProcess::startDetached("xdg-open", {item.destPath});
        }
        return;
    }
}

void DownloadManagerDialog::onRemoveClicked()
{
    if (m_selectedId >= 0)
        DownloadManager::instance()->removeItem(m_selectedId);
}

void DownloadManagerDialog::onStartSetupClicked(int downloadId, const QString& destPath, const QString& gameTitle, const QString& gameId)
{
    // Find the .exe installer in the download directory.
    QString exePath;
    QDir dir(destPath);
    const auto entries = dir.entryInfoList(QDir::Files);
    for (const QFileInfo& fi : entries) {
        if (fi.suffix().toLower() == QLatin1String("exe")) {
            exePath = fi.absoluteFilePath();
            break;
        }
    }

    if (exePath.isEmpty()) {
        QMessageBox::warning(this, tr("Setup"),
            tr("No installer (.exe) found in the download folder for '%1'.").arg(gameTitle));
        return;
    }

    // Show runner selection dialog.
    RunnerDialog dialog(this, gameTitle, QString(), true);
    if (dialog.exec() != QDialog::Accepted) {
        return;
    }
    const std::optional<RunnerChoice> choiceOpt = dialog.choice();
    if (!choiceOpt.has_value())
        return;
    const RunnerChoice choice = *choiceOpt;

    // Start installer.
    auto* runner = new SetupRunner(this);
    QString error;
    if (!runner->start(exePath, choice, {}, gameId, &error)) {
        QMessageBox::warning(this, tr("Install failed"),
                             tr("Could not start installer:\n%1").arg(error));
        return;
    }
    // Wait for installer to finish and add shortcut like GogStoreDialog does.
    connect(runner, &SetupRunner::finished, this,
            [this, runner, gameTitle, gameId, choice, destPath](const SetupResult& result) {
                RunnerChoice c = choice;
                c.source = QStringLiteral("gog");
                c.gogId = gameId;

                QString exe;
                QString workDir;
                QString iconPath;

                if (result.found) {
                    exe = result.found->exe;
                    workDir = result.found->workdir;
                    if (result.found->hasIcon)
                        iconPath = result.found->icon;
                } else {
                    if (result.exitCode && *result.exitCode != 0) {
                        QMessageBox::warning(this, tr("Install"),
                            tr("Installer exited (code %1) - no shortcut added.")
                                .arg(*result.exitCode));
                        runner->deleteLater();
                        emit installCompleted();
                        return;
                    }
                    // Auto-select best executable without asking.
                    exe = QString();
                    if (!result.candidates.isEmpty()) {
                        exe = result.candidates.first().exe;
                    } else if (!result.driveC.isEmpty() && QDir(result.driveC).exists()) {
                        // Fallback: find any .exe in the driveC.
                        QDir driveCDir(result.driveC);
                        const auto exes = driveCDir.entryInfoList({"*.exe"}, QDir::Files);
                        if (!exes.isEmpty())
                            exe = exes.first().absoluteFilePath();
                    }
                    if (exe.isEmpty()) {
                        QMessageBox::information(this, tr("Install"),
                            tr("Installed - no shortcut added (no .exe found)."));
                        runner->deleteLater();
                        emit installCompleted();
                        return;
                    }
                }

                // Prefer cached GOG cover as icon.
                const QString cover = paths::gogCovers() + QLatin1Char('/') + gameId
                                      + QStringLiteral(".jpg");
                if (QFileInfo::exists(cover))
                    iconPath = cover;

                const QString finalName = shortcut::addGameShortcut(gameTitle, exe, c, iconPath, workDir);
                if (finalName.isEmpty()) {
                    QMessageBox::warning(this, tr("Shortcut"),
                        tr("Could not add the shortcut."));
                } else {
                    QMessageBox::information(this, tr("Install"),
                        tr("'%1' was added to the launcher.").arg(finalName));
                    emit installCompleted();

                    // Ask user if they want to delete the setup files to save space.
                    const auto ret = QMessageBox::question(
                        this, tr("Clean up"),
                        tr("Installation complete. Delete the setup files in:\n%1\n\n"
                           "This will free up disk space. The game is already installed and playable.")
                            .arg(destPath),
                        QMessageBox::Yes | QMessageBox::No,
                        QMessageBox::Yes);
                    if (ret == QMessageBox::Yes) {
                        QDir dir(destPath);
                        if (dir.exists()) {
                            dir.removeRecursively();
                            emit statusMessage(tr("Setup files deleted for '%1'.").arg(gameTitle), true);
                        }
                    }
                }
                runner->deleteLater();
            });
}
