#pragma once

#include <QDialog>
#include <QString>

class QLabel;
class QPlainTextEdit;
class QProgressBar;
class QPushButton;

// Simple log window for background tasks (download/extract, later backup/restore).
// Port of open_task_log_window(): progress bar, scrolling text, optional Pause
// button. While the task is still running the window hides instead of closing.
class TaskLogWindow : public QDialog {
    Q_OBJECT
public:
    TaskLogWindow(const QString& title, QWidget* parent = nullptr, bool withPause = false,
                  bool withCancel = false);

    void appendLine(const QString& text);
    void setProgress(int percent); // < 0 -> indeterminate
    void markFinished();
    void disablePause();
    bool isFinished() const { return m_finished; }

signals:
    void pauseRequested(bool paused);
    void cancelRequested();

protected:
    void closeEvent(QCloseEvent* event) override;

private:
    QPlainTextEdit* m_view = nullptr;
    QProgressBar* m_bar = nullptr;
    QLabel* m_pct = nullptr;
    QPushButton* m_pauseBtn = nullptr;
    QPushButton* m_cancelBtn = nullptr;
    QPushButton* m_closeBtn = nullptr;
    bool m_finished = false;
    bool m_paused = false;
};
