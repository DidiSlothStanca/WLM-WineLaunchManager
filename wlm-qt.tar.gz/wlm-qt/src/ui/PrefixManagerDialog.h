#pragma once

#include "core/GameLauncher.h"
#include "core/PrefixOps.h"

#include <QDialog>
#include <QList>

#include <optional>

class QLabel;
class QTreeWidget;
class LogWindow;
class TaskLogWindow;

// Prefix Configuration Manager: list every known prefix and run winecfg /
// explorer / uninstaller / winetricks, open the folder, move, back up, restore,
// or remove them. Port of open_prefix_manager_dialog().
class PrefixManagerDialog : public QDialog {
    Q_OBJECT
public:
    explicit PrefixManagerDialog(QWidget* parent);

signals:
    void statusMessage(const QString& text, bool success);
    void dataChanged();

private:
    void buildUi();
    void refreshList();
    std::optional<prefixops::PrefixInfo> selected() const;

    void runTool(prefixops::PrefixInfo entry, const QString& tool);
    void openWinetricks(prefixops::PrefixInfo entry);
    bool resolveProton(prefixops::PrefixInfo& entry);

    void openFolder(const prefixops::PrefixInfo& entry);
    void backupPrefix(const prefixops::PrefixInfo& entry);
    void restoreBackup();
    void removePrefixEntry(prefixops::PrefixInfo entry);
    void movePrefix(const prefixops::PrefixInfo& entry);
    void showLogs();

    QTreeWidget* m_tree = nullptr;
    QLabel* m_empty = nullptr;
    QList<prefixops::PrefixInfo> m_prefixes;

    GameLauncher* m_launcher = nullptr;

    TaskLogWindow* m_taskWindow = nullptr;
    bool m_taskBusy = false;
    QString m_taskLabel;
};
