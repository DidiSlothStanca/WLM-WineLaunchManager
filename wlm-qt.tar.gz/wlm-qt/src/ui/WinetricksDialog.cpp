#include "ui/WinetricksDialog.h"

#include "core/WindowState.h"

#include <QCheckBox>
#include <QGridLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QMessageBox>
#include <QPushButton>
#include <QRegularExpression>
#include <QVBoxLayout>

namespace {

struct Verb {
    const char* verb;
    const char* description;
};

const Verb kCommonVerbs[] = {
    {"corefonts", "Core Fonts (Arial, Times New Roman, dll)"},
    {"cjkfonts", "CJK Fonts (China/Jepang/Korea)"},
    {"vcrun2005", "Visual C++ 2005 Redist"},
    {"vcrun2008", "Visual C++ 2008 Redist"},
    {"vcrun2010", "Visual C++ 2010 Redist"},
    {"vcrun2012", "Visual C++ 2012 Redist"},
    {"vcrun2013", "Visual C++ 2013 Redist"},
    {"vcrun2019", "Visual C++ 2015-2019 Redist"},
    {"vcrun2022", "Visual C++ 2015-2022 Redist"},
    {"dotnet48", ".NET Framework 4.8"},
    {"dotnet6", ".NET 6 Runtime"},
    {"dotnetdesktop6", ".NET 6 Desktop Runtime"},
    {"d3dx9", "DirectX 9 (d3dx9)"},
    {"d3dx11_43", "DirectX 11 (d3dx11_43)"},
    {"d3dcompiler_47", "D3D Compiler 47"},
    {"xact", "XAudio (xact)"},
    {"physx", "PhysX"},
    {"dxvk", "DXVK (DirectX -> Vulkan)"},
    {"vkd3d", "VKD3D (Direct3D 12 -> Vulkan)"},
    {"faudio", "FAudio"},
};

} // namespace

WinetricksDialog::WinetricksDialog(const QString& prefixCode, QWidget* parent)
    : QDialog(parent)
    , m_prefixCode(prefixCode)
{
    setWindowTitle(tr("Winetricks - %1").arg(prefixCode));
    setWindowFlags(windowFlags() | Qt::Window);
    new WindowStateHelper(this, QStringLiteral("winetricks"), QSize(680, 480));
    buildUi();
}

void WinetricksDialog::buildUi()
{
    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(15, 15, 15, 15);
    root->setSpacing(8);

    root->addWidget(new QLabel(
        tr("Select components to install into prefix '%1':").arg(m_prefixCode)));

    auto* grid = new QGridLayout;
    const int columns = 2;
    int i = 0;
    for (const Verb& v : kCommonVerbs) {
        auto* box = new QCheckBox(QStringLiteral("%1 - %2").arg(v.verb, v.description));
        grid->addWidget(box, i / columns, i % columns, Qt::AlignLeft);
        m_boxes.append(box);
        m_verbs.append(QString::fromLatin1(v.verb));
        ++i;
    }
    root->addLayout(grid);

    root->addWidget(new QLabel(tr("Additional/custom verb(s) (space separated):")));
    m_custom = new QLineEdit;
    root->addWidget(m_custom);

    auto* buttons = new QHBoxLayout;
    buttons->addStretch(1);
    auto* runBtn = new QPushButton(tr("Run Selected"));
    runBtn->setObjectName(QStringLiteral("Accent"));
    auto* interactiveBtn = new QPushButton(tr("Open Interactive Menu"));
    auto* cancelBtn = new QPushButton(tr("Cancel"));
    buttons->addWidget(runBtn);
    buttons->addWidget(interactiveBtn);
    buttons->addWidget(cancelBtn);
    root->addLayout(buttons);

    connect(cancelBtn, &QPushButton::clicked, this, &QDialog::reject);
    connect(runBtn, &QPushButton::clicked, this, [this] {
        QStringList verbs;
        for (int j = 0; j < m_boxes.size(); ++j) {
            if (m_boxes.at(j)->isChecked())
                verbs << m_verbs.at(j);
        }
        const QString custom = m_custom->text().trimmed();
        if (!custom.isEmpty())
            verbs << custom.split(QRegularExpression(QStringLiteral("\\s+")), Qt::SkipEmptyParts);
        if (verbs.isEmpty()) {
            QMessageBox::information(this, tr("Info"),
                                     tr("Select at least one component, or type a custom verb."));
            return;
        }
        emit runRequested(verbs);
        accept();
    });
    connect(interactiveBtn, &QPushButton::clicked, this, [this] {
        emit interactiveRequested();
        accept();
    });
}
