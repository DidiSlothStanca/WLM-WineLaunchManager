#include "ui/DownloadOptionsDialog.h"

#include "core/Proton.h"
#include "core/RunnerConfig.h"

#include <QVariant>

#include <QCheckBox>
#include <QComboBox>
#include <QDialogButtonBox>
#include <QLabel>
#include <QVBoxLayout>

DownloadOptionsDialog::DownloadOptionsDialog(QWidget* parent)
    : QDialog(parent)
{
    setWindowTitle(tr("Download Options"));
    setMinimumWidth(420);
    setWindowFlags(windowFlags() | Qt::Window
                   | Qt::WindowMinMaxButtonsHint
                   | Qt::WindowCloseButtonHint
                   | Qt::WindowSystemMenuHint);

    auto* layout = new QVBoxLayout(this);
    layout->setContentsMargins(20, 20, 20, 20);
    layout->setSpacing(12);

    auto* info = new QLabel(
        tr("What should happen after the download finishes?"),
        this);
    info->setWordWrap(true);
    layout->addWidget(info);

    m_startSetupCheck = new QCheckBox(tr("Start Setup After Download Completed"), this);
    layout->addWidget(m_startSetupCheck);

    m_deleteInstallerCheck = new QCheckBox(tr("Delete installer after successful install (save disk space)"), this);
    m_deleteInstallerCheck->setEnabled(false);
    layout->addWidget(m_deleteInstallerCheck);

    auto* runnerLabel = new QLabel(tr("Runner / Proton to use for installation:"), this);
    runnerLabel->setEnabled(false);
    layout->addWidget(runnerLabel);

    m_runnerCombo = new QComboBox(this);
    m_runnerCombo->setEnabled(false);

    // Populate with available runners (Wine + Proton GE + Proton-CachyOS).
    const auto protonGE = Proton::findProtonGEInstallations();
    const auto protonCachy = Proton::findProtonCachyOSInstallations();

    // System Wine
    RunnerChoice wineChoice;
    wineChoice.runner = QLatin1String("wine");
    m_runnerCombo->addItem(tr("System Wine"), QVariant::fromValue(wineChoice));

    for (const auto& p : protonGE) {
        RunnerChoice choice;
        choice.runner = QLatin1String("protonge");
        choice.protonName = p.name;
        choice.protonPath = p.path;
        m_runnerCombo->addItem(tr("Proton GE %1").arg(p.name), QVariant::fromValue(choice));
    }
    for (const auto& p : protonCachy) {
        RunnerChoice choice;
        choice.runner = QLatin1String("protoncachyos");
        choice.protonName = p.name;
        choice.protonPath = p.path;
        m_runnerCombo->addItem(tr("Proton-CachyOS %1").arg(p.name), QVariant::fromValue(choice));
    }

    layout->addWidget(m_runnerCombo);

    connect(m_startSetupCheck, &QCheckBox::toggled, this, [this, runnerLabel](bool checked) {
        m_runnerCombo->setEnabled(checked);
        runnerLabel->setEnabled(checked);
        m_deleteInstallerCheck->setEnabled(checked);
    });

    m_buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
    connect(m_buttonBox, &QDialogButtonBox::accepted, this, &QDialog::accept);
    connect(m_buttonBox, &QDialogButtonBox::rejected, this, &QDialog::reject);
    layout->addWidget(m_buttonBox);
}

DownloadOptionsDialog::Options DownloadOptionsDialog::getOptions() const
{
    Options opts;
    opts.startSetupAfterDownload = m_startSetupCheck->isChecked();
    if (opts.startSetupAfterDownload) {
        const int idx = m_runnerCombo->currentIndex();
        if (idx >= 0) {
            opts.runnerChoice = m_runnerCombo->itemData(idx).value<RunnerChoice>();
        }
    }
    opts.deleteInstallerAfterInstall = m_deleteInstallerCheck->isChecked();
    return opts;
}