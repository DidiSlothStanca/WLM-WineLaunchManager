#pragma once

#include "core/Proton.h"
#include "core/RunnerConfig.h"

#include <QDialog>

#include <optional>

class QCheckBox;
class QComboBox;
class QLabel;
class QLineEdit;
class QRadioButton;
class QStackedWidget;

// Port of ask_runner_choice(): pick Wine / Proton GE / Proton-CachyOS, choose a
// prefix, and edit launch options + a comment. Executes as a modal dialog and
// exposes the resulting RunnerChoice via choice().
class RunnerDialog : public QDialog {
    Q_OBJECT
public:
    RunnerDialog(QWidget* parent, const QString& gameTitle, const QString& existingName,
                 bool forSetup = false);

    std::optional<RunnerChoice> choice() const { return m_choice; }

signals:
    // Emitted when the user clicks "Saves..." (only offered once the game has a
    // prefix, i.e. it has been launched before). The parent opens the non-modal
    // Save Manager on top of this dialog.
    void savesRequested();

private:
    void buildUi();
    void updateRunnerPage();
    void browseBaseDir(const QString& runnerKey, const QString& title);
    void useDefaultBaseDir(const QString& runnerKey);
    void acceptChoice();

    // Resolve the prefix code/path for a runner: reuse the existing one for this
    // game if present, otherwise create a new code under `baseDir`.
    QString prefixCodeFor(const QString& runnerKey, QString* pathOut, const QString& baseDir) const;

    QString m_existingName;
    QString m_gameTitle;
    bool m_forSetup = false;
    std::optional<RunnerChoice> m_choice;
    RunnerChoice m_existing;

    QList<Proton::Build> m_geBuilds;
    QList<Proton::Build> m_cachyBuilds;

    QRadioButton* m_wineRadio = nullptr;
    QRadioButton* m_geRadio = nullptr;
    QRadioButton* m_cachyRadio = nullptr;
    QStackedWidget* m_pages = nullptr;

    // Wine page
    QCheckBox* m_wineUsePrefix = nullptr;
    QLabel* m_wineInfo = nullptr;

    // Proton pages
    QComboBox* m_geCombo = nullptr;
    QLabel* m_geInfo = nullptr;
    QComboBox* m_cachyCombo = nullptr;
    QLabel* m_cachyInfo = nullptr;

    QLineEdit* m_launchOptions = nullptr;
    QLineEdit* m_comment = nullptr;

    // Base directories for new prefixes (custom, refreshed from prefixreg).
    QString m_wineBase;
    QString m_geBase;
    QString m_cachyBase;
};
