#include "ui/RestoreBackupDialog.h"

#include "core/WindowState.h"

#include <QDir>
#include <QFileDialog>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QMessageBox>
#include <QPushButton>
#include <QVBoxLayout>

RestoreBackupDialog::RestoreBackupDialog(const QString& archiveName, const QString& runnerLabel,
                                         const QStringList& insideGames,
                                         const QStringList& externalGames,
                                         const QString& suggestedCode, const QString& originalCode,
                                         const QString& defaultPrefixRoot, QWidget* parent)
    : QDialog(parent)
{
    setWindowTitle(tr("Restore Backup"));
    setWindowFlags(windowFlags() | Qt::Window);
    new WindowStateHelper(this, QStringLiteral("restore_backup"), QSize(560, 420));
    buildUi(archiveName, runnerLabel, insideGames, externalGames, suggestedCode, originalCode,
            defaultPrefixRoot);
}

void RestoreBackupDialog::buildUi(const QString& archiveName, const QString& runnerLabel,
                                  const QStringList& insideGames, const QStringList& externalGames,
                                  const QString& suggestedCode, const QString& originalCode,
                                  const QString& defaultPrefixRoot)
{
    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(15, 15, 15, 15);
    root->setSpacing(6);

    root->addWidget(new QLabel(tr("Archive: %1").arg(archiveName)));
    root->addWidget(new QLabel(tr("Runner: %1").arg(runnerLabel)));

    if (!insideGames.isEmpty() || !externalGames.isEmpty()) {
        QStringList lines;
        if (!insideGames.isEmpty())
            lines << tr("Included inside the prefix: %1").arg(insideGames.join(QStringLiteral(", ")));
        if (!externalGames.isEmpty())
            lines << tr("Stored separately (own folder): %1")
                         .arg(externalGames.join(QStringLiteral(", ")));
        auto* desc = new QLabel(lines.join(QLatin1Char('\n')));
        desc->setWordWrap(true);
        desc->setProperty("muted", true);
        root->addWidget(desc);
    } else {
        root->addWidget(new QLabel(tr("This backup contains only the prefix (no game linked).")));
    }

    root->addSpacing(6);
    root->addWidget(new QLabel(tr("Prefix code (folder name) for the restored prefix:")));
    m_code = new QLineEdit(suggestedCode);
    root->addWidget(m_code);
    if (suggestedCode != originalCode) {
        auto* note = new QLabel(tr("Original code was '%1', already used here - '%2' suggested. "
                                   "You can still change it.")
                                    .arg(originalCode, suggestedCode));
        note->setWordWrap(true);
        note->setProperty("muted", true);
        root->addWidget(note);
    }

    root->addWidget(new QLabel(tr("Restore prefix into folder:")));
    auto* prefixRow = new QHBoxLayout;
    m_prefixDest = new QLineEdit(defaultPrefixRoot);
    prefixRow->addWidget(m_prefixDest, 1);
    auto* prefixBrowse = new QPushButton(tr("Browse..."));
    prefixRow->addWidget(prefixBrowse);
    root->addLayout(prefixRow);

    m_hasExternal = !externalGames.isEmpty();
    if (m_hasExternal) {
        root->addWidget(new QLabel(tr("Restore game file(s) into folder (each gets a subfolder):")));
        auto* gamesRow = new QHBoxLayout;
        m_gamesDest = new QLineEdit(QDir::homePath() + QStringLiteral("/RestoredGames"));
        gamesRow->addWidget(m_gamesDest, 1);
        auto* gamesBrowse = new QPushButton(tr("Browse..."));
        gamesRow->addWidget(gamesBrowse);
        root->addLayout(gamesRow);

        connect(gamesBrowse, &QPushButton::clicked, this, [this] {
            const QString dir = QFileDialog::getExistingDirectory(
                this, tr("Choose folder to restore game file(s) into"), m_gamesDest->text());
            if (!dir.isEmpty())
                m_gamesDest->setText(dir);
        });
    }

    connect(prefixBrowse, &QPushButton::clicked, this, [this] {
        const QString dir = QFileDialog::getExistingDirectory(
            this, tr("Choose folder to restore the prefix into"), m_prefixDest->text());
        if (!dir.isEmpty())
            m_prefixDest->setText(dir);
    });

    root->addSpacing(6);
    auto* buttons = new QHBoxLayout;
    buttons->addStretch(1);
    auto* okBtn = new QPushButton(tr("OK"));
    okBtn->setObjectName(QStringLiteral("Accent"));
    auto* cancelBtn = new QPushButton(tr("Cancel"));
    buttons->addWidget(okBtn);
    buttons->addWidget(cancelBtn);
    root->addLayout(buttons);

    connect(okBtn, &QPushButton::clicked, this, [this] {
        if (prefixCode().isEmpty()) {
            QMessageBox::information(this, tr("Info"), tr("Prefix code cannot be empty."));
            return;
        }
        if (prefixDestBase().isEmpty()) {
            QMessageBox::information(this, tr("Info"),
                                     tr("Please choose a destination folder for the prefix."));
            return;
        }
        if (m_hasExternal && gamesDestBase().isEmpty()) {
            QMessageBox::information(
                this, tr("Info"), tr("Please choose a destination folder for the game file(s)."));
            return;
        }
        accept();
    });
    connect(cancelBtn, &QPushButton::clicked, this, &QDialog::reject);
}

QString RestoreBackupDialog::prefixCode() const
{
    return m_code->text().trimmed();
}

QString RestoreBackupDialog::prefixDestBase() const
{
    return m_prefixDest->text().trimmed();
}

QString RestoreBackupDialog::gamesDestBase() const
{
    return m_gamesDest ? m_gamesDest->text().trimmed() : QString();
}
