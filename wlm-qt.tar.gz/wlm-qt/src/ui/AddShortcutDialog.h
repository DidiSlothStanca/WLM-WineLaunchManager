#pragma once

#include "core/InstallWatch.h"

#include <QDialog>
#include <QVector>

class QComboBox;
class QLineEdit;

// Dialog konfirmasi shortcut untuk install manual non-GOG (exe kandidat tidak
// bisa dipastikan). Port of ask_shortcut_dialog() dari launcher.py.
class AddShortcutDialog : public QDialog {
    Q_OBJECT
public:
    AddShortcutDialog(const QVector<installwatch::Candidate>& candidates,
                      const QString& driveC, const QString& defaultName,
                      QWidget* parent = nullptr);

    QString chosenName() const;
    QString chosenExe() const;

protected:
    void showEvent(QShowEvent* event) override;

private:
    void browse();
    void refreshCombo();
    QString labelFor(const installwatch::Candidate& c) const;

    QVector<installwatch::Candidate> m_candidates;
    QString m_driveC;
    QLineEdit* m_name = nullptr;
    QComboBox* m_combo = nullptr;
    bool m_centered = false;
};
