#pragma once

#include "core/HudConfig.h"

#include <QDialog>

#include <optional>

class QCheckBox;
class QComboBox;
class QLabel;
class QBoxLayout;
class QMoveEvent;
class QShowEvent;

// Dialog "Config HUD": checklist indikator + ukuran untuk mode Launch VulkanHUD
// (DXVK_HUD) dan GalliumHUD (GALLIUM_HUD). Port of open_hud_config_dialog().
//
// Perilaku sama dengan Python: "Save" menulis hud_config.json tanpa menutup
// dialog, "Reset to Defaults" hanya mengembalikan checkbox/combo di dialog, dan
// posisi jendela selalu disimpan (Save / Close / tombol X sama-sama) lewat key
// "window_position" dengan format "+x+y".
class HudConfigDialog : public QDialog {
    Q_OBJECT
public:
    explicit HudConfigDialog(QWidget* parent = nullptr);

signals:
    void statusMessage(const QString& text, bool success);

protected:
    void showEvent(QShowEvent* event) override;
    void moveEvent(QMoveEvent* event) override;
    void done(int result) override;

private:
    struct Section {
        QList<QCheckBox*> boxes;
        QStringList keys;
        QComboBox* scale = nullptr;
    };

    void buildUi();
    Section buildSection(QBoxLayout* root, const QString& title,
                         const QList<QPair<QString, QString>>& metrics,
                         const QStringList& scaleOptions, const QStringList& savedMetrics,
                         const QString& savedScale);
    void applyDefaults();
    void save();
    void persistPosition();

    hudconfig::HudConfig m_saved;
    Section m_vulkan;
    Section m_gallium;
    std::optional<QPoint> m_movedTo;
    bool m_fixedSize = false;
};
