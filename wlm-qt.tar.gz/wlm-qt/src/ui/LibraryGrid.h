#pragma once

#include "core/Theme.h"

#include <QHash>
#include <QImage>
#include <QSet>
#include <QString>
#include <QStringList>
#include <QWidget>

#include <functional>

class CoverCardDelegate;
class CoverFetcher;
class QListWidget;
class QListWidgetItem;

namespace covers {
class CoverStore;
}

// Cover-card grid for the library (port of game_covers.py's LibraryGrid). Shows
// a card per game: cover + title + GOG/Non-GOG tag. Images are composed lazily
// for the visible cards only, and missing covers are fetched asynchronously via
// CoverFetcher.
class LibraryGrid : public QWidget {
    Q_OBJECT
public:
    LibraryGrid(covers::CoverStore* store, CoverFetcher* fetcher, QWidget* parent = nullptr);

    void setTheme(const Theme& theme);
    void setCardWidth(int width);
    int cardWidth() const { return m_cardWidth; }
    // Scale the card text area with the UI zoom (1.0 = 100%).
    void setScale(double scale);

    void setSourceOf(std::function<QString(const QString&)> fn) { m_sourceOf = std::move(fn); }

    // Replace the list of cards. No-op (unless force) when unchanged.
    void setItems(const QStringList& names, bool force = false);
    // Mark a card selected WITHOUT emitting `selected` (mirrors LibraryGrid.highlight).
    void highlight(const QString& name);
    // Reload one card; force=true re-downloads from the internet.
    void refresh(const QString& name, bool force = false);

    // Try to download covers for every game that has none. Returns the count.
    int fetchMissing();

signals:
    void selected(const QString& name);
    void deselected();
    void activated(const QString& name);
    void statusMessage(const QString& text, const QString& color);
    void uninstallRequested(const QString& name);  // Request uninstall from context menu

private:
    void rebuild();
    void updateCardSizes();
    int titleHeight() const;
    int tagHeight() const;
    void ensureCard(QListWidgetItem* item, bool allowFetch = true);
    void loadVisible();
    void onCoverReady(const QString& name, bool hasCover);

    QImage composeCard(const QString& name) const;
    QImage fitCover(const QImage& src) const;
    QImage blankCard(const QString& name, bool withLetter) const;

    void onItemClicked(QListWidgetItem* item);
    void showContextMenu(const QPoint& pos);
    void chooseCoverImage(const QString& name);
    QListWidgetItem* itemFor(const QString& name) const;

    QListWidget* m_list = nullptr;
    CoverCardDelegate* m_delegate = nullptr;
    covers::CoverStore* m_store = nullptr;
    CoverFetcher* m_fetcher = nullptr;

    Theme m_theme;
    int m_cardWidth = 200;
    int m_cardHeight = 112;
    double m_scale = 1.0;

    QStringList m_names;
    QString m_selected;
    QSet<QString> m_loaded;
    QSet<QString> m_pending;
    std::function<QString(const QString&)> m_sourceOf;
};
