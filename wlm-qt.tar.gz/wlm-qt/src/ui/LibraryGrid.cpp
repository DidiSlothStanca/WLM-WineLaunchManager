#include "ui/LibraryGrid.h"

#include "core/CoverFetcher.h"
#include "core/CoverStore.h"
#include "core/Paths.h"
#include "core/RunnerConfig.h"
#include "core/ThemeManager.h"

#include <QAction>
#include <QAbstractAnimation>
#include <QDir>
#include <QFile>
#include <QFileDialog>
#include <QFont>
#include <QListWidget>
#include <QMenu>
#include <QPainter>
#include <QPainterPath>
#include <QPoint>
#include <QPropertyAnimation>
#include <QEasingCurve>
#include <QScrollBar>
#include <QSignalBlocker>
#include <QStyledItemDelegate>
#include <QTimer>
#include <QVBoxLayout>

#include <algorithm>

namespace {

constexpr double kCoverRatio = 0.5625; // height / width (16:9, like a GOG tile)
constexpr int kTitleHeight = 34;       // space reserved for a 2-line title
constexpr int kTagHeight = 16;         // space reserved for the GOG / Non-GOG tag

// Item data roles.
constexpr int RoleSource = Qt::UserRole + 2;
constexpr int RoleImage = Qt::UserRole + 3;

QString itemName(const QListWidgetItem* item)
{
    return item->data(Qt::DisplayRole).toString();
}

} // namespace

// Paints one cover card: rounded card, cover image, title and source tag.
class CoverCardDelegate : public QStyledItemDelegate {
public:
    void setTheme(const Theme& t) { m_theme = t; }
    void setCardSize(int w, int h)
    {
        m_width = w;
        m_height = h;
    }
    // Scale the text area (title/tag) together with the UI zoom so enlarged
    // fonts still fit inside the card.
    void setScale(double scale)
    {
        m_titleHeight = std::max(14, qRound(kTitleHeight * scale));
        m_tagHeight = std::max(8, qRound(kTagHeight * scale));
    }

    QSize sizeHint(const QStyleOptionViewItem&, const QModelIndex&) const override
    {
        return QSize(m_width + 8, m_height + m_titleHeight + m_tagHeight + 18);
    }

    void paint(QPainter* painter, const QStyleOptionViewItem& option,
               const QModelIndex& index) const override
    {
        painter->save();
        painter->setRenderHint(QPainter::Antialiasing, true);
        painter->setRenderHint(QPainter::SmoothPixmapTransform, true);

        const QRect cell = option.rect;
        const bool selected = option.state & QStyle::State_Selected;
        const bool hovered = option.state & QStyle::State_MouseOver;
        const QString name = index.data(Qt::DisplayRole).toString();
        const QString source = index.data(RoleSource).toString();
        const QImage img = index.data(RoleImage).value<QImage>();

        const QRect card(cell.left() + 4, cell.top() + 4, cell.width() - 8,
                         m_height + m_titleHeight + m_tagHeight + 10);
        QPainterPath path;
        path.addRoundedRect(card, 8, 8);
        painter->fillPath(path, m_theme.cardBg);

        const QRect cover(card.left(), card.top(), card.width(), m_height);
        if (!img.isNull()) {
            painter->drawImage(cover, img);
        } else {
            painter->fillRect(cover, m_theme.secondary);
            QFont f = option.font;
            f.setPixelSize(std::max(16, m_height / 2));
            f.setBold(true);
            painter->setFont(f);
            painter->setPen(m_theme.textSecondary);
            QString letter = name.trimmed().left(1).toUpper();
            if (letter.isEmpty())
                letter = QStringLiteral("?");
            painter->drawText(cover, Qt::AlignCenter, letter);
        }

        // Selection border (Python uses a 2px highlight around the card).
        QPen pen(selected ? m_theme.highlight : m_theme.cardBg, 2);
        painter->setPen(pen);
        painter->setBrush(Qt::NoBrush);
        painter->drawRoundedRect(card.adjusted(1, 1, -1, -1), 8, 8);

        // Text color: highlight on hover, normal text otherwise
        QColor textColor = hovered ? m_theme.highlight : m_theme.text;
        const bool gog = source == QLatin1String("gog");
        QColor tagColor = gog ? QColor(QStringLiteral("#b06cff")) : m_theme.textSecondary;
        if (hovered)
            tagColor = tagColor.lighter(130);

        QFont titleFont = option.font;
        if (titleFont.pointSize() > 9)
            titleFont.setPointSize(titleFont.pointSize() - 1);
        painter->setFont(titleFont);
        painter->setPen(textColor);
        const QRect titleRect(card.left() + 4, card.top() + m_height + 3, card.width() - 8,
                              m_titleHeight);
        painter->drawText(titleRect, Qt::AlignHCenter | Qt::AlignTop | Qt::TextWordWrap, name);

        if (!source.isEmpty()) {
            QFont tagFont = option.font;
            if (option.font.pointSize() > 0)
                tagFont.setPointSize(std::max(7, option.font.pointSize() - 2));
            else if (option.font.pixelSize() > 0)
                tagFont.setPixelSize(std::max(8, option.font.pixelSize() - 3));
            painter->setFont(tagFont);
            painter->setPen(tagColor);
            const QRect tagRect(card.left() + 4, titleRect.bottom() + 1, card.width() - 8,
                                m_tagHeight);
            painter->drawText(tagRect, Qt::AlignHCenter | Qt::AlignVCenter,
                              gog ? QStringLiteral("\u25CF GOG") : QStringLiteral("\u25CB Non-GOG"));
        }

        painter->restore();
    }

private:
    Theme m_theme;
    int m_width = 200;
    int m_height = 112;
    int m_titleHeight = kTitleHeight;
    int m_tagHeight = kTagHeight;
};

LibraryGrid::LibraryGrid(covers::CoverStore* store, CoverFetcher* fetcher, QWidget* parent)
    : QWidget(parent)
    , m_store(store)
    , m_fetcher(fetcher)
    , m_theme(ThemeManager::byId(QStringLiteral("default")))
{
    m_cardHeight = int(m_cardWidth * kCoverRatio);

    auto* layout = new QVBoxLayout(this);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(0);

    m_list = new QListWidget(this);
    m_list->setObjectName(QStringLiteral("LibraryGrid"));
    m_list->setViewMode(QListView::IconMode);
    m_list->setResizeMode(QListView::Adjust);
    m_list->setMovement(QListView::Static);
    m_list->setWrapping(true);
    m_list->setFlow(QListView::LeftToRight);
    m_list->setUniformItemSizes(true);
    m_list->setSelectionMode(QAbstractItemView::SingleSelection);
    m_list->setSpacing(2);
    m_list->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    m_list->setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);
    m_list->setContextMenuPolicy(Qt::CustomContextMenu);
    m_list->setFocusPolicy(Qt::NoFocus);
    m_list->setMouseTracking(true);  // Enable mouse tracking for hover effects
    layout->addWidget(m_list, 1);

    m_delegate = new CoverCardDelegate;
    m_list->setItemDelegate(m_delegate);
    m_delegate->setTheme(m_theme);
    m_delegate->setCardSize(m_cardWidth, m_cardHeight);

    connect(m_list, &QListWidget::itemClicked, this, &LibraryGrid::onItemClicked);
    connect(m_list, &QListWidget::itemDoubleClicked, this, [this](QListWidgetItem* item) {
        if (item)
            emit activated(itemName(item));
    });
    connect(m_list, &QWidget::customContextMenuRequested, this, &LibraryGrid::showContextMenu);
    connect(m_list->verticalScrollBar(), &QScrollBar::valueChanged, this,
            [this] { loadVisible(); });
    connect(m_list->verticalScrollBar(), &QScrollBar::rangeChanged, this,
            [this] { loadVisible(); });

    if (m_fetcher)
        connect(m_fetcher, &CoverFetcher::coverReady, this, &LibraryGrid::onCoverReady);

    setTheme(m_theme);
}

void LibraryGrid::setTheme(const Theme& theme)
{
    m_theme = theme;
    if (m_delegate)
        m_delegate->setTheme(theme);
    if (m_list) {
        m_list->setStyleSheet(QStringLiteral(
            "QListWidget{background-color:%1;border:none;}"
            "QListWidget::item{background:transparent;padding:0px;}"
            "QListWidget::item:selected{background:transparent;}")
            .arg(theme.primary.name()));
    }
    // Cards bake the theme colours in, so recompose visible ones.
    m_loaded.clear();
    for (int i = 0; m_list && i < m_list->count(); ++i)
        m_list->item(i)->setData(RoleImage, QVariant());
    if (m_list)
        m_list->viewport()->update();
    loadVisible();
}

void LibraryGrid::setCardWidth(int width)
{
    const int w = std::max(120, std::min(400, width));
    if (w == m_cardWidth)
        return;
    m_cardWidth = w;
    m_cardHeight = int(m_cardWidth * kCoverRatio);
    updateCardSizes();
}

void LibraryGrid::setScale(double scale)
{
    const double s = std::max(0.1, std::min(3.0, scale));
    if (qFuzzyCompare(s, m_scale))
        return;
    m_scale = s;
    if (!m_delegate || !m_list)
        return;
    // Only the vertical text area changes with zoom; the cover images stay the
    // same size, so avoid recomposing them (keeps slider dragging smooth).
    m_delegate->setScale(m_scale);
    m_list->setGridSize(QSize(m_cardWidth + 8,
                              m_cardHeight + titleHeight() + tagHeight() + 18));
    m_list->doItemsLayout();
    m_list->viewport()->update();
}

int LibraryGrid::titleHeight() const
{
    return std::max(14, qRound(kTitleHeight * m_scale));
}

int LibraryGrid::tagHeight() const
{
    return std::max(8, qRound(kTagHeight * m_scale));
}

void LibraryGrid::updateCardSizes()
{
    if (!m_delegate || !m_list)
        return;
    m_delegate->setScale(m_scale);
    m_delegate->setCardSize(m_cardWidth, m_cardHeight);
    m_list->setIconSize(QSize(m_cardWidth, m_cardHeight));
    m_list->setGridSize(QSize(m_cardWidth + 8, m_cardHeight + titleHeight() + tagHeight() + 18));
    m_loaded.clear();
    for (int i = 0; i < m_list->count(); ++i)
        m_list->item(i)->setData(RoleImage, QVariant());
    m_list->doItemsLayout();
    loadVisible();
}

void LibraryGrid::setItems(const QStringList& names, bool force)
{
    if (names == m_names && !force)
        return;
    m_names = names;
    rebuild();
}

void LibraryGrid::rebuild()
{
    m_loaded.clear();
    m_pending.clear();
    if (!m_list)
        return;

    {
        const QSignalBlocker blocker(m_list);
        m_list->clear();
        for (const QString& name : m_names) {
            auto* item = new QListWidgetItem(name, m_list);
            item->setData(RoleSource, m_sourceOf ? m_sourceOf(name) : QString());
            item->setToolTip(name);
        }
    }

    if (!m_selected.isEmpty() && m_names.contains(m_selected))
        highlight(m_selected);
    else
        m_selected.clear();

    QTimer::singleShot(0, this, &LibraryGrid::loadVisible);
}

QListWidgetItem* LibraryGrid::itemFor(const QString& name) const
{
    if (!m_list)
        return nullptr;
    for (int i = 0; i < m_list->count(); ++i) {
        QListWidgetItem* item = m_list->item(i);
        if (item->data(Qt::DisplayRole).toString() == name)
            return item;
    }
    return nullptr;
}

void LibraryGrid::highlight(const QString& name)
{
    m_selected = name;
    if (!m_list)
        return;
    if (name.isEmpty()) {
        const QSignalBlocker blocker(m_list);
        m_list->clearSelection();
        m_list->setCurrentItem(nullptr);
    } else if (QListWidgetItem* item = itemFor(name)) {
        const QSignalBlocker blocker(m_list);
        m_list->setCurrentItem(item);
        m_list->scrollToItem(item);
    }
    m_list->viewport()->update();
}

void LibraryGrid::loadVisible()
{
    if (!m_list || m_list->count() == 0)
        return;
    const QRect viewport = m_list->viewport()->rect().adjusted(0, -m_cardHeight, 0, m_cardHeight);
    for (int i = 0; i < m_list->count(); ++i) {
        QListWidgetItem* item = m_list->item(i);
        if (m_list->visualItemRect(item).intersects(viewport))
            ensureCard(item);
    }
}

void LibraryGrid::ensureCard(QListWidgetItem* item, bool allowFetch)
{
    if (!item)
        return;
    const QString name = itemName(item);
    if (m_loaded.contains(name))
        return;
    m_loaded.insert(name);

    item->setData(RoleImage, composeCard(name));

    if (allowFetch && m_fetcher && m_store && !m_store->has(name) && !m_pending.contains(name)) {
        m_pending.insert(name);
        // Reuse the GOG Store's cached cover when this is a GOG game.
        const QString gogId = runnerconfig::gameSource(name).gogId;
        m_fetcher->ensure(name, false, gogId);
    }
    m_list->viewport()->update();
}

void LibraryGrid::onCoverReady(const QString& name, bool hasCover)
{
    m_pending.remove(name);
    if (!hasCover)
        return;
    m_loaded.remove(name);
    if (QListWidgetItem* item = itemFor(name)) {
        ensureCard(item, false);
        m_list->viewport()->update();
    }
}

void LibraryGrid::refresh(const QString& name, bool force)
{
    m_loaded.remove(name);
    QListWidgetItem* item = itemFor(name);
    if (item)
        item->setData(RoleImage, QVariant());
    if (item)
        ensureCard(item, !force);
    if (force && m_fetcher) {
        m_pending.insert(name);
        m_fetcher->ensure(name, true);
    }
    if (m_list)
        m_list->viewport()->update();
}

int LibraryGrid::fetchMissing()
{
    if (m_store)
        m_store->clearOffline();
    int count = 0;
    for (const QString& name : m_names) {
        if (m_store && m_store->has(name))
            continue;
        if (m_store)
            m_store->clearMiss(name);
        m_loaded.remove(name);
        ++count;
        if (m_fetcher && !m_pending.contains(name)) {
            m_pending.insert(name);
            m_fetcher->ensure(name);
        }
    }
    loadVisible();
    return count;
}

QImage LibraryGrid::composeCard(const QString& name) const
{
    if (m_store && m_store->has(name)) {
        QImage img(m_store->path(name));
        if (!img.isNull())
            return fitCover(img);
        QFile::remove(m_store->path(name)); // corrupt -> refetch later
    }

    const QString iconPath = paths::icons() + QLatin1Char('/') + name + QStringLiteral(".png");
    QImage icon(iconPath);
    if (!icon.isNull()) {
        QImage card = blankCard(name, false);
        QPainter painter(&card);
        painter.setRenderHint(QPainter::SmoothPixmapTransform, true);
        const int side = m_cardHeight - 8;
        const QImage scaled =
            icon.scaled(side, side, Qt::KeepAspectRatio, Qt::SmoothTransformation);
        painter.drawImage((m_cardWidth - scaled.width()) / 2, (m_cardHeight - scaled.height()) / 2,
                          scaled);
        return card;
    }

    return blankCard(name, true);
}

QImage LibraryGrid::fitCover(const QImage& src) const
{
    const QImage scaled = src.scaled(m_cardWidth, m_cardHeight, Qt::KeepAspectRatioByExpanding,
                                     Qt::SmoothTransformation);
    const int x = (scaled.width() - m_cardWidth) / 2;
    const int y = (scaled.height() - m_cardHeight) / 2;
    return scaled.copy(x, y, m_cardWidth, m_cardHeight);
}

QImage LibraryGrid::blankCard(const QString& name, bool withLetter) const
{
    QImage img(m_cardWidth, m_cardHeight, QImage::Format_ARGB32);
    img.fill(m_theme.secondary);
    if (withLetter) {
        QPainter painter(&img);
        painter.setRenderHint(QPainter::Antialiasing, true);
        QFont f;
        f.setPixelSize(std::max(16, m_cardHeight / 2));
        f.setBold(true);
        painter.setFont(f);
        painter.setPen(m_theme.textSecondary);
        QString letter = name.trimmed().left(1).toUpper();
        if (letter.isEmpty())
            letter = QStringLiteral("?");
        painter.drawText(img.rect(), Qt::AlignCenter, letter);
    }
    return img;
}

void LibraryGrid::onItemClicked(QListWidgetItem* item)
{
    if (!item)
        return;
    const QString name = itemName(item);
    if (name == m_selected) {
        // Clicking the selected card clears the selection (Python behaviour).
        m_selected.clear();
        {
            const QSignalBlocker blocker(m_list);
            m_list->clearSelection();
            m_list->setCurrentItem(nullptr);
        }
        m_list->viewport()->update();
        emit deselected();
        return;
    }
    m_selected = name;
    m_list->viewport()->update();
    emit selected(name);
}

void LibraryGrid::showContextMenu(const QPoint& pos)
{
    if (!m_list)
        return;
    QListWidgetItem* item = m_list->itemAt(pos);
    if (!item)
        return;

    const QString name = itemName(item);
    {
        const QSignalBlocker blocker(m_list);
        m_list->setCurrentItem(item);
    }
    m_selected = name;
    emit selected(name);

    // Selection animation on the card
    QRect itemRect = m_list->visualItemRect(item);
    QWidget* viewport = m_list->viewport();
    QPropertyAnimation* anim = new QPropertyAnimation(viewport, "geometry", viewport);
    anim->setDuration(120);
    anim->setEasingCurve(QEasingCurve::OutCubic);
    QRect startRect = viewport->geometry();
    QRect endRect = startRect.adjusted(-3, -3, 3, 3);
    anim->setStartValue(startRect);
    anim->setEndValue(endRect);
    anim->start(QAbstractAnimation::DeleteWhenStopped);

    QMenu menu;
    menu.setStyleSheet(QStringLiteral(
        "QMenu {"
        "   background-color: %1;"
        "   border: 1px solid %2;"
        "   border-radius: 6px;"
        "   padding: 4px;"
        "}"
        "QMenu::item {"
        "   background-color: transparent;"
        "   color: %3;"
        "   padding: 8px 24px 8px 16px;"
        "   border-radius: 4px;"
        "}"
        "QMenu::item:selected {"
        "   background-color: %4;"
        "   color: %5;"
        "}"
        "QMenu::separator {"
        "   height: 1px;"
        "   background: %6;"
        "   margin: 4px 8px;"
        "}"
        "QMenu::item:disabled {"
        "   color: %7;"
        "}"
    ).arg(m_theme.cardBg.name(), m_theme.border.name(),
          m_theme.text.name(), m_theme.highlight.name(), m_theme.buttonText.name(),
          m_theme.border.name(), m_theme.textSecondary.name()));

    QAction* again = menu.addAction(tr("Download cover again"));
    QAction* pick = menu.addAction(tr("Choose cover image..."));
    QAction* remove = menu.addAction(tr("Remove cover"));
    remove->setEnabled(m_store && m_store->has(name));

    menu.addSeparator();

    QAction* uninstallAct = menu.addAction(tr("Uninstall Game"));
    uninstallAct->setObjectName(QStringLiteral("DangerAction"));

    QAction* chosen = menu.exec(m_list->viewport()->mapToGlobal(pos));
    if (!chosen)
        return;
    if (chosen == again) {
        emit statusMessage(tr("Looking for a new cover for %1...").arg(name),
                           m_theme.textSecondary.name());
        refresh(name, true);
    } else if (chosen == pick) {
        chooseCoverImage(name);
    } else if (chosen == remove) {
        if (m_store) m_store->forget(name);
        refresh(name);
        emit statusMessage(tr("Cover removed: %1").arg(name), m_theme.warning.name());
    } else if (chosen == uninstallAct) {
        emit uninstallRequested(name);
    }
}

void LibraryGrid::chooseCoverImage(const QString& name)
{
    const QString path = QFileDialog::getOpenFileName(
        this, tr("Select Cover"), QDir::homePath(),
        tr("Image Files (*.png *.jpg *.jpeg *.bmp *.webp);;All Files (*)"));
    if (path.isEmpty())
        return;
    QString error;
    if (!m_store || !m_store->setManual(name, path, &error)) {
        emit statusMessage(error.isEmpty() ? tr("Failed to set cover") : error,
                           m_theme.danger.name());
        return;
    }
    refresh(name);
    emit statusMessage(tr("Cover set for %1").arg(name), m_theme.success.name());
}
