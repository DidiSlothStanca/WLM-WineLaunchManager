#pragma once

#include "core/GogClient.h"

#include <QDialog>
#include <QVector>

#include <optional>

class GogCoverGrid;
class QLabel;
class QLineEdit;
class QPushButton;
class QShowEvent;
class QStackedWidget;
class QTreeWidget;
class QTreeWidgetItem;

struct RunnerChoice;
struct SetupResult;

// GOG Store window (port of gog_store.py's open_dialog). Shows the logged-in
// account, the owned library as a text list or cover grid, and can download the
// offline installer ("Download Setup") into ~/wlm/gog_downloads. A "Download
// Manager" button opens a separate window tracking all active/completed downloads
// (like the Python version's gog_downloads.json). After a download finishes the
// installer can be run with Wine/Proton and the newly installed game is detected
// (install_watch) and added as a shortcut.
class GogStoreDialog : public QDialog {
    Q_OBJECT
public:
    explicit GogStoreDialog(QWidget* parent = nullptr);

signals:
    void statusMessage(const QString& text, bool success);
    void downloadCompleted(const QString& title);
    void gameInstalled();  // Emitted when a game is successfully installed and added to library

protected:
    void showEvent(QShowEvent* event) override;

private:
    void buildUi();
    void updateAccountUi();
    void loadLibrary();
    void onLoggedIn();
    void doLogin();
    void doLogout();
    void populate();

    std::optional<gog::Game> selectedGame() const;
    void doDownloadSetup();
    void doDirectDownload();
    void startDownload(const gog::Game& game, const gog::Installer& installer);
    void startInstall(const gog::Game& game, const QString& exePath);
    void finishInstall(const gog::Game& game, const RunnerChoice& choice,
                       const SetupResult& result, bool interactive = true);
    void selectGame(const QString& id);
    void setStatus(const QString& text);
    void openDownloadManager();

    // Helper to auto-create prefix for Proton runners
    bool ensurePrefixForRunner(RunnerChoice& choice, QString* error = nullptr);

    gog::GogClient* m_client;
    gog::Config m_cfg;
    QVector<gog::Game> m_games;

    QLabel* m_account = nullptr;
    QLineEdit* m_search = nullptr;
    QLabel* m_status = nullptr;
    QStackedWidget* m_stack = nullptr;
    QTreeWidget* m_tree = nullptr;
    GogCoverGrid* m_grid = nullptr;
    QPushButton* m_loginBtn = nullptr;
    QPushButton* m_logoutBtn = nullptr;
    QPushButton* m_refreshBtn = nullptr;
    QPushButton* m_viewBtn = nullptr;
    QPushButton* m_downloadMgrBtn = nullptr;
    bool m_gridMode = true;
};
