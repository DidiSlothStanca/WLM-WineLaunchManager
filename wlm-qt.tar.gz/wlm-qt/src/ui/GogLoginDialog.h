#pragma once

#include "core/GogClient.h"

#include <QDialog>

class QLabel;
class QLineEdit;
class QPushButton;
class QShowEvent;

#ifdef WLM_HAVE_WEBENGINE
class QWebEngineView;
#endif

// GOG login window. With QtWebEngine it embeds the real GOG auth page and
// watches for the redirect that carries the OAuth `code` (the job pywebview did
// in gog_login_browser.py). The embedded view uses an off-the-record profile
// (like pywebview's private_mode) and spoofs a modern Chrome user agent.
// A native event filter suppresses harmless console noise (CORS telemetry,
// WebGPU, Permissions-Policy) that GOG's page generates in embedded mode.
class GogLoginDialog : public QDialog {
    Q_OBJECT
public:
    GogLoginDialog(gog::GogClient* client, const gog::Config& cfg, QWidget* parent = nullptr);

    bool loggedIn() const { return m_loggedIn; }

protected:
    void showEvent(QShowEvent* event) override;

private:
    void finishWithCode(const QString& code);
    void setStatus(const QString& text, bool error = false);
    void handleUrl(const QString& url);

    gog::GogClient* m_client;
    gog::Config m_cfg;
    bool m_loggedIn = false;

    QLabel* m_status = nullptr;
    QLineEdit* m_manual = nullptr;

#ifdef WLM_HAVE_WEBENGINE
    QWebEngineView* m_view = nullptr;
#endif
};
