#pragma once

#include "core/GogClient.h"

#include <QHash>
#include <QList>
#include <QSet>
#include <QVector>
#include <QWidget>

class QListWidget;
class QListWidgetItem;
class QNetworkAccessManager;
class QResizeEvent;

// Cover-card grid for the GOG Store, equivalent to gog_store.py's _CoverGrid.
// Covers are loaded asynchronously for the visible items only and cached in
// ~/wlm/gog_covers/<id>.jpg (same folder the Python version uses).
class GogCoverGrid : public QWidget {
    Q_OBJECT
public:
    GogCoverGrid(gog::GogClient* client, const gog::Config& cfg, QWidget* parent = nullptr);

    void setGames(const QVector<gog::Game>& games);
    void setFilter(const QString& needle);
    QString selectedId() const;
    void selectById(const QString& id);
    void clearSelection();

signals:
    void activated();

protected:
    void resizeEvent(QResizeEvent* event) override;

private:
    void scheduleVisible();
    void pump();
    void fetchCover(const gog::Game& game, int suffixIndex);
    void applyIcon(QListWidgetItem* item, const QPixmap& px);
    void markResolved(const QString& id);
    bool loadCached(const gog::Game& game, QPixmap* out);
    QString coverBaseUrl(const QString& image) const;
    QPixmap placeholder(const QString& title) const;
    void rebuildGrid();

    gog::GogClient* m_client;
    gog::Config m_cfg;
    QListWidget* m_list;
    QNetworkAccessManager* m_nam;

    QVector<gog::Game> m_games;
    QHash<QString, int> m_indexById;   // id -> index in m_games
    QSet<QString> m_queued;
    QSet<QString> m_loading;
    QList<QString> m_queue;
    int m_active = 0;

    int m_cardW = 200;
    int m_cardH = 112;
};
