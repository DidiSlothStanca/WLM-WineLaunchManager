#include "ui/HudConfigDialog.h"

#include <QCheckBox>
#include <QComboBox>
#include <QFrame>
#include <QGridLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QMoveEvent>
#include <QPushButton>
#include <QShowEvent>
#include <QVBoxLayout>

namespace {

// (key, deskripsi) - urutan sama dengan VULKAN_HUD_METRICS / GALLIUM_HUD_METRICS.
const QList<QPair<QString, QString>> kVulkanMetrics = {
    {QStringLiteral("fps"), QStringLiteral("FPS")},
    {QStringLiteral("frametimes"), QStringLiteral("Frame time graph")},
    {QStringLiteral("gpuload"), QStringLiteral("GPU load")},
    {QStringLiteral("memory"), QStringLiteral("Memory usage")},
    {QStringLiteral("devinfo"), QStringLiteral("Device info (GPU/driver)")},
    {QStringLiteral("version"), QStringLiteral("DXVK version")},
    {QStringLiteral("api"), QStringLiteral("D3D API version")},
    {QStringLiteral("drawcalls"), QStringLiteral("Draw calls")},
    {QStringLiteral("submissions"), QStringLiteral("Command submissions")},
    {QStringLiteral("pipelines"), QStringLiteral("Pipeline compiles")},
    {QStringLiteral("compiler"), QStringLiteral("Shader compiler activity")},
    {QStringLiteral("samplers"), QStringLiteral("Sampler count")},
};

const QStringList kVulkanScaleOptions = {
    QStringLiteral("0.5"), QStringLiteral("0.75"), QStringLiteral("1"),
    QStringLiteral("1.25"), QStringLiteral("1.5"), QStringLiteral("2"),
    QStringLiteral("3"),
};

const QList<QPair<QString, QString>> kGalliumMetrics = {
    {QStringLiteral("fps"), QStringLiteral("FPS")},
    {QStringLiteral("cpu"), QStringLiteral("Overall CPU load")},
    {QStringLiteral("GPU-load"), QStringLiteral("GPU load (RADV/radeonsi)")},
    {QStringLiteral("VRAM-usage"), QStringLiteral("VRAM usage")},
    {QStringLiteral("GTT-usage"), QStringLiteral("GTT (system) memory usage")},
    {QStringLiteral("draw-calls"), QStringLiteral("Draw calls")},
    {QStringLiteral("requested-VRAM"), QStringLiteral("Requested VRAM")},
    {QStringLiteral("requested-GTT"), QStringLiteral("Requested GTT memory")},
};

const QStringList kGalliumScaleOptions = {
    QStringLiteral("1"), QStringLiteral("2"), QStringLiteral("3"),
    QStringLiteral("4"), QStringLiteral("5"),
};

QLabel* mutedLabel(const QString& text)
{
    auto* l = new QLabel(text);
    l->setProperty("muted", true);
    return l;
}

QFrame* horizontalSeparator()
{
    auto* f = new QFrame;
    f->setFrameShape(QFrame::HLine);
    f->setFrameShadow(QFrame::Sunken);
    return f;
}

} // namespace

HudConfigDialog::HudConfigDialog(QWidget* parent)
    : QDialog(parent)
    , m_saved(hudconfig::load())
{
    setWindowTitle(tr("Config HUD"));
    setModal(true);
    setWindowFlags(windowFlags() | Qt::Window);
    buildUi();

    if (const std::optional<QPoint> pos = hudconfig::loadWindowPosition())
        move(*pos);
}

void HudConfigDialog::buildUi()
{
    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(15, 15, 15, 15);
    root->setSpacing(8);

    auto* intro = new QLabel(
        tr("Choose what each HUD mode shows, and its size.\n"
           "Applies to the \"VulkanHUD\" and \"GalliumHUD\" Launch Mode options."));
    intro->setProperty("muted", true);
    root->addWidget(intro);

    m_vulkan = buildSection(root, tr("Vulkan HUD (DXVK_HUD) - DirectX 9-11 games via Vulkan"),
                            kVulkanMetrics, kVulkanScaleOptions,
                            m_saved.vulkanHud.metrics, m_saved.vulkanHud.scale);

    root->addWidget(horizontalSeparator());

    m_gallium = buildSection(root, tr("Gallium HUD (GALLIUM_HUD) - native OpenGL games via Mesa"),
                             kGalliumMetrics, kGalliumScaleOptions,
                             m_saved.galliumHud.metrics, m_saved.galliumHud.scale);

    auto* buttons = new QHBoxLayout;
    buttons->addStretch(1);
    auto* saveBtn = new QPushButton(tr("Save"));
    saveBtn->setObjectName(QStringLiteral("Accent"));
    auto* resetBtn = new QPushButton(tr("Reset to Defaults"));
    auto* closeBtn = new QPushButton(tr("Close"));
    buttons->addWidget(saveBtn);
    buttons->addWidget(resetBtn);
    buttons->addWidget(closeBtn);
    root->addLayout(buttons);

    connect(saveBtn, &QPushButton::clicked, this, &HudConfigDialog::save);
    connect(resetBtn, &QPushButton::clicked, this, &HudConfigDialog::applyDefaults);
    connect(closeBtn, &QPushButton::clicked, this, &HudConfigDialog::reject);
}

HudConfigDialog::Section HudConfigDialog::buildSection(
    QBoxLayout* root, const QString& title,
    const QList<QPair<QString, QString>>& metrics, const QStringList& scaleOptions,
    const QStringList& savedMetrics, const QString& savedScale)
{
    Section section;

    root->addWidget(new QLabel(title));

    auto* grid = new QGridLayout;
    const int columns = 2;
    int i = 0;
    for (const auto& m : metrics) {
        auto* check = new QCheckBox(QStringLiteral("%1 - %2").arg(m.first, m.second));
        check->setChecked(savedMetrics.contains(m.first));
        grid->addWidget(check, i / columns, i % columns, Qt::AlignLeft);
        section.boxes.append(check);
        section.keys.append(m.first);
        ++i;
    }
    root->addLayout(grid);

    auto* sizeRow = new QHBoxLayout;
    sizeRow->addWidget(mutedLabel(tr("HUD Size:")));
    auto* combo = new QComboBox;
    combo->addItems(scaleOptions);
    combo->setEditable(false);
    const int idx = scaleOptions.indexOf(savedScale);
    // Python: scale tersimpan yang tidak ada di daftar -> pakai opsi ke-3.
    combo->setCurrentIndex(idx >= 0 ? idx : qMin(2, scaleOptions.size() - 1));
    sizeRow->addWidget(combo);
    sizeRow->addWidget(mutedLabel(tr("(1 = default)")));
    sizeRow->addStretch(1);
    root->addLayout(sizeRow);

    section.scale = combo;
    root->addSpacing(10);
    return section;
}

void HudConfigDialog::applyDefaults()
{
    const hudconfig::HudConfig defaults;

    for (int i = 0; i < m_vulkan.boxes.size(); ++i)
        m_vulkan.boxes.at(i)->setChecked(
            defaults.vulkanHud.metrics.contains(m_vulkan.keys.at(i)));
    if (m_vulkan.scale)
        m_vulkan.scale->setCurrentText(defaults.vulkanHud.scale);

    for (int i = 0; i < m_gallium.boxes.size(); ++i)
        m_gallium.boxes.at(i)->setChecked(
            defaults.galliumHud.metrics.contains(m_gallium.keys.at(i)));
    if (m_gallium.scale)
        m_gallium.scale->setCurrentText(defaults.galliumHud.scale);
}

void HudConfigDialog::save()
{
    hudconfig::HudConfig cfg;
    for (int i = 0; i < m_vulkan.boxes.size(); ++i) {
        if (m_vulkan.boxes.at(i)->isChecked())
            cfg.vulkanHud.metrics << m_vulkan.keys.at(i);
    }
    cfg.vulkanHud.scale = m_vulkan.scale ? m_vulkan.scale->currentText()
                                         : QStringLiteral("1");

    for (int i = 0; i < m_gallium.boxes.size(); ++i) {
        if (m_gallium.boxes.at(i)->isChecked())
            cfg.galliumHud.metrics << m_gallium.keys.at(i);
    }
    cfg.galliumHud.scale = m_gallium.scale ? m_gallium.scale->currentText()
                                           : QStringLiteral("1");

    hudconfig::save(cfg);
    persistPosition();
    m_saved = cfg;
    emit statusMessage(tr("HUD configuration saved."), true);
}

void HudConfigDialog::showEvent(QShowEvent* event)
{
    QDialog::showEvent(event);
    // dialog.resizable(False, False)
    if (!m_fixedSize) {
        m_fixedSize = true;
        setFixedSize(sizeHint());
    }
}

void HudConfigDialog::moveEvent(QMoveEvent* event)
{
    QDialog::moveEvent(event);
    m_movedTo = event->pos();
}

void HudConfigDialog::done(int result)
{
    persistPosition();
    QDialog::done(result);
}

void HudConfigDialog::persistPosition()
{
    hudconfig::saveWindowPosition(m_movedTo.value_or(pos()));
}
