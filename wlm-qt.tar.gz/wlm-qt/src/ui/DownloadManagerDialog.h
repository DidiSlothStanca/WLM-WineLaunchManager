#pragma once

#include "core/DownloadManager.h"

#include <QDialog>

class QLabel;
class QProgressBar;
class QPushButton;
class QTableWidget;
class QTableWidgetItem;
class QTimer;

// Download manager window (opened from GOG Store's "List Download" button).
// Grid view with: #, Title, Category, Progress bar, Speed, Status, Size, Setup.
// Auto-refreshes every second so progress updates without clicking.
class DownloadManagerDialog : public QDialog {
    Q_OBJECT
public:
    explicit DownloadManagerDialog(QWidget* parent = nullptr);

signals:
    void installCompleted();  // Emitted when a game is installed via Start Setup.
    void downloadCompleted(const QString& title);  // Emitted when download finishes without auto-install.
    void statusMessage(const QString& text, bool success);  // Status message for parent.

protected:
    void showEvent(QShowEvent* event) override;

private:
    void refresh();
    void onPauseClicked();
    void onResumeClicked();
    void onCancelClicked();
    void onClearFinished();
    void onOpenFolder();
    void onRemoveClicked();
    void onStartSetupClicked(int downloadId, const QString& destPath, const QString& gameTitle, const QString& gameId);

    QTableWidget* m_table = nullptr;
    QLabel* m_emptyLabel = nullptr;
    QPushButton* m_pauseBtn = nullptr;
    QPushButton* m_resumeBtn = nullptr;
    QPushButton* m_cancelBtn = nullptr;
    QPushButton* m_removeBtn = nullptr;
    QPushButton* m_clearBtn = nullptr;
    QPushButton* m_openFolderBtn = nullptr;
    QPushButton* m_closeBtn = nullptr;
    QTimer* m_refreshTimer = nullptr;

    int m_selectedId = -1;
};
