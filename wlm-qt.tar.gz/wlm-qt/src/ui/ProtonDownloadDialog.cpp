#include "ui/ProtonDownloadDialog.h"

#include "core/WindowState.h"

#include "core/ArchiveExtractor.h"
#include "core/DownloadManager.h"
#include "core/EnvConfig.h"
#include "core/Paths.h"
#include "core/Proton.h"
#include "core/ProtonDownloader.h"
#include "ui/TaskLogWindow.h"

#include <QDateTime>
#include <QDesktopServices>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QHBoxLayout>
#include <QHash>
#include <QHeaderView>
#include <QLabel>
#include <QMessageBox>
#include <QPushButton>
#include <QRandomGenerator>
#include <QSet>
#include <QTreeWidget>
#include <QUrl>
#include <QVBoxLayout>

namespace {

QString tempDownloadPath(const QString& prefix, const QString& suffix)
{
    const QString stamp = QString::number(QDateTime::currentMSecsSinceEpoch());
    const quint32 rnd = QRandomGenerator::global()->generate();
    return QDir::tempPath()
        + QStringLiteral("/%1_%2_%3%4").arg(prefix, stamp).arg(rnd).arg(suffix);
}

} // namespace

ProtonDownloadDialog::ProtonDownloadDialog(bool cachyos, QWidget* parent)
    : QDialog(parent)
    , m_cachyos(cachyos)
    , m_manager(new ProtonManager(this))
{
    setWindowTitle(cachyos ? tr("Download Proton-CachyOS") : tr("Download ProtonGE"));
    setWindowFlags(windowFlags() | Qt::Window);
    new WindowStateHelper(this, cachyos ? QStringLiteral("proton_dl_cachyos") : QStringLiteral("proton_dl_ge"),
                          cachyos ? QSize(1040, 600) : QSize(900, 560),
                          cachyos ? QSize(900, 480) : QSize(760, 480));
    if (cachyos) {
        resize(1040, 600);
        setMinimumSize(900, 480);
    } else {
        resize(900, 560);
        setMinimumSize(760, 480);
    }

    m_cpu = protonutil::detectCpuProfile();
    buildUi();
    loadReleases();
}

QWidget* ProtonDownloadDialog::logOwner() const
{
    return parentWidget() ? parentWidget() : const_cast<ProtonDownloadDialog*>(this);
}

QString ProtonDownloadDialog::targetDir() const
{
    return m_cachyos ? paths::protonCachyOS() : paths::protonGE();
}

void ProtonDownloadDialog::buildUi()
{
    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(15, 15, 15, 15);
    root->setSpacing(6);

    auto* topBar = new QHBoxLayout;
    auto* heading = new QLabel(m_cachyos
        ? tr("Latest Proton-CachyOS builds (CachyOS/proton-cachyos):")
        : tr("Latest ProtonGE releases (GloriousEggroll/proton-ge-custom):"));
    topBar->addWidget(heading);
    topBar->addStretch(1);
    m_refreshBtn = new QPushButton(tr("Refresh"));
    m_refreshBtn->setFixedWidth(100);
    topBar->addWidget(m_refreshBtn);
    root->addLayout(topBar);

    if (m_cachyos) {
        auto* hint = new QLabel(tr("Your CPU: %1  -  pick a build whose 'Your CPU' column says "
                                   "Recommended or Compatible.").arg(m_cpu.text));
        hint->setProperty("muted", true);
        root->addWidget(hint);
    }

    m_status = new QLabel(tr("Loading releases from GitHub..."));
    m_status->setProperty("muted", true);
    root->addWidget(m_status);

    m_tree = new QTreeWidget;
    m_tree->setRootIsDecorated(false);
    m_tree->setAllColumnsShowFocus(true);
    m_tree->setUniformRowHeights(true);
    m_tree->setSelectionMode(QAbstractItemView::SingleSelection);
    m_tree->setAlternatingRowColors(true);
    if (m_cachyos) {
        m_tree->setColumnCount(7);
        m_tree->setHeaderLabels({tr("Build (full name)"), tr("Variant"), tr("Architecture"),
                                 tr("Your CPU"), tr("Published"), tr("Size"), tr("Status")});
        m_tree->setColumnWidth(0, 340);
        m_tree->setColumnWidth(1, 85);
        m_tree->setColumnWidth(2, 150);
        m_tree->setColumnWidth(3, 100);
        m_tree->setColumnWidth(4, 90);
        m_tree->setColumnWidth(5, 80);
        m_tree->setColumnWidth(6, 75);
    } else {
        m_tree->setColumnCount(5);
        m_tree->setHeaderLabels({tr("Version"), tr("File"), tr("Published"), tr("Size"), tr("Status")});
        m_tree->setColumnWidth(0, 170);
        m_tree->setColumnWidth(1, 260);
        m_tree->setColumnWidth(2, 110);
        m_tree->setColumnWidth(3, 90);
        m_tree->setColumnWidth(4, 100);
    }
    m_tree->header()->setStretchLastSection(false);
    root->addWidget(m_tree, 1);

    if (m_cachyos) {
        m_detail = new QLabel;
        m_detail->setProperty("muted", true);
        m_detail->setWordWrap(true);
        root->addWidget(m_detail);
    }

    auto* buttonRow = new QHBoxLayout;
    buttonRow->addStretch(1);
    m_downloadBtn = new QPushButton(tr("Download & Install"));
    m_downloadBtn->setObjectName(QStringLiteral("Accent"));
    auto* openPageBtn = new QPushButton(tr("Open Releases Page"));
    buttonRow->addWidget(m_downloadBtn);
    buttonRow->addWidget(openPageBtn);
    buttonRow->addStretch(1);
    root->addLayout(buttonRow);

    connect(m_refreshBtn, &QPushButton::clicked, this, &ProtonDownloadDialog::loadReleases);
    connect(m_downloadBtn, &QPushButton::clicked, this, &ProtonDownloadDialog::doDownload);
    connect(openPageBtn, &QPushButton::clicked, this, &ProtonDownloadDialog::openReleasesPage);
    connect(m_tree, &QTreeWidget::itemSelectionChanged, this,
            &ProtonDownloadDialog::onSelectionChanged);
    connect(m_tree, &QTreeWidget::itemDoubleClicked, this,
            [this](QTreeWidgetItem*, int) { doDownload(); });
    connect(m_manager, &ProtonManager::releasesReady, this, &ProtonDownloadDialog::populate);
    connect(m_manager, &ProtonManager::fetchFailed, this, [this](const QString& error) {
        m_refreshBtn->setEnabled(true);
        m_status->setText(tr("Failed to load releases: %1").arg(error));
        QMessageBox::critical(this, tr("Error"),
                              tr("Failed to fetch the release list from GitHub:\n%1\n\n"
                                 "Check your internet connection and try Refresh again.").arg(error));
    });
}

void ProtonDownloadDialog::loadReleases()
{
    m_status->setText(tr("Loading releases from GitHub..."));
    m_refreshBtn->setEnabled(false);
    m_manager->fetchReleases(m_cachyos, m_cachyos ? 20 : 100);
}

void ProtonDownloadDialog::populate(const QList<ProtonRelease>& releases)
{
    m_refreshBtn->setEnabled(true);
    m_status->setText(m_cachyos ? tr("%1 build(s) loaded.").arg(releases.size())
                                : tr("%1 release(s) loaded.").arg(releases.size()));

    m_releases = releases;
    m_tree->clear();

    QSet<QString> installed;
    if (m_cachyos) {
        for (const Proton::Build& b : Proton::findProtonCachyOSInstallations())
            installed.insert(b.name);
    } else {
        for (const Proton::Build& b : Proton::findProtonGEInstallations())
            installed.insert(b.name);
    }

    if (!m_cachyos) {
        int row = 0;
        for (const ProtonRelease& rel : releases) {
            const QString folder = protonutil::stripArchiveSuffix(rel.assetName);
            const bool isInstalled = installed.contains(rel.tag) || installed.contains(folder);
            auto* item = new QTreeWidgetItem(m_tree);
            item->setText(0, rel.name);
            item->setText(1, rel.assetName);
            item->setText(2, rel.publishedAt);
            item->setText(3, protonutil::humanSize(rel.size));
            item->setText(4, isInstalled ? tr("Installed") : QString());
            item->setData(0, Qt::UserRole, row++);
        }
        return;
    }

    // Proton-CachyOS: mark the most optimized compatible build per (tag, variant).
    QHash<QString, QPair<int, QString>> best; // group -> (rank, assetName)
    for (const ProtonRelease& rel : releases) {
        if (protonutil::archCompat(rel.archKey, m_cpu) == 1) {
            const QString grp = rel.tag + QLatin1Char('|') + rel.variant;
            const int rank = protonutil::archRank(rel.archKey);
            if (!best.contains(grp) || rank > best.value(grp).first)
                best.insert(grp, {rank, rel.assetName});
        }
    }

    int row = 0;
    for (const ProtonRelease& rel : releases) {
        const QString fullName = protonutil::stripArchiveSuffix(rel.assetName);
        const bool isInstalled = installed.contains(rel.tag) || installed.contains(fullName);
        const int ok = protonutil::archCompat(rel.archKey, m_cpu);
        QString verdict;
        if (ok == 0)
            verdict = tr("Not compatible");
        else if (ok == 1) {
            const QString grp = rel.tag + QLatin1Char('|') + rel.variant;
            verdict = (best.value(grp).second == rel.assetName) ? tr("Recommended") : tr("Compatible");
        }

        auto* item = new QTreeWidgetItem(m_tree);
        item->setText(0, fullName);
        item->setText(1, rel.variant);
        item->setText(2, rel.archLabel);
        item->setText(3, verdict);
        item->setText(4, rel.publishedAt);
        item->setText(5, protonutil::humanSize(rel.size));
        item->setText(6, isInstalled ? tr("Installed") : QString());
        item->setData(0, Qt::UserRole, row++);
    }
}

int ProtonDownloadDialog::selectedRow() const
{
    QTreeWidgetItem* item = m_tree->currentItem();
    if (!item)
        return -1;
    return item->data(0, Qt::UserRole).toInt();
}

void ProtonDownloadDialog::onSelectionChanged()
{
    if (!m_cachyos || !m_detail)
        return;
    const int idx = selectedRow();
    if (idx < 0 || idx >= m_releases.size()) {
        m_detail->clear();
        return;
    }
    const ProtonRelease& rel = m_releases.at(idx);
    const int ok = protonutil::archCompat(rel.archKey, m_cpu);
    QString note;
    if (ok == 0)
        note = tr("  -  NOT compatible with your CPU");
    else if (ok == 1)
        note = tr("  -  compatible with your CPU");
    m_detail->setText(tr("File: %1\nRelease: %2 (%3)    Architecture: %4%5")
                          .arg(rel.assetName, rel.name, rel.tag, rel.archLabel, note));
}

void ProtonDownloadDialog::doDownload()
{
    const int idx = selectedRow();
    if (idx < 0 || idx >= m_releases.size()) {
        QMessageBox::information(this, tr("Info"),
                                 m_cachyos ? tr("Select a build from the list first.")
                                           : tr("Select a release from the list first."));
        return;
    }
    const ProtonRelease rel = m_releases.at(idx);

    if (m_cachyos && protonutil::archCompat(rel.archKey, m_cpu) == 0) {
        const auto ans = QMessageBox::warning(
            this, tr("Architecture mismatch"),
            tr("'%1' targets %2, which your CPU (%3) does not appear to support, "
               "so games may fail to start.\n\nDownload it anyway?")
                .arg(rel.assetName, rel.archLabel, m_cpu.text),
            QMessageBox::Yes | QMessageBox::No);
        if (ans != QMessageBox::Yes)
            return;
    }

    QString confirm;
    if (m_cachyos) {
        confirm = tr("Download and install %1?\n\nVariant: %2    Architecture: %3\n"
                     "File: %4\nSize: %5\n\nIt will be extracted into:\n%6")
                      .arg(protonutil::stripArchiveSuffix(rel.assetName), rel.variant,
                           rel.archLabel, rel.assetName, protonutil::humanSize(rel.size),
                           targetDir());
    } else {
        confirm = tr("Download and install ProtonGE %1?\n\nFile: %2\nSize: %3\n\n"
                     "It will be extracted into:\n%4")
                      .arg(rel.tag, rel.assetName, protonutil::humanSize(rel.size), targetDir());
    }
    if (QMessageBox::question(this, tr("Download & Install"), confirm) != QMessageBox::Yes)
        return;

    // Determine temp suffix.
    static const QStringList suffixes = {QStringLiteral(".tar.gz"), QStringLiteral(".tar.xz"),
                                         QStringLiteral(".tgz"), QStringLiteral(".zip")};
    QString suffix;
    for (const QString& s : suffixes) {
        if (rel.assetName.toLower().endsWith(s)) {
            suffix = s;
            break;
        }
    }
    if (suffix.isEmpty())
        suffix = QLatin1Char('.') + QFileInfo(rel.assetName).suffix();

    const QString tmpPath = tempDownloadPath(m_cachyos ? QStringLiteral("wlm_protoncachyos_")
                                                       : QStringLiteral("wlm_protonge_"),
                                             suffix);
    const QString fullName = protonutil::stripArchiveSuffix(rel.assetName);
    const QString title = m_cachyos ? tr("Download %1").arg(fullName)
                                    : tr("Download ProtonGE - %1").arg(rel.tag);

    auto* win = new TaskLogWindow(title, logOwner(), true);
    win->setAttribute(Qt::WA_DeleteOnClose);

    // Register with the central download manager.
    DownloadManager* dm = DownloadManager::instance();
    const int dlId = dm->startDownload(
        m_cachyos ? tr("Proton-CachyOS %1").arg(rel.tag) : tr("ProtonGE %1").arg(rel.tag),
        m_cachyos ? QStringLiteral("Proton-CachyOS") : QStringLiteral("ProtonGE"),
        rel.size, targetDir());

    auto* downloader = new ProtonDownloader(win);
    auto* extractor = new ArchiveExtractor(win);

    if (m_cachyos) {
        win->appendLine(tr("Release: %1 (%2) - %3").arg(rel.name, rel.tag, rel.assetName));
    } else {
        win->appendLine(tr("Release: %1 (%2)").arg(rel.name, rel.tag));
    }
    win->appendLine(QString());
    win->appendLine(tr("Downloading %1 (%2)...").arg(rel.assetName, protonutil::humanSize(rel.size)));
    win->show();

    connect(downloader, &ProtonDownloader::line, win, &TaskLogWindow::appendLine);
    connect(downloader, &ProtonDownloader::progress, win,
            [this, dm, dlId, win](qint64 downloaded, qint64 total) {
                if (total > 0) {
                    const int pct = static_cast<int>(downloaded * 100 / total);
                    win->setProgress(pct);
                    dm->updateProgress(dlId, pct, downloaded, total);
                }
            });
    connect(win, &TaskLogWindow::pauseRequested, downloader, &ProtonDownloader::setPaused);

    const bool cachy = m_cachyos;
    connect(downloader, &ProtonDownloader::failed, win,
            [this, dm, dlId, win, cachy, tmpPath](const QString& err) {
                dm->markFailed(dlId, err);
                QFile::remove(tmpPath);
                win->appendLine(QString());
                win->appendLine(tr("ERROR: %1").arg(err));
                win->markFinished();
                QMessageBox::critical(win, tr("Download Failed"),
                                      tr("Failed to download/install %1:\n%2")
                                          .arg(cachy ? QStringLiteral("Proton-CachyOS")
                                                     : QStringLiteral("ProtonGE"), err));
                emit statusMessage(tr("%1 download failed: %2")
                                       .arg(cachy ? QStringLiteral("Proton-CachyOS")
                                                  : QStringLiteral("ProtonGE"), err),
                                   false);
            });

    connect(downloader, &ProtonDownloader::finished, win,
            [this, dm, dlId, win, extractor](const QString& dest, qint64 downloaded) {
                dm->markCompleted(dlId);
                win->disablePause();
                win->appendLine(QString());
                win->appendLine(tr("Download complete (%1). Extracting to %2...")
                                    .arg(protonutil::humanSize(downloaded), targetDir()));
                win->setProgress(-1);
                extractor->extract(dest, targetDir());
            });

    connect(extractor, &ArchiveExtractor::line, win, &TaskLogWindow::appendLine);
    connect(extractor, &ArchiveExtractor::finished, win,
            [this, win, rel, fullName, tmpPath](bool ok, const QString& err) {
                win->appendLine(QString());
                QString installedMsg = m_cachyos
                    ? tr("%1 installed successfully.").arg(fullName)
                    : tr("ProtonGE %1 installed successfully.").arg(rel.tag);
                if (ok) {
                    win->appendLine(installedMsg);
                    emit statusMessage(installedMsg, true);
                } else {
                    win->appendLine(tr("ERROR: %1").arg(err));
                    QMessageBox::critical(win, tr("Extraction Failed"),
                                          tr("Failed to extract archive:\n%1").arg(err));
                    emit statusMessage(tr("Extraction failed: %1").arg(err), false);
                }
                QFile::remove(tmpPath);
                win->markFinished();
            });

    downloader->start(rel.downloadUrl, tmpPath, rel.size);
}

void ProtonDownloadDialog::openReleasesPage()
{
    const EnvConfig cfg = EnvConfig::load();
    const QString page = m_cachyos ? cfg.protonCachyOS.releasesPage : cfg.protonGE.releasesPage;
    QDesktopServices::openUrl(QUrl(page));
}
