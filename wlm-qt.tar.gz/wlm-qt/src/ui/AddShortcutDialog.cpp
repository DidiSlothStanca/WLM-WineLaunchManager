#include "ui/AddShortcutDialog.h"

#include <QComboBox>
#include <QDir>
#include <QFileDialog>
#include <QFileInfo>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QShowEvent>
#include <QVBoxLayout>

namespace {

QString humanSize(qint64 bytes)
{
    const double kb = bytes / 1024.0;
    const double mb = kb / 1024.0;
    if (mb > 1)
        return QStringLiteral("%1 MB").arg(mb, 0, 'f', 2);
    if (kb > 1)
        return QStringLiteral("%1 KB").arg(kb, 0, 'f', 2);
    return QStringLiteral("%1 bytes").arg(bytes);
}

} // namespace

AddShortcutDialog::AddShortcutDialog(const QVector<installwatch::Candidate>& candidates,
                                     const QString& driveC, const QString& defaultName,
                                     QWidget* parent)
    : QDialog(parent)
    , m_candidates(candidates)
    , m_driveC(driveC)
{
    setWindowTitle(tr("Add Shortcut"));
    setModal(true);
    setWindowFlags(windowFlags() | Qt::Window);

    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(15, 15, 15, 15);
    root->setSpacing(8);

    root->addWidget(new QLabel(tr("Setup finished. Add the installed program to the launcher?")));
    root->addWidget(new QLabel(tr("Name:")));
    m_name = new QLineEdit(defaultName);
    root->addWidget(m_name);

    root->addWidget(new QLabel(tr("Executable to launch:")));
    m_combo = new QComboBox;
    m_combo->setMinimumWidth(420);
    root->addWidget(m_combo);
    refreshCombo();

    auto* browseBtn = new QPushButton(tr("Browse Other..."));
    connect(browseBtn, &QPushButton::clicked, this, &AddShortcutDialog::browse);
    root->addWidget(browseBtn, 0, Qt::AlignLeft);

    auto* buttons = new QHBoxLayout;
    buttons->addStretch(1);
    auto* okBtn = new QPushButton(tr("Add Shortcut"));
    okBtn->setObjectName(QStringLiteral("Accent"));
    auto* skipBtn = new QPushButton(tr("Skip"));
    buttons->addWidget(okBtn);
    buttons->addWidget(skipBtn);
    root->addLayout(buttons);

    connect(okBtn, &QPushButton::clicked, this, [this] {
        if (m_name->text().trimmed().isEmpty()) {
            m_name->setFocus();
            return;
        }
        accept();
    });
    connect(skipBtn, &QPushButton::clicked, this, &QDialog::reject);
}

QString AddShortcutDialog::labelFor(const installwatch::Candidate& c) const
{
    QString rel = c.exe;
    if (!m_driveC.isEmpty()) {
        const QString prefix = QDir(m_driveC).absolutePath() + QLatin1Char('/');
        if (rel.startsWith(prefix))
            rel = rel.mid(prefix.size());
    }
    return QStringLiteral("%1  (%2)").arg(rel, humanSize(c.size));
}

void AddShortcutDialog::refreshCombo()
{
    const QString current = m_combo->currentData().toString();
    m_combo->clear();
    for (const installwatch::Candidate& c : m_candidates)
        m_combo->addItem(labelFor(c), c.exe);
    if (!current.isEmpty()) {
        const int idx = m_combo->findData(current);
        if (idx >= 0)
            m_combo->setCurrentIndex(idx);
    }
}

void AddShortcutDialog::browse()
{
    const QString start = !m_driveC.isEmpty() && QFileInfo(m_driveC).isDir()
                              ? m_driveC
                              : QDir::homePath();
    const QString picked = QFileDialog::getOpenFileName(
        this, tr("Select Executable"), start,
        tr("Executable Files (*.exe);;All Files (*)"));
    if (picked.isEmpty())
        return;

    installwatch::Candidate c;
    c.exe = picked;
    c.gameDir = QFileInfo(picked).absolutePath();
    c.size = QFileInfo(picked).size();
    m_candidates.append(c);
    refreshCombo();
    m_combo->setCurrentIndex(m_combo->count() - 1);
}

QString AddShortcutDialog::chosenName() const
{
    return m_name->text().trimmed();
}

QString AddShortcutDialog::chosenExe() const
{
    return m_combo->currentData().toString();
}

void AddShortcutDialog::showEvent(QShowEvent* event)
{
    QDialog::showEvent(event);
    if (!m_centered) {
        m_centered = true;
        adjustSize();
        if (QWidget* p = parentWidget())
            move(p->window()->frameGeometry().center() - rect().center());
    }
}
