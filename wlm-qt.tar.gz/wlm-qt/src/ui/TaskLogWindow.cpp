#include "ui/TaskLogWindow.h"

#include "core/WindowState.h"

#include <QCloseEvent>
#include <QHBoxLayout>
#include <QLabel>
#include <QMessageBox>
#include <QPlainTextEdit>
#include <QProgressBar>
#include <QPushButton>
#include <QScrollBar>
#include <QVBoxLayout>

TaskLogWindow::TaskLogWindow(const QString& title, QWidget* parent, bool withPause,
                             bool withCancel)
    : QDialog(parent)
{
    setWindowTitle(title);
    resize(800, 480);
    setMinimumSize(480, 300);
    setWindowFlags(windowFlags() | Qt::Window);
    new WindowStateHelper(this, QStringLiteral("task_log"), QSize(800, 480), QSize(480, 300));

    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(10, 10, 10, 10);
    root->setSpacing(8);

    auto* progressRow = new QHBoxLayout;
    m_bar = new QProgressBar;
    m_bar->setRange(0, 0); // indeterminate until a size is known
    m_bar->setTextVisible(false);
    progressRow->addWidget(m_bar, 1);
    m_pct = new QLabel;
    m_pct->setFixedWidth(48);
    m_pct->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
    progressRow->addWidget(m_pct);
    root->addLayout(progressRow);

    m_view = new QPlainTextEdit;
    m_view->setReadOnly(true);
    m_view->setLineWrapMode(QPlainTextEdit::NoWrap);
    QFont mono(QStringLiteral("Courier"));
    mono.setStyleHint(QFont::TypeWriter);
    mono.setPointSize(9);
    m_view->setFont(mono);
    root->addWidget(m_view, 1);

    auto* buttonRow = new QHBoxLayout;
    if (withPause) {
        m_pauseBtn = new QPushButton(tr("Pause"));
        connect(m_pauseBtn, &QPushButton::clicked, this, [this] {
            if (m_finished)
                return;
            m_paused = !m_paused;
            m_pauseBtn->setText(m_paused ? tr("Resume") : tr("Pause"));
            emit pauseRequested(m_paused);
        });
        buttonRow->addWidget(m_pauseBtn);
    }
    if (withCancel) {
        m_cancelBtn = new QPushButton(tr("Cancel"));
        connect(m_cancelBtn, &QPushButton::clicked, this, [this] {
            if (m_finished)
                return;
            if (QMessageBox::question(this, tr("Cancel"),
                                      tr("Cancel this operation?")) != QMessageBox::Yes)
                return;
            m_cancelBtn->setEnabled(false);
            emit cancelRequested();
        });
        buttonRow->addWidget(m_cancelBtn);
    }
    buttonRow->addStretch(1);
    m_closeBtn = new QPushButton(tr("Close"));
    connect(m_closeBtn, &QPushButton::clicked, this, &QDialog::close);
    buttonRow->addWidget(m_closeBtn);
    root->addLayout(buttonRow);
}

void TaskLogWindow::appendLine(const QString& text)
{
    m_view->appendPlainText(text);
    m_view->verticalScrollBar()->setValue(m_view->verticalScrollBar()->maximum());
}

void TaskLogWindow::setProgress(int percent)
{
    if (percent < 0) {
        m_bar->setRange(0, 0);
        m_pct->clear();
        return;
    }
    if (m_bar->maximum() != 100)
        m_bar->setRange(0, 100);
    m_bar->setValue(qBound(0, percent, 100));
    m_pct->setText(QStringLiteral("%1%").arg(qBound(0, percent, 100)));
}

void TaskLogWindow::markFinished()
{
    m_finished = true;
    disablePause();
    if (m_cancelBtn)
        m_cancelBtn->setEnabled(false);
    if (m_closeBtn)
        m_closeBtn->setEnabled(true);
}

void TaskLogWindow::disablePause()
{
    if (m_pauseBtn) {
        m_paused = false;
        m_pauseBtn->setEnabled(false);
        m_pauseBtn->setText(tr("Pause"));
    }
}

void TaskLogWindow::closeEvent(QCloseEvent* event)
{
    if (!m_finished) {
        // Task still running: hide instead of destroying so progress is kept.
        event->ignore();
        hide();
        return;
    }
    QDialog::closeEvent(event);
}
