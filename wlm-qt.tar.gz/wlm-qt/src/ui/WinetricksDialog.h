#pragma once

#include <QDialog>
#include <QList>
#include <QStringList>

class QCheckBox;
class QLineEdit;

// Small dialog to pick common Winetricks verbs (checkboxes) plus a free-text
// field for extra verbs. Port of open_winetricks_dialog().
class WinetricksDialog : public QDialog {
    Q_OBJECT
public:
    explicit WinetricksDialog(const QString& prefixCode, QWidget* parent = nullptr);

signals:
    void runRequested(const QStringList& verbs); // empty list == interactive menu
    void interactiveRequested();

private:
    void buildUi();

    QString m_prefixCode;
    QLineEdit* m_custom = nullptr;
    QStringList m_verbs;
    QList<QCheckBox*> m_boxes;
};
