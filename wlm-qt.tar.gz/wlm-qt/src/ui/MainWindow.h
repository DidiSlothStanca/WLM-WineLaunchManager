#pragma once

#include <QHash>
#include <QList>
#include <QMainWindow>
#include <QQueue>
#include <QString>

class AppConfig;
class CoverFetcher;
class GameLauncher;
class GogStoreDialog;
class LibraryGrid;
class LogWindow;
class SaveManagerDialog;
class ThemeManager;
class QTreeWidgetItem;

struct RunnerChoice;
struct SetupResult;

namespace covers {
class CoverStore;
}

class QComboBox;
class QEvent;
class QFrame;
class QLabel;
class QLineEdit;
class QPushButton;
class QResizeEvent;
class QSlider;
class QSplitter;
class QStackedWidget;
class QTimer;
class QToolButton;
class QTreeWidget;

// Main application window: header, toolbar, library/detail split view, footer.
// Stage 1 covers the game library (list view): shortcuts, run, logs, rename,
// icon, folder, remove + runner selection.
class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    MainWindow(AppConfig& config, ThemeManager* theme, QWidget* parent = nullptr);
    ~MainWindow() override;

protected:
    void showEvent(QShowEvent* event) override;
    void closeEvent(QCloseEvent* event) override;
    void resizeEvent(QResizeEvent* event) override;
    bool eventFilter(QObject* obj, QEvent* event) override;

signals:
    void startQueuedInstall(const QString& title);

private slots:
    void onThemeSelected(int index);
    void onSplitterMoved();
    void onSelectionChanged();
    void onSortChanged();
    void setViewMode(const QString& mode);
    void onCardSizeChanged();
    void fetchCovers();
    void addGame();
    void removeGame();
    void renameGame();
    void changeIcon();
    void openFolder();
    void play();
    void viewLogs();
    void installApps();
    void openHudConfig();
    void openProtonDownload(bool cachyos);
    void extractProtonArchive(bool cachyos);
    void openPrefixManager();
    void openGogStore();
    void openDownloadManager();

    // Cover context menu actions
    void showCoverContextMenu(const QPoint& pos);
    void downloadCover();
    void removeCover();
    void uninstallGame();

    // Download queue management
    void processDownloadQueue();
    void onDownloadQueueInstallFinished(const QString& title, bool success);

private:
    void openSaveManager(const QString& name, QWidget* parentForDialog);
    void finishManualInstall(const RunnerChoice& choice, const SetupResult& result);

    void buildUi();
    QWidget* buildToolbar();
    QWidget* buildLibraryPanel();
    QWidget* buildDetailPanel();
    QWidget* buildFooter();
    void buildSidePanel(QWidget* central);

    void toggleSidePanel();
    void showSidePanel();
    void hideSidePanel();
    void applyZoomPercent(int percent);

    void refreshList(bool keepSelection = true);
    QString currentName() const;
    void selectName(const QString& name);
    void updateDetail();
    void loadIcon(const QString& name);
    void setStatus(const QString& text, const QString& color = QString());
    void saveViewConfig();

    void restoreGeometryFromConfig();
    void restoreSash();
    void persistWindow();

    AppConfig& m_config;
    ThemeManager* m_theme;
    GameLauncher* m_launcher;

    QSplitter* m_splitter = nullptr;

    // Library (list view)
    QLineEdit* m_search = nullptr;
    QComboBox* m_sortCombo = nullptr;
    QLabel* m_countLabel = nullptr;
    QStackedWidget* m_libraryStack = nullptr;
    QTreeWidget* m_tree = nullptr;

    // Library (grid view / cover art)
    covers::CoverStore* m_coverStore = nullptr;
    CoverFetcher* m_coverFetcher = nullptr;
    LibraryGrid* m_libraryGrid = nullptr;
    QWidget* m_viewFrame = nullptr;      // card-size row (grid mode only)
    QComboBox* m_sizeCombo = nullptr;
    QPushButton* m_gridBtn = nullptr;
    QPushButton* m_listBtn = nullptr;
    QString m_viewMode = QStringLiteral("list");
    int m_cardWidth = 200;

    // Detail card
    QLabel* m_iconLabel = nullptr;
    QLabel* m_titleLabel = nullptr;
    QLabel* m_sourceValue = nullptr;
    QLabel* m_locationValue = nullptr;
    QLabel* m_modifiedValue = nullptr;
    QLabel* m_sizeValue = nullptr;
    QComboBox* m_launchMode = nullptr;
    QList<QPushButton*> m_actionButtons; // require a selected game

    GogStoreDialog* m_gogStore = nullptr;
    QHash<QString, SaveManagerDialog*> m_saveDialogs;

    // Footer
    QLabel* m_status = nullptr;
    QComboBox* m_themeCombo = nullptr;
    QTimer* m_saveTimer = nullptr;
    QTimer* m_searchTimer = nullptr;

    // Side panel (hamburger drawer)
    QToolButton* m_menuBtn = nullptr;
    QFrame* m_sidePanel = nullptr;
    QWidget* m_sideScrim = nullptr;
    QList<QPushButton*> m_sideItems;
    QSlider* m_zoomSlider = nullptr;
    QLineEdit* m_zoomEdit = nullptr;

    QHash<QString, LogWindow*> m_logWindows;

    // Download queue for sequential installs
    QQueue<QString> m_downloadQueue;
    QString m_currentInstalling;
    bool m_isInstalling = false;

    bool m_sideVisible = false;

    bool m_shown = false;
    bool m_sashRestored = false;
    QString m_lastNormalSize;
    QString m_lastNormalPos;
};
