#pragma once

#include <QDialog>
#include <QString>

class GameLauncher;

class QLabel;
class QPlainTextEdit;

// Real-time / last-saved log viewer for one game. Port of open_log_window().
class LogWindow : public QDialog {
    Q_OBJECT
public:
    LogWindow(GameLauncher* launcher, const QString& name, QWidget* parent = nullptr);

private slots:
    void onOutput(const QString& name, const QString& text);
    void onFinished(const QString& name, int exitCode);

private:
    void appendText(const QString& text);

    GameLauncher* m_launcher;
    QString m_name;
    QPlainTextEdit* m_view = nullptr;
    QLabel* m_state = nullptr;
};
