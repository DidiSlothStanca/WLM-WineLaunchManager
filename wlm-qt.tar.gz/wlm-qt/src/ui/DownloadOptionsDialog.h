#pragma once

#include "core/RunnerConfig.h"

#include <QDialog>

class QCheckBox;
class QComboBox;
class QDialogButtonBox;
class QLabel;
class QVBoxLayout;

class DownloadOptionsDialog : public QDialog {
    Q_OBJECT
public:
    struct Options {
        bool startSetupAfterDownload = false;
        RunnerChoice runnerChoice;  // valid only if startSetupAfterDownload is true
        bool deleteInstallerAfterInstall = false;  // delete installer files after successful install
    };

    explicit DownloadOptionsDialog(QWidget* parent = nullptr);

    Options getOptions() const;

private:
    QCheckBox* m_startSetupCheck = nullptr;
    QCheckBox* m_deleteInstallerCheck = nullptr;
    QComboBox* m_runnerCombo = nullptr;
    QDialogButtonBox* m_buttonBox = nullptr;
};