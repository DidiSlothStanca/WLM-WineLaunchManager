#include "ui/GogStoreDialog.h"

#include "core/DialogSizes.h"
#include "core/DownloadManager.h"
#include "core/GogAuth.h"
#include "core/GogDownloader.h"
#include "core/JsonIO.h"
#include "core/Paths.h"
#include "core/PrefixRegistry.h"
#include "core/Proton.h"
#include "core/SetupRunner.h"
#include "core/Shortcut.h"
#include "core/WindowState.h"
#include "ui/DownloadManagerDialog.h"
#include "ui/DownloadOptionsDialog.h"
#include "ui/GogCoverGrid.h"
#include "ui/GogLoginDialog.h"
#include "ui/RunnerDialog.h"
#include "ui/TaskLogWindow.h"

#include <QDesktopServices>
#include <QFileDialog>
#include <QHBoxLayout>
#include <QStringList>
#include <QHeaderView>
#include <QInputDialog>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QListWidgetItem>
#include <QMessageBox>
#include <QProcess>
#include <QProgressBar>
#include <QPushButton>
#include <QRegularExpression>
#include <QStackedWidget>
#include <QTreeWidget>
#include <QUrl>
#include <QVBoxLayout>
#include <QDateTime>
#include <QDir>
#include <QFileInfo>
#include <QFrame>
#include <QJsonArray>

namespace {

QString humanSize(qint64 bytes)
{
    // Port of launcher.py human_size(): "512 B", "482.3 MB", ...
    double n = double(bytes);
    static const char* units[] = {"B", "KB", "MB", "GB", "TB"};
    for (int i = 0; i < 5; ++i) {
        const QString unit = QString::fromLatin1(units[i]);
        if (n < 1024.0 || i == 4) {
            if (i == 0)
                return QStringLiteral("%1 B").arg(static_cast<qint64>(n));
            return QStringLiteral("%1 %2").arg(n, 0, 'f', 1).arg(unit);
        }
        n /= 1024.0;
    }
    return QStringLiteral("%1 B").arg(bytes);
}

QString safeName(const QString& text, const QString& fallback)
{
    QString out;
    for (const QChar& c : text) {
        if (c.isLetterOrNumber() || c == QLatin1Char('_') || c == QLatin1Char('-')
            || c == QLatin1Char('.') || c == QLatin1Char(' '))
            out.append(c);
    }
    out = out.trimmed();
    return out.isEmpty() ? fallback : out;
}

void openLocalFolder(const QString& path)
{
    QDir().mkpath(path);
    QDesktopServices::openUrl(QUrl::fromLocalFile(path));
}

} // namespace

GogStoreDialog::GogStoreDialog(QWidget* parent)
    : QDialog(parent)
    , m_client(new gog::GogClient(this))
    , m_cfg(gog::loadConfig())
{
    setWindowTitle(tr("GOG Store"));
    setWindowFlags(windowFlags() | Qt::Window
                   | Qt::WindowMinMaxButtonsHint
                   | Qt::WindowCloseButtonHint
                   | Qt::WindowSystemMenuHint);
    buildUi();

    new WindowStateHelper(this, QStringLiteral("gog_store"), QSize(900, 640), QSize(640, 460));

    updateAccountUi();
}

void GogStoreDialog::buildUi()
{
    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(15, 15, 15, 15);
    root->setSpacing(8);

    // ---- Top bar -----------------------------------------------------------
    auto* top = new QHBoxLayout;
    m_account = new QLabel(this);
    top->addWidget(m_account);
    top->addStretch(1);

    m_viewBtn = new QPushButton(tr("List View"), this);
    m_viewBtn->setFixedWidth(110);
    top->addWidget(m_viewBtn);

    m_refreshBtn = new QPushButton(tr("Refresh"), this);
    m_refreshBtn->setFixedWidth(100);
    connect(m_refreshBtn, &QPushButton::clicked, this, [this] { loadLibrary(); });
    top->addWidget(m_refreshBtn);

    m_downloadMgrBtn = new QPushButton(tr("List Download"), this);
    m_downloadMgrBtn->setFixedWidth(120);
    connect(m_downloadMgrBtn, &QPushButton::clicked, this,
            [this] { openDownloadManager(); });
    top->addWidget(m_downloadMgrBtn);

    m_loginBtn = new QPushButton(tr("Login"), this);
    m_loginBtn->setFixedWidth(100);
    connect(m_loginBtn, &QPushButton::clicked, this, [this] { doLogin(); });
    top->addWidget(m_loginBtn);

    m_logoutBtn = new QPushButton(tr("Logout"), this);
    m_logoutBtn->setFixedWidth(100);
    connect(m_logoutBtn, &QPushButton::clicked, this, [this] { doLogout(); });
    top->addWidget(m_logoutBtn);
    root->addLayout(top);

    // ---- Search row --------------------------------------------------------
    auto* searchRow = new QHBoxLayout;
    searchRow->addWidget(new QLabel(tr("Search:"), this));
    m_search = new QLineEdit(this);
    searchRow->addWidget(m_search, 1);
    root->addLayout(searchRow);

    m_status = new QLabel(this);
    root->addWidget(m_status);

    // ---- Content (list + grid) --------------------------------------------
    m_stack = new QStackedWidget(this);

    m_tree = new QTreeWidget(this);
    m_tree->setColumnCount(2);
    m_tree->setHeaderLabels({tr("Game"), tr("Platforms")});
    m_tree->header()->setStretchLastSection(false);
    m_tree->header()->setSectionResizeMode(0, QHeaderView::Stretch);
    m_tree->header()->setSectionResizeMode(1, QHeaderView::Fixed);
    m_tree->setColumnWidth(1, 180);
    m_tree->setRootIsDecorated(false);
    m_tree->setSelectionMode(QAbstractItemView::SingleSelection);
    m_tree->setAlternatingRowColors(true);
    connect(m_tree, &QTreeWidget::itemSelectionChanged, this, [this] {
        if (m_grid)
            m_grid->clearSelection();
    });
    connect(m_tree, &QTreeWidget::itemDoubleClicked, this,
            [this](QTreeWidgetItem*, int) { doDownloadSetup(); });
    m_stack->addWidget(m_tree);

    m_grid = new GogCoverGrid(m_client, m_cfg, this);
    connect(m_grid, &GogCoverGrid::activated, this, [this] { doDownloadSetup(); });
    m_stack->addWidget(m_grid);
    root->addWidget(m_stack, 1);

    connect(m_search, &QLineEdit::textChanged, this, [this](const QString&) { populate(); });

    // ---- Buttons -----------------------------------------------------------
    auto* btnRow = new QHBoxLayout;
    btnRow->addStretch(1);
    auto* directBtn = new QPushButton(tr("Direct Download"), this);
    connect(directBtn, &QPushButton::clicked, this, [this] { doDirectDownload(); });
    btnRow->addWidget(directBtn);

    auto* setupBtn = new QPushButton(tr("Download Setup"), this);
    connect(setupBtn, &QPushButton::clicked, this, [this] { doDownloadSetup(); });
    btnRow->addWidget(setupBtn);

    auto* gamesFolderBtn = new QPushButton(tr("Open Games Folder"), this);
    connect(gamesFolderBtn, &QPushButton::clicked, this,
            [this] { openLocalFolder(m_cfg.gameRoot()); });
    btnRow->addWidget(gamesFolderBtn);

    auto* setupFolderBtn = new QPushButton(tr("Open Setup Folder"), this);
    connect(setupFolderBtn, &QPushButton::clicked, this,
            [this] { openLocalFolder(m_cfg.downloadRoot()); });
    btnRow->addWidget(setupFolderBtn);
    btnRow->addStretch(1);
    root->addLayout(btnRow);

    // Start in the view configured in gog_config.json ("grid" by default).
    m_gridMode = m_cfg.view.trimmed().toLower() != QLatin1String("list");
    m_viewBtn->setText(m_gridMode ? tr("List View") : tr("Grid View"));
    connect(m_viewBtn, &QPushButton::clicked, this, [this] {
        const QString id = selectedGame() ? selectedGame()->id : QString();
        m_gridMode = !m_gridMode;
        m_viewBtn->setText(m_gridMode ? tr("List View") : tr("Grid View"));
        m_stack->setCurrentIndex(m_gridMode ? 1 : 0);
        selectGame(id);
    });
    m_stack->setCurrentIndex(m_gridMode ? 1 : 0);
}

void GogStoreDialog::updateAccountUi()
{
    const gog::Auth auth = gog::loadAuth();
    const bool loggedIn = auth.loggedIn();
    m_account->setText(loggedIn
                           ? tr("Logged in as %1")
                                 .arg(auth.username.isEmpty() ? tr("GOG user") : auth.username)
                           : tr("Not logged in"));
    m_loginBtn->setEnabled(!loggedIn);
    m_logoutBtn->setEnabled(loggedIn);
    m_refreshBtn->setEnabled(loggedIn);
}

void GogStoreDialog::showEvent(QShowEvent* event)
{
    QDialog::showEvent(event);
    // Auto-refresh library every time the dialog is opened.
    if (gog::loadAuth().loggedIn())
        loadLibrary();
}

void GogStoreDialog::loadLibrary()
{
    setStatus(tr("Loading your GOG library..."));
    m_refreshBtn->setEnabled(false);

    m_client->fetchLibrary(m_cfg,
                           [this](const QVector<gog::Game>& games, const QString& err,
                                  bool authError) {
                               // Process the result even if the dialog was hidden
                               // during the fetch — otherwise data is lost.
                               updateAccountUi();
                               if (!err.isEmpty()) {
                                   if (authError)
                                       updateAccountUi();
                                   if (isVisible())
                                       setStatus(tr("Failed to load library: %1").arg(err));
                                   emit statusMessage(tr("GOG library error: %1").arg(err), false);
                                   return;
                               }
                               m_games = games;
                               if (m_grid)
                                   m_grid->setGames(m_games);
                               populate();
                               if (isVisible())
                                   setStatus(tr("%1 game(s) in your library. Select one, then click "
                                                "Download Setup.")
                                                 .arg(games.size()));
                               emit statusMessage(tr("Loaded %1 GOG game(s).").arg(games.size()),
                                                  true);
                           });
}

void GogStoreDialog::onLoggedIn()
{
    updateAccountUi();
    emit statusMessage(tr("Logged in to GOG."), true);
    loadLibrary();
}

void GogStoreDialog::doLogin()
{
    GogLoginDialog dialog(m_client, m_cfg, this);
    if (dialog.exec() == QDialog::Accepted)
        onLoggedIn();
}

void GogStoreDialog::doLogout()
{
    if (QMessageBox::question(this, tr("Logout"),
                              tr("Remove the saved GOG login from this launcher?"))
        != QMessageBox::Yes)
        return;
    gog::clearAuth();
    m_games.clear();
    if (m_grid)
        m_grid->setGames(m_games);
    populate();
    updateAccountUi();
    setStatus(QString());
    emit statusMessage(tr("Logged out of GOG."), true);
}

void GogStoreDialog::populate()
{
    const QString needle = m_search ? m_search->text().trimmed().toLower() : QString();
    m_tree->clear();
    for (const gog::Game& g : m_games) {
        if (!needle.isEmpty() && !g.title.toLower().contains(needle))
            continue;
        auto* item = new QTreeWidgetItem(m_tree);
        item->setText(0, g.title);
        item->setText(1, g.platforms);
        item->setData(0, Qt::UserRole, g.id);
    }
    if (m_grid)
        m_grid->setFilter(needle);
}

std::optional<gog::Game> GogStoreDialog::selectedGame() const
{
    QString id;
    if (m_gridMode) {
        if (m_grid)
            id = m_grid->selectedId();
    } else if (!m_tree->selectedItems().isEmpty()) {
        id = m_tree->selectedItems().first()->data(0, Qt::UserRole).toString();
    }
    if (id.isEmpty())
        return std::nullopt;
    for (const gog::Game& g : m_games) {
        if (g.id == id)
            return g;
    }
    return std::nullopt;
}

void GogStoreDialog::selectGame(const QString& id)
{
    if (id.isEmpty())
        return;
    if (m_gridMode) {
        if (m_grid)
            m_grid->selectById(id);
    } else {
        for (int i = 0; i < m_tree->topLevelItemCount(); ++i) {
            QTreeWidgetItem* item = m_tree->topLevelItem(i);
            if (item->data(0, Qt::UserRole).toString() == id) {
                m_tree->setCurrentItem(item);
                break;
            }
        }
    }
}

void GogStoreDialog::doDirectDownload()
{
    const auto game = selectedGame();
    if (!game) {
        QMessageBox::information(this, tr("GOG Store"), tr("Select a game from the list first."));
        return;
    }
    setStatus(tr("Fetching available versions for %1...").arg(game->title));

    const gog::Game picked = *game;
    m_client->fetchInstallers(
        m_cfg, picked.id,
        [this, picked](const QVector<gog::Installer>& installers, const QString& err,
                       bool authError) {
            if (!isVisible())
                return;
            if (!err.isEmpty()) {
                if (authError)
                    updateAccountUi();
                setStatus(tr("Failed to fetch installers: %1").arg(err));
                QMessageBox::warning(this, tr("GOG Store"),
                                     tr("Failed to fetch installers:\n%1").arg(err));
                return;
            }
            setStatus(QString());
            if (installers.isEmpty()) {
                QMessageBox::information(
                    this, tr("GOG Store"),
                    tr("No downloadable version found for '%1'.").arg(picked.title));
                return;
            }
            QStringList labels;
            for (const gog::Installer& ins : installers) {
                const QString lang =
                    ins.languageName.isEmpty() ? ins.language : ins.languageName;
                labels << QStringLiteral("%1 - %2 - v%3 - %4")
                              .arg(ins.os.isEmpty() ? QStringLiteral("?") : ins.os,
                                   lang.isEmpty() ? QStringLiteral("?") : lang,
                                   ins.version.isEmpty() ? QStringLiteral("?") : ins.version,
                                   humanSize(ins.totalSize));
            }
            bool ok = false;
            const QString choice = QInputDialog::getItem(
                this, tr("Choose Version - %1").arg(picked.title),
                tr("Select the OS/version to download (you'll pick the runner later):"),
                labels, 0, false, &ok);
            if (!ok)
                return;
            const int index = labels.indexOf(choice);
            if (index < 0)
                return;
            startDownload(picked, installers.at(index));
        });
}

void GogStoreDialog::doDownloadSetup()
{
    const auto game = selectedGame();
    if (!game) {
        QMessageBox::information(this, tr("GOG Store"), tr("Select a game from the list first."));
        return;
    }
    setStatus(tr("Fetching installers for %1...").arg(game->title));

    const gog::Game picked = *game;
    m_client->fetchInstallers(
        m_cfg, picked.id,
        [this, picked](const QVector<gog::Installer>& installers, const QString& err,
                       bool authError) {
            if (!isVisible())
                return;
            if (!err.isEmpty()) {
                if (authError)
                    updateAccountUi();
                setStatus(tr("Failed to fetch installers: %1").arg(err));
                QMessageBox::warning(this, tr("GOG Store"),
                                     tr("Failed to fetch installers:\n%1").arg(err));
                return;
            }
            setStatus(QString());
            if (installers.isEmpty()) {
                QMessageBox::information(
                    this, tr("GOG Store"),
                    tr("No downloadable installer found for '%1'.").arg(picked.title));
                return;
            }
            QStringList labels;
            for (const gog::Installer& ins : installers) {
                const QString lang =
                    ins.languageName.isEmpty() ? ins.language : ins.languageName;
                labels << QStringLiteral("%1 - %2 - v%3 - %4")
                              .arg(ins.os.isEmpty() ? QStringLiteral("?") : ins.os,
                                   lang.isEmpty() ? QStringLiteral("?") : lang,
                                   ins.version.isEmpty() ? QStringLiteral("?") : ins.version,
                                   humanSize(ins.totalSize));
            }
            bool ok = false;
            const QString choice = QInputDialog::getItem(
                this, tr("Choose Installer - %1").arg(picked.title),
                tr("Select the installer to download:"), labels, 0, false, &ok);
            if (!ok)
                return;
            const int index = labels.indexOf(choice);
            if (index < 0)
                return;
            startDownload(picked, installers.at(index));
        });
}

void GogStoreDialog::startDownload(const gog::Game& game, const gog::Installer& installer)
{
    const QString dest =
        m_cfg.downloadRoot() + QLatin1Char('/') + safeName(game.title, game.id);

    // Show download options dialog first.
    DownloadOptionsDialog dlg(this);
    if (dlg.exec() != QDialog::Accepted) {
        return; // User cancelled.
    }
    const DownloadOptionsDialog::Options opts = dlg.getOptions();

    // Show notification instead of progress window.
    setStatus(tr("Download started for '%1'. Check \"List Download\" for progress.")
              .arg(game.title));
    emit statusMessage(tr("Download started for '%1'.").arg(game.title), true);

    // Register with the central download manager.
    DownloadManager* dm = DownloadManager::instance();
    const int dlId = dm->startDownload(game.title, QStringLiteral("GOG"),
                                        installer.totalSize, dest);

    auto* downloader = new gog::GogDownloader(m_client);
    // Connect cancel signal from DownloadManager to downloader.
    connect(dm, &DownloadManager::cancelRequested, downloader,
            [dlId, downloader](int id) {
                if (id == dlId)
                    downloader->cancel();
            });
    connect(downloader, &gog::GogDownloader::progress, this,
            [this, dm, dlId](qint64 done, qint64 total) {
                const int pct = total > 0 ? static_cast<int>(done * 100 / total) : -1;
                dm->updateProgress(dlId, pct, done, total);
            });

    connect(downloader, &gog::GogDownloader::finished, this,
            [this, dm, dlId, dest, game, opts](bool ok, const QString& exePath, const QString& err) {
                if (!ok) {
                    dm->markFailed(dlId, err);
                    setStatus(tr("Download failed: %1").arg(err));
                    emit statusMessage(tr("GOG download failed: %1").arg(err), false);
                    QMessageBox::warning(this, tr("Download failed"),
                                         tr("The download did not finish:\n%1").arg(err));
                    return;
                }
                dm->markCompleted(dlId);
                setStatus(tr("Download finished: %1").arg(game.title));
                emit statusMessage(tr("Downloaded GOG setup for '%1'.").arg(game.title), true);

                if (opts.startSetupAfterDownload && !exePath.isEmpty() && QFileInfo::exists(exePath)) {
                    // Auto-run installer with pre-selected runner.
                    // Ensure prefix exists for Proton runners.
                    RunnerChoice choice = opts.runnerChoice;
                    QString prefixError;
                    if (!ensurePrefixForRunner(choice, &prefixError)) {
                        QMessageBox::warning(this, tr("Prefix Error"),
                                             tr("Failed to create prefix:\n%1").arg(prefixError));
                        return;
                    }
                    auto* runner = new SetupRunner(this);
                    QString error;
                    if (!runner->start(exePath, choice, {}, game.id, &error)) {
                        QMessageBox::warning(this, tr("Install failed"),
                                             tr("Could not start installer:\n%1").arg(error));
                        return;
                    }
                    setStatus(tr("Installation started for '%1'.").arg(game.title));
                    // Wait for install to finish, then add the launcher shortcut.
                    connect(runner, &SetupRunner::finished, this,
                            [this, runner, game, choice, dest, opts](const SetupResult& result) {
                                runner->deleteLater();
                                // Reuse the manual install path in non-interactive
                                // mode so the game is added to the launcher library
                                // (emits gameInstalled) without any dialogs.
                                finishInstall(game, choice, result, /*interactive=*/false);
                                const bool succeeded =
                                    result.found
                                    || (!result.candidates.isEmpty() && result.exitCode
                                        && *result.exitCode == 0);
                                if (opts.deleteInstallerAfterInstall && succeeded) {
                                    QDir dir(dest);
                                    if (dir.exists())
                                        dir.removeRecursively();
                                    setStatus(tr("Installation complete, installer cleaned up for '%1'.")
                                                  .arg(game.title));
                                }
                            });
                } else {
                    QMessageBox::information(this, tr("Download complete"),
                        tr("Downloaded the setup files for '%1' to:\n%2\n\n"
                           "No single installer executable was found - run the setup files "
                           "yourself with your preferred runner.")
                            .arg(game.title, dest));
                }
            });

    downloader->start(m_cfg, game.title, installer, dest);
}

// Helper to ensure a prefix exists for the selected runner.
// Returns true on success, false on error (sets error string if provided).
bool GogStoreDialog::ensurePrefixForRunner(RunnerChoice& choice, QString* error)
{
    // Only needed for Proton runners (protonge or protoncachyos)
    if (choice.runner != QLatin1String("protonge") && choice.runner != QLatin1String("protoncachyos")) {
        return true; // Wine doesn't need a specific prefix
    }

    if (choice.protonPath.isEmpty()) {
        if (error) *error = tr("No Proton build selected.");
        return false;
    }

    const QString runnerKey = (choice.runner == QLatin1String("protonge"))
        ? QStringLiteral("protonge") : QStringLiteral("protoncachyos");

    // Generate prefix code and path
    const QString baseDir = prefixreg::getPrefixBaseDir(runnerKey);
    const QString code = prefixreg::generateNextPrefixCode(runnerKey);
    const QString path = QDir(prefixreg::getPrefixBaseDir(runnerKey)).filePath(code);

    // Create the prefix directory
    if (!QDir().mkpath(path)) {
        if (error) *error = tr("Failed to create prefix directory: %1").arg(path);
        return false;
    }

    // Record the prefix in the registry
    prefixreg::recordPrefixUsage(runnerKey, code, path, choice.protonName, choice.protonPath);

    // Set the prefix info in the choice
    choice.prefixCode = code;
    choice.prefixPath = path;

    return true;
}

// Setelah download selesai: pilih runner (dialog yang sama dengan Play) lalu
// jalankan installer di prefix itu. Port of _after_download() dengan choice.
void GogStoreDialog::startInstall(const gog::Game& game, const QString& exePath)
{
    RunnerDialog dialog(this, game.title, QString(), true);
    if (dialog.exec() != QDialog::Accepted) {
        setStatus(tr("Installation cancelled."));
        return;
    }
    const std::optional<RunnerChoice> choiceOpt = dialog.choice();
    if (!choiceOpt.has_value())
        return;
    const RunnerChoice choice = *choiceOpt;

    auto* runner = new SetupRunner(this);
    QString error;
    if (!runner->start(exePath, choice, {}, game.id, &error)) {
        runner->deleteLater();
        setStatus(tr("Could not start the installer: %1").arg(error));
        emit statusMessage(tr("Could not start installer: %1").arg(error), false);
        QMessageBox::warning(this, tr("Install failed"),
                             tr("Could not start the installer:\n%1").arg(error));
        return;
    }

    setStatus(tr("Installing %1...").arg(game.title));
    emit statusMessage(tr("Installing '%1'...").arg(game.title), true);
    connect(runner, &SetupRunner::finished, this,
            [this, runner, game, choice](const SetupResult& result) {
                runner->deleteLater();
                finishInstall(game, choice, result);
            });
}

// Main thread: buat shortcut dari hasil deteksi installer (atau tanya kalau
// tidak ketemu pasti). Port of _finish_install() dari gog_store.py.
void GogStoreDialog::finishInstall(const gog::Game& game, const RunnerChoice& choice,
                                   const SetupResult& result, bool interactive)
{
    RunnerChoice c = choice;
    c.source = QStringLiteral("gog");
    c.gogId = game.id;

    QString exe;
    QString workDir;
    QString iconPath;

    if (result.found) {
        exe = result.found->exe;
        workDir = result.found->workdir;
        if (result.found->hasIcon)
            iconPath = result.found->icon;
    } else {
        if (result.exitCode && *result.exitCode != 0) {
            setStatus(tr("Installer exited (code %1) - no shortcut was added.")
                          .arg(*result.exitCode));
            emit statusMessage(tr("'%1' install closed (exit code %2) - no shortcut added.")
                                   .arg(game.title)
                                   .arg(*result.exitCode),
                               false);
            return;
        }
        if (!result.candidates.isEmpty()) {
            const QString best = result.candidates.first().exe;
            QString rel = best;
            if (!result.driveC.isEmpty()
                && rel.startsWith(result.driveC + QLatin1Char('/')))
                rel = rel.mid(result.driveC.size() + 1);
            // Auto mode (post-download) picks the best candidate without asking.
            if (!interactive) {
                exe = best;
            } else if (QMessageBox::question(
                    this, tr("Add Shortcut"),
                    tr("'%1' was installed, but no GOG info file was found.\n\n"
                       "Use this executable for the launcher shortcut?\n%2")
                        .arg(game.title, rel))
                == QMessageBox::Yes) {
                exe = best;
            }
        }
        if (exe.isEmpty()) {
            if (interactive && QMessageBox::question(
                    this, tr("Add Shortcut"),
                    tr("The installer finished, but '%1' could not be located "
                       "automatically.\n\nSelect its .exe now to add a launcher shortcut?")
                        .arg(game.title))
                == QMessageBox::Yes) {
                const QString start = !result.driveC.isEmpty()
                                          && QFileInfo(result.driveC).isDir()
                                      ? result.driveC
                                      : QDir::homePath();
                exe = QFileDialog::getOpenFileName(
                    this, tr("Select the game executable - %1").arg(game.title), start,
                    tr("Executable Files (*.exe);;All Files (*)"));
            }
        }
        if (exe.isEmpty()) {
            setStatus(tr("Installed - no shortcut added."));
            emit statusMessage(tr("'%1' installed - no shortcut added.").arg(game.title),
                               true);
            return;
        }
    }

    // Utamakan cover GOG yang sudah di-cache sebagai ikon; kalau tidak ada
    // jatuh ke ikon .ico dari goggame-*.info.
    const QString cover = paths::gogCovers() + QLatin1Char('/') + game.id
                          + QStringLiteral(".jpg");
    if (QFileInfo::exists(cover))
        iconPath = cover;

    const QString finalName = shortcut::addGameShortcut(game.title, exe, c, iconPath, workDir);
    if (finalName.isEmpty()) {
        setStatus(tr("Could not add the shortcut."));
        emit statusMessage(tr("Could not add shortcut for '%1'.").arg(game.title), false);
        return;
    }
    setStatus(tr("'%1' was added to the launcher.").arg(finalName));
    emit statusMessage(tr("'%1' was added to the launcher.").arg(finalName), true);
    emit gameInstalled();  // Notify MainWindow to refresh library
}

void GogStoreDialog::setStatus(const QString& text)
{
    m_status->setText(text);
}

void GogStoreDialog::openDownloadManager()
{
    auto* dlg = new DownloadManagerDialog(this);
    dlg->setAttribute(Qt::WA_DeleteOnClose);
    dlg->show();
    dlg->raise();
    dlg->activateWindow();
}
