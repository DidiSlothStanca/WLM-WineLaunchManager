#pragma once

#include "core/ProtonManager.h"

#include <QDialog>
#include <QList>

class QLabel;
class QPushButton;
class QTreeWidget;

// Release browser + installer for Proton GE and Proton-CachyOS. Mirrors
// open_protonge_download_dialog() / open_protoncachyos_download_dialog().
class ProtonDownloadDialog : public QDialog {
    Q_OBJECT
public:
    ProtonDownloadDialog(bool cachyos, QWidget* parent);

signals:
    void statusMessage(const QString& text, bool success);

private:
    void buildUi();
    void loadReleases();
    void populate(const QList<ProtonRelease>& releases);
    void onSelectionChanged();
    void doDownload();
    void openReleasesPage();
    int selectedRow() const;
    QWidget* logOwner() const;
    QString targetDir() const;

    bool m_cachyos;
    ProtonManager* m_manager = nullptr;
    CpuProfile m_cpu;

    QTreeWidget* m_tree = nullptr;
    QLabel* m_status = nullptr;
    QLabel* m_detail = nullptr;
    QPushButton* m_refreshBtn = nullptr;
    QPushButton* m_downloadBtn = nullptr;

    QList<ProtonRelease> m_releases;
};
