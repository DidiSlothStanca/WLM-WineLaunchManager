#include "core/AppConfig.h"
#include "core/EnvConfig.h"
#include "core/Paths.h"
#include "core/ThemeManager.h"
#include "core/Version.h"
#include "ui/MainWindow.h"

#include <QApplication>
#include <QIcon>
#include <QStringList>
#include <cstdio>

namespace {

void printVersionAndExit()
{
    std::printf("WLM Version: %s\n", WLM_VERSION);
    std::printf("Developer: %s (%s)\n", WLM_DEVELOPER, WLM_DEVELOPER_ABBR);
    std::printf("Maintener: %s\n", WLM_MAINTAINER); // spelling kept as in the Python original
}

} // namespace

int main(int argc, char* argv[])
{
    for (int i = 1; i < argc; ++i) {
        const QString arg = QString::fromLocal8Bit(argv[i]);
        if (arg == QLatin1String("--version") || arg == QLatin1String("-v")) {
            printVersionAndExit();
            return 0;
        }
    }

    // Suppress harmless GPU/sandbox warnings from QtWebEngine on older Intel
    // (Haswell) and restricted environments. These don't affect functionality.
    if (qEnvironmentVariableIsEmpty("MESA_NO_ERROR"))
        qputenv("MESA_NO_ERROR", "1");
    if (qEnvironmentVariableIsEmpty("QTWEBENGINE_DISABLE_SANDBOX"))
        qputenv("QTWEBENGINE_DISABLE_SANDBOX", "1");

    QApplication app(argc, argv);
    QApplication::setApplicationName(QStringLiteral("Wine Launch Manager"));
    QApplication::setApplicationDisplayName(QStringLiteral("Wine Launch Manager"));
    QApplication::setApplicationVersion(QLatin1String(WLM_VERSION));
    QApplication::setOrganizationName(QStringLiteral("OOGR"));
    // App / window icon (top-left corner of the window). Embedded via wlm.qrc.
    QApplication::setWindowIcon(QIcon(QStringLiteral(":/icons/my_gear.png")));

    // Make sure the ~/wlm data directory exists before anything reads it.
    paths::ensureDirectories();

    // Parse env_config.yaml once so a malformed file is reported early.
    const EnvConfig env = EnvConfig::load();
    Q_UNUSED(env);

    AppConfig config;
    config.load();

    ThemeManager theme;
    theme.apply(config.theme());
    theme.setFontScalePercent(config.window().zoom);

    MainWindow window(config, &theme);
    window.show();

    return app.exec();
}
