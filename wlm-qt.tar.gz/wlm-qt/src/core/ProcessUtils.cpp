#include "core/ProcessUtils.h"

namespace procutil {

QProcessEnvironment cleanEnvironment()
{
    QProcessEnvironment env = QProcessEnvironment::systemEnvironment();
    if (env.contains(QStringLiteral("APPIMAGE"))
        && env.contains(QStringLiteral("LD_LIBRARY_PATH"))) {
        env.remove(QStringLiteral("LD_LIBRARY_PATH"));
    }
    return env;
}

} // namespace procutil
