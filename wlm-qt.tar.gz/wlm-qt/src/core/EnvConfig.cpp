#include "core/EnvConfig.h"

#include "core/Paths.h"

#include <QFile>
#include <QSaveFile>
#include <QTextStream>

namespace {

const char* kProtonGEApi =
    "https://api.github.com/repos/GloriousEggroll/proton-ge-custom/releases";
const char* kProtonGEPage =
    "https://github.com/GloriousEggroll/proton-ge-custom/releases";
const char* kProtonCachyOSApi =
    "https://api.github.com/repos/CachyOS/proton-cachyos/releases";
const char* kProtonCachyOSPage =
    "https://github.com/CachyOS/proton-cachyos/releases";

// Strip surrounding single/double quotes and whitespace.
QString unquote(QString s)
{
    s = s.trimmed();
    if (s.size() >= 2
        && ((s.startsWith(QLatin1Char('"')) && s.endsWith(QLatin1Char('"')))
            || (s.startsWith(QLatin1Char('\'')) && s.endsWith(QLatin1Char('\''))))) {
        s = s.mid(1, s.size() - 2);
    }
    return s;
}

bool isBlankOrComment(const QString& line)
{
    const QString t = line.trimmed();
    return t.isEmpty() || t.startsWith(QLatin1Char('#'));
}

} // namespace

EnvConfig EnvConfig::load()
{
    EnvConfig cfg;
    cfg.protonGE.releasesApi = QLatin1String(kProtonGEApi);
    cfg.protonGE.releasesPage = QLatin1String(kProtonGEPage);
    cfg.protonCachyOS.releasesApi = QLatin1String(kProtonCachyOSApi);
    cfg.protonCachyOS.releasesPage = QLatin1String(kProtonCachyOSPage);

    const QString path = paths::envConfig();

    if (!QFile::exists(path)) {
        // Write a default file so the user has something to edit.
        QSaveFile f(path);
        if (f.open(QIODevice::WriteOnly | QIODevice::Text)) {
            QTextStream out(&f);
            out << "# Wine Launch Manager - environment configuration\n"
                << "# URLs used by the \"Download Online\" feature to check for and fetch new\n"
                << "# Proton GE / Proton-CachyOS builds. Edit and save, then restart WLM (or\n"
                << "# reopen the Download Online dialog) to apply changes.\n\n"
                << "proton_ge:\n"
                << "  releases_api: " << kProtonGEApi << "\n"
                << "  releases_page: " << kProtonGEPage << "\n"
                << "proton_cachyos:\n"
                << "  releases_api: " << kProtonCachyOSApi << "\n"
                << "  releases_page: " << kProtonCachyOSPage << "\n";
            f.commit();
        }
        return cfg;
    }

    QFile f(path);
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text))
        return cfg;

    QTextStream in(&f);
    QString section;
    while (!in.atEnd()) {
        const QString raw = in.readLine();
        if (isBlankOrComment(raw))
            continue;

        const bool indented = raw.startsWith(QLatin1Char(' ')) || raw.startsWith(QLatin1Char('\t'));
        const QString line = raw.trimmed();
        const int colon = line.indexOf(QLatin1Char(':'));
        if (colon < 0)
            continue;

        const QString key = line.left(colon).trimmed();
        const QString value = unquote(line.mid(colon + 1));

        if (!indented) {
            section = key;
            continue;
        }

        if (section == QLatin1String("proton_ge")) {
            if (key == QLatin1String("releases_api") && !value.isEmpty())
                cfg.protonGE.releasesApi = value;
            else if (key == QLatin1String("releases_page") && !value.isEmpty())
                cfg.protonGE.releasesPage = value;
        } else if (section == QLatin1String("proton_cachyos")) {
            if (key == QLatin1String("releases_api") && !value.isEmpty())
                cfg.protonCachyOS.releasesApi = value;
            else if (key == QLatin1String("releases_page") && !value.isEmpty())
                cfg.protonCachyOS.releasesPage = value;
        }
    }

    return cfg;
}
