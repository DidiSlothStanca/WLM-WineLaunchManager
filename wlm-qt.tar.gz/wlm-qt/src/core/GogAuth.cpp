#include "core/GogAuth.h"

#include "core/JsonIO.h"
#include "core/Paths.h"

#include <QFile>
#include <QRegularExpression>
#include <QUrl>

namespace gog {

namespace {
QString resolvePath(const QString& path)
{
    return path.isEmpty() ? paths::gogAuth() : path;
}
} // namespace

QJsonObject Auth::toJson() const
{
    QJsonObject obj;
    if (!accessToken.isEmpty())
        obj.insert(QStringLiteral("access_token"), accessToken);
    if (!refreshToken.isEmpty())
        obj.insert(QStringLiteral("refresh_token"), refreshToken);
    if (!userId.isEmpty())
        obj.insert(QStringLiteral("user_id"), userId);
    if (!username.isEmpty())
        obj.insert(QStringLiteral("username"), username);
    if (expiresAt > 0)
        obj.insert(QStringLiteral("expires_at"), static_cast<double>(expiresAt));
    return obj;
}

Auth Auth::fromJson(const QJsonObject& obj)
{
    Auth a;
    a.accessToken = obj.value(QStringLiteral("access_token")).toString();
    a.refreshToken = obj.value(QStringLiteral("refresh_token")).toString();
    a.userId = obj.value(QStringLiteral("user_id")).toString();
    a.username = obj.value(QStringLiteral("username")).toString();
    a.expiresAt = static_cast<qint64>(obj.value(QStringLiteral("expires_at")).toDouble());
    return a;
}

Auth loadAuth(const QString& path)
{
    return Auth::fromJson(jsonio::readObject(resolvePath(path)));
}

void saveAuth(const Auth& auth, const QString& path)
{
    const QString p = resolvePath(path);
    jsonio::writeObjectAtomic(p, auth.toJson());
    QFile::setPermissions(p, QFileDevice::ReadOwner | QFileDevice::WriteOwner); // 0600
}

void clearAuth(const QString& path)
{
    QFile::remove(resolvePath(path));
}

QString loginUrl(const Config& cfg)
{
    auto enc = [](const QString& s) {
        return QString::fromLatin1(QUrl::toPercentEncoding(s));
    };
    return cfg.authUrl + QStringLiteral("?client_id=") + enc(cfg.clientId)
        + QStringLiteral("&redirect_uri=") + enc(cfg.redirectUri)
        + QStringLiteral("&response_type=code&layout=client2");
}

QString extractCode(const QString& textIn)
{
    const QString text = textIn.trimmed();
    if (text.isEmpty())
        return {};

    static const QRegularExpression re(QStringLiteral("[?&]code=([^&\\s#]+)"));
    const QRegularExpressionMatch m = re.match(text);
    if (m.hasMatch())
        return QUrl::fromPercentEncoding(m.captured(1).toUtf8());

    static const QRegularExpression bare(QStringLiteral("^[\\w\\-.~]+$"));
    if (bare.match(text).hasMatch())
        return text;
    return {};
}

} // namespace gog
