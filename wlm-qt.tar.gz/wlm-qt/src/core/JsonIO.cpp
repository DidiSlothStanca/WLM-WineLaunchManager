#include "core/JsonIO.h"

#include <QDir>
#include <QFile>
#include <QJsonDocument>
#include <QSaveFile>

namespace jsonio {

QJsonObject readObject(const QString& path)
{
    QFile f(path);
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text))
        return {};
    const QByteArray data = f.readAll();
    f.close();

    QJsonParseError err{};
    const QJsonDocument doc = QJsonDocument::fromJson(data, &err);
    if (err.error != QJsonParseError::NoError || !doc.isObject())
        return {};
    return doc.object();
}

bool writeObjectAtomic(const QString& path, const QJsonObject& obj)
{
    // QSaveFile writes to a temp file and atomically renames on commit().
    QSaveFile f(path);
    if (!f.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate))
        return false;

    const QByteArray data = QJsonDocument(obj).toJson(QJsonDocument::Indented);
    if (f.write(data) != data.size()) {
        f.cancelWriting();
        return false;
    }
    return f.commit();
}

} // namespace jsonio
