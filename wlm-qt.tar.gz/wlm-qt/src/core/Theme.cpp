#include "core/Theme.h"

#include <QtMath>

QColor mixColor(const QColor& c1, const QColor& c2, double t)
{
    if (!c1.isValid() || !c2.isValid())
        return c1;
    auto blend = [t](int a, int b) {
        return static_cast<int>(qRound(a + (b - a) * t));
    };
    return QColor(blend(c1.red(), c2.red()),
                  blend(c1.green(), c2.green()),
                  blend(c1.blue(), c2.blue()));
}

QColor readableOn(const QColor& bg, const QColor& dark, const QColor& light)
{
    if (!bg.isValid())
        return light;
    const double luma = 0.299 * bg.red() + 0.587 * bg.green() + 0.114 * bg.blue();
    return luma > 150.0 ? dark : light;
}
