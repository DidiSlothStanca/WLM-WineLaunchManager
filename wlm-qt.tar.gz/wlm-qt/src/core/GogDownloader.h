#pragma once

#include "core/GogClient.h"

#include <QObject>
#include <QString>
#include <QVector>

class QFile;
class QNetworkAccessManager;
class QNetworkReply;

namespace gog {

// Downloads every file of a GOG installer into a folder, one after another,
// following the same idea as gog_store.py's _download_worker(): resolve each
// file's temporary downlink, stream it to `<name>.part`, then rename it. Resumes
// from an existing `.part` with a Range request. Emits line/progress/finished so
// the UI can drive a TaskLogWindow.
class GogDownloader : public QObject {
    Q_OBJECT
public:
    explicit GogDownloader(GogClient* client, QObject* parent = nullptr);

    void start(const Config& cfg, const QString& label, const Installer& installer,
               const QString& destDir);
    void cancel();

    bool isRunning() const { return m_running; }

signals:
    void line(const QString& text);
    void progress(qint64 done, qint64 total);
    void finished(bool ok, const QString& exePath, const QString& error);

private:
    void startNextFile();
    void beginDownload(const QString& url, qint64 offset);
    void finishRun(bool ok, const QString& error);

    GogClient* m_client;
    QNetworkAccessManager* m_nam;

    Config m_cfg;
    QString m_label;
    QString m_destDir;
    QVector<InstallerFile> m_files;
    int m_index = 0;
    qint64 m_total = 0;
    qint64 m_done = 0;
    QString m_exePath;

    QString m_currentName;
    QString m_currentFinal;
    QString m_currentPart;

    QNetworkReply* m_reply = nullptr;
    QFile* m_file = nullptr;
    qint64 m_pendingOffset = 0;
    bool m_cancelled = false;
    bool m_running = false;
    bool m_finished = false;
};

} // namespace gog
