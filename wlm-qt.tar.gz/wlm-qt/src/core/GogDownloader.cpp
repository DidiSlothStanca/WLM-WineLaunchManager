#include "core/GogDownloader.h"

#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QUrl>

namespace gog {

GogDownloader::GogDownloader(GogClient* client, QObject* parent)
    : QObject(parent)
    , m_client(client)
    , m_nam(new QNetworkAccessManager(this))
{
}

void GogDownloader::start(const Config& cfg, const QString& label, const Installer& installer,
                          const QString& destDir)
{
    if (m_running)
        return;
    m_cfg = cfg;
    m_label = label;
    m_destDir = destDir;
    m_files = installer.files;
    m_index = 0;
    m_done = 0;
    m_total = 0;
    m_exePath.clear();
    m_cancelled = false;
    m_finished = false;
    m_running = true;

    for (const InstallerFile& f : m_files)
        m_total += f.size;

    QDir().mkpath(m_destDir);
    emit line(QStringLiteral("Downloading setup for \"%1\"...").arg(label));
    emit line(QStringLiteral("Destination: %1").arg(m_destDir));
    emit line(QString());
    emit progress(0, m_total);

    startNextFile();
}

void GogDownloader::cancel()
{
    m_cancelled = true;
    if (m_reply)
        m_reply->abort();
}

void GogDownloader::startNextFile()
{
    if (m_cancelled) {
        finishRun(false, QStringLiteral("Cancelled."));
        return;
    }
    if (m_index >= m_files.size()) {
        emit line(QString());
        emit line(QStringLiteral("Download complete."));
        finishRun(true, QString());
        return;
    }

    const InstallerFile f = m_files.at(m_index);
    m_client->resolveDownlink(
        m_cfg, f.downlink,
        [this, f](const QString& url, const QString& err, bool) {
            if (m_cancelled) {
                finishRun(false, QStringLiteral("Cancelled."));
                return;
            }
            if (!err.isEmpty()) {
                finishRun(false, err);
                return;
            }

            QString name = QUrl(url).fileName();
            if (name.isEmpty())
                name = QStringLiteral("installer-%1.bin").arg(m_index + 1);
            m_currentName = name;
            m_currentFinal = m_destDir + QLatin1Char('/') + name;
            m_currentPart = m_currentFinal + QStringLiteral(".part");

            const bool finalExists = QFileInfo::exists(m_currentFinal);
            const bool partExists = QFileInfo::exists(m_currentPart);
            if (finalExists && !partExists) {
                emit line(QStringLiteral("Already downloaded: %1").arg(name));
                const qint64 actual =
                    f.size > 0 ? f.size : QFileInfo(m_currentFinal).size();
                m_done += actual;
                emit progress(m_done, m_total);
                ++m_index;
                startNextFile();
                return;
            }

            const qint64 offset = partExists ? QFileInfo(m_currentPart).size() : 0;
            emit line(offset > 0
                          ? QStringLiteral("Resuming %1...").arg(name)
                          : QStringLiteral("Downloading %1...").arg(name));
            if (offset > 0)
                m_done += offset;
            beginDownload(url, offset);
        });
}

void GogDownloader::beginDownload(const QString& url, qint64 offset)
{
    QNetworkRequest req{QUrl(url)};
    req.setHeader(QNetworkRequest::UserAgentHeader, m_cfg.userAgent);
    req.setAttribute(QNetworkRequest::RedirectPolicyAttribute,
                     QNetworkRequest::NoLessSafeRedirectPolicy);
    if (offset > 0)
        req.setRawHeader("Range", "bytes=" + QByteArray::number(offset) + "-");

    m_pendingOffset = offset;
    QNetworkReply* reply = m_nam->get(req);
    m_reply = reply;

    connect(reply, &QNetworkReply::readyRead, this, [this, reply] {
        if (!m_file) {
            // Open lazily so we can tell whether the server honoured the Range
            // request (HTTP 206) or sent the whole file again (HTTP 200). When
            // it ignored the range, restart this file from scratch.
            const int status = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
            const bool resumed = m_pendingOffset > 0 && status == 206;
            if (m_pendingOffset > 0 && !resumed)
                m_done -= m_pendingOffset;
            m_file = new QFile(m_currentPart);
            const QIODevice::OpenMode mode =
                QIODevice::WriteOnly | (resumed ? QIODevice::Append : QIODevice::Truncate);
            if (!m_file->open(mode)) {
                delete m_file;
                m_file = nullptr;
                finishRun(false, QStringLiteral("Could not write to %1").arg(m_currentPart));
                reply->abort();
                return;
            }
        }
        const QByteArray data = reply->readAll();
        if (data.isEmpty())
            return;
        m_file->write(data);
        m_done += data.size();
        emit progress(m_done, m_total);
    });

    connect(reply, &QNetworkReply::finished, this, [this, reply] {
        reply->deleteLater();
        if (m_file) {
            m_file->close();
            delete m_file;
            m_file = nullptr;
        }
        m_reply = nullptr;

        if (m_cancelled) {
            finishRun(false, QStringLiteral("Cancelled."));
            return;
        }
        if (reply->error() != QNetworkReply::NoError) {
            finishRun(false, reply->errorString());
            return;
        }

        // A zero-byte file never triggered readyRead, so make sure the .part
        // exists before renaming it into place.
        if (!QFileInfo::exists(m_currentPart)) {
            QFile empty(m_currentPart);
            empty.open(QIODevice::WriteOnly);
            empty.close();
        }

        QFile::remove(m_currentFinal);
        if (!QFile::rename(m_currentPart, m_currentFinal)) {
            finishRun(false, QStringLiteral("Could not finalize %1").arg(m_currentName));
            return;
        }
        emit line(QStringLiteral("Downloaded: %1").arg(m_currentName));
        if (m_currentName.endsWith(QStringLiteral(".exe"), Qt::CaseInsensitive))
            m_exePath = m_currentFinal;

        ++m_index;
        startNextFile();
    });
}

void GogDownloader::finishRun(bool ok, const QString& error)
{
    if (m_finished)
        return;
    m_finished = true;
    m_running = false;
    if (!ok && !error.isEmpty())
        emit line(QStringLiteral("ERROR: %1").arg(error));
    emit finished(ok, m_exePath, error);
}

} // namespace gog
