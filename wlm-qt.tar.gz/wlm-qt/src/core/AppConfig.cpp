#include "core/AppConfig.h"

#include "core/JsonIO.h"
#include "core/Paths.h"

#include <QJsonObject>
#include <QRegularExpression>

QSize WindowGeometry::toSize() const
{
    // Accept only a single 'x' separator, e.g. "1000x720".
    static const QRegularExpression re(QStringLiteral("^(\\d+)x(\\d+)$"));
    const QRegularExpressionMatch m = re.match(size);
    if (m.hasMatch())
        return QSize(m.captured(1).toInt(), m.captured(2).toInt());
    return QSize(1000, 720);
}

bool WindowGeometry::hasPosition() const
{
    // Exactly two '+' characters and the string starts with '+', e.g. "+10+20".
    return position.startsWith(QLatin1Char('+'))
        && position.count(QLatin1Char('+')) == 2;
}

QPoint WindowGeometry::toPoint() const
{
    static const QRegularExpression re(QStringLiteral("^\\+(\\d+)\\+(\\d+)$"));
    const QRegularExpressionMatch m = re.match(position);
    if (m.hasMatch())
        return QPoint(m.captured(1).toInt(), m.captured(2).toInt());
    return {};
}

void AppConfig::load()
{
    m_theme = QStringLiteral("default");
    m_window = WindowGeometry{};

    // --- theme_config.json ---
    const QJsonObject themeObj = jsonio::readObject(paths::themeConfig());
    if (themeObj.contains(QStringLiteral("theme"))) {
        const QString t = themeObj.value(QStringLiteral("theme")).toString();
        if (!t.isEmpty())
            m_theme = t;
    }

    // --- window_config.json ---
    const QJsonObject winObj = jsonio::readObject(paths::windowConfig());
    if (!winObj.isEmpty()) {
        const QString loadedSize = winObj.value(QStringLiteral("size")).toString();
        if (loadedSize.contains(QLatin1Char('x'))
            && loadedSize.count(QLatin1Char('x')) == 1) {
            m_window.size = loadedSize;
        }

        const QString loadedPos = winObj.value(QStringLiteral("position")).toString();
        m_window.position = loadedPos;

        m_window.maximized =
            winObj.value(QStringLiteral("maximized")).toBool(false);

        const QJsonValue sashVal = winObj.value(QStringLiteral("sash"));
        if (sashVal.isDouble()) {
            const int sash = sashVal.toInt(-1);
            if (sash > 0)
                m_window.sash = sash;
        }

        const QJsonValue zoomVal = winObj.value(QStringLiteral("zoom"));
        if (zoomVal.isDouble()) {
            const int zoom = zoomVal.toInt(100);
            if (zoom >= 10 && zoom <= 200)
                m_window.zoom = zoom;
        }
    }
}

void AppConfig::saveTheme() const
{
    QJsonObject obj;
    obj.insert(QStringLiteral("theme"), m_theme);
    jsonio::writeObjectAtomic(paths::themeConfig(), obj);
}

void AppConfig::saveWindow() const
{
    QJsonObject obj;
    obj.insert(QStringLiteral("size"), m_window.size);
    obj.insert(QStringLiteral("position"),
               m_window.hasPosition() ? m_window.position : QString());
    obj.insert(QStringLiteral("maximized"), m_window.maximized);
    if (m_window.sash > 0)
        obj.insert(QStringLiteral("sash"), m_window.sash);
    obj.insert(QStringLiteral("zoom"), m_window.zoom);
    jsonio::writeObjectAtomic(paths::windowConfig(), obj);
}
