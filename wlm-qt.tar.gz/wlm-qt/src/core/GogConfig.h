#pragma once

#include <QJsonObject>
#include <QString>
#include <QStringList>

// Port of gog_store.py's DEFAULT_CONFIG / load_config(). The same
// ~/wlm/gog_config.json file is read/written, so the Python and C++ versions
// stay interchangeable. Defaults (the public GOG Galaxy client credentials) are
// written to disk only when the file does not exist yet, exactly like Python.
namespace gog {

struct Config {
    QString clientId = QStringLiteral("46899977096215655");
    QString clientSecret =
        QStringLiteral("9d85c43b1482497dbbce61f6e4aa173a433796eeae2ca8c5f6129f2dc4de46d9");
    QString authUrl = QStringLiteral("https://auth.gog.com/auth");
    QString tokenUrl = QStringLiteral("https://auth.gog.com/token");
    QString redirectUri = QStringLiteral("https://embed.gog.com/on_login_success?origin=client");
    QString userdataUrl = QStringLiteral("https://embed.gog.com/userData.json");
    QString libraryUrl = QStringLiteral("https://embed.gog.com/account/getFilteredProducts");
    QString productUrl = QStringLiteral("https://api.gog.com/products/{id}");
    QString downloadDir;    // empty -> ~/wlm/gog_downloads (installer destination)
    QString gameDir;        // empty -> ~/wlm/gog_games (direct-download folder)
    QString contentSystemUrl = QStringLiteral("https://content-system.gog.com");
    QString depotMetaUrl = QStringLiteral("https://cdn.gog.com/content-system/v2/meta");
    QString ownedUrl = QStringLiteral("https://embed.gog.com/user/data/games");
    int directThreads = 4;
    QString os = QStringLiteral("windows"); // windows / linux / mac / "" = all
    QString language;                       // e.g. "en"; "" = all
    QString userAgent = QStringLiteral("wine-launcher-manager");
    QString browserCommand;
    int browserTimeout = 600;
    QString installArgs;
    bool autoShortcut = true;
    int maxDownloads = 1;
    QString view = QStringLiteral("grid"); // "grid" or "list"
    int cardWidth = 200;                   // 120..400
    double coverRatio = 0.5625;            // height / width

    QStringList coverSuffixes = {
        QStringLiteral("_product_tile_398.jpg"),
        QStringLiteral("_196.jpg"),
        QStringLiteral(".jpg"),
        QStringLiteral(".png"),
    };

    // Resolved download / game roots (honour the custom dirs, else ~/wlm/...).
    QString downloadRoot() const;
    QString gameRoot() const;

    QJsonObject toJson() const;
    static Config fromJson(const QJsonObject&);
};

// Load ~/wlm/gog_config.json (creating it with defaults when missing).
Config loadConfig(const QString& path = QString());
void saveConfig(const Config& c, const QString& path = QString());

} // namespace gog
