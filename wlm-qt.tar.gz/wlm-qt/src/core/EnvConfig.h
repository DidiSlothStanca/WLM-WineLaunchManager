#pragma once

#include <QString>

// Values from ~/wlm/env_config.yaml (URLs used by the "Download Online" Proton
// feature). The file has a small, fixed two-section shape:
//
//   proton_ge:
//     releases_api: https://...
//     releases_page: https://...
//   proton_cachyos:
//     releases_api: https://...
//     releases_page: https://...
//
// Rather than pull in a full YAML library, this uses a tiny tolerant parser
// that is enough for the above. Missing keys fall back to the built-in
// defaults, and a default file is written on first run (like the Python code).
struct EnvConfig {
    struct Section {
        QString releasesApi;
        QString releasesPage;
    };

    Section protonGE;
    Section protonCachyOS;

    static EnvConfig load();
};
