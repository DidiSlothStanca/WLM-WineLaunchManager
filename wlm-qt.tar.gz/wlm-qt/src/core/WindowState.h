#pragma once

#include <QObject>
#include <QSize>
#include <QString>

class QCloseEvent;
class QEvent;
class QMoveEvent;
class QResizeEvent;
class QTimer;
class QWidget;

// Per-dialog window-state persistence. Stores per-dialog geometry in
// window_config.json under a "dialogs" object: {"key": {"size":"WxH",
// "maximized":bool}, ...}. This keeps the Python launcher's main-window keys
// untouched while letting every Qt dialog remember its size/maximized state.
namespace windowstate {

struct DialogGeometry {
    QString size = QStringLiteral("800x600"); // "WxH"
    bool maximized = false;
};

DialogGeometry load(const QString& key);
void save(const QString& key, const DialogGeometry& g);

} // namespace windowstate

// Attaches standard window chrome (minimize / maximize / restore / close via
// Qt::Window flag) plus geometry persistence to any dialog. Create it right
// after building the dialog and before showing it; it owns itself (deletes
// with the dialog via parent()).
//
// Port of the Python launcher's per-dialog remember-size behaviour, extended
// to also remember the maximized flag.
class WindowStateHelper : public QObject {
    Q_OBJECT
public:
    WindowStateHelper(QWidget* dialog, QString key, QSize defaultSize,
                      QSize minSize = QSize(0, 0), QWidget* parent = nullptr);

protected:
    bool eventFilter(QObject* obj, QEvent* ev) override;

private:
    void applyInitial();
    void persist();

    QWidget* m_dialog;
    QString m_key;
    QSize m_defaultSize;
    QSize m_minSize;
    QTimer* m_timer = nullptr;
    bool m_ready = false;
};
