#pragma once

#include "core/RunnerConfig.h"

#include <QJsonObject>
#include <QString>
#include <QStringList>
#include <QVector>
#include <optional>

namespace installwatch {

// Konstanta mirip install_watch.py
extern const QStringList kContainers;
extern const QStringList kSystemTop;
extern const QStringList kIgnoreDirs;
extern const QStringList kJunkDirs;
extern const QStringList kSearchDirs;

// Hasil temuan GOG game
struct GogGameFound {
    QString exe;
    QString workdir;
    QString name;
    QString icon;
    bool hasIcon = false;
};

// Kandidat exe non-GOG (hasil find_candidates)
struct Candidate {
    QString exe;
    QString gameDir;
    qint64 size = 0;
};

// drive_c untuk prefix/runner
QString driveCFor(const RunnerChoice& choice);

// resolve_ci case-insensitive
QString resolveCi(const QString& base, const QString& rel);

// _fresh: mtime/ctime >= since-2
bool fresh(const QString& path, double since);

// primary exe dari playTasks goggame-*.info
QPair<QString, QString> primaryExe(const QString& infoDir, const QJsonObject& data);

// find_goggame
std::optional<GogGameFound> findGoggame(const QString& driveC, const QString& gameId, double since, bool installerRunning);

// game_dirs
QStringList gameDirs(const QString& driveC);

// find_candidates
QVector<Candidate> findCandidates(const QString& driveC, double since, int limit = 15);

} // namespace installwatch
