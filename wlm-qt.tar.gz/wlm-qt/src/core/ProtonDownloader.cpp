#include "core/ProtonDownloader.h"

#include "core/ProtonManager.h"

#include <QFile>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QUrl>

ProtonDownloader::ProtonDownloader(QObject* parent)
    : QObject(parent)
    , m_nam(new QNetworkAccessManager(this))
{
}

ProtonDownloader::~ProtonDownloader()
{
    if (m_file) {
        m_file->close();
        delete m_file;
        m_file = nullptr;
    }
}

void ProtonDownloader::start(const QString& url, const QString& destPath, qint64 totalSize)
{
    m_url = url;
    m_dest = destPath;
    m_total = totalSize;
    m_downloaded = 0;
    m_paused = false;
    m_done = false;

    if (m_file) {
        m_file->close();
        delete m_file;
    }
    m_file = new QFile(m_dest);
    if (!m_file->open(QIODevice::ReadWrite | QIODevice::Truncate)) {
        emit failed(tr("Could not create download file: %1").arg(m_dest));
        return;
    }

    m_lastReport.start();
    beginRequest();
}

void ProtonDownloader::beginRequest()
{
    if (m_reply) {
        m_reply->deleteLater();
        m_reply = nullptr;
    }

    QNetworkRequest req{QUrl(m_url)};
    req.setRawHeader("User-Agent", "wine-launcher-manager");
    if (m_downloaded > 0)
        req.setRawHeader("Range", QStringLiteral("bytes=%1-").arg(m_downloaded).toUtf8());

    QNetworkReply* r = m_nam->get(req);
    m_reply = r;
    m_statusChecked = false;

    connect(r, &QIODevice::readyRead, this, [this, r] {
        if (r == m_reply)
            onReadyRead();
    });
    connect(r, &QNetworkReply::finished, this, [this, r] {
        if (r != m_reply) {
            r->deleteLater();
            return;
        }
        onReplyFinished();
    });
}

void ProtonDownloader::onReadyRead()
{
    if (m_paused || !m_reply || !m_file)
        return;

    if (!m_statusChecked) {
        m_statusChecked = true;
        const int status = m_reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        if (m_downloaded > 0 && status != 206) {
            emit line(QStringLiteral("  Server ignored the resume request - restarting from the beginning."));
            m_downloaded = 0;
            m_file->resize(0);
            m_file->seek(0);
        }
    }

    const QByteArray chunk = m_reply->readAll();
    if (chunk.isEmpty())
        return;

    m_file->write(chunk);
    m_file->flush();
    m_downloaded += chunk.size();

    if (m_lastReport.elapsed() > 200)
        reportProgress();
}

void ProtonDownloader::reportProgress()
{
    if (m_total > 0) {
        const double pct = m_downloaded * 100.0 / m_total;
        emit line(QStringLiteral("  %1 / %2 (%3%)")
                      .arg(protonutil::humanSize(m_downloaded),
                           protonutil::humanSize(m_total),
                           QString::number(pct, 'f', 0)));
        emit progress(m_downloaded, m_total);
    } else {
        emit line(QStringLiteral("  %1 downloaded...").arg(protonutil::humanSize(m_downloaded)));
        emit progress(m_downloaded, 0);
    }
    m_lastReport.restart();
}

void ProtonDownloader::onReplyFinished()
{
    if (!m_reply)
        return;

    const QNetworkReply::NetworkError error = m_reply->error();

    if (m_paused) {
        // Deliberate abort for pause: keep the partial file, wait for resume.
        m_reply->deleteLater();
        m_reply = nullptr;
        return;
    }

    if (error != QNetworkReply::NoError) {
        const QString err = m_reply->errorString();
        m_reply->deleteLater();
        m_reply = nullptr;
        if (m_file) {
            m_file->close();
            m_file->remove();
        }
        emit failed(err);
        return;
    }

    // Drain anything still buffered.
    onReadyRead();

    m_done = true;
    if (m_file) {
        m_file->flush();
        m_file->close();
    }
    if (m_total > 0)
        emit progress(m_total, m_total);

    m_reply->deleteLater();
    m_reply = nullptr;

    emit finished(m_dest, m_downloaded);
}

void ProtonDownloader::setPaused(bool paused)
{
    if (m_done)
        return;
    if (paused == m_paused)
        return;

    m_paused = paused;
    if (paused) {
        emit line(QString());
        emit line(tr("Paused at %1. Click Resume to continue.")
                      .arg(protonutil::humanSize(m_downloaded)));
        if (m_reply)
            m_reply->abort();
    } else {
        emit line(tr("Resuming from %1...").arg(protonutil::humanSize(m_downloaded)));
        m_lastReport.restart();
        beginRequest();
    }
}
