#pragma once

#include <QList>
#include <QString>

// Discovery of extracted Proton builds and the Steam client path. Ports the
// find_proton* / find_steam_install_path helpers from launcher.py.
namespace Proton {

struct Build {
    QString name;   // folder name, e.g. "GE-Proton9-20"
    QString path;   // full path to the "proton" binary
};

// Scan a directory for build folders that contain a "proton" executable.
// Results are sorted by name, descending (newest build first).
QList<Build> findInstallations(const QString& baseDir);

QList<Build> findProtonGEInstallations();       // ~/wlm/protonge
QList<Build> findProtonCachyOSInstallations();  // ~/wlm/protoncachyos

// Locate the Steam client directory; falls back to ~/wlm/steamclient (created).
QString findSteamInstallPath();

} // namespace Proton
