#pragma once

#include <QObject>
#include <QString>
#include <QStringList>

class QProcess;

// Extracts a Proton archive (.tar.gz/.tar.xz/.tgz/.zip) into a target directory,
// wrapping the result in a single folder when the archive does not already
// contain exactly one top-level entry. Port of extract_archive_to_dir().
//
// Runs the actual extraction through the system `tar`/`unzip` programs so it
// stays asynchronous (the UI keeps repainting) and no extra library is needed.
class ArchiveExtractor : public QObject {
    Q_OBJECT
public:
    explicit ArchiveExtractor(QObject* parent = nullptr);

    void extract(const QString& archivePath, const QString& targetDir);

signals:
    void line(const QString& text);
    void finished(bool ok, const QString& error);

private:
    void finishPostProcess();
    static QString stripArchiveSuffix(const QString& name);

    QString m_archive;
    QString m_target;
    QStringList m_beforeEntries;
    QProcess* m_proc = nullptr;
};
