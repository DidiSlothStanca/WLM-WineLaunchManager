#pragma once

#include <QJsonObject>
#include <QMap>
#include <QString>

class QImage;

// Cover-art bookkeeping ported from game_covers.py: title normalisation/matching,
// the on-disk cover store (~/wlm/covers/<name>.jpg + index.json) and the
// Grid/List view config (~/wlm/library_view.json).
namespace covers {

// Card widths in px: Small 160, Medium 200, Large 260.
const QMap<QString, int>& cardSizes();

// height / width of a cover card (16:9, like a GOG tile).
constexpr double kCoverRatio = 0.5625;

// 0-1 title match threshold below which a cover search is treated as a miss.
constexpr double kMatchThreshold = 0.72;

// Structured view of library_view.json.
struct ViewConfig {
    QString view = QStringLiteral("list"); // "grid" | "list"
    int cardWidth = 200;
};

ViewConfig loadViewConfig(const QString& path);
void saveViewConfig(const QString& path, const ViewConfig& cfg);

// Lower-case, accent-stripped, edition-stripped title used for matching.
QString normalizeTitle(const QString& text);

// 0-1 similarity (1.0 for identical normalised titles). Differing sequel
// numbers ("Doom" vs "Doom 3") are penalised so covers are not mismatched.
double titleSimilarity(const QString& a, const QString& b);

// On-disk cover store. Network fetching lives in CoverFetcher.
class CoverStore {
public:
    explicit CoverStore(const QString& dataDir);

    QString directory() const { return m_dir; }
    QString path(const QString& name) const;
    bool has(const QString& name) const;

    // Copy `imagePath` in as the manual cover for `name` (converted to JPEG).
    bool setManual(const QString& name, const QString& imagePath, QString* error);
    void forget(const QString& name);
    void rename(const QString& oldName, const QString& newName);

    // Persist an already-decoded image as the cover (scaled to <= 640, JPEG q88).
    bool saveImage(const QString& name, const QImage& image, QString* error);

    bool recentMiss(const QString& name) const;
    void clearMiss(const QString& name);
    void recordMiss(const QString& name, double score);
    void recordHit(const QString& name, const QString& matched, double score);

    // Network backoff after a connection failure (seconds since epoch based).
    bool offline() const;
    void markOffline();
    void clearOffline();

private:
    QJsonObject& index();
    void saveIndex();

    QString m_dir;
    QString m_indexPath;
    QJsonObject m_index;
    bool m_indexLoaded = false;
    qint64 m_offlineUntil = 0; // msec since epoch
};

} // namespace covers
