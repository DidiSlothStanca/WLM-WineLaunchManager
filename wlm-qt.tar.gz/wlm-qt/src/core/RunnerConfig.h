#pragma once

#include <QJsonObject>
#include <QString>

// Per-game runner choice + the runner_config.json store. Ports the
// load_runner_config / save_runner_config / game_source helpers.
struct RunnerChoice {
    QString runner = QStringLiteral("wine"); // wine | protonge | protoncachyos
    QString prefixCode;
    QString prefixPath;
    QString protonName;
    QString protonPath;
    QString launchOptions;
    QString comment;
    QString source;                          // "gog" or empty
    QString gogId;

    QJsonObject toJson() const;
    static RunnerChoice fromJson(const QJsonObject& obj);
};

namespace runnerconfig {

// Load the whole runner_config.json (game name -> choice object).
QJsonObject load();

// Overwrite runner_config.json with `cfg` (pretty-printed).
void save(const QJsonObject& cfg);

RunnerChoice get(const QString& name);
void set(const QString& name, const RunnerChoice& choice);
void remove(const QString& name);
void rename(const QString& oldName, const QString& newName);

struct GameSource {
    QString source = QStringLiteral("other"); // "gog" or "other"
    QString gogId;
};
// Determine whether a game is from GOG (via runner_config 'source' or a
// goggame-*.info file next to its exe).
GameSource gameSource(const QString& name);

} // namespace runnerconfig
