#include "core/ProtonManager.h"

#include "core/EnvConfig.h"

#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QRegularExpression>
#include <QSysInfo>
#include <QUrl>
#include <QUrlQuery>

namespace {

QString jsonStr(const QJsonObject& o, const QString& key)
{
    return o.value(key).toString();
}

QString stripSuffixes(const QString& name)
{
    static const QStringList suffixes = {
        QStringLiteral(".tar.gz"), QStringLiteral(".tar.xz"),
        QStringLiteral(".tgz"), QStringLiteral(".zip"),
    };
    for (const QString& s : suffixes) {
        if (name.toLower().endsWith(s))
            return name.left(name.size() - s.size());
    }
    return name;
}

} // namespace

namespace protonutil {

QString stripArchiveSuffix(const QString& name)
{
    return stripSuffixes(name);
}

QString humanSize(qint64 bytes)
{
    double n = static_cast<double>(bytes);
    const QStringList units = {QStringLiteral("B"), QStringLiteral("KB"), QStringLiteral("MB"),
                               QStringLiteral("GB"), QStringLiteral("TB")};
    for (const QString& unit : units) {
        if (n < 1024.0 || unit == QLatin1String("TB")) {
            if (unit == QLatin1String("B"))
                return QStringLiteral("%1 B").arg(static_cast<qint64>(n));
            return QStringLiteral("%1 %2").arg(n, 0, 'f', 1).arg(unit);
        }
        n /= 1024.0;
    }
    return QStringLiteral("%1 B").arg(bytes);
}

QPair<QString, QString> assetArch(const QString& assetName)
{
    const QString n = stripSuffixes(assetName).toLower();

    QRegularExpression zn(QStringLiteral("znver(\\d)"));
    QRegularExpressionMatch m = zn.match(n);
    if (m.hasMatch()) {
        const QString d = m.captured(1);
        return {QStringLiteral("AMD Zen %1 (znver%1)").arg(d), QStringLiteral("znver%1").arg(d)};
    }

    QRegularExpression xv(QStringLiteral("x86[_-]64[_-]v([1-4])"));
    m = xv.match(n);
    if (m.hasMatch())
        return {QStringLiteral("x86-64-v%1").arg(m.captured(1)), QStringLiteral("v%1").arg(m.captured(1))};

    if (QRegularExpression(QStringLiteral("aarch64|arm64")).match(n).hasMatch())
        return {QStringLiteral("ARM64 (aarch64)"), QStringLiteral("arm64")};

    if (QRegularExpression(QStringLiteral("x86[_-]64|amd64")).match(n).hasMatch())
        return {QStringLiteral("x86-64 (standard)"), QStringLiteral("v1")};

    return {QStringLiteral("not stated"), QString()};
}

int archCompat(const QString& key, const CpuProfile& cpu)
{
    if (key.isEmpty() || cpu.machine.isEmpty())
        return -1;

    const bool isX86 = cpu.machine == QLatin1String("x86_64") || cpu.machine == QLatin1String("amd64");
    if (key == QLatin1String("arm64")) {
        const bool isArm = cpu.machine == QLatin1String("aarch64") || cpu.machine == QLatin1String("arm64");
        return (!isX86 && isArm) ? 1 : 0;
    }
    if (!isX86)
        return 0;
    if (cpu.level == 0)
        return -1;

    if (key.startsWith(QLatin1Char('v'))) {
        return cpu.level >= key.mid(1).toInt() ? 1 : 0;
    }
    if (key.startsWith(QLatin1String("znver"))) {
        if (cpu.vendor != QLatin1String("AuthenticAMD"))
            return 0;
        const int n = key.mid(5).toInt();
        if (n <= 2)
            return cpu.level >= 3 ? 1 : 0;
        const QString flag = n == 3 ? QStringLiteral("vaes")
                             : n == 4 ? QStringLiteral("avx512_bf16")
                                      : QStringLiteral("avx512_vp2intersect");
        return cpu.flags.contains(flag) ? 1 : 0;
    }
    return -1;
}

int archRank(const QString& key)
{
    if (key.startsWith(QLatin1String("znver")))
        return 5;
    if (key == QLatin1String("v1")) return 1;
    if (key == QLatin1String("v2")) return 2;
    if (key == QLatin1String("v3")) return 3;
    if (key == QLatin1String("v4")) return 4;
    if (key == QLatin1String("arm64")) return 1;
    return 0;
}

QString variantLabel(const QString& assetName)
{
    const QString n = assetName.toLower();
    if (n.contains(QLatin1String("native")))
        return QStringLiteral("Native");
    if (n.contains(QLatin1String("slr")))
        return QStringLiteral("SLR");
    return QStringLiteral("Standalone");
}

CpuProfile detectCpuProfile()
{
    CpuProfile cpu;
    QString machine = QSysInfo::currentCpuArchitecture().toLower();
    if (machine == QLatin1String("arm64"))
        machine = QStringLiteral("aarch64");
    cpu.machine = machine;

    QFile f(QStringLiteral("/proc/cpuinfo"));
    if (f.open(QIODevice::ReadOnly | QIODevice::Text)) {
        // /proc files report size 0, so readLine()/atEnd() cannot be used;
        // read the whole (small) file at once and split it.
        const QString content = QString::fromUtf8(f.readAll());
        const QStringList lines = content.split(QLatin1Char('\n'));
        for (const QString& line : lines) {
            if (line.startsWith(QLatin1String("flags")) && cpu.flags.isEmpty()) {
                const QStringList parts = line.section(QLatin1Char(':'), 1).split(
                    QRegularExpression(QStringLiteral("\\s+")), Qt::SkipEmptyParts);
                for (const QString& p : parts)
                    cpu.flags.insert(p);
            } else if (line.startsWith(QLatin1String("vendor_id")) && cpu.vendor.isEmpty()) {
                cpu.vendor = line.section(QLatin1Char(':'), 1).trimmed();
            }
            if (!cpu.flags.isEmpty() && !cpu.vendor.isEmpty())
                break;
        }
    }

    int level = 0;
    if ((machine == QLatin1String("x86_64") || machine == QLatin1String("amd64")) && !cpu.flags.isEmpty()) {
        const QSet<QString> v2 = {QStringLiteral("cx16"), QStringLiteral("lahf_lm"),
                                  QStringLiteral("popcnt"), QStringLiteral("sse4_1"),
                                  QStringLiteral("sse4_2"), QStringLiteral("ssse3")};
        QSet<QString> v3 = v2;
        v3.unite({QStringLiteral("avx"), QStringLiteral("avx2"), QStringLiteral("bmi1"),
                  QStringLiteral("bmi2"), QStringLiteral("f16c"), QStringLiteral("fma"),
                  QStringLiteral("abm"), QStringLiteral("movbe"), QStringLiteral("xsave")});
        QSet<QString> v4 = v3;
        v4.unite({QStringLiteral("avx512f"), QStringLiteral("avx512bw"), QStringLiteral("avx512cd"),
                  QStringLiteral("avx512dq"), QStringLiteral("avx512vl")});

        auto subset = [&cpu](const QSet<QString>& req) {
            for (const QString& f : req) {
                if (!cpu.flags.contains(f))
                    return false;
            }
            return true;
        };
        if (subset(v4)) level = 4;
        else if (subset(v3)) level = 3;
        else if (subset(v2)) level = 2;
        else level = 1;
    }
    cpu.level = level;

    if (machine == QLatin1String("aarch64") || machine == QLatin1String("arm64")) {
        cpu.text = QStringLiteral("ARM64 (aarch64)");
    } else if (level) {
        QString vendor;
        if (cpu.vendor == QLatin1String("AuthenticAMD"))
            vendor = QStringLiteral(" (AMD)");
        else if (cpu.vendor == QLatin1String("GenuineIntel"))
            vendor = QStringLiteral(" (Intel)");
        cpu.text = QStringLiteral("x86-64-v%1%2").arg(level).arg(vendor);
    } else {
        cpu.text = machine.isEmpty() ? QStringLiteral("unknown") : machine;
    }
    return cpu;
}

} // namespace protonutil

ProtonManager::ProtonManager(QObject* parent)
    : QObject(parent)
    , m_nam(new QNetworkAccessManager(this))
{
}

void ProtonManager::fetchReleases(bool cachyos, int limit)
{
    const EnvConfig cfg = EnvConfig::load();
    const QString api = cachyos ? cfg.protonCachyOS.releasesApi : cfg.protonGE.releasesApi;

    QUrl url(api);
    QUrlQuery query;
    query.addQueryItem(QStringLiteral("per_page"), QString::number(limit));
    url.setQuery(query);

    QNetworkRequest req(url);
    req.setRawHeader("User-Agent", "wine-launcher-manager");
    req.setRawHeader("Accept", "application/vnd.github+json");

    QNetworkReply* reply = m_nam->get(req);
    connect(reply, &QNetworkReply::finished, this, [this, reply, cachyos] {
        reply->deleteLater();
        if (reply->error() != QNetworkReply::NoError) {
            emit fetchFailed(reply->errorString());
            return;
        }

        const QJsonDocument doc = QJsonDocument::fromJson(reply->readAll());
        if (!doc.isArray()) {
            emit fetchFailed(QStringLiteral("Unexpected response from GitHub."));
            return;
        }

        static const QStringList suffixes = {
            QStringLiteral(".tar.gz"), QStringLiteral(".tar.xz"),
            QStringLiteral(".tgz"), QStringLiteral(".zip"),
        };
        auto endsWithArchive = [](const QString& n) {
            for (const QString& s : suffixes) {
                if (n.toLower().endsWith(s))
                    return true;
            }
            return false;
        };

        QList<ProtonRelease> out;
        for (const QJsonValue& value : doc.array()) {
            const QJsonObject rel = value.toObject();
            const QString tag = jsonStr(rel, QStringLiteral("tag_name"));

            if (!cachyos) {
                const QJsonArray assets = rel.value(QStringLiteral("assets")).toArray();
                for (const QJsonValue& av : assets) {
                    const QJsonObject a = av.toObject();
                    const QString name = jsonStr(a, QStringLiteral("name"));
                    if (!name.toLower().endsWith(QLatin1String(".tar.gz")))
                        continue;
                    ProtonRelease r;
                    r.tag = tag;
                    r.name = jsonStr(rel, QStringLiteral("name"));
                    if (r.name.isEmpty())
                        r.name = tag;
                    r.publishedAt = jsonStr(rel, QStringLiteral("published_at")).left(10);
                    r.assetName = name;
                    r.downloadUrl = jsonStr(a, QStringLiteral("browser_download_url"));
                    r.size = static_cast<qint64>(a.value(QStringLiteral("size")).toDouble());
                    out.append(r);
                    break;
                }
            } else {
                const QString releaseName = jsonStr(rel, QStringLiteral("name"));
                for (const QJsonValue& av : rel.value(QStringLiteral("assets")).toArray()) {
                    const QJsonObject a = av.toObject();
                    const QString name = jsonStr(a, QStringLiteral("name"));
                    if (!endsWithArchive(name))
                        continue;
                    ProtonRelease r;
                    r.tag = tag;
                    r.name = releaseName.isEmpty() ? tag : releaseName;
                    r.publishedAt = jsonStr(rel, QStringLiteral("published_at")).left(10);
                    r.assetName = name;
                    r.downloadUrl = jsonStr(a, QStringLiteral("browser_download_url"));
                    r.size = static_cast<qint64>(a.value(QStringLiteral("size")).toDouble());
                    r.variant = protonutil::variantLabel(name);
                    const QPair<QString, QString> arch = protonutil::assetArch(name);
                    r.archLabel = arch.first;
                    r.archKey = arch.second;
                    out.append(r);
                }
            }
        }

        emit releasesReady(out);
    });
}
