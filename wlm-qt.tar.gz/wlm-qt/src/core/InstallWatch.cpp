#include "core/InstallWatch.h"

#include <QDir>
#include <QDirIterator>
#include <QFile>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonParseError>
#include <QRegularExpression>
#include <QSet>
#include <QString>
#include <QVector>
#include <algorithm>
#include <optional>

#include <sys/stat.h>
#include <sys/types.h>

namespace installwatch {

const QStringList kContainers = {
    QStringLiteral("gog games"),
    QStringLiteral("games"),
    QStringLiteral("gog.com"),
    QStringLiteral("program files"),
    QStringLiteral("program files (x86)")
};

const QStringList kSystemTop = {
    QStringLiteral("windows"),
    QStringLiteral("users"),
    QStringLiteral("programdata"),
    QStringLiteral("temp"),
    QStringLiteral("windows.old")
};

const QStringList kIgnoreDirs = {
    QStringLiteral("common files"),
    QStringLiteral("internet explorer"),
    QStringLiteral("windows nt"),
    QStringLiteral("windows media player"),
    QStringLiteral("windows mail"),
    QStringLiteral("windows photo viewer"),
    QStringLiteral("windows portable devices"),
    QStringLiteral("windows defender"),
    QStringLiteral("windowspowershell"),
    QStringLiteral("microsoft.net"),
    QStringLiteral("microsoft"),
    QStringLiteral("reference assemblies"),
    QStringLiteral("msbuild"),
    QStringLiteral("modifiablewindowsapps"),
    QStringLiteral("wine"),
    QStringLiteral("steam")
};

const QStringList kJunkDirs = {
    QStringLiteral("redist"),
    QStringLiteral("_redist"),
    QStringLiteral("_commonredist"),
    QStringLiteral("commonredist"),
    QStringLiteral("directx"),
    QStringLiteral("dotnet"),
    QStringLiteral("vcredist"),
    QStringLiteral("redistributables"),
    QStringLiteral("prerequisites"),
    QStringLiteral("__installer"),
    QStringLiteral("support"),
    QStringLiteral("crashreporter"),
    QStringLiteral("_commonredist")
};

const QStringList kSearchDirs = {
    QStringLiteral("GOG Games"),
    QStringLiteral("Games"),
    QStringLiteral("GOG.com"),
    QStringLiteral("Program Files (x86)"),
    QStringLiteral("Program Files")
};

static const QRegularExpression kJunkFileRe(
    QStringLiteral("(^unins\\d*|unwise|uninst|setup|install|vc_?redist|vcredist|dxsetup|dxwebsetup|dotnet|"
                   "ndp\\d|oalinst|physx|crashpad|crashreport|crashhandler|redist|updater|notification_helper)"),
    QRegularExpression::CaseInsensitiveOption);

QString driveCFor(const RunnerChoice& choice)
{
    const QString prefix = choice.prefixPath;
    if (choice.runner == QLatin1String("protonge") || choice.runner == QLatin1String("protoncachyos")) {
        if (prefix.isEmpty())
            return QString();
        const QDir base(prefix);
        if (!base.exists(QStringLiteral("pfx")) && base.exists(QStringLiteral("drive_c")))
            return base.filePath(QStringLiteral("drive_c"));
        return base.filePath(QStringLiteral("pfx/drive_c"));
    }
    const QDir base(prefix.isEmpty() ? (QString::fromLocal8Bit(qgetenv("WINEPREFIX")).isEmpty()
                                           ? QDir::home().filePath(QStringLiteral(".wine"))
                                           : QString::fromLocal8Bit(qgetenv("WINEPREFIX")))
                                     : prefix);
    return base.filePath(QStringLiteral("drive_c"));
}

QString resolveCi(const QString& base, const QString& rel)
{
    QString cur = base;
    const QStringList parts = rel.split(QRegularExpression(QStringLiteral("[\\\\/]")), Qt::SkipEmptyParts);
    for (const QString& part : parts) {
        if (part == QLatin1String("."))
            continue;
        if (part == QLatin1String("..")) {
            const QFileInfo fi(cur);
            cur = fi.dir().absolutePath();
            continue;
        }
        const QDir d(cur);
        if (d.exists(part)) {
            cur = d.filePath(part);
            continue;
        }
        bool found = false;
        const QFileInfoList entries = d.entryInfoList(QDir::Dirs | QDir::Files | QDir::NoDotAndDotDot);
        for (const QFileInfo& e : entries) {
            if (e.fileName().compare(part, Qt::CaseInsensitive) == 0) {
                cur = e.absoluteFilePath();
                found = true;
                break;
            }
        }
        if (!found)
            return QString();
    }
    return cur;
}

bool fresh(const QString& path, double since)
{
    struct stat st;
    if (::stat(QFile::encodeName(path).constData(), &st) != 0)
        return false;
    double m = static_cast<double>(st.st_mtime);
    double c = static_cast<double>(st.st_ctime);
    double best = m > c ? m : c;
    return best >= since - 2.0;
}

QPair<QString, QString> primaryExe(const QString& infoDir, const QJsonObject& data)
{
    QJsonArray tasks = data.value(QStringLiteral("playTasks")).toArray();
    QVector<QJsonObject> list;
    for (const QJsonValue& v : tasks) {
        if (v.isObject())
            list.append(v.toObject());
    }
    std::sort(list.begin(), list.end(), [](const QJsonObject& a, const QJsonObject& b) {
        bool ap = a.value(QStringLiteral("isPrimary")).toBool();
        bool bp = b.value(QStringLiteral("isPrimary")).toBool();
        if (ap != bp)
            return ap && !bp;
        QString ac = a.value(QStringLiteral("category")).toString().toLower();
        QString bc = b.value(QStringLiteral("category")).toString().toLower();
        bool ag = ac == QLatin1String("game");
        bool bg = bc == QLatin1String("game");
        if (ag != bg)
            return ag && !bg;
        return false;
    });
    for (const QJsonObject& t : list) {
        QString p = t.value(QStringLiteral("path")).toString();
        if (p.isEmpty())
            continue;
        QString exe = resolveCi(infoDir, p);
        if (exe.isEmpty() || !QFileInfo(exe).isFile())
            continue;
        QString w = t.value(QStringLiteral("workingDir")).toString();
        QString wdir;
        if (!w.isEmpty()) {
            QString rw = resolveCi(infoDir, w);
            if (!rw.isEmpty() && QFileInfo(rw).isDir())
                wdir = rw;
        }
        return qMakePair(exe, wdir);
    }
    return qMakePair(QString(), QString());
}

std::optional<GogGameFound> findGoggame(const QString& driveC, const QString& gameId, double since, bool installerRunning)
{
    if (driveC.isEmpty() || !QFileInfo(driveC).isDir())
        return std::nullopt;
    std::optional<std::pair<int, GogGameFound> > best;
    for (const QString& topName : kSearchDirs) {
        QString topDir = resolveCi(driveC, topName);
        if (topDir.isEmpty() || !QFileInfo(topDir).isDir())
            continue;
        QDirIterator it(topDir, QDir::Dirs | QDir::Files | QDir::NoDotAndDotDot, QDirIterator::Subdirectories);
        while (it.hasNext()) {
            it.next();
            const QFileInfo fi = it.fileInfo();
            if (fi.isDir())
                continue;
            const QString fn = fi.fileName().toLower();
            if (!(fn.startsWith(QLatin1String("goggame-")) && fn.endsWith(QLatin1String(".info"))))
                continue;
            const QString dirpath = fi.absolutePath();
            bool hasFreshUninst = false;
            const QFileInfoList df = QDir(dirpath).entryInfoList(QDir::Files | QDir::NoDotAndDotDot);
            for (const QFileInfo& uf : df) {
                const QString ufn = uf.fileName().toLower();
                if (ufn.startsWith(QLatin1String("unins")) && ufn.endsWith(QLatin1String(".exe"))) {
                    if (fresh(uf.absoluteFilePath(), since))
                        hasFreshUninst = true;
                }
            }
            if (installerRunning && !hasFreshUninst)
                continue;
            QFile f(fi.absoluteFilePath());
            if (!f.open(QIODevice::ReadOnly))
                continue;
            QByteArray raw = f.readAll();
            f.close();
            QJsonParseError perr{};
            QJsonDocument doc = QJsonDocument::fromJson(raw, &perr);
            if (perr.error != QJsonParseError::NoError || !doc.isObject())
                continue;
            QJsonObject data = doc.object();
            QString gid = data.value(QStringLiteral("gameId")).toVariant().toString();
            QString rootId = data.value(QStringLiteral("rootGameId")).toVariant().toString();
            int score = 0;
            if (!gameId.isEmpty()) {
                if (gid == gameId)
                    score = 4;
                else if (rootId == gameId)
                    score = 3;
                else
                    continue;
            } else {
                if (fresh(fi.absoluteFilePath(), since)) {
                    if (rootId.isEmpty() || gid == rootId)
                        score = 2;
                    else
                        score = 1;
                } else {
                    continue;
                }
            }
            auto pe = primaryExe(dirpath, data);
            if (pe.first.isEmpty())
                continue;
            GogGameFound g;
            g.exe = pe.first;
            g.workdir = pe.second;
            g.name = data.value(QStringLiteral("name")).toString();
            QString iconPath = resolveCi(dirpath, fi.baseName() + QLatin1String(".ico"));
            if (!iconPath.isEmpty() && QFileInfo(iconPath).isFile()) {
                g.icon = iconPath;
                g.hasIcon = true;
            }
            if (!best.has_value() || score > best->first)
                best = std::make_pair(score, std::move(g));
        }
    }
    if (!best.has_value())
        return std::nullopt;
    return best->second;
}

QStringList gameDirs(const QString& driveC)
{
    QStringList out;
    QSet<QString> seen;
    if (driveC.isEmpty() || !QFileInfo(driveC).isDir())
        return out;
    QDir d(driveC);
    const QFileInfoList tops = d.entryInfoList(QDir::Dirs | QDir::NoDotAndDotDot);
    for (const QFileInfo& top : tops) {
        const QString lname = top.fileName().toLower();
        bool isContainer = false;
        for (const QString& c : kContainers) {
            if (lname == c) { isContainer = true; break; }
        }
        if (isContainer) {
            QDir td(top.absoluteFilePath());
            const QFileInfoList kids = td.entryInfoList(QDir::Dirs | QDir::NoDotAndDotDot);
            for (const QFileInfo& k : kids) {
                const QString kl = k.fileName().toLower();
                bool ignore = false;
                for (const QString& ig : kIgnoreDirs) {
                    if (kl == ig) { ignore = true; break; }
                }
                if (!ignore && !seen.contains(k.absoluteFilePath())) {
                    seen.insert(k.absoluteFilePath());
                    out << k.absoluteFilePath();
                }
            }
        } else {
            bool system = false;
            for (const QString& s : kSystemTop) {
                if (lname == s) { system = true; break; }
            }
            if (!system && !seen.contains(top.absoluteFilePath())) {
                seen.insert(top.absoluteFilePath());
                out << top.absoluteFilePath();
            }
        }
    }
    return out;
}

QVector<Candidate> findCandidates(const QString& driveC, double since, int limit)
{
    QVector<Candidate> res;
    const QStringList gdirs = gameDirs(driveC);
    for (const QString& gd : gdirs) {
        QDirIterator it(gd, QDir::Dirs | QDir::Files | QDir::NoDotAndDotDot, QDirIterator::Subdirectories);
        while (it.hasNext()) {
            it.next();
            const QFileInfo fi = it.fileInfo();
            if (fi.isDir())
                continue;
            const QString fn = fi.fileName().toLower();
            if (!fn.endsWith(QLatin1String(".exe")))
                continue;
            if (kJunkFileRe.match(fi.fileName()).hasMatch())
                continue;
            const QString dirpath = fi.absolutePath();
            bool inJunk = false;
            const QStringList dparts = QDir(dirpath).absolutePath().split(QLatin1Char('/'));
            for (const QString& p : dparts) {
                const QString pl = p.toLower();
                for (const QString& j : kJunkDirs) {
                    if (pl == j) { inJunk = true; break; }
                }
                if (inJunk) break;
            }
            if (inJunk)
                continue;
            if (fresh(fi.absoluteFilePath(), since)) {
                Candidate c;
                c.exe = fi.absoluteFilePath();
                c.gameDir = gd;
                c.size = fi.size();
                res.append(c);
            }
        }
    }
    std::sort(res.begin(), res.end(), [](const Candidate& a, const Candidate& b) {
        if (a.size != b.size)
            return a.size > b.size;
        return a.exe < b.exe;
    });
    if (limit >= 0 && res.size() > limit)
        res.resize(limit);
    return res;
}

} // namespace installwatch
