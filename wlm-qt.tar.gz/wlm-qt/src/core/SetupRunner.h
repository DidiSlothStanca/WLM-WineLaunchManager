#pragma once

#include "core/InstallWatch.h"
#include "core/RunnerConfig.h"

#include <QObject>
#include <QString>
#include <QStringList>
#include <QVector>

#include <optional>

class QProcess;
class QTimer;

// Hasil satu kali pantauan installer (port of install_watch.wait_for_install()).
struct SetupResult {
    std::optional<installwatch::GogGameFound> found; // game GOG yang terdeteksi terpasang
    std::optional<int> exitCode;                     // nullopt = masih berjalan saat game terdeteksi
    QVector<installwatch::Candidate> candidates;     // hanya diisi kalau found kosong + exit 0
    QString driveC;
};

// Menjalankan sebuah installer .exe lewat Wine/Proton lalu memantaunya sampai
// game yang baru terpasang terdeteksi (goggame-*.info) atau installer berhenti.
//
// Port of run_exe_setup() + _watch_manual_install()/wait_for_install() dari
// launcher.py, dibuat non-blocking (QTimer polling 2 detik) supaya UI tetap
// responsif - pemanggil cukup menunggu signal finished().
class SetupRunner : public QObject {
    Q_OBJECT
public:
    explicit SetupRunner(QObject* parent = nullptr);
    ~SetupRunner() override;

    // extraArgs : argumen tambahan untuk installer (mis. /SILENT)
    // gameId    : id produk GOG yang dicari (kosong = game apa saja)
    // Return false + *error kalau installer gagal dijalankan.
    bool start(const QString& exePath, const RunnerChoice& choice,
               const QStringList& extraArgs = {}, const QString& gameId = QString(),
               QString* error = nullptr);

    bool isRunning() const;
    QString driveC() const { return m_driveC; }

signals:
    void started();
    void finished(const SetupResult& result);

private:
    void poll();
    void finish(const std::optional<installwatch::GogGameFound>& found);

    QProcess* m_proc = nullptr;
    QTimer* m_timer = nullptr;
    QString m_gameId;
    QString m_driveC;
    double m_started = 0.0;
    bool m_done = false;
};
