#pragma once

#include "core/RunnerConfig.h"

#include <QByteArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QMap>
#include <QObject>
#include <QPair>
#include <QString>
#include <QStringList>
#include <QVector>

#include <functional>

class QNetworkAccessManager;

// Save Manager core: local save backup/restore (tar.gz) and GOG cloud saves
// (list + download + upload). Port of gog_saves.py (upload is new - the Python
// version only downloaded). Network and archive work is event-driven on the
// main thread (QNetworkAccessManager / QProcess), so every operation takes a
// completion callback instead of blocking.
namespace gogsaves {

struct Context {
    QString name;
    QString exePath;
    QString dataDir;
    RunnerChoice choice;
    QJsonObject info;   // goggame-<id>.info contents (empty when not a GOG game)
    QString infoPath;
};

struct Target {
    QString label;   // e.g. "gog_My Saves" / "custom1"
    QString kind;    // "gog" | "custom"
    QString name;
    QString macro;
    QString path;    // resolved folder, empty when not found
    QString note;
    bool hasPath() const { return !path.isEmpty(); }
};

struct CloudItem {
    QString name;
    qint64 size = 0;
    QString hash;
    double mtime = 0; // epoch seconds, 0 = unknown
};

struct PlanItem {
    CloudItem file;
    QString dest;
    QString status; // "new" | "overwrite" | "same"
    bool newerLocal = false;
};

struct Plan {
    QString clientId;
    QString userId;
    QString token;
    QVector<Target> targets;
    QVector<PlanItem> items;
    int skipped = 0;
    int totalCloud = 0;
    bool fromCache = false;
};

struct Summary {
    int newCount = 0;
    int overwrite = 0;
    int same = 0;
    int newerLocal = 0;
    qint64 bytes = 0;
};

struct Backup {
    QString path;
    QString when;
    QString note;
    qint64 size = 0;
};

// One local save file that should be uploaded to the GOG cloud.
struct UploadItem {
    QString cloudName;   // "{location name}/{relative path}" (forward slashes)
    QString localPath;   // absolute local file path
    QString status;      // "new" | "overwrite" | "same"
    bool newerCloud = false; // the cloud copy is newer than the local one
};

struct UploadPlan {
    QString clientId;
    QString userId;
    QString token;
    QVector<UploadItem> items; // files to upload ("new" / "overwrite")
    int totalLocal = 0;        // local files scanned in the save folders
    int skipped = 0;           // already identical in the cloud ("same")
};

// ---- pure/local helpers (ports of the module-level functions) --------------

QString safe(const QString& text, const QString& fallback = QStringLiteral("game"));
QString humanSize(qint64 n);
double parseTs(const QString& text);            // 0 when unknown
QPair<QString, QJsonObject> findGogGameInfo(const QString& exePath);
QString userHome(const QString& driveC);
QString resolveLocation(const QString& location, const QString& driveC,
                        const QString& installDir);
QMap<QString, QPair<qint64, double>> listFiles(const QString& root);
QString md5(const QString& path);
QString safeDest(const QString& base, const QString& rel); // empty when unsafe
// GOG stores saves gzip-compressed (Python gzip.compress(data, 6, mtime=0));
// gzipData replicates that exact byte layout, so md5(gzipData(...)) matches the
// "hash" GOG keeps in the cloud file list.
QByteArray gzipData(const QByteArray& data);

QJsonObject loadCache(const QString& dataDir);
void saveCache(const QString& dataDir, const QJsonObject& cache);
QStringList loadCustomFolders(const QString& dataDir, const QString& game);
void saveCustomFolders(const QString& dataDir, const QString& game,
                       const QStringList& folders);

QString backupsDir(const QString& dataDir, const QString& game);
QVector<Backup> listBackups(const QString& dataDir, const QString& game);
Summary summarize(const Plan& plan);

// gog_ui.json sections (size / maximized of the Save Manager window).
QJsonObject readUiSection(const QString& dataDir, const QString& section);
void writeUiSection(const QString& dataDir, const QString& section,
                    const QJsonObject& value);

// ---- async client ----------------------------------------------------------

class Client : public QObject {
    Q_OBJECT
public:
    using LogFn = std::function<void(const QString&)>;

    explicit Client(QObject* parent = nullptr);

    // Save folders of this game. Only hits the network for GOG cloud locations
    // (and falls back to the cached copy when offline).
    void buildTargets(const Context& ctx, bool refresh, LogFn log,
                      std::function<void(const QVector<Target>&)> done);

    // Compare cloud vs local without changing anything.
    void planCloudDownload(const Context& ctx, LogFn log,
                           std::function<void(const Plan&, const QString& err)> done);

    // Back up local saves (when overwriting), then download new/changed files.
    void executeDownload(const Context& ctx, const Plan& plan, LogFn log,
                         bool skipNewerLocal,
                         std::function<void(int downloaded, int skipped, int failed,
                                            const QString& err)> done);

    // Upload the local GOG save folders to the cloud. Only plans; nothing is
    // sent until executeUpload runs.
    void planCloudUpload(const Context& ctx, LogFn log,
                         std::function<void(const UploadPlan& plan,
                                            const QString& err)> done);

    // Send the files from a planCloudUpload() result to GOG.
    void executeUpload(const UploadPlan& plan, LogFn log,
                       std::function<void(int uploaded, int failed,
                                          const QString& err)> done);

    // Local archive operations.
    void makeBackup(const QString& dataDir, const QString& game,
                    const QVector<Target>& targets, const QString& note,
                    std::function<void(const QString& path, int count,
                                       const QString& err)> done);
    void restoreBackup(const QString& archive, const QVector<Target>& targets,
                       LogFn log,
                       std::function<void(int count, const QString& err)> done);

private:
    struct HttpResponse {
        bool ok = false;
        bool offline = false;
        int status = 0;
        QMap<QString, QString> headers; // lower-cased keys
        QByteArray body;
        QString error;
    };

    void httpGet(const QString& url, const QMap<QString, QString>& headers,
                 int timeoutSec, qint64 limit,
                 std::function<void(const HttpResponse&)> cb);
    void getJson(const QString& url, const QMap<QString, QString>& headers,
                 int timeoutSec,
                 std::function<void(bool ok, const QJsonDocument& doc, const QString& err,
                                    bool offline, int status)> cb);

    void galaxyRefreshToken(const QString& dataDir,
                            std::function<void(bool ok, const QString& refresh,
                                               const QString& uid, const QString& err)> cb);
    void clientCredentials(const Context& ctx, LogFn log,
                           std::function<void(bool ok, const QString& cid,
                                              const QString& secret, const QString& err,
                                              bool offline)> cb);
    void gameToken(const QString& clientId, const QString& secret, const QString& refresh,
                   std::function<void(bool ok, const QString& token, const QString& uid,
                                      const QString& err, bool offline)> cb);
    void cloudLocations(const QString& dataDir, const QString& clientId, bool refresh,
                        std::function<void(const QJsonObject& entry, bool fromCache,
                                           const QString& err, bool offline)> cb);
    void cloudList(const QString& userId, const QString& clientId, const QString& token,
                   std::function<void(bool ok, const QVector<CloudItem>&, const QString& err,
                                      bool offline)> cb);
    void cloudGet(const QString& userId, const QString& clientId, const QString& token,
                  const QString& name, const QString& expectedHash,
                  std::function<void(bool ok, const QByteArray& data, double mtime,
                                     const QString& err, bool offline)> cb);
    void cloudPut(const QString& userId, const QString& clientId, const QString& token,
                  const QString& cloudName, const QByteArray& gzipBytes,
                  const QString& etag, const QString& mtimeIso,
                  std::function<void(bool ok, const QString& err, bool offline)> cb);
    void httpPut(const QString& url, const QMap<QString, QString>& headers,
                 const QByteArray& body, int timeoutSec,
                 std::function<void(const HttpResponse&)> cb);

    QNetworkAccessManager* m_nam;
};

} // namespace gogsaves
