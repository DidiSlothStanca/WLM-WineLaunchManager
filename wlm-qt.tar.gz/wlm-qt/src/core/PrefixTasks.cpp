#include "core/PrefixTasks.h"

#include "core/JsonIO.h"
#include "core/Paths.h"
#include "core/PrefixRegistry.h"
#include "core/ProtonManager.h" // protonutil::humanSize
#include "core/RunnerConfig.h"
#include "core/Shortcut.h"

#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QProcess>

namespace {

QString newTempPath(const QString& prefix, const QString& suffix)
{
    return QDir::tempPath() + QLatin1Char('/') + prefix
        + QString::number(QDateTime::currentMSecsSinceEpoch()) + suffix;
}

} // namespace

// --------------------------------------------------------------------------
// BackupTask
// --------------------------------------------------------------------------

BackupTask::BackupTask(QObject* parent)
    : QObject(parent)
{
}

void BackupTask::cancel()
{
    m_cancelled = true;
    if (m_proc && m_proc->state() != QProcess::NotRunning)
        m_proc->kill();
}

void BackupTask::start(const prefixops::PrefixInfo& entry,
                       const QList<prefixops::GameBackupInfo>& games, const QString& destPath,
                       qint64 totalBytes)
{
    m_dest = destPath;
    m_cancelled = false;

    emit line(QStringLiteral("Calculating total size to back up..."));
    emit line(totalBytes > 0 ? QStringLiteral("Total size: %1").arg(protonutil::humanSize(totalBytes))
                             : QStringLiteral("Total size: unknown"));
    emit line(QString());
    emit progress(-1);

    QDir().mkpath(QFileInfo(destPath).absolutePath());

    QJsonObject manifest;
    manifest[QStringLiteral("format_version")] = 2;
    manifest[QStringLiteral("created_at")] =
        QDateTime::currentDateTime().toString(QStringLiteral("yyyy-MM-ddTHH:mm:ss"));
    manifest[QStringLiteral("runner")] = entry.runner;
    manifest[QStringLiteral("prefix_code")] = entry.code;
    QJsonArray gameArr;
    for (const prefixops::GameBackupInfo& g : games) {
        QJsonObject o;
        o[QStringLiteral("script_name")] = g.scriptName;
        o[QStringLiteral("relative_exe")] = g.relativeExe;
        o[QStringLiteral("exe_path")] = g.exePath;
        o[QStringLiteral("launch_options")] = g.launchOptions;
        o[QStringLiteral("comment")] = g.comment;
        o[QStringLiteral("inside_prefix")] = g.insidePrefix;
        o[QStringLiteral("relative_to_prefix")] = g.relativeToPrefix;
        o[QStringLiteral("has_icon")] = g.hasIcon;
        gameArr.append(o);
    }
    manifest[QStringLiteral("games")] = gameArr;

    const QString manifestDir = newTempPath(QStringLiteral("wlm_manifest_"), QString());
    QDir().mkpath(manifestDir);
    m_tmpManifest = manifestDir + QStringLiteral("/manifest.json");
    {
        QFile f(m_tmpManifest);
        if (!f.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate)) {
            emit finished(false, tr("Could not write the backup manifest."), false);
            return;
        }
        f.write(QJsonDocument(manifest).toJson(QJsonDocument::Indented));
    }

    QStringList args;
    args << QStringLiteral("-c") << QStringLiteral("-z") << QStringLiteral("-v")
         << QStringLiteral("-f") << destPath;

    emit line(QStringLiteral("Archiving prefix files..."));
    const QFileInfo pf(entry.path);
    args << QStringLiteral("-C") << pf.absolutePath() << QStringLiteral("--transform")
         << QStringLiteral("s,^%1,prefix,").arg(pf.fileName()) << pf.fileName();

    for (const prefixops::GameBackupInfo& g : games) {
        if (g.missing) {
            emit line(QStringLiteral("Skipping '%1' (folder not found on disk).").arg(g.scriptName));
            continue;
        }
        if (g.insidePrefix) {
            emit line(QStringLiteral("Skipping separate archive for '%1' "
                                     "(already included inside the prefix folder).")
                          .arg(g.scriptName));
            continue;
        }
        emit line(QStringLiteral("Archiving game files: %1...").arg(g.scriptName));
        const QFileInfo gf(g.folderPath);
        args << QStringLiteral("-C") << gf.absolutePath() << QStringLiteral("--transform")
             << QStringLiteral("s,^%1,games/%2,").arg(gf.fileName(), g.scriptName)
             << gf.fileName();
    }

    for (const prefixops::GameBackupInfo& g : games) {
        if (!g.hasIcon)
            continue;
        const QFileInfo ic(g.iconPath);
        args << QStringLiteral("-C") << ic.absolutePath() << QStringLiteral("--transform")
             << QStringLiteral("s,^%1,icons/%2.png,").arg(ic.fileName(), g.scriptName)
             << ic.fileName();
    }

    args << QStringLiteral("-C") << QFileInfo(m_tmpManifest).absolutePath()
         << QFileInfo(m_tmpManifest).fileName();

    m_proc = new QProcess(this);
    m_proc->setProgram(QStringLiteral("tar"));
    m_proc->setArguments(args);
    m_proc->setProcessChannelMode(QProcess::MergedChannels);

    connect(m_proc, &QProcess::readyReadStandardOutput, this, [this] {
        const QString text = QString::fromUtf8(m_proc->readAllStandardOutput());
        for (const QString& line : text.split(QLatin1Char('\n')))
            if (!line.trimmed().isEmpty())
                emit this->line(line);
    });
    connect(m_proc, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished), this,
            [this](int exitCode, QProcess::ExitStatus) {
                QDir(QFileInfo(m_tmpManifest).absolutePath()).removeRecursively();
                if (m_cancelled) {
                    QFile::remove(m_dest);
                    emit line(QString());
                    emit line(QStringLiteral("Backup cancelled by user."));
                    emit finished(false, QStringLiteral("cancelled"), true);
                    return;
                }
                if (exitCode != 0) {
                    emit line(QString());
                    emit line(QStringLiteral("ERROR: backup failed (exit code %1).").arg(exitCode));
                    emit finished(false, QStringLiteral("tar exited with code %1").arg(exitCode),
                                  false);
                    return;
                }
                emit progress(100);
                emit line(QString());
                emit line(QStringLiteral("Done."));
                emit line(QStringLiteral("Backup saved to: %1").arg(m_dest));
                emit finished(true, QString(), false);
            });
    connect(m_proc, &QProcess::errorOccurred, this, [this](QProcess::ProcessError e) {
        if (e == QProcess::FailedToStart) {
            QDir(QFileInfo(m_tmpManifest).absolutePath()).removeRecursively();
            emit finished(false, tr("Could not start the 'tar' program."), false);
        }
    });

    m_proc->start();
}

// --------------------------------------------------------------------------
// RestoreTask
// --------------------------------------------------------------------------

RestoreTask::RestoreTask(QObject* parent)
    : QObject(parent)
{
}

void RestoreTask::cancel()
{
    m_cancelled = true;
    if (m_proc && m_proc->state() != QProcess::NotRunning)
        m_proc->kill();
}

void RestoreTask::cleanupStaging()
{
    if (!m_staging.isEmpty())
        QDir(m_staging).removeRecursively();
}

void RestoreTask::start(const QString& archivePath, const QJsonObject& manifest,
                        const QString& runner, const QString& prefixCode,
                        const QString& targetPrefixPath, const QString& gamesDestBase,
                        qint64 totalBytes)
{
    m_archive = archivePath;
    m_manifest = manifest;
    m_runner = runner;
    m_prefixCode = prefixCode;
    m_targetPrefix = targetPrefixPath;
    m_gamesDestBase = gamesDestBase;
    m_cancelled = false;

    emit line(totalBytes > 0
                  ? QStringLiteral("Restoring %1...").arg(protonutil::humanSize(totalBytes))
                  : QStringLiteral("Restoring (size unknown)..."));
    emit line(QString());
    emit progress(-1);

    m_staging = newTempPath(QStringLiteral("wlm_restore_"), QString());
    QDir().mkpath(m_staging);

    m_proc = new QProcess(this);
    m_proc->setProgram(QStringLiteral("tar"));
    m_proc->setArguments({QStringLiteral("-x"), QStringLiteral("-z"), QStringLiteral("-v"),
                          QStringLiteral("-f"), archivePath, QStringLiteral("-C"), m_staging});
    m_proc->setProcessChannelMode(QProcess::MergedChannels);

    connect(m_proc, &QProcess::readyReadStandardOutput, this, [this] {
        const QString text = QString::fromUtf8(m_proc->readAllStandardOutput());
        for (const QString& line : text.split(QLatin1Char('\n')))
            if (!line.trimmed().isEmpty())
                emit this->line(line);
    });
    connect(m_proc, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished), this,
            [this](int exitCode, QProcess::ExitStatus) {
                if (m_cancelled) {
                    cleanupStaging();
                    emit line(QString());
                    emit line(QStringLiteral("Restore cancelled by user."));
                    emit finished(false, QStringLiteral("cancelled"), true);
                    return;
                }
                if (exitCode != 0) {
                    cleanupStaging();
                    emit line(QString());
                    emit line(QStringLiteral("ERROR: extraction failed (exit code %1).").arg(exitCode));
                    emit finished(false,
                                  QStringLiteral("tar exited with code %1").arg(exitCode), false);
                    return;
                }
                finishRestore();
            });
    connect(m_proc, &QProcess::errorOccurred, this, [this](QProcess::ProcessError e) {
        if (e == QProcess::FailedToStart) {
            cleanupStaging();
            emit finished(false, tr("Could not start the 'tar' program."), false);
        }
    });

    m_proc->start();
}

void RestoreTask::finishRestore()
{
    QDir staging(m_staging);

    // 1) Move the prefix contents into place.
    QDir().mkpath(m_targetPrefix);
    QDir prefixSrc(staging.filePath(QStringLiteral("prefix")));
    if (prefixSrc.exists()) {
        for (const QFileInfo& fi : prefixSrc.entryInfoList(QDir::AllEntries | QDir::NoDotAndDotDot)) {
            const QString dst = m_targetPrefix + QLatin1Char('/') + fi.fileName();
            if (fi.isDir()) {
                if (!MoveTask::copyRecursive(fi.filePath(), dst, nullptr)) {
                    cleanupStaging();
                    emit finished(false, tr("Failed to move restored prefix files."), false);
                    return;
                }
            } else {
                QFile::remove(dst);
                if (!QFile::copy(fi.filePath(), dst)) {
                    cleanupStaging();
                    emit finished(false, tr("Failed to move restored prefix files."), false);
                    return;
                }
            }
        }
    }

    // 2) Move external game folders.
    const QJsonArray games = m_manifest.value(QStringLiteral("games")).toArray();
    if (!m_gamesDestBase.isEmpty())
        QDir().mkpath(m_gamesDestBase);
    for (const QJsonValue& v : games) {
        const QJsonObject g = v.toObject();
        if (g.value(QStringLiteral("inside_prefix")).toBool())
            continue;
        const QString scriptName = g.value(QStringLiteral("script_name")).toString();
        const QString src = staging.filePath(QStringLiteral("games/") + scriptName);
        if (!QFileInfo::exists(src))
            continue;
        emit line(QStringLiteral("Placing game files: %1...").arg(scriptName));
        const QString dst = m_gamesDestBase + QLatin1Char('/') + scriptName;
        QDir().mkpath(QFileInfo(dst).absolutePath());
        MoveTask::copyRecursive(src, dst, nullptr);
    }

    // 3) Icons.
    for (const QJsonValue& v : games) {
        const QJsonObject g = v.toObject();
        if (!g.value(QStringLiteral("has_icon")).toBool())
            continue;
        const QString scriptName = g.value(QStringLiteral("script_name")).toString();
        const QString src = staging.filePath(QStringLiteral("icons/") + scriptName + QStringLiteral(".png"));
        if (!QFileInfo::exists(src))
            continue;
        QDir().mkpath(paths::icons());
        QFile::remove(paths::icons() + QLatin1Char('/') + scriptName + QStringLiteral(".png"));
        QFile::copy(src, paths::icons() + QLatin1Char('/') + scriptName + QStringLiteral(".png"));
    }

    // 4) Register prefix + games in the launcher.
    prefixreg::recordPrefixUsage(m_runner, m_prefixCode, m_targetPrefix);

    for (const QJsonValue& v : games) {
        const QJsonObject g = v.toObject();
        const QString scriptName = g.value(QStringLiteral("script_name")).toString();
        const bool inside = g.value(QStringLiteral("inside_prefix")).toBool();

        QString gameDir;
        if (inside) {
            const QString rel = g.value(QStringLiteral("relative_to_prefix")).toString();
            gameDir = rel.isEmpty() ? m_targetPrefix : m_targetPrefix + QLatin1Char('/') + rel;
        } else {
            if (m_gamesDestBase.isEmpty())
                continue;
            gameDir = m_gamesDestBase + QLatin1Char('/') + scriptName;
        }

        const QString relativeExe = g.value(QStringLiteral("relative_exe")).toString();
        QString exePath;
        if (!relativeExe.isEmpty())
            exePath = gameDir + QLatin1Char('/') + relativeExe;
        else {
            exePath = g.value(QStringLiteral("exe_path")).toString();
            emit line(QStringLiteral("WARNING: could not determine the .exe location for '%1'.")
                          .arg(scriptName));
        }

        RunnerChoice choice;
        choice.runner = m_runner;
        choice.prefixCode = m_prefixCode;
        choice.prefixPath = m_targetPrefix;
        choice.launchOptions = g.value(QStringLiteral("launch_options")).toString();
        choice.comment = g.value(QStringLiteral("comment")).toString();

        const QString scriptPath =
            paths::bashlaunch() + QLatin1Char('/') + scriptName + QStringLiteral(".sh");
        QDir().mkpath(paths::bashlaunch());
        QFile f(scriptPath);
        if (f.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate)) {
            f.write(shortcut::buildScriptContent(gameDir, exePath, choice.toJson()).toUtf8());
            f.close();
            QFile::setPermissions(scriptPath,
                                  QFileDevice::ReadOwner | QFileDevice::WriteOwner
                                      | QFileDevice::ExeOwner | QFileDevice::ReadGroup
                                      | QFileDevice::ExeGroup | QFileDevice::ReadOther
                                      | QFileDevice::ExeOther);
        }
        runnerconfig::set(scriptName, choice);
    }

    cleanupStaging();
    emit progress(100);
    emit line(QString());
    emit line(QStringLiteral("Restore completed successfully."));
    if (m_runner != QLatin1String("wine")) {
        emit line(QStringLiteral("Note: this prefix's Proton build was not carried over;"));
        emit line(QStringLiteral("you'll be asked to pick a local build the first time you use it."));
    }
    emit finished(true, QString(), false);
}

// --------------------------------------------------------------------------
// MoveTask
// --------------------------------------------------------------------------

MoveTask::MoveTask(QObject* parent)
    : QObject(parent)
{
}

bool MoveTask::copyRecursive(const QString& src, const QString& dst, QString* error)
{
    const QFileInfo si(src);
    if (si.isDir()) {
        if (!QDir().mkpath(dst)) {
            if (error)
                *error = QStringLiteral("Could not create %1").arg(dst);
            return false;
        }
        QDir srcDir(src);
        for (const QFileInfo& fi : srcDir.entryInfoList(QDir::AllEntries | QDir::NoDotAndDotDot)) {
            if (!copyRecursive(fi.filePath(), dst + QLatin1Char('/') + fi.fileName(), error))
                return false;
        }
        return true;
    }

    QFile::remove(dst);
    if (!QFile::copy(src, dst)) {
        if (error)
            *error = QStringLiteral("Could not copy %1").arg(src);
        return false;
    }
    return true;
}

bool MoveTask::moveDirectory(const QString& oldPath, const QString& newPath, QString* error)
{
    QDir().mkpath(QFileInfo(newPath).absolutePath());
    if (QDir().rename(oldPath, newPath))
        return true;

    // Cross-filesystem fallback: copy then delete.
    if (!copyRecursive(oldPath, newPath, error))
        return false;
    if (!QDir(oldPath).removeRecursively()) {
        // Not fatal: files were copied successfully.
    }
    return true;
}

void MoveTask::start(const QString& oldPath, const QString& newPath, const QString& runner,
                     const QString& code)
{
    emit line(QStringLiteral("Moving prefix '%1'...").arg(code));

    QString error;
    if (!moveDirectory(oldPath, newPath, &error)) {
        emit finished(false, error, {});
        return;
    }

    const QStringList relinked = prefixops::relinkScriptsAfterMove(runner, code, oldPath, newPath);
    prefixreg::updateRegistryPrefixPath(runner, code, newPath);

    emit line(QStringLiteral("Moved to: %1").arg(newPath));
    if (!relinked.isEmpty())
        emit line(QStringLiteral("Relinked %1 game(s): %2")
                      .arg(relinked.size())
                      .arg(relinked.join(QStringLiteral(", "))));
    emit finished(true, QString(), relinked);
}
