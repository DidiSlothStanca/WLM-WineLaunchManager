#include "core/CoverStore.h"

#include "core/JsonIO.h"

#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QImage>
#include <QRegularExpression>
#include <QSet>
#include <QVector>

#include <algorithm>

namespace covers {

namespace {

constexpr qint64 kMissRetrySecs = 7 * 24 * 3600;
constexpr qint64 kOfflineBackoffSecs = 60;

const QMap<QString, int>& sizesRef()
{
    static const QMap<QString, int> s = {
        {QStringLiteral("Small"), 160},
        {QStringLiteral("Medium"), 200},
        {QStringLiteral("Large"), 260},
    };
    return s;
}

// difflib.SequenceMatcher.ratio(): 2*M/T with M = total matched characters.
int longestMatch(const QString& a, int alo, int ahi, const QString& b, int blo, int bhi,
                 int* outI, int* outJ)
{
    int best = 0, bi = alo, bj = blo;
    const int n = ahi - alo, m = bhi - blo;
    QVector<int> prev(m + 1, 0), cur(m + 1, 0);
    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= m; ++j) {
            if (a.at(alo + i - 1) == b.at(blo + j - 1)) {
                cur[j] = prev[j - 1] + 1;
                if (cur[j] > best) {
                    best = cur[j];
                    bi = alo + i - cur[j];
                    bj = blo + j - cur[j];
                }
            } else {
                cur[j] = 0;
            }
        }
        prev = cur;
        std::fill(cur.begin(), cur.end(), 0);
    }
    *outI = bi;
    *outJ = bj;
    return best;
}

void matchingBlocks(const QString& a, int alo, int ahi, const QString& b, int blo, int bhi,
                    int* matched)
{
    if (alo >= ahi || blo >= bhi)
        return;
    int i = alo, j = blo;
    const int size = longestMatch(a, alo, ahi, b, blo, bhi, &i, &j);
    if (size <= 0)
        return;
    matchingBlocks(a, alo, i, b, blo, j, matched);
    *matched += size;
    matchingBlocks(a, i + size, ahi, b, j + size, bhi, matched);
}

double sequenceRatio(const QString& a, const QString& b)
{
    const int total = a.size() + b.size();
    if (total == 0)
        return 1.0;
    int matched = 0;
    matchingBlocks(a, 0, a.size(), b, 0, b.size(), &matched);
    return 2.0 * matched / total;
}

const QRegularExpression& editionRe()
{
    static const QRegularExpression re(
        QStringLiteral("\\b(goty|game of the year( edition)?|definitive edition|complete edition|"
                       "deluxe edition|enhanced edition|special edition|ultimate edition|"
                       "gold edition|collector'?s edition|remastered|remaster|gog edition|"
                       "director'?s cut|anniversary edition)\\b"));
    return re;
}

const QMap<QString, QString>& romanMap()
{
    static const QMap<QString, QString> m = {
        {QStringLiteral("ii"), QStringLiteral("2")},   {QStringLiteral("iii"), QStringLiteral("3")},
        {QStringLiteral("iv"), QStringLiteral("4")},   {QStringLiteral("v"), QStringLiteral("5")},
        {QStringLiteral("vi"), QStringLiteral("6")},   {QStringLiteral("vii"), QStringLiteral("7")},
        {QStringLiteral("viii"), QStringLiteral("8")}, {QStringLiteral("ix"), QStringLiteral("9")},
        {QStringLiteral("x"), QStringLiteral("10")},
    };
    return m;
}

QSet<QString> numberTokens(const QString& norm)
{
    const QStringList toks = norm.split(QLatin1Char(' '), Qt::SkipEmptyParts);
    QSet<QString> nums;
    for (const QString& t : toks) {
        if (romanMap().contains(t))
            nums.insert(romanMap().value(t));
        else {
            bool ok = false;
            t.toInt(&ok);
            if (ok)
                nums.insert(t);
        }
    }
    if (!toks.isEmpty() && toks.size() > 1 && romanMap().contains(toks.first()))
        nums.remove(romanMap().value(toks.first()));
    return nums;
}

} // namespace

const QMap<QString, int>& cardSizes()
{
    return sizesRef();
}

ViewConfig loadViewConfig(const QString& path)
{
    ViewConfig cfg;
    const QJsonObject data = jsonio::readObject(path);
    if (data.isEmpty())
        return cfg;
    const QString v = data.value(QStringLiteral("view")).toString();
    if (v == QLatin1String("grid") || v == QLatin1String("list"))
        cfg.view = v;
    bool ok = false;
    int w = data.value(QStringLiteral("card_width")).toVariant().toInt(&ok);
    if (!ok)
        w = cfg.cardWidth;
    cfg.cardWidth = std::max(120, std::min(400, w));
    return cfg;
}

void saveViewConfig(const QString& path, const ViewConfig& cfg)
{
    QJsonObject obj;
    obj[QStringLiteral("view")] = cfg.view;
    obj[QStringLiteral("card_width")] = cfg.cardWidth;
    jsonio::writeObjectAtomic(path, obj);
}

QString normalizeTitle(const QString& text)
{
    QString t = text.normalized(QString::NormalizationForm_KD).toLower();
    QString stripped;
    stripped.reserve(t.size());
    for (const QChar& c : t) {
        const QChar::Category cat = c.category();
        if (cat == QChar::Mark_NonSpacing || cat == QChar::Mark_SpacingCombining
            || cat == QChar::Mark_Enclosing)
            continue;
        stripped.append(c);
    }
    t = stripped;
    t.remove(QChar(0x2122)); // ™
    t.remove(QChar(0x00AE)); // ®
    t.remove(QChar(0x00A9)); // ©
    t.replace(QStringLiteral("&"), QStringLiteral(" and "));
    t.remove(QRegularExpression(QStringLiteral(R"([(\[].*?[)\]])")));
    t.replace(editionRe(), QStringLiteral(" "));
    t.replace(QRegularExpression(QStringLiteral("[^a-z0-9]+")), QStringLiteral(" "));
    return t.trimmed().replace(QRegularExpression(QStringLiteral("\\s+")), QStringLiteral(" "));
}

double titleSimilarity(const QString& a, const QString& b)
{
    const QString na = normalizeTitle(a);
    const QString nb = normalizeTitle(b);
    if (na.isEmpty() || nb.isEmpty())
        return 0.0;
    if (na == nb)
        return 1.0;
    double score = sequenceRatio(na, nb);
    if (numberTokens(na) != numberTokens(nb))
        score *= 0.6;
    return score;
}

CoverStore::CoverStore(const QString& dataDir)
    : m_dir(dataDir + QStringLiteral("/covers"))
    , m_indexPath(m_dir + QStringLiteral("/index.json"))
{
}

QString CoverStore::path(const QString& name) const
{
    QString safe = name;
    safe.replace(QRegularExpression(QStringLiteral("[\\\\/]")), QStringLiteral("_"));
    return m_dir + QLatin1Char('/') + safe + QStringLiteral(".jpg");
}

bool CoverStore::has(const QString& name) const
{
    return QFileInfo::exists(path(name));
}

QJsonObject& CoverStore::index()
{
    if (!m_indexLoaded) {
        m_index = jsonio::readObject(m_indexPath);
        m_indexLoaded = true;
    }
    return m_index;
}

void CoverStore::saveIndex()
{
    QDir().mkpath(m_dir);
    jsonio::writeObjectAtomic(m_indexPath, m_index);
}

bool CoverStore::saveImage(const QString& name, const QImage& image, QString* error)
{
    if (image.isNull()) {
        if (error)
            *error = QStringLiteral("empty image");
        return false;
    }
    QImage img = image.convertToFormat(QImage::Format_RGB888);
    if (img.width() > 640 || img.height() > 640)
        img = img.scaled(640, 640, Qt::KeepAspectRatio, Qt::SmoothTransformation);
    QDir().mkpath(m_dir);
    const QString target = path(name);
    const QString tmp = target + QStringLiteral(".tmp");
    if (!img.save(tmp, "JPEG", 88)) {
        if (error)
            *error = QStringLiteral("could not write image");
        return false;
    }
    QFile::remove(target);
    if (!QFile::rename(tmp, target)) {
        if (error)
            *error = QStringLiteral("could not replace image");
        QFile::remove(tmp);
        return false;
    }
    return true;
}

bool CoverStore::setManual(const QString& name, const QString& imagePath, QString* error)
{
    QImage img(imagePath);
    if (img.isNull()) {
        if (error)
            *error = QStringLiteral("could not open that image");
        return false;
    }
    if (!saveImage(name, img, error))
        return false;
    QJsonObject entry;
    entry[QStringLiteral("src")] = QStringLiteral("manual");
    entry[QStringLiteral("ts")] = static_cast<double>(QDateTime::currentSecsSinceEpoch());
    index()[name] = entry;
    saveIndex();
    return true;
}

void CoverStore::forget(const QString& name)
{
    QFile::remove(path(name));
    QJsonObject& idx = index();
    if (idx.contains(name)) {
        idx.remove(name);
        saveIndex();
    }
}

void CoverStore::rename(const QString& oldName, const QString& newName)
{
    const QString oldPath = path(oldName);
    const QString newPath = path(newName);
    if (QFileInfo::exists(oldPath) && !QFileInfo::exists(newPath))
        QFile::rename(oldPath, newPath);
    else
        QFile::remove(oldPath);

    const QJsonObject entry = index().value(oldName).toObject();
    index().remove(oldName);
    if (!entry.isEmpty() && !entry.contains(QStringLiteral("miss")))
        index()[newName] = entry;
    saveIndex();
}

bool CoverStore::recentMiss(const QString& name) const
{
    const QJsonObject entry = m_indexLoaded ? m_index.value(name).toObject()
                                           : jsonio::readObject(m_indexPath).value(name).toObject();
    const QJsonValue ts = entry.value(QStringLiteral("miss"));
    if (ts.isUndefined())
        return false;
    return QDateTime::currentSecsSinceEpoch() - static_cast<qint64>(ts.toDouble()) < kMissRetrySecs;
}

void CoverStore::clearMiss(const QString& name)
{
    if (index().value(name).toObject().contains(QStringLiteral("miss"))) {
        index().remove(name);
        saveIndex();
    }
}

void CoverStore::recordMiss(const QString& name, double score)
{
    QJsonObject o;
    o[QStringLiteral("miss")] = static_cast<double>(QDateTime::currentSecsSinceEpoch());
    o[QStringLiteral("score")] = score;
    index()[name] = o;
    saveIndex();
}

void CoverStore::recordHit(const QString& name, const QString& matched, double score)
{
    QJsonObject o;
    o[QStringLiteral("src")] = QStringLiteral("auto");
    if (!matched.isEmpty())
        o[QStringLiteral("matched")] = matched;
    o[QStringLiteral("score")] = score;
    o[QStringLiteral("ts")] = static_cast<double>(QDateTime::currentSecsSinceEpoch());
    index()[name] = o;
    saveIndex();
}

bool CoverStore::offline() const
{
    return QDateTime::currentMSecsSinceEpoch() < m_offlineUntil;
}

void CoverStore::markOffline()
{
    m_offlineUntil = QDateTime::currentMSecsSinceEpoch() + kOfflineBackoffSecs * 1000;
}

void CoverStore::clearOffline()
{
    m_offlineUntil = 0;
}

} // namespace covers
