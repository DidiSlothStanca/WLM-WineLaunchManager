#pragma once

#include <QJsonObject>
#include <QString>
#include <QStringList>
#include <QPoint>

#include <optional>

namespace hudconfig {

struct VulkanHud {
    QStringList metrics;
    QString scale;
};

struct GalliumHud {
    QStringList metrics;
    QString scale;
};

struct HudConfig {
    VulkanHud vulkanHud;
    GalliumHud galliumHud;
};

// Baca hud_config.json (root ~/wlm). Isi field kosong/rusak dengan default.
HudConfig load();

// Simpan hanya vulkan_hud dan gallium_hud (tidak menghapus key lain).
void save(const HudConfig& cfg);

// Baca/simpan posisi terakhir dialog Config HUD. Skema sama dengan Python:
// string "+x+y" di key "window_position"; None/kosong kalau belum pernah disimpan.
std::optional<QPoint> loadWindowPosition();
void saveWindowPosition(const QPoint& pos);

// Bangun prefix env untuk DXVK/Vulkan HUD: "DXVK_HUD=..."
QString buildVulkanHudEnvPrefix(const HudConfig& cfg);

// Bangun prefix env untuk Gallium HUD: "GALLIUM_HUD=..."
QString buildGalliumHudEnvPrefix(const HudConfig& cfg);

} // namespace hudconfig
