#pragma once

#include <QObject>
#include <QString>
#include <QVector>

#include "core/RunnerConfig.h"

#include <QDateTime>

// Central download manager. Tracks all active and completed downloads across
// the app (GOG installers, Proton GE/CachyOS, etc.). Persists history to
// download_history.json so it survives restarts.
//
// Usage: create one instance (or use the global singleton), call startDownload()
// to register a new download, then wire your downloader's progress/cancel signals
// to the manager's update/cancel methods.
class DownloadManager : public QObject {
    Q_OBJECT
public:
    enum class Status {
        Queued,
        Downloading,
        Paused,
        Completed,
        Failed,
        Cancelled
    };
    Q_ENUM(Status)

    struct Item {
        int id = 0;
        QString title;
        QString category; // "GOG", "ProtonGE", "Proton-CachyOS"
        Status status = Status::Queued;
        qint64 totalSize = 0;
        qint64 downloadedSize = 0;
        int progress = 0; // 0-100, -1 = indeterminate
        QString error;
        QDateTime startedAt;
        QDateTime finishedAt;
        QString destPath;
        // Auto-install options (for GOG downloads).
        bool startSetupAfterDownload = false;
        RunnerChoice runnerChoice;
    };

    explicit DownloadManager(QObject* parent = nullptr);
    ~DownloadManager() override;

    // Start tracking a new download. Returns the item ID.
    int startDownload(const QString& title, const QString& category,
                      qint64 totalSize, const QString& destPath);

    // Update progress (0-100, or -1 for indeterminate).
    void updateProgress(int id, int progress, qint64 downloaded, qint64 total);

    // Pause/resume/cancel.
    void pauseDownload(int id);
    void resumeDownload(int id);
    void cancelDownload(int id);

    // Mark as completed or failed.
    void markCompleted(int id);
    void markFailed(int id, const QString& error);

    // Remove a single item or all completed/failed items.
    void removeItem(int id);
    void clearFinished();
    void resetNextId();

    // Accessors.
    QVector<Item> items() const;
    QVector<Item> activeItems() const;
    bool hasActive() const;

    // Global singleton (created on first use).
    static DownloadManager* instance();

signals:
    void itemAdded(const Item& item);
    void itemUpdated(const Item& item);
    void itemRemoved(int id);
    // Emitted when a download should be cancelled (passes download ID).
    void cancelRequested(int id);

private:
    void load();
    void save() const;

    QVector<Item> m_items;
    int m_nextId = 1;
    static DownloadManager* s_instance;
};
