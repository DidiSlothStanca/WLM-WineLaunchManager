#pragma once

#include <QObject>
#include <QSize>
#include <QString>

#include <optional>

class QEvent;
class QTimer;
class QWidget;

// Persisted per-dialog sizes (dialog_sizes.json: {"key": "WxH", ...}).
namespace dialogsizes {

std::optional<QSize> load(const QString& key);
void save(const QString& key, const QSize& size);

} // namespace dialogsizes

// Attaches "remember my last size" behaviour to a dialog: restores the saved
// size (or `defaultSize`), clamps to min size / screen, centres on `parent`,
// then saves the size after the user resizes (debounced 500 ms) and on close.
//
// Port of remember_dialog_size() from launcher.py. Create it right after
// building the dialog and before showing it; it owns itself (deletes with the
// dialog via parent()).
class DialogSizeKeeper : public QObject {
    Q_OBJECT
public:
    DialogSizeKeeper(QWidget* dialog, QString key, QSize defaultSize,
                     QSize minSize = QSize(0, 0), QWidget* parent = nullptr);

    QSize appliedSize() const { return m_size; }

protected:
    bool eventFilter(QObject* obj, QEvent* ev) override;

private:
    void centerOnParent();
    void persist();

    QWidget* m_dialog;
    QString m_key;
    QSize m_size;
    QTimer* m_timer;
    bool m_ready = false;
};
