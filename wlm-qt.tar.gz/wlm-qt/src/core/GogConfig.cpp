#include "core/GogConfig.h"

#include "core/JsonIO.h"
#include "core/Paths.h"

#include <QDir>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonValue>

namespace gog {

namespace {

QString expandHome(const QString& path)
{
    if (path.startsWith(QLatin1Char('~')))
        return QDir::homePath() + path.mid(1);
    return path;
}

} // namespace

QJsonObject Config::toJson() const
{
    QJsonObject o;
    o.insert(QStringLiteral("client_id"), clientId);
    o.insert(QStringLiteral("client_secret"), clientSecret);
    o.insert(QStringLiteral("auth_url"), authUrl);
    o.insert(QStringLiteral("token_url"), tokenUrl);
    o.insert(QStringLiteral("redirect_uri"), redirectUri);
    o.insert(QStringLiteral("userdata_url"), userdataUrl);
    o.insert(QStringLiteral("library_url"), libraryUrl);
    o.insert(QStringLiteral("product_url"), productUrl);
    o.insert(QStringLiteral("download_dir"), downloadDir);
    o.insert(QStringLiteral("game_dir"), gameDir);
    o.insert(QStringLiteral("content_system_url"), contentSystemUrl);
    o.insert(QStringLiteral("depot_meta_url"), depotMetaUrl);
    o.insert(QStringLiteral("owned_url"), ownedUrl);
    o.insert(QStringLiteral("direct_threads"), directThreads);
    o.insert(QStringLiteral("os"), os);
    o.insert(QStringLiteral("language"), language);
    o.insert(QStringLiteral("user_agent"), userAgent);
    o.insert(QStringLiteral("browser_command"), browserCommand);
    o.insert(QStringLiteral("browser_timeout"), browserTimeout);
    o.insert(QStringLiteral("install_args"), installArgs);
    o.insert(QStringLiteral("auto_shortcut"), autoShortcut);
    o.insert(QStringLiteral("max_downloads"), maxDownloads);
    o.insert(QStringLiteral("view"), view);
    o.insert(QStringLiteral("card_width"), cardWidth);
    o.insert(QStringLiteral("cover_ratio"), coverRatio);
    QJsonArray sufs;
    for (const QString& s : coverSuffixes)
        sufs.append(s);
    o.insert(QStringLiteral("cover_suffixes"), sufs);
    return o;
}

Config Config::fromJson(const QJsonObject& obj)
{
    Config c; // start from defaults, then overlay whatever the file defines
    auto string = [&obj](const char* key, QString& out) {
        const QJsonValue v = obj.value(QLatin1String(key));
        if (v.isString())
            out = v.toString();
    };
    auto boolean = [&obj](const char* key, bool& out) {
        const QJsonValue v = obj.value(QLatin1String(key));
        if (v.isBool())
            out = v.toBool();
    };
    auto integer = [&obj](const char* key, int& out) {
        const QJsonValue v = obj.value(QLatin1String(key));
        if (v.isDouble())
            out = v.toInt();
    };
    auto number = [&obj](const char* key, double& out) {
        const QJsonValue v = obj.value(QLatin1String(key));
        if (v.isDouble())
            out = v.toDouble();
    };

    string("client_id", c.clientId);
    string("client_secret", c.clientSecret);
    string("auth_url", c.authUrl);
    string("token_url", c.tokenUrl);
    string("redirect_uri", c.redirectUri);
    string("userdata_url", c.userdataUrl);
    string("library_url", c.libraryUrl);
    string("product_url", c.productUrl);
    string("download_dir", c.downloadDir);
    string("game_dir", c.gameDir);
    string("content_system_url", c.contentSystemUrl);
    string("depot_meta_url", c.depotMetaUrl);
    string("owned_url", c.ownedUrl);
    integer("direct_threads", c.directThreads);
    string("os", c.os);
    string("language", c.language);
    string("user_agent", c.userAgent);
    string("browser_command", c.browserCommand);
    integer("browser_timeout", c.browserTimeout);
    string("install_args", c.installArgs);
    boolean("auto_shortcut", c.autoShortcut);
    integer("max_downloads", c.maxDownloads);
    string("view", c.view);
    integer("card_width", c.cardWidth);
    number("cover_ratio", c.coverRatio);

    const QJsonValue sufs = obj.value(QStringLiteral("cover_suffixes"));
    if (sufs.isArray()) {
        QStringList list;
        for (const QJsonValue& v : sufs.toArray()) {
            if (v.isString() && !v.toString().isEmpty())
                list << v.toString();
        }
        if (!list.isEmpty())
            c.coverSuffixes = list;
    }
    return c;
}

QString Config::downloadRoot() const
{
    const QString custom = downloadDir.trimmed();
    if (!custom.isEmpty())
        return expandHome(custom);
    return paths::gogDownloads();
}

QString Config::gameRoot() const
{
    const QString custom = gameDir.trimmed();
    if (!custom.isEmpty())
        return expandHome(custom);
    return paths::gogGames();
}

Config loadConfig(const QString& path)
{
    const QString p = path.isEmpty() ? paths::gogConfig() : path;
    if (!QFileInfo::exists(p)) {
        const Config defaults;
        saveConfig(defaults, p);
        return defaults;
    }
    return Config::fromJson(jsonio::readObject(p));
}

void saveConfig(const Config& c, const QString& path)
{
    jsonio::writeObjectAtomic(path.isEmpty() ? paths::gogConfig() : path, c.toJson());
}

} // namespace gog
