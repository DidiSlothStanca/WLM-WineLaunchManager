#include "core/Shortcut.h"

#include "core/Paths.h"
#include "core/Proton.h"
#include "core/RunnerConfig.h"

#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QImage>
#include <QImageReader>
#include <QJsonObject>
#include <QRegularExpression>
#include <QSet>
#include <QTextStream>

namespace shortcut {
namespace {

// Potong persegi + skala ke ikon launcher lalu simpan sebagai PNG.
// Port of blok ikon di add_game_shortcut() (PIL: crop tengah + LANCZOS).
bool saveShortcutIcon(const QString& srcPath, const QString& targetPath, int size)
{
    QImageReader reader(srcPath);
    QImage image = reader.read();
    if (image.isNull())
        return false;

    image = image.convertToFormat(QImage::Format_ARGB32);
    const int side = qMin(image.width(), image.height());
    const int left = (image.width() - side) / 2;
    const int top = (image.height() - side) / 2;
    image = image.copy(left, top, side, side)
                .scaled(size, size, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    return image.save(targetPath, "PNG");
}

} // namespace

QString shellQuote(const QString& s)
{
    if (s.isEmpty())
        return QStringLiteral("''");

    // Safe unquoted characters, mirroring Python's shlex.quote regex
    // [A-Za-z0-9_@%+=:,./-]. Also allow '~' and '^' conservatively.
    static const QRegularExpression safe(QStringLiteral("^[A-Za-z0-9_@%+=:,./~^-]+$"));
    if (safe.match(s).hasMatch())
        return s;

    QString quoted = s;
    quoted.replace(QLatin1Char('\''), QLatin1String("'\\''"));
    return QLatin1Char('\'') + quoted + QLatin1Char('\'');
}

QString sanitizeName(const QString& name)
{
    QString out;
    out.reserve(name.size());
    for (const QChar& c : name) {
        if (c.isLetterOrNumber() || c == QLatin1Char(' ') || c == QLatin1Char('_')
            || c == QLatin1Char('-')) {
            out.append(c);
        }
    }
    return out.trimmed();
}

LaunchOptions parseLaunchOptions(const QString& launchOptions)
{
    LaunchOptions result;
    const QString trimmed = launchOptions.trimmed();
    if (trimmed.isEmpty())
        return result;

    // Simple whitespace split (good enough for the intended KEY=VALUE / %command% form).
    const QStringList tokens = trimmed.split(QRegularExpression(QStringLiteral("\\s+")),
                                             Qt::SkipEmptyParts);

    const int cmdIdx = tokens.indexOf(QStringLiteral("%command%"));
    if (cmdIdx >= 0) {
        for (int i = 0; i < cmdIdx; ++i) {
            const QString& t = tokens.at(i);
            if (t.contains(QLatin1Char('=')) && !t.startsWith(QLatin1Char('-'))) {
                const int eq = t.indexOf(QLatin1Char('='));
                result.envVars.append({t.left(eq), t.mid(eq + 1)});
            }
        }
        for (int i = cmdIdx + 1; i < tokens.size(); ++i)
            result.extraArgs.append(tokens.at(i));
    } else {
        for (const QString& t : tokens) {
            if (t.contains(QLatin1Char('=')) && !t.startsWith(QLatin1Char('-'))) {
                const int eq = t.indexOf(QLatin1Char('='));
                result.envVars.append({t.left(eq), t.mid(eq + 1)});
            } else {
                result.extraArgs.append(t);
            }
        }
    }
    return result;
}

QString extractExePath(const QString& scriptPath)
{
    QFile f(scriptPath);
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text))
        return {};

    const QString content = QString::fromUtf8(f.readAll());
    static const QRegularExpression wineRe(QStringLiteral("wine\\s+\"([^\"]+)\""));
    static const QRegularExpression protonRe(QStringLiteral("\"[^\"]*\"\\s+run\\s+\"([^\"]+)\""));

    QRegularExpressionMatch m = wineRe.match(content);
    if (!m.hasMatch())
        m = protonRe.match(content);
    if (m.hasMatch())
        return m.captured(1);
    return {};
}

QString extractFolderPath(const QString& scriptPath)
{
    QFile f(scriptPath);
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text))
        return {};

    QTextStream in(&f);
    QStringList lines;
    while (!in.atEnd() && lines.size() < 2)
        lines.append(in.readLine());

    if (lines.size() >= 2) {
        static const QRegularExpression cdRe(QStringLiteral("cd\\s+\"([^\"]+)\""));
        const QRegularExpressionMatch m = cdRe.match(lines.at(1).trimmed());
        if (m.hasMatch())
            return m.captured(1);
    }
    return {};
}

QString buildScriptContent(const QString& folderPath, const QString& exePath,
                           const QJsonObject& choice)
{
    QStringList lines;
    lines << QStringLiteral("#!/bin/bash");
    lines << QStringLiteral("cd \"%1\"").arg(folderPath);

    const QString comment = choice.value(QStringLiteral("comment")).toString().trimmed();
    if (!comment.isEmpty()) {
        const QStringList commentLines = comment.split(QLatin1Char('\n'));
        for (const QString& c : commentLines)
            lines << QStringLiteral("# %1").arg(c);
    }

    const QString launchOptions =
        choice.value(QStringLiteral("launch_options")).toString().trimmed();
    if (!launchOptions.isEmpty())
        lines << QStringLiteral("# Launch Options: %1").arg(launchOptions);

    const LaunchOptions parsed = parseLaunchOptions(launchOptions);
    for (const auto& kv : parsed.envVars)
        lines << QStringLiteral("export %1=%2").arg(kv.first, shellQuote(kv.second));

    QString extraArgs;
    if (!parsed.extraArgs.isEmpty()) {
        extraArgs = QLatin1Char(' ');
        QStringList quoted;
        for (const QString& a : parsed.extraArgs)
            quoted << shellQuote(a);
        extraArgs += quoted.join(QLatin1Char(' '));
    }

    const QString runner = choice.value(QStringLiteral("runner")).toString();
    if (runner == QLatin1String("protonge") || runner == QLatin1String("protoncachyos")) {
        lines << QStringLiteral("export STEAM_COMPAT_DATA_PATH=\"%1\"")
                     .arg(choice.value(QStringLiteral("prefix_path")).toString());
        lines << QStringLiteral("export STEAM_COMPAT_CLIENT_INSTALL_PATH=\"%1\"")
                     .arg(Proton::findSteamInstallPath());
        lines << QStringLiteral("\"%1\" run \"%2\"%3")
                     .arg(choice.value(QStringLiteral("proton_path")).toString(),
                          exePath, extraArgs);
    } else {
        const QString prefixPath = choice.value(QStringLiteral("prefix_path")).toString();
        if (!prefixPath.isEmpty())
            lines << QStringLiteral("export WINEPREFIX=\"%1\"").arg(prefixPath);
        lines << QStringLiteral("wine \"%1\"%2").arg(exePath, extraArgs);
    }

    return lines.join(QLatin1Char('\n')) + QLatin1Char('\n');
}

QString detectGogId(const QString& exePath)
{
    if (exePath.isEmpty())
        return {};

    static const QSet<QString> stopDirs = {
        QStringLiteral("drive_c"), QStringLiteral("gog games"), QStringLiteral("games"),
        QStringLiteral("gog.com"), QStringLiteral("program files"),
        QStringLiteral("program files (x86)"),
    };

    QDir dir = QFileInfo(exePath).dir();
    for (int i = 0; i < 4; ++i) {
        const QFileInfoList entries =
            dir.entryInfoList(QDir::Files | QDir::NoDotAndDotDot | QDir::Hidden);
        for (const QFileInfo& fi : entries) {
            const QString n = fi.fileName().toLower();
            if (n.startsWith(QLatin1String("goggame-")) && n.endsWith(QLatin1String(".info"))) {
                return fi.fileName().mid(7, fi.fileName().size() - 7 - 5);
            }
        }
        if (stopDirs.contains(dir.dirName().toLower()))
            return {};
        if (!dir.cdUp())
            return {};
    }
    return {};
}

QString addGameShortcut(const QString& name, const QString& exePath,
                        const RunnerChoice& choice, const QString& iconPath,
                        const QString& workDir)
{
    const QFileInfo exeInfo(exePath);
    const QString exeResolved = exeInfo.canonicalFilePath().isEmpty()
                                    ? exeInfo.absoluteFilePath()
                                    : exeInfo.canonicalFilePath();

    QString folderResolved;
    if (!workDir.isEmpty()) {
        const QFileInfo wi(workDir);
        folderResolved = wi.canonicalFilePath().isEmpty() ? wi.absoluteFilePath()
                                                          : wi.canonicalFilePath();
    } else {
        folderResolved = exeInfo.absolutePath();
    }

    QString base = sanitizeName(name);
    if (base.isEmpty())
        base = exeInfo.completeBaseName();

    // Nama unik: script yang sudah ada dan menunjuk exe yang sama dipakai ulang
    // (mis. install ulang), selain itu ditambah angka.
    QString safeName = base;
    QString scriptPath;
    int n = 2;
    while (true) {
        scriptPath = paths::bashlaunch() + QLatin1Char('/') + safeName + QStringLiteral(".sh");
        if (!QFileInfo::exists(scriptPath))
            break;
        const QString existing = extractExePath(scriptPath);
        if (!existing.isEmpty() && existing == exeResolved)
            break;
        safeName = base + QLatin1Char(' ') + QString::number(n);
        ++n;
    }

    QDir().mkpath(paths::bashlaunch());
    {
        QFile f(scriptPath);
        if (!f.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate))
            return {};
        f.write(buildScriptContent(folderResolved, exeResolved, choice.toJson()).toUtf8());
        f.close();
    }
    QFile::setPermissions(scriptPath,
                          QFileDevice::ReadOwner | QFileDevice::WriteOwner
                              | QFileDevice::ExeOwner | QFileDevice::ReadGroup
                              | QFileDevice::ExeGroup | QFileDevice::ReadOther
                              | QFileDevice::ExeOther);

    runnerconfig::set(safeName, choice);

    const QString iconTarget =
        paths::icons() + QLatin1Char('/') + safeName + QStringLiteral(".png");
    if (!iconPath.isEmpty() && !QFileInfo::exists(iconTarget)) {
        QDir().mkpath(paths::icons());
        if (!saveShortcutIcon(iconPath, iconTarget, 250))
            qWarning("Could not save icon for %s", qPrintable(safeName));
    }
    return safeName;
}

} // namespace shortcut
