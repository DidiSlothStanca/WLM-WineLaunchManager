#pragma once

#include <QByteArray>
#include <QList>
#include <QObject>
#include <QPair>
#include <QQueue>
#include <QSet>
#include <QString>
#include <QStringList>

#include <functional>

class QNetworkAccessManager;
class QUrl;

namespace covers {
class CoverStore;
}

// Async GOG catalog cover lookup + download (event-driven QNetworkAccessManager,
// no blocking). Port of game_covers.py's find_cover_url / CoverStore.ensure.
class CoverFetcher : public QObject {
    Q_OBJECT
public:
    explicit CoverFetcher(covers::CoverStore* store, QObject* parent = nullptr);

    // Queue a cover fetch. Emits coverReady(name, hasCover) when done.
    // If gogId is provided, uses it to fetch directly from GOG's CDN (more reliable).
    void ensure(const QString& name, bool force = false, const QString& gogId = QString());
    bool isPending(const QString& name) const { return m_queued.contains(name); }

signals:
    void coverReady(const QString& name, bool hasCover);
    void statusMessage(const QString& text, bool warning);

private:
    struct Job {
        QString name;
        bool force = false;
        QString gogId;
    };

    void startNext();
    void finishJob(const QString& name, bool hasCover);

    // Search one query against source 0 (catalog) / 1 (embed); advances the job.
    void trySource(int sourceIndex);
    void nextQuery();
    void finalizeMiss();

    void evaluate(const QList<QPair<QString, QString>>& results); // (title, url)
    void downloadImage(const QString& url);

    // Reuse a cover the GOG Store already cached (~/wlm/gog_covers/<gogId>.jpg)
    // before falling back to a title search.
    bool useCachedGogCover(const QString& gogId, const QString& name);

    // Set up the title queries and start searching source 0.
    void beginSearch();

    // source 0 = catalog, 1 = embed. `cb(results, offline, error)`.
    void querySource(int sourceIndex, const QString& query,
                     std::function<void(const QList<QPair<QString, QString>>&, bool, bool)> cb);

    void get(const QUrl& url, int limitBytes, int timeoutMs,
             std::function<void(const QByteArray&, bool offline, bool error)> cb);

    covers::CoverStore* m_store = nullptr;
    QNetworkAccessManager* m_net = nullptr;

    QQueue<Job> m_queue;
    QSet<QString> m_queued;
    bool m_busy = false;

    // Current job state.
    Job m_job;
    QStringList m_queries;
    int m_queryIndex = 0;
    QString m_bestUrl;
    QString m_bestTitle;
    double m_bestScore = 0.0;
};
