#include "core/Proton.h"

#include "core/Paths.h"

#include <QDir>
#include <QFileInfo>

#include <algorithm>
#include <functional>

namespace Proton {

QList<Build> findInstallations(const QString& baseDir)
{
    QList<Build> found;
    QDir dir(baseDir);
    if (!dir.exists())
        return found;

    QStringList names = dir.entryList(QDir::Dirs | QDir::NoDotAndDotDot);
    // Python used sorted(..., reverse=True): newest/greatest name first.
    std::sort(names.begin(), names.end(), std::greater<QString>());

    for (const QString& name : names) {
        const QString protonBin = dir.filePath(name + QStringLiteral("/proton"));
        if (QFileInfo::exists(protonBin))
            found.append({name, protonBin});
    }
    return found;
}

QList<Build> findProtonGEInstallations()
{
    return findInstallations(paths::protonGE());
}

QList<Build> findProtonCachyOSInstallations()
{
    return findInstallations(paths::protonCachyOS());
}

QString findSteamInstallPath()
{
    const QString home = QDir::homePath();
    const QStringList candidates = {
        home + QStringLiteral("/.steam/steam"),
        home + QStringLiteral("/.local/share/Steam"),
        home + QStringLiteral("/.var/app/com.valvesoftware.Steam/data/Steam"),
    };
    for (const QString& c : candidates) {
        if (QFileInfo(c).isDir())
            return c;
    }
    const QString fallback = paths::root() + QStringLiteral("/steamclient");
    QDir().mkpath(fallback);
    return fallback;
}

} // namespace Proton
