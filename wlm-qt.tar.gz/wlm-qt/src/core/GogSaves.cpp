#include "core/GogSaves.h"

#include "core/InstallWatch.h"
#include "core/JsonIO.h"

#include <QCryptographicHash>
#include <QDateTime>
#include <QDir>
#include <QDirIterator>
#include <QFile>
#include <QFileInfo>
#include <QHash>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonParseError>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QProcess>
#include <QRegularExpression>
#include <QSet>
#include <QTemporaryDir>
#include <QTimeZone>
#include <QUrl>
#include <QUrlQuery>

#include <zlib.h>

#include <algorithm>
#include <memory>

namespace gogsaves {

namespace {

const QString kUserAgent = QStringLiteral("wine-launcher-manager");
const QString kGalaxyUa = QStringLiteral(
    "GOGGalaxyCommunicationService/2.0.13.27 (Windows_32bit) "
    "dont_sync_marker/true installation_source/gog");
const QString kRemoteConfigUrl = QStringLiteral(
    "https://remote-config.gog.com/components/galaxy_client/clients/{cid}?component_version=2.0.43");
const QString kBuildsUrl =
    QStringLiteral("https://content-system.gog.com/products/{pid}/os/windows/builds?generation=2");

QString variantToString(const QJsonValue& v)
{
    return v.toVariant().toString();
}

QString jsonString(const QJsonObject& o, const QString& key)
{
    return variantToString(o.value(key));
}

// Inflate one stream. windowBits matches Python's zlib.decompress(data, wbits).
bool inflateRaw(const QByteArray& in, QByteArray& out, int windowBits)
{
    z_stream strm{};
    if (inflateInit2(&strm, windowBits) != Z_OK)
        return false;
    strm.next_in = reinterpret_cast<Bytef*>(const_cast<char*>(in.constData()));
    strm.avail_in = static_cast<uInt>(in.size());
    QByteArray result;
    QByteArray buf(65536, Qt::Uninitialized);
    int ret = Z_OK;
    while (ret != Z_STREAM_END) {
        strm.next_out = reinterpret_cast<Bytef*>(buf.data());
        strm.avail_out = static_cast<uInt>(buf.size());
        ret = inflate(&strm, Z_NO_FLUSH);
        if (ret != Z_OK && ret != Z_STREAM_END) {
            inflateEnd(&strm);
            return false;
        }
        result.append(buf.constData(), static_cast<int>(buf.size() - strm.avail_out));
    }
    inflateEnd(&strm);
    out = result;
    return true;
}

bool gunzip(const QByteArray& in, QByteArray& out)
{
    return inflateRaw(in, out, MAX_WBITS + 16);
}

// Port of _zlib_json(): try the three zlib wrappers, then plain JSON.
QJsonDocument zlibJson(const QByteArray& data, bool* ok)
{
    for (int wbits : {15, -15, 31}) {
        QByteArray dec;
        if (inflateRaw(data, dec, wbits)) {
            QJsonParseError e{};
            const QJsonDocument d = QJsonDocument::fromJson(dec, &e);
            if (e.error == QJsonParseError::NoError) {
                *ok = true;
                return d;
            }
        }
    }
    QJsonParseError e{};
    const QJsonDocument d = QJsonDocument::fromJson(data, &e);
    *ok = e.error == QJsonParseError::NoError;
    return *ok ? d : QJsonDocument();
}

QString md5Bytes(const QByteArray& b)
{
    return QString::fromLatin1(QCryptographicHash::hash(b, QCryptographicHash::Md5).toHex());
}

// ISO-8601 UTC with seconds, e.g. 2024-01-02T03:04:05+00:00 (the
// X-Object-Meta-LocalLastModified format both gogdl and the cloud expect).
QString epochToIso(double epochSeconds)
{
    if (epochSeconds <= 0)
        return QString();
    return QDateTime::fromSecsSinceEpoch(static_cast<qint64>(epochSeconds), QTimeZone::utc())
               .toString(QStringLiteral("yyyy-MM-dd'T'HH:mm:ss"))
        + QStringLiteral("+00:00");
}

QString encodeCloudName(const QString& name)
{
    // Keep the '/' separators; encode every path segment like urllib quote().
    QStringList parts = name.split(QLatin1Char('/'));
    for (QString& p : parts)
        p = QString::fromUtf8(QUrl::toPercentEncoding(p));
    return parts.join(QLatin1Char('/'));
}

void setFileTimes(const QString& path, double seconds)
{
    if (seconds <= 0)
        return;
    QFile f(path);
    if (!f.open(QIODevice::ReadWrite))
        return;
    const QDateTime dt =
        QDateTime::fromMSecsSinceEpoch(static_cast<qint64>(seconds * 1000.0), QTimeZone::utc());
    f.setFileTime(dt, QFileDevice::FileModificationTime);
    f.setFileTime(dt, QFileDevice::FileAccessTime);
}

} // namespace

// --------------------------------------------------------------------------- helpers

// Port of Python's gzip.compress(data, 6, mtime=0); GOG stores saves this way
// and reports md5(this) as the object "hash" in the cloud file list.
QByteArray gzipData(const QByteArray& data)
{
    // gzip header, exactly like CPython: magic | flg=0 | mtime=0 | xfl=0 | os=255
    QByteArray out;
    out.reserve(data.size() + 64);
    out.append(char(0x1f));
    out.append(char(0x8b));
    out.append(char(0x08));
    out.append('\0'); // FLG: no name / comment
    out.append('\0'); // mtime = 0
    out.append('\0');
    out.append('\0');
    out.append('\0');
    out.append('\0'); // XFL (compresslevel 6 -> 0)
    out.append(char(0xff)); // OS: unknown (CPython _OS_NONE)

    z_stream strm{};
    strm.next_in = reinterpret_cast<Bytef*>(const_cast<char*>(data.constData()));
    strm.avail_in = static_cast<uInt>(data.size());
    // raw deflate (no zlib/gzip wrapper) - we write the header/trailer ourselves.
    if (deflateInit2(&strm, 6, Z_DEFLATED, -MAX_WBITS, 8, Z_DEFAULT_STRATEGY) != Z_OK)
        return {};

    QByteArray buf(65536, Qt::Uninitialized);
    int ret = Z_OK;
    while (ret != Z_STREAM_END) {
        strm.next_out = reinterpret_cast<Bytef*>(buf.data());
        strm.avail_out = static_cast<uInt>(buf.size());
        ret = deflate(&strm, Z_FINISH);
        if (ret != Z_OK && ret != Z_STREAM_END) {
            deflateEnd(&strm);
            return {};
        }
        out.append(buf.constData(), static_cast<int>(buf.size() - strm.avail_out));
    }
    deflateEnd(&strm);

    // trailer: CRC-32 of the original data, then ISIZE, both little-endian.
    const uLong crc =
        crc32(0L, reinterpret_cast<const Bytef*>(data.constData()), static_cast<uInt>(data.size()));
    for (int i = 0; i < 4; ++i)
        out.append(static_cast<char>((crc >> (8 * i)) & 0xff));
    const quint32 isize = static_cast<quint32>(data.size());
    for (int i = 0; i < 4; ++i)
        out.append(static_cast<char>((isize >> (8 * i)) & 0xff));
    return out;
}

QString safe(const QString& text, const QString& fallback)
{
    if (text.isEmpty())
        return fallback;
    static const QRegularExpression bad(
        QStringLiteral("[^\\w.\\- ]+"),
        QRegularExpression::UseUnicodePropertiesOption);
    QString s = text;
    s.replace(bad, QStringLiteral("_"));
    int start = 0;
    int end = s.size();
    while (start < end
           && (s.at(start) == QLatin1Char(' ') || s.at(start) == QLatin1Char('.')))
        ++start;
    while (end > start
           && (s.at(end - 1) == QLatin1Char(' ') || s.at(end - 1) == QLatin1Char('.')))
        --end;
    s = s.mid(start, end - start);
    return s.isEmpty() ? fallback : s;
}

QString humanSize(qint64 n)
{
    if (n < 0)
        n = 0;
    double v = static_cast<double>(n);
    const char* units[] = {"B", "KB", "MB", "GB"};
    for (int i = 0; i < 4; ++i) {
        if (v < 1024.0 || i == 3) {
            if (i == 0)
                return QStringLiteral("%1 B").arg(static_cast<qint64>(v));
            return QString::number(v, 'f', 1) + QLatin1Char(' ')
                + QLatin1String(units[i]);
        }
        v /= 1024.0;
    }
    return QString();
}

double parseTs(const QString& text)
{
    const QString t = text.trimmed();
    if (t.isEmpty())
        return 0;
    QDateTime dt = QDateTime::fromString(t, Qt::ISODateWithMs);
    if (!dt.isValid())
        dt = QDateTime::fromString(t, Qt::ISODate);
    if (!dt.isValid())
        dt = QDateTime::fromString(t, Qt::RFC2822Date);
    if (!dt.isValid())
        return 0;
    if (dt.timeSpec() == Qt::LocalTime)
        dt = QDateTime(dt.date(), dt.time(), QTimeZone::utc());
    return static_cast<double>(dt.toMSecsSinceEpoch()) / 1000.0;
}

QPair<QString, QJsonObject> findGogGameInfo(const QString& exePath)
{
    static const QSet<QString> stopDirs = {
        QStringLiteral("drive_c"),       QStringLiteral("gog games"),
        QStringLiteral("games"),         QStringLiteral("gog.com"),
        QStringLiteral("program files"), QStringLiteral("program files (x86)"),
    };
    if (exePath.isEmpty())
        return {QString(), QJsonObject()};

    QString dir = QFileInfo(exePath).absolutePath();
    for (int level = 0; level < 4 && !dir.isEmpty(); ++level) {
        QVector<QPair<QString, QJsonObject>> found;
        const QFileInfoList files = QDir(dir).entryInfoList(
            QDir::Files | QDir::NoDotAndDotDot | QDir::Hidden, QDir::Name);
        for (const QFileInfo& fi : files) {
            const QString name = fi.fileName().toLower();
            if (!name.startsWith(QLatin1String("goggame-"))
                || !name.endsWith(QLatin1String(".info")))
                continue;
            QFile f(fi.absoluteFilePath());
            if (!f.open(QIODevice::ReadOnly))
                continue;
            QByteArray data = f.readAll();
            f.close();
            if (data.startsWith("\xEF\xBB\xBF"))
                data.remove(0, 3);
            QJsonParseError err{};
            const QJsonDocument doc = QJsonDocument::fromJson(data, &err);
            if (err.error != QJsonParseError::NoError || !doc.isObject())
                continue;
            found.append({fi.absoluteFilePath(), doc.object()});
        }
        if (!found.isEmpty()) {
            for (const auto& pair : found) {
                const QString gid = jsonString(pair.second, QStringLiteral("gameId"));
                const QString root = jsonString(pair.second, QStringLiteral("rootGameId"));
                if (root.isEmpty() || gid == root)
                    return pair;
            }
            return found.first();
        }
        if (stopDirs.contains(QFileInfo(dir).fileName().toLower()))
            break;
        const QDir parent = QFileInfo(dir).absoluteDir();
        if (parent.absolutePath() == dir)
            break;
        dir = parent.absolutePath();
    }
    return {QString(), QJsonObject()};
}

QString userHome(const QString& driveC)
{
    const QString usersPath = installwatch::resolveCi(driveC, QStringLiteral("users"));
    if (usersPath.isEmpty() || !QFileInfo(usersPath).isDir())
        return QString();
    const QSet<QString> skip = {QStringLiteral("public"), QStringLiteral("all users"),
                                QStringLiteral("default"), QStringLiteral("default user")};
    QStringList cand;
    for (const QFileInfo& e :
         QDir(usersPath).entryInfoList(QDir::Dirs | QDir::NoDotAndDotDot, QDir::NoSort))
        if (e.isDir() && !skip.contains(e.fileName().toLower()))
            cand << e.fileName();

    QStringList wants = {QStringLiteral("steamuser")};
    QString user;
    for (const char* env : {"LOGNAME", "USER", "LNAME", "USERNAME"}) {
        const QByteArray v = qgetenv(env);
        if (!v.isEmpty()) {
            user = QString::fromLocal8Bit(v);
            break;
        }
    }
    if (user.isEmpty())
        user = QFileInfo(QDir::homePath()).fileName();
    if (!user.isEmpty())
        wants << user;

    for (const QString& want : wants)
        for (const QString& n : cand)
            if (n.compare(want, Qt::CaseInsensitive) == 0)
                return QDir(usersPath).filePath(n);

    if (cand.isEmpty())
        return QString();
    cand.sort();
    return QDir(usersPath).filePath(cand.first());
}

QString resolveLocation(const QString& location, const QString& driveC,
                        const QString& installDir)
{
    static const QRegularExpression macroRe(
        QStringLiteral("^<\\?([A-Z_]+)\\?>[\\\\/]*(.*)$"));
    const QRegularExpressionMatch m = macroRe.match(location.trimmed());
    if (!m.hasMatch())
        return QString();
    const QString name = m.captured(1);
    const QString rest = m.captured(2);

    using Dirs = QStringList;
    static const QMap<QString, QList<Dirs>> macros = {
        {QStringLiteral("DOCUMENTS"),
         {Dirs{QStringLiteral("Documents")}, Dirs{QStringLiteral("My Documents")}}},
        {QStringLiteral("SAVED_GAMES"), {Dirs{QStringLiteral("Saved Games")}}},
        {QStringLiteral("APPLICATION_DATA_LOCAL"),
         {Dirs{QStringLiteral("AppData"), QStringLiteral("Local")},
          Dirs{QStringLiteral("Local Settings"), QStringLiteral("Application Data")}}},
        {QStringLiteral("APPLICATION_DATA_LOCAL_LOW"),
         {Dirs{QStringLiteral("AppData"), QStringLiteral("LocalLow")}}},
        {QStringLiteral("APPLICATION_DATA_ROAMING"),
         {Dirs{QStringLiteral("AppData"), QStringLiteral("Roaming")},
          Dirs{QStringLiteral("Application Data")}}},
    };

    QString base;
    if (name == QLatin1String("INSTALL")) {
        base = installDir;
    } else if (const auto it = macros.constFind(name); it != macros.constEnd()) {
        if (driveC.isEmpty())
            return QString();
        const QString home = userHome(driveC);
        if (home.isEmpty())
            return QString();
        for (const QStringList& cand : *it) {
            const QString p = installwatch::resolveCi(home, cand.join(QLatin1Char('/')));
            if (!p.isEmpty() && QFileInfo(p).isDir()) {
                base = p;
                break;
            }
        }
        if (base.isEmpty())
            base = QDir(home).filePath(it->first().join(QLatin1Char('/')));
    } else {
        return QString();
    }
    if (base.isEmpty())
        return QString();

    static const QRegularExpression sep(QStringLiteral("[\\\\/]+"));
    QStringList parts;
    for (const QString& p : rest.split(sep))
        if (!p.isEmpty() && p != QLatin1String("."))
            parts << p;
    QString cur = base;
    for (int i = 0; i < parts.size(); ++i) {
        const QString& part = parts[i];
        if (part == QLatin1String(".."))
            return QString(); // unsafe save location (matches Python's SaveError)
        QString nxt;
        if (QFileInfo(cur).isDir())
            nxt = installwatch::resolveCi(cur, part);
        if (nxt.isEmpty())
            return QDir(cur).filePath(parts.mid(i).join(QLatin1Char('/')));
        cur = nxt;
    }
    return cur;
}

QString safeDest(const QString& base, const QString& rel)
{
    if (base.isEmpty() || rel.isEmpty())
        return QString();
    if (rel.startsWith(QLatin1Char('/')) || rel.startsWith(QLatin1Char('\\')))
        return QString();
    static const QRegularExpression sep(QStringLiteral("[\\\\/]+"));
    QStringList parts;
    for (const QString& p : rel.split(sep))
        if (!p.isEmpty() && p != QLatin1String("."))
            parts << p;
    if (parts.isEmpty())
        return QString();
    for (const QString& p : parts)
        if (p == QLatin1String(".."))
            return QString();
    return QDir(base).filePath(parts.join(QLatin1Char('/')));
}

QString md5(const QString& path)
{
    QFile f(path);
    if (!f.open(QIODevice::ReadOnly))
        return QString();
    QCryptographicHash h(QCryptographicHash::Md5);
    if (!h.addData(&f))
        return QString();
    return QString::fromLatin1(h.result().toHex());
}

QMap<QString, QPair<qint64, double>> listFiles(const QString& root)
{
    QMap<QString, QPair<qint64, double>> out;
    if (root.isEmpty())
        return out;
    QDir dir(root);
    if (!dir.exists())
        return out;
    QDirIterator it(root, QDir::Files | QDir::NoDotAndDotDot | QDir::System,
                    QDirIterator::Subdirectories);
    while (it.hasNext()) {
        const QString p = it.next();
        const QFileInfo fi(p);
        if (fi.isSymLink())
            continue;
        out.insert(dir.relativeFilePath(p),
                   {fi.size(),
                    static_cast<double>(fi.lastModified().toMSecsSinceEpoch()) / 1000.0});
    }
    return out;
}

QJsonObject loadCache(const QString& dataDir)
{
    return jsonio::readObject(QDir(dataDir).filePath(QStringLiteral("gog_cloud_cache.json")));
}

void saveCache(const QString& dataDir, const QJsonObject& cache)
{
    jsonio::writeObjectAtomic(QDir(dataDir).filePath(QStringLiteral("gog_cloud_cache.json")),
                              cache);
}

QStringList loadCustomFolders(const QString& dataDir, const QString& game)
{
    const QJsonObject data =
        jsonio::readObject(QDir(dataDir).filePath(QStringLiteral("save_folders.json")));
    QStringList out;
    for (const QJsonValue& v : data.value(game).toArray())
        if (v.isString())
            out << v.toString();
    return out;
}

void saveCustomFolders(const QString& dataDir, const QString& game, const QStringList& folders)
{
    const QString path = QDir(dataDir).filePath(QStringLiteral("save_folders.json"));
    QJsonObject data = jsonio::readObject(path);
    if (folders.isEmpty()) {
        data.remove(game);
    } else {
        QJsonArray arr;
        for (const QString& f : folders)
            arr.append(f);
        data.insert(game, arr);
    }
    jsonio::writeObjectAtomic(path, data);
}

QString backupsDir(const QString& dataDir, const QString& game)
{
    return QDir(dataDir).filePath(QStringLiteral("save_backups/") + safe(game));
}

QVector<Backup> listBackups(const QString& dataDir, const QString& game)
{
    QVector<Backup> out;
    const QDir dir(backupsDir(dataDir, game));
    if (!dir.exists())
        return out;
    static const QRegularExpression re(QStringLiteral("^(\\d{8}-\\d{6})_(.*)\\.tar\\.gz$"));
    const QFileInfoList entries = dir.entryInfoList(
        {QStringLiteral("*.tar.gz")}, QDir::Files, QDir::Name | QDir::Reversed | QDir::IgnoreCase);
    for (const QFileInfo& fi : entries) {
        Backup b;
        b.path = fi.absoluteFilePath();
        b.size = fi.size();
        const QRegularExpressionMatch m = re.match(fi.fileName());
        if (m.hasMatch()) {
            const QDateTime dt =
                QDateTime::fromString(m.captured(1), QStringLiteral("yyyyMMdd-HHmmss"));
            b.when = dt.isValid() ? dt.toString(QStringLiteral("yyyy-MM-dd HH:mm:ss"))
                                  : fi.fileName();
            b.note = m.captured(2);
        } else {
            b.when = fi.fileName();
        }
        out.append(b);
    }
    return out;
}

Summary summarize(const Plan& plan)
{
    Summary s;
    for (const PlanItem& i : plan.items) {
        if (i.status == QLatin1String("new")) {
            ++s.newCount;
            s.bytes += i.file.size;
        } else if (i.status == QLatin1String("overwrite")) {
            ++s.overwrite;
            s.bytes += i.file.size;
            if (i.newerLocal)
                ++s.newerLocal;
        } else if (i.status == QLatin1String("same")) {
            ++s.same;
        }
    }
    return s;
}

QJsonObject readUiSection(const QString& dataDir, const QString& section)
{
    QFile f(QDir(dataDir).filePath(QStringLiteral("gog_ui.json")));
    if (!f.open(QIODevice::ReadOnly))
        return {};
    const QByteArray raw = f.readAll();
    f.close();
    QJsonParseError err{};
    const QJsonDocument doc = QJsonDocument::fromJson(raw, &err);
    if (err.error != QJsonParseError::NoError || !doc.isObject())
        return {};
    const QJsonValue v = doc.object().value(section);
    return v.isObject() ? v.toObject() : QJsonObject();
}

void writeUiSection(const QString& dataDir, const QString& section, const QJsonObject& value)
{
    const QString path = QDir(dataDir).filePath(QStringLiteral("gog_ui.json"));
    QJsonObject root;
    QFile f(path);
    if (f.open(QIODevice::ReadOnly)) {
        const QByteArray raw = f.readAll();
        f.close();
        QJsonParseError err{};
        const QJsonDocument doc = QJsonDocument::fromJson(raw, &err);
        if (err.error == QJsonParseError::NoError && doc.isObject())
            root = doc.object();
    }
    root.insert(section, value);
    jsonio::writeObjectAtomic(path, root);
}

// --------------------------------------------------------------------------- Client

Client::Client(QObject* parent)
    : QObject(parent)
    , m_nam(new QNetworkAccessManager(this))
{
}

void Client::httpGet(const QString& url, const QMap<QString, QString>& headers,
                     int timeoutSec, qint64 limit,
                     std::function<void(const HttpResponse&)> cb)
{
    QNetworkRequest req{QUrl(url)};
    req.setHeader(QNetworkRequest::UserAgentHeader, kUserAgent);
    for (auto it = headers.constBegin(); it != headers.constEnd(); ++it)
        req.setRawHeader(it.key().toUtf8(), it.value().toUtf8());
    req.setAttribute(QNetworkRequest::RedirectPolicyAttribute,
                     QNetworkRequest::NoLessSafeRedirectPolicy);
    req.setTransferTimeout(timeoutSec * 1000);

    QNetworkReply* reply = m_nam->get(req);
    connect(reply, &QNetworkReply::finished, this, [reply, url, limit, cb]() {
        HttpResponse r;
        r.status = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        for (const QNetworkReply::RawHeaderPair& h : reply->rawHeaderPairs())
            r.headers.insert(QString::fromUtf8(h.first).toLower(),
                             QString::fromUtf8(h.second));
        const QByteArray body = reply->readAll();
        if (reply->error() != QNetworkReply::NoError) {
            if (r.status == 0) {
                r.offline = true;
                r.error = QStringLiteral(
                    "Could not reach GOG. Check your internet connection.");
            } else {
                r.error = QStringLiteral("GOG returned HTTP %1 for %2.")
                              .arg(r.status)
                              .arg(QUrl(url).host());
            }
            cb(r);
            reply->deleteLater();
            return;
        }
        if (body.size() > limit) {
            r.error = QStringLiteral("Response from GOG was too large.");
            cb(r);
            reply->deleteLater();
            return;
        }
        r.ok = true;
        r.body = body;
        cb(r);
        reply->deleteLater();
    });
}

void Client::httpPut(const QString& url, const QMap<QString, QString>& headers,
                     const QByteArray& body, int timeoutSec,
                     std::function<void(const HttpResponse&)> cb)
{
    QNetworkRequest req{QUrl(url)};
    req.setHeader(QNetworkRequest::UserAgentHeader, kGalaxyUa);
    req.setHeader(QNetworkRequest::ContentTypeHeader, QStringLiteral("application/octet-stream"));
    for (auto it = headers.constBegin(); it != headers.constEnd(); ++it)
        req.setRawHeader(it.key().toUtf8(), it.value().toUtf8());
    req.setAttribute(QNetworkRequest::RedirectPolicyAttribute,
                     QNetworkRequest::NoLessSafeRedirectPolicy);
    req.setTransferTimeout(timeoutSec * 1000);

    QNetworkReply* reply = m_nam->put(req, body);
    connect(reply, &QNetworkReply::finished, this, [reply, url, cb]() {
        HttpResponse r;
        r.status = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        for (const QNetworkReply::RawHeaderPair& h : reply->rawHeaderPairs())
            r.headers.insert(QString::fromUtf8(h.first).toLower(),
                             QString::fromUtf8(h.second));
        r.body = reply->readAll();
        if (reply->error() != QNetworkReply::NoError) {
            if (r.status == 0) {
                r.offline = true;
                r.error = QStringLiteral(
                    "Could not reach GOG. Check your internet connection.");
            } else {
                r.error = QStringLiteral("GOG returned HTTP %1 for %2.")
                              .arg(r.status)
                              .arg(QUrl(url).host());
            }
            cb(r);
            reply->deleteLater();
            return;
        }
        r.ok = true;
        cb(r);
        reply->deleteLater();
    });
}

void Client::getJson(const QString& url, const QMap<QString, QString>& headers, int timeoutSec,
                     std::function<void(bool, const QJsonDocument&, const QString&, bool, int)> cb)
{
    const QString host = QUrl(url).host();
    httpGet(url, headers, timeoutSec, 4 * 1024 * 1024,
            [cb, host](const HttpResponse& r) {
                if (!r.ok) {
                    cb(false, {}, r.error, r.offline, r.status);
                    return;
                }
                QJsonParseError err{};
                const QJsonDocument doc = QJsonDocument::fromJson(r.body, &err);
                if (err.error != QJsonParseError::NoError) {
                    cb(false, {},
                       QStringLiteral("Unexpected (non-JSON) answer from %1.").arg(host),
                       false, r.status);
                    return;
                }
                cb(true, doc, {}, false, r.status);
            });
}

void Client::galaxyRefreshToken(
    const QString& dataDir,
    std::function<void(bool, const QString&, const QString&, const QString&)> cb)
{
    QJsonObject auth;
    QFile f(QDir(dataDir).filePath(QStringLiteral("gog_auth.json")));
    if (f.open(QIODevice::ReadOnly)) {
        const QJsonDocument doc = QJsonDocument::fromJson(f.readAll());
        if (doc.isObject())
            auth = doc.object();
        f.close();
    }
    const QString refresh = auth.value(QStringLiteral("refresh_token")).toString();
    if (refresh.isEmpty()) {
        cb(false, {}, {},
           QStringLiteral("Not logged in to GOG. Open GOG STORE and log in first."));
        return;
    }
    cb(true, refresh, variantToString(auth.value(QStringLiteral("user_id"))), {});
}

void Client::clientCredentials(
    const Context& ctx, LogFn log,
    std::function<void(bool, const QString&, const QString&, const QString&, bool)> cb)
{
    Q_UNUSED(log);
    const QString clientId = variantToString(ctx.info.value(QStringLiteral("clientId")));
    if (clientId.isEmpty()) {
        cb(false, {}, {},
           QStringLiteral("This game has no GOG clientId (it does not use GOG Galaxy "
                          "cloud saves)."),
           false);
        return;
    }
    QJsonObject cache = loadCache(ctx.dataDir);
    const QString cached =
        cache.value(QStringLiteral("secrets")).toObject().value(clientId).toString();
    if (!cached.isEmpty()) {
        cb(true, clientId, cached, {}, false);
        return;
    }

    QStringList pids;
    for (const char* key : {"rootGameId", "gameId"}) {
        const QString v = variantToString(ctx.info.value(QLatin1String(key)));
        if (!v.isEmpty() && !pids.contains(v))
            pids << v;
    }

    struct State {
        QString clientId;
        QString dataDir;
        QStringList pids;
        int pi = 0;
        QJsonArray items;
        int ii = 0;
        std::function<void(bool, const QString&, const QString&, const QString&, bool)> cb;
        std::function<void()> nextPid;
        std::function<void()> nextItem;
    };
    auto st = std::make_shared<State>();
    st->clientId = clientId;
    st->dataDir = ctx.dataDir;
    st->pids = pids;
    st->cb = cb;

    st->nextPid = [this, st]() {
        if (st->pi >= st->pids.size()) {
            st->cb(false, {}, {},
                   QStringLiteral("Could not find the cloud credentials of this game.\n"
                                  "If you know its client secret, add it to "
                                  "gog_cloud_cache.json under \"secrets\": "
                                  "{\"%1\": \"<secret>\"}.")
                       .arg(st->clientId),
                   false);
            return;
        }
        const QString pid = st->pids.at(st->pi);
        const QString url =
            QString(kBuildsUrl).replace(QStringLiteral("{pid}"), pid);
        getJson(url, {}, 20,
                [this, st](bool ok, const QJsonDocument& doc, const QString& err,
                           bool offline, int) {
                    if (!ok) {
                        if (offline) {
                            st->cb(false, {}, {}, err, true);
                            return;
                        }
                        ++st->pi;
                        st->nextPid();
                        return;
                    }
                    st->items = doc.object().value(QStringLiteral("items")).toArray();
                    st->ii = 0;
                    st->nextItem();
                });
    };

    st->nextItem = [this, st]() {
        if (st->ii >= st->items.size() || st->ii >= 3) {
            ++st->pi;
            st->nextPid();
            return;
        }
        const QJsonObject item = st->items.at(st->ii).toObject();
        ++st->ii;
        const QString link = item.value(QStringLiteral("link")).toString();
        if (link.isEmpty()) {
            st->nextItem();
            return;
        }
        httpGet(link, {}, 30, 4 * 1024 * 1024,
                [this, st](const HttpResponse& r) {
                    if (!r.ok) {
                        st->cb(false, {}, {}, r.error, r.offline);
                        return;
                    }
                    bool ok = false;
                    const QJsonDocument meta = zlibJson(r.body, &ok);
                    if (!ok) {
                        st->cb(false, {}, {},
                               QStringLiteral("Could not read the GOG build manifest."),
                               false);
                        return;
                    }
                    const QJsonObject m = meta.object();
                    const QString sec = m.value(QStringLiteral("clientSecret")).toString();
                    QString cid = m.value(QStringLiteral("clientId")).toString();
                    if (cid.isEmpty())
                        cid = st->clientId;
                    if (!sec.isEmpty() && cid == st->clientId) {
                        QJsonObject c = loadCache(st->dataDir);
                        QJsonObject secrets =
                            c.value(QStringLiteral("secrets")).toObject();
                        secrets.insert(st->clientId, sec);
                        c.insert(QStringLiteral("secrets"), secrets);
                        saveCache(st->dataDir, c);
                        st->cb(true, st->clientId, sec, {}, false);
                        return;
                    }
                    st->nextItem();
                });
    };

    st->nextPid();
}

void Client::gameToken(
    const QString& clientId, const QString& secret, const QString& refresh,
    std::function<void(bool, const QString&, const QString&, const QString&, bool)> cb)
{
    QUrlQuery q;
    q.addQueryItem(QStringLiteral("client_id"), clientId);
    q.addQueryItem(QStringLiteral("client_secret"), secret);
    q.addQueryItem(QStringLiteral("grant_type"), QStringLiteral("refresh_token"));
    q.addQueryItem(QStringLiteral("refresh_token"), refresh);
    q.addQueryItem(QStringLiteral("without_new_session"), QStringLiteral("1"));
    const QString full = QStringLiteral("https://auth.gog.com/token?")
        + q.query(QUrl::FullyEncoded);

    getJson(full, {}, 20,
            [cb](bool ok, const QJsonDocument& doc, const QString& err, bool offline,
                 int status) {
                if (!ok) {
                    if (!offline && (status == 400 || status == 401 || status == 403)) {
                        cb(false, {}, {},
                           QStringLiteral("GOG rejected the login session. Log in again "
                                          "in GOG STORE and retry."),
                           false);
                        return;
                    }
                    cb(false, {}, {}, err, offline);
                    return;
                }
                const QJsonObject o = doc.object();
                const QString token = o.value(QStringLiteral("access_token")).toString();
                if (token.isEmpty()) {
                    cb(false, {}, {},
                       QStringLiteral("GOG did not return an access token for this game."),
                       false);
                    return;
                }
                cb(true, token, variantToString(o.value(QStringLiteral("user_id"))), {},
                   false);
            });
}

void Client::cloudLocations(
    const QString& dataDir, const QString& clientId, bool refresh,
    std::function<void(const QJsonObject&, bool, const QString&, bool)> cb)
{
    QJsonObject cache = loadCache(dataDir);
    QJsonObject entry =
        cache.value(QStringLiteral("locations")).toObject().value(clientId).toObject();

    if (!refresh) {
        if (!entry.isEmpty())
            cb(entry, true, {}, false);
        else
            cb({}, false,
               QStringLiteral("Save locations of this game are unknown yet (connect to "
                              "the internet once)."),
               false);
        return;
    }

    const QString url = QString(kRemoteConfigUrl).replace(QStringLiteral("{cid}"), clientId);
    getJson(url, {}, 20,
            [dataDir, clientId, entry, cb](bool ok, const QJsonDocument& doc,
                                           const QString& err, bool offline, int) {
                if (!ok) {
                    if (offline && !entry.isEmpty()) {
                        cb(entry, true, {}, true);
                        return;
                    }
                    cb({}, false, err, offline);
                    return;
                }
                QJsonObject windows;
                {
                    const QJsonObject root = doc.object();
                    const QJsonObject content =
                        root.value(QStringLiteral("content")).toObject();
                    windows = content.value(QStringLiteral("Windows")).toObject();
                }
                const QJsonObject build =
                    windows.value(QStringLiteral("cloudStorage")).toObject();
                QJsonArray locs;
                for (const QJsonValue& lv :
                     build.value(QStringLiteral("locations")).toArray()) {
                    if (!lv.isObject())
                        continue;
                    const QJsonObject l = lv.toObject();
                    const QString location =
                        l.value(QStringLiteral("location")).toString();
                    if (location.isEmpty())
                        continue;
                    QJsonObject o;
                    o.insert(QStringLiteral("name"),
                             l.value(QStringLiteral("name")).toVariant().toString());
                    o.insert(QStringLiteral("location"), location);
                    locs.append(o);
                }
                QJsonObject newEntry;
                newEntry.insert(QStringLiteral("enabled"),
                                build.value(QStringLiteral("enabled")).toBool()
                                    && !locs.isEmpty());
                newEntry.insert(QStringLiteral("locations"), locs);

                QJsonObject c = loadCache(dataDir);
                QJsonObject all = c.value(QStringLiteral("locations")).toObject();
                all.insert(clientId, newEntry);
                c.insert(QStringLiteral("locations"), all);
                saveCache(dataDir, c);

                cb(newEntry, false, {}, false);
            });
}

void Client::cloudList(
    const QString& userId, const QString& clientId, const QString& token,
    std::function<void(bool, const QVector<CloudItem>&, const QString&, bool)> cb)
{
    const QString url = QStringLiteral("https://cloudstorage.gog.com/v1/") + userId
        + QLatin1Char('/') + clientId;
    QMap<QString, QString> headers;
    headers.insert(QStringLiteral("Authorization"), QStringLiteral("Bearer ") + token);
    headers.insert(QStringLiteral("Accept"), QStringLiteral("application/json"));

    getJson(url, headers, 30,
            [cb](bool ok, const QJsonDocument& doc, const QString& err, bool offline, int) {
                if (!ok) {
                    cb(false, {}, err, offline);
                    return;
                }
                QJsonArray arr;
                if (doc.isArray()) {
                    arr = doc.array();
                } else {
                    const QJsonObject o = doc.object();
                    if (o.value(QStringLiteral("items")).isArray())
                        arr = o.value(QStringLiteral("items")).toArray();
                    else if (o.value(QStringLiteral("files")).isArray())
                        arr = o.value(QStringLiteral("files")).toArray();
                }
                QVector<CloudItem> out;
                for (const QJsonValue& fv : arr) {
                    if (!fv.isObject())
                        continue;
                    const QJsonObject f = fv.toObject();
                    const QString name = variantToString(f.value(QStringLiteral("name")));
                    if (name.isEmpty() || name.endsWith(QLatin1Char('/')))
                        continue;
                    CloudItem item;
                    item.name = name;
                    item.hash = f.value(QStringLiteral("hash")).toString().toLower();
                    const QJsonValue size = f.value(QStringLiteral("bytes")).isUndefined()
                        ? f.value(QStringLiteral("size"))
                        : f.value(QStringLiteral("bytes"));
                    item.size = static_cast<qint64>(size.toVariant().toDouble());
                    item.mtime = parseTs(variantToString(
                        f.value(QStringLiteral("last_modified"))));
                    out.append(item);
                }
                cb(true, out, {}, false);
            });
}

void Client::cloudGet(
    const QString& userId, const QString& clientId, const QString& token,
    const QString& name, const QString& expectedHash,
    std::function<void(bool, const QByteArray&, double, const QString&, bool)> cb)
{
    const QString url = QStringLiteral("https://cloudstorage.gog.com/v1/") + userId
        + QLatin1Char('/') + clientId + QLatin1Char('/') + encodeCloudName(name);
    QMap<QString, QString> headers;
    headers.insert(QStringLiteral("Authorization"), QStringLiteral("Bearer ") + token);
    headers.insert(QStringLiteral("Accept-Encoding"), QStringLiteral("gzip"));

    httpGet(url, headers, 60, 256LL * 1024 * 1024,
            [cb, name, expectedHash](const HttpResponse& r) {
                if (!r.ok) {
                    cb(false, {}, 0, r.error, r.offline);
                    return;
                }
                QByteArray data = r.body;
                const bool hasCe = r.headers.value(QStringLiteral("content-encoding"))
                                       .toLower()
                                       .contains(QStringLiteral("gzip"));
                const bool magic = r.body.size() >= 2
                    && static_cast<unsigned char>(r.body.at(0)) == 0x1f
                    && static_cast<unsigned char>(r.body.at(1)) == 0x8b;
                if (hasCe) {
                    QByteArray dec;
                    if (!gunzip(r.body, dec)) {
                        cb(false, {}, 0,
                           QStringLiteral("Could not decompress '%1'.").arg(name),
                           false);
                        return;
                    }
                    data = dec;
                } else if (magic) {
                    QByteArray dec;
                    if (gunzip(r.body, dec)) {
                        const bool rawMatches = !expectedHash.isEmpty()
                            && md5Bytes(r.body) == expectedHash;
                        if (!rawMatches)
                            data = dec;
                    }
                }
                const double mtime = parseTs(
                    r.headers.value(QStringLiteral("x-object-meta-locallastmodified")));
                cb(true, data, mtime, {}, false);
            });
}

void Client::cloudPut(const QString& userId, const QString& clientId, const QString& token,
                      const QString& cloudName, const QByteArray& gzipBytes,
                      const QString& etag, const QString& mtimeIso,
                      std::function<void(bool, const QString&, bool)> cb)
{
    const QString url = QStringLiteral("https://cloudstorage.gog.com/v1/") + userId
        + QLatin1Char('/') + clientId + QLatin1Char('/')
        + encodeCloudName(cloudName);
    QMap<QString, QString> headers;
    headers.insert(QStringLiteral("Authorization"), QStringLiteral("Bearer ") + token);
    headers.insert(QStringLiteral("Content-Encoding"), QStringLiteral("gzip"));
    headers.insert(QStringLiteral("Etag"), etag);
    if (!mtimeIso.isEmpty())
        headers.insert(QStringLiteral("X-Object-Meta-LocalLastModified"), mtimeIso);
    headers.insert(QStringLiteral("X-Object-Meta-User-Agent"), kGalaxyUa);

    httpPut(url, headers, gzipBytes, 60,
            [cloudName, cb](const HttpResponse& r) {
                if (!r.ok) {
                    if (r.offline) {
                        cb(false,
                           QStringLiteral("Could not reach GOG. Check your internet "
                                          "connection."),
                           true);
                        return;
                    }
                    if (r.status == 401 || r.status == 403) {
                        cb(false,
                           QStringLiteral("GOG rejected the login session. Log in again "
                                          "in GOG STORE and retry."),
                           false);
                        return;
                    }
                    cb(false,
                       QStringLiteral("GOG returned HTTP %1 for '%2'.")
                           .arg(r.status)
                           .arg(cloudName),
                       false);
                    return;
                }
                cb(true, {}, false);
            });
}

void Client::buildTargets(const Context& ctx, bool refresh, LogFn log,
                          std::function<void(const QVector<Target>&)> done)
{
    auto targets = std::make_shared<QVector<Target>>();
    auto appendCustom = [targets](const Context& c) {
        int i = 1;
        for (const QString& folder : loadCustomFolders(c.dataDir, c.name)) {
            Target t;
            t.label = QStringLiteral("custom%1").arg(i);
            t.kind = QStringLiteral("custom");
            t.name = t.label;
            t.path = folder;
            targets->append(t);
            ++i;
        }
    };

    const QString clientId = variantToString(ctx.info.value(QStringLiteral("clientId")));
    if (clientId.isEmpty()) {
        appendCustom(ctx);
        done(*targets);
        return;
    }

    const QString driveC = installwatch::driveCFor(ctx.choice);
    const QString installDir =
        ctx.infoPath.isEmpty() ? QString() : QFileInfo(ctx.infoPath).absolutePath();
    const Context c = ctx;

    cloudLocations(ctx.dataDir, clientId, refresh,
                   [targets, done, c, driveC, installDir, log](const QJsonObject& cfg,
                                                               bool, const QString& err,
                                                               bool) {
                       if (!err.isEmpty()) {
                           if (log)
                               log(QStringLiteral("Save locations: ") + err);
                       } else {
                           for (const QJsonValue& lv :
                                cfg.value(QStringLiteral("locations")).toArray()) {
                               const QJsonObject l = lv.toObject();
                               const QString locName = variantToString(
                                   l.value(QStringLiteral("name")));
                               const QString macro =
                                   l.value(QStringLiteral("location")).toString();
                               Target t;
                               t.label = QStringLiteral("gog_")
                                   + safe(locName, QStringLiteral("saves"));
                               t.kind = QStringLiteral("gog");
                               t.name = locName;
                               t.macro = macro;
                               t.path = resolveLocation(macro, driveC, installDir);
                               t.note = t.path.isEmpty()
                                   ? QStringLiteral("unsupported location")
                                   : QString();
                               targets->append(t);
                           }
                       }
                       int i = 1;
                       for (const QString& folder :
                            loadCustomFolders(c.dataDir, c.name)) {
                           Target t;
                           t.label = QStringLiteral("custom%1").arg(i);
                           t.kind = QStringLiteral("custom");
                           t.name = t.label;
                           t.path = folder;
                           targets->append(t);
                           ++i;
                       }
                       done(*targets);
                   });
}

void Client::planCloudDownload(
    const Context& ctx, LogFn log,
    std::function<void(const Plan&, const QString&)> done)
{
    if (ctx.info.isEmpty()
        || variantToString(ctx.info.value(QStringLiteral("clientId"))).isEmpty()) {
        done(Plan(), QStringLiteral("This game is not a GOG Galaxy game, so it has no "
                                    "GOG cloud saves."));
        return;
    }
    const Context c = ctx;

    galaxyRefreshToken(
        c.dataDir,
        [this, c, log, done](bool ok, const QString& refresh, const QString&, const QString& err) {
            if (!ok) {
                done(Plan(), err);
                return;
            }
            if (log)
                log(QStringLiteral("Reading GOG game credentials..."));
            this->clientCredentials(
                c, log,
                [this, c, log, done, refresh](bool ok2, const QString& clientId,
                                              const QString& secret, const QString& e2, bool) {
                    if (!ok2) {
                        done(Plan(), e2);
                        return;
                    }
                    this->gameToken(
                        clientId, secret, refresh,
                        [this, c, log, done, clientId](bool ok3, const QString& token,
                                                       const QString& userId,
                                                       const QString& e3, bool) {
                            if (!ok3) {
                                done(Plan(), e3);
                                return;
                            }
                            if (userId.isEmpty()) {
                                done(Plan(),
                                     QStringLiteral("GOG did not tell which account "
                                                    "this is (user id missing)."));
                                return;
                            }
                            this->cloudLocations(
                                c.dataDir, clientId, true,
                                [this, c, log, done, clientId, token, userId](
                                    const QJsonObject& cfg, bool fromCache,
                                    const QString& e4, bool) {
                                    if (!e4.isEmpty()) {
                                        done(Plan(), e4);
                                        return;
                                    }
                                    if (!cfg.value(QStringLiteral("enabled")).toBool()) {
                                        done(Plan(),
                                             QStringLiteral("GOG has no cloud saves "
                                                            "for this game."));
                                        return;
                                    }
                                    this->buildTargets(
                                        c, true, log,
                                        [this, done, clientId, token, userId, fromCache, log](
                                            const QVector<Target>& targets) {
                                            QHash<QString, QString> bases;
                                            for (const Target& t : targets)
                                                if (t.kind == QLatin1String("gog")
                                                    && t.hasPath())
                                                    bases.insert(t.name, t.path);
                                            if (log)
                                                log(QStringLiteral(
                                                    "Listing cloud saves..."));
                                            this->cloudList(
                                                userId, clientId, token,
                                                [done, targets, bases, fromCache, clientId,
                                                 token, userId](bool ok5,
                                                                const QVector<CloudItem>& files,
                                                                const QString& e5, bool) {
                                                    if (!ok5) {
                                                        done(Plan(), e5);
                                                        return;
                                                    }
                                                    Plan plan;
                                                    plan.clientId = clientId;
                                                    plan.userId = userId;
                                                    plan.token = token;
                                                    plan.targets = targets;
                                                    plan.fromCache = fromCache;
                                                    plan.totalCloud = files.size();
                                                    int skipped = 0;
                                                    for (const CloudItem& f : files) {
                                                        const int slash = f.name.indexOf(
                                                            QLatin1Char('/'));
                                                        const QString loc = slash >= 0
                                                            ? f.name.left(slash)
                                                            : f.name;
                                                        const QString rel = slash >= 0
                                                            ? f.name.mid(slash + 1)
                                                            : QString();
                                                        const QString base = bases.value(loc);
                                                        const QString dest =
                                                            (base.isEmpty() || rel.isEmpty())
                                                            ? QString()
                                                            : safeDest(base, rel);
                                                        if (dest.isEmpty()) {
                                                            ++skipped;
                                                            continue;
                                                        }
                                                        PlanItem item;
                                                        item.file = f;
                                                        item.dest = dest;
                                                        item.status = QStringLiteral("new");
                                                        double localMtime = 0;
                                                        const QFileInfo fi(dest);
                                                        if (fi.isFile()) {
                                                            localMtime =
                                                                static_cast<double>(
                                                                    fi.lastModified()
                                                                        .toMSecsSinceEpoch())
                                                                / 1000.0;
                                                            if (!f.hash.isEmpty()
                                                                && md5(dest) == f.hash)
                                                                item.status = QStringLiteral(
                                                                    "same");
                                                            else
                                                                item.status = QStringLiteral(
                                                                    "overwrite");
                                                        }
                                                        item.newerLocal =
                                                            item.status
                                                                == QLatin1String("overwrite")
                                                            && f.mtime > 0 && localMtime > 0
                                                            && localMtime > f.mtime + 60;
                                                        plan.items.append(item);
                                                    }
                                                    plan.skipped = skipped;
                                                    done(plan, {});
                                                });
                                        });
                                });
                        });
                });
        });
}

void Client::planCloudUpload(
    const Context& ctx, LogFn log,
    std::function<void(const UploadPlan&, const QString&)> done)
{
    if (ctx.info.isEmpty()
        || variantToString(ctx.info.value(QStringLiteral("clientId"))).isEmpty()) {
        done(UploadPlan(), QStringLiteral("This game is not a GOG Galaxy game, so it "
                                          "has no GOG cloud saves."));
        return;
    }
    const Context c = ctx;

    galaxyRefreshToken(
        c.dataDir,
        [this, c, log, done](bool ok, const QString& refresh, const QString&, const QString& err) {
            if (!ok) {
                done(UploadPlan(), err);
                return;
            }
            if (log)
                log(QStringLiteral("Reading GOG game credentials..."));
            this->clientCredentials(
                c, log,
                [this, c, log, done, refresh](bool ok2, const QString& clientId,
                                              const QString& secret, const QString& e2, bool) {
                    if (!ok2) {
                        done(UploadPlan(), e2);
                        return;
                    }
                    this->gameToken(
                        clientId, secret, refresh,
                        [this, c, log, done, clientId](bool ok3, const QString& token,
                                                       const QString& userId,
                                                       const QString& e3, bool) {
                            if (!ok3) {
                                done(UploadPlan(), e3);
                                return;
                            }
                            if (userId.isEmpty()) {
                                done(UploadPlan(),
                                     QStringLiteral("GOG did not tell which account this "
                                                    "is (user id missing)."));
                                return;
                            }
                            this->cloudLocations(
                                c.dataDir, clientId, true,
                                [this, c, log, done, clientId, token, userId](
                                    const QJsonObject& cfg, bool, const QString& e4, bool) {
                                    if (!e4.isEmpty()) {
                                        done(UploadPlan(), e4);
                                        return;
                                    }
                                    if (!cfg.value(QStringLiteral("enabled")).toBool()) {
                                        done(UploadPlan(),
                                             QStringLiteral("GOG has no cloud saves for "
                                                            "this game."));
                                        return;
                                    }
                                    this->buildTargets(
                                        c, false, log,
                                        [this, done, clientId, token, userId, log](
                                            const QVector<Target>& targets) {
                                            QHash<QString, QString> bases;
                                            for (const Target& t : targets)
                                                if (t.kind == QLatin1String("gog")
                                                    && t.hasPath())
                                                    bases.insert(t.name, t.path);
                                            if (log)
                                                log(QStringLiteral("Reading cloud file "
                                                                   "list..."));
                                            this->cloudList(
                                                userId, clientId, token,
                                                [done, bases, clientId, token, userId](
                                                    bool ok5,
                                                    const QVector<CloudItem>& files,
                                                    const QString& e5, bool) {
                                                    if (!ok5) {
                                                        done(UploadPlan(), e5);
                                                        return;
                                                    }
                                                    QHash<QString, CloudItem> cloudByName;
                                                    for (const CloudItem& f : files)
                                                        cloudByName.insert(f.name, f);

                                                    UploadPlan plan;
                                                    plan.clientId = clientId;
                                                    plan.userId = userId;
                                                    plan.token = token;

                                                    QVector<UploadItem> items;
                                                    int same = 0;
                                                    int totalLocal = 0;
                                                    for (auto it = bases.constBegin();
                                                         it != bases.constEnd(); ++it) {
                                                        const QString loc = it.key();
                                                        const QString base = it.value();
                                                        if (!QFileInfo(base).isDir())
                                                            continue;
                                                        const auto local = listFiles(base);
                                                        for (auto lit = local.constBegin();
                                                             lit != local.constEnd(); ++lit) {
                                                            const QString rel = lit.key();
                                                            const double localMtime =
                                                                lit.value().second;
                                                            ++totalLocal;
                                                            UploadItem item;
                                                            item.cloudName = loc
                                                                + QLatin1Char('/') + rel;
                                                            item.localPath =
                                                                QDir(base).filePath(rel);
                                                            item.status =
                                                                QStringLiteral("new");
                                                            CloudItem cloud =
                                                                cloudByName.value(
                                                                    item.cloudName);
                                                            if (!cloud.name.isEmpty()) {
                                                                QFile f(item.localPath);
                                                                if (!f.open(
                                                                        QIODevice::ReadOnly)) {
                                                                    continue;
                                                                }
                                                                const QByteArray raw =
                                                                    f.readAll();
                                                                f.close();
                                                                const QByteArray gz =
                                                                    gzipData(raw);
                                                                // GOG may hash objects by their raw content or by the
                                                                // gzip body (gogdl sends Etag=md5(gzip)); accept either
                                                                // so unchanged files are skipped under both schemes.
                                                                const bool isSame =
                                                                    !cloud.hash.isEmpty()
                                                                    && (md5Bytes(gz) == cloud.hash
                                                                        || md5Bytes(raw)
                                                                            == cloud.hash);
                                                                if (!isSame) {
                                                                    item.status = QStringLiteral(
                                                                        "overwrite");
                                                                    item.newerCloud =
                                                                        cloud.mtime > 0
                                                                        && localMtime > 0
                                                                        && cloud.mtime
                                                                            > localMtime + 60;
                                                                } else {
                                                                    ++same;
                                                                    continue;
                                                                }
                                                            }
                                                            items.append(item);
                                                        }
                                                    }
                                                    plan.items = items;
                                                    plan.totalLocal = totalLocal;
                                                    plan.skipped = same;
                                                    done(plan, {});
                                                });
                                        });
                                });
                        });
            });
        });
}

void Client::executeUpload(const UploadPlan& plan, LogFn log,
                           std::function<void(int, int, const QString&)> done)
{
    struct Up {
        UploadPlan plan;
        LogFn log;
        std::function<void(int, int, const QString&)> done;
        std::function<void()> next;
        int index = 0;
        int uploaded = 0;
        int failed = 0;
    };
    auto st = std::make_shared<Up>();
    st->plan = plan;
    st->log = log;
    st->done = done;

    st->next = [this, st]() {
        if (st->index >= st->plan.items.size()) {
            st->done(st->uploaded, st->failed, {});
            return;
        }
        const UploadItem item = st->plan.items.at(st->index);
        const int shown = st->index + 1;
        const int total = st->plan.items.size();

        QFile f(item.localPath);
        if (!f.open(QIODevice::ReadOnly)) {
            ++st->index;
            ++st->failed;
            if (st->log)
                st->log(QStringLiteral("[%1/%2] FAILED %3: could not read the local file")
                            .arg(shown)
                            .arg(total)
                            .arg(item.cloudName));
            st->next();
            return;
        }
        const QByteArray raw = f.readAll();
        f.close();
        const QByteArray gz = gzipData(raw);
        if (gz.isEmpty()) {
            ++st->index;
            ++st->failed;
            if (st->log)
                st->log(QStringLiteral("[%1/%2] FAILED %3: could not compress the file")
                            .arg(shown)
                            .arg(total)
                            .arg(item.cloudName));
            st->next();
            return;
        }
        const double mtime = static_cast<double>(
            QFileInfo(item.localPath).lastModified().toMSecsSinceEpoch()) / 1000.0;
        this->cloudPut(
            st->plan.userId, st->plan.clientId, st->plan.token, item.cloudName, gz,
            md5Bytes(gz), epochToIso(mtime),
            [st, item, shown, total](bool ok, const QString& err, bool) {
                ++st->index;
                if (!ok) {
                    ++st->failed;
                    if (st->log)
                        st->log(QStringLiteral("[%1/%2] FAILED %3: %4")
                                    .arg(shown)
                                    .arg(total)
                                    .arg(item.cloudName, err));
                    st->next();
                    return;
                }
                ++st->uploaded;
                if (st->log)
                    st->log(QStringLiteral("[%1/%2] %3")
                                .arg(shown)
                                .arg(total)
                                .arg(item.cloudName));
                st->next();
            });
    };

    if (st->plan.items.isEmpty()) {
        st->done(0, 0, {});
        return;
    }
    st->next();
}

void Client::executeDownload(
    const Context& ctx, const Plan& plan, LogFn log, bool skipNewerLocal,
    std::function<void(int, int, int, const QString&)> done)
{
    QVector<PlanItem> todo;
    for (const PlanItem& i : plan.items) {
        if (i.status != QLatin1String("new") && i.status != QLatin1String("overwrite"))
            continue;
        if (skipNewerLocal && i.newerLocal)
            continue;
        todo.append(i);
    }

    struct Dl {
        Plan plan;
        QVector<PlanItem> todo;
        LogFn log;
        std::function<void(int, int, int, const QString&)> done;
        std::function<void()> next;
        int index = 0;
        int downloaded = 0;
        int failed = 0;
        int skipped = 0;
    };
    auto st = std::make_shared<Dl>();
    st->plan = plan;
    st->todo = todo;
    st->log = log;
    st->done = done;
    st->skipped = plan.items.size() - todo.size();

    st->next = [this, st]() {
        if (st->index >= st->todo.size()) {
            st->done(st->downloaded, st->skipped, st->failed, {});
            return;
        }
        const PlanItem item = st->todo.at(st->index);
        const int shown = st->index + 1;
        const int total = st->todo.size();
        this->cloudGet(
            st->plan.userId, st->plan.clientId, st->plan.token, item.file.name,
            item.file.hash,
            [this, st, item, shown, total](bool ok, const QByteArray& data, double mtime,
                                           const QString& err, bool offline) {
                ++st->index;
                if (!ok) {
                    if (offline) {
                        // Python counts an offline failure, logs it, then stops the
                        // loop without surfacing a final error.
                        ++st->failed;
                        if (st->log)
                            st->log(QStringLiteral("[%1/%2] FAILED %3: %4")
                                        .arg(shown)
                                        .arg(total)
                                        .arg(item.file.name, err));
                        st->done(st->downloaded, st->skipped, st->failed, {});
                        return;
                    }
                    ++st->failed;
                    if (st->log)
                        st->log(QStringLiteral("[%1/%2] FAILED %3: %4")
                                    .arg(shown)
                                    .arg(total)
                                    .arg(item.file.name, err));
                    st->next();
                    return;
                }
                QDir().mkpath(QFileInfo(item.dest).absolutePath());
                const QString tmp = item.dest + QStringLiteral(".wlm-tmp");
                QFile::remove(tmp);
                bool wrote = false;
                {
                    QFile out(tmp);
                    if (out.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
                        wrote = out.write(data) == data.size();
                        out.close();
                    }
                }
                if (!wrote || !QFile::rename(tmp, item.dest)) {
                    QFile::remove(tmp);
                    ++st->failed;
                    if (st->log)
                        st->log(QStringLiteral("[%1/%2] FAILED %3: could not write the file")
                                    .arg(shown)
                                    .arg(total)
                                    .arg(item.file.name));
                    st->next();
                    return;
                }
                const double ts = mtime > 0 ? mtime : item.file.mtime;
                setFileTimes(item.dest, ts);
                ++st->downloaded;
                if (st->log)
                    st->log(QStringLiteral("[%1/%2] %3")
                                .arg(shown)
                                .arg(total)
                                .arg(item.file.name));
                st->next();
            });
    };

    const bool anyOverwrite =
        std::any_of(todo.cbegin(), todo.cend(), [](const PlanItem& i) {
            return i.status == QLatin1String("overwrite");
        });
    if (!anyOverwrite) {
        st->next();
        return;
    }
    makeBackup(ctx.dataDir, ctx.name, plan.targets,
               QStringLiteral("before-cloud-download"),
               [st](const QString& path, int count, const QString& err) {
                   if (!err.isEmpty()) {
                       if (st->log)
                           st->log(QStringLiteral("No safety backup needed: ") + err);
                   } else if (st->log) {
                       st->log(QStringLiteral("Safety backup created (%1 file(s)): %2")
                                   .arg(count)
                                   .arg(QFileInfo(path).fileName()));
                   }
                   st->next();
               });
}

void Client::makeBackup(const QString& dataDir, const QString& game,
                        const QVector<Target>& targets, const QString& note,
                        std::function<void(const QString&, int, const QString&)> done)
{
    struct Entry {
        QString label;
        QString kind;
        QString name;
        QString macro;
        QString path;
        int files = 0;
    };
    QVector<Entry> entries;
    int total = 0;
    for (const Target& t : targets) {
        if (t.path.isEmpty() || !QFileInfo(t.path).isDir())
            continue;
        const int n = listFiles(t.path).size();
        if (n == 0)
            continue;
        Entry e;
        e.label = t.label;
        e.kind = t.kind;
        e.name = t.name;
        e.macro = t.macro;
        e.path = t.path;
        e.files = n;
        entries.append(e);
        total += n;
    }
    if (entries.isEmpty()) {
        done(QString(), 0,
             QStringLiteral("There are no save files to back up yet."));
        return;
    }

    const QString dirPath = backupsDir(dataDir, game);
    QDir().mkpath(dirPath);
    const QString stamp =
        QDateTime::currentDateTime().toString(QStringLiteral("yyyyMMdd-HHmmss"));
    const QString finalPath = dirPath + QLatin1Char('/') + stamp + QLatin1Char('_')
        + safe(note, QStringLiteral("manual")) + QStringLiteral(".tar.gz");
    const QString tmpPath = finalPath + QStringLiteral(".tmp");

    QJsonArray entryArray;
    for (const Entry& e : entries) {
        QJsonObject o;
        o.insert(QStringLiteral("label"), e.label);
        o.insert(QStringLiteral("kind"), e.kind);
        o.insert(QStringLiteral("name"), e.name);
        o.insert(QStringLiteral("macro"), e.macro);
        o.insert(QStringLiteral("path"), e.path);
        o.insert(QStringLiteral("files"), e.files);
        entryArray.append(o);
    }
    QJsonObject manifest;
    manifest.insert(QStringLiteral("version"), 1);
    manifest.insert(QStringLiteral("game"), game);
    manifest.insert(QStringLiteral("created"),
                    QDateTime::currentDateTime().toString(Qt::ISODate));
    manifest.insert(QStringLiteral("note"), note);
    manifest.insert(QStringLiteral("entries"), entryArray);

    auto staging = std::make_shared<QTemporaryDir>();
    if (!staging->isValid()) {
        done(QString(), 0,
             QStringLiteral("Could not create a temporary folder for the backup."));
        return;
    }
    {
        QFile mf(staging->path() + QStringLiteral("/manifest.json"));
        if (!mf.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
            done(QString(), 0, QStringLiteral("Could not write the backup manifest."));
            return;
        }
        mf.write(QJsonDocument(manifest).toJson(QJsonDocument::Indented));
        mf.close();
    }

    QStringList args;
    args << QStringLiteral("-czhf") << tmpPath << QStringLiteral("-C")
         << staging->path() << QStringLiteral("manifest.json");
    for (const Entry& e : entries) {
        const QString link = staging->path() + QLatin1Char('/') + e.label;
        QFile::remove(link);
        if (!QFile::link(e.path, link)) {
            done(QString(), 0,
                 QStringLiteral("Could not prepare '%1' for archiving.").arg(e.label));
            return;
        }
        args << e.label;
    }

    auto called = std::make_shared<bool>(false);
    auto report = [done, called](bool ok, const QString& path, int count,
                                 const QString& err) {
        if (*called)
            return;
        *called = true;
        if (ok)
            done(path, count, {});
        else
            done(QString(), 0, err);
    };

    auto* proc = new QProcess(this);
    connect(proc, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished), this,
            [proc, staging, tmpPath, finalPath, total, report](int code,
                                                               QProcess::ExitStatus) {
                const QString errOut =
                    QString::fromLocal8Bit(proc->readAllStandardError()).trimmed();
                proc->deleteLater();
                if (code == 0) {
                    QFile::remove(finalPath);
                    if (!QFile::rename(tmpPath, finalPath)) {
                        report(false, {}, 0,
                               QStringLiteral("Could not move the backup into place."));
                        return;
                    }
                    report(true, finalPath, total, {});
                } else {
                    QFile::remove(tmpPath);
                    report(false, {}, 0,
                           errOut.isEmpty()
                               ? QStringLiteral("Could not create the backup archive.")
                               : QStringLiteral("Could not create the backup archive: ")
                                   + errOut);
                }
            });
    connect(proc, &QProcess::errorOccurred, this,
            [proc, staging, tmpPath, report](QProcess::ProcessError e) {
                if (e != QProcess::FailedToStart)
                    return;
                proc->deleteLater();
                QFile::remove(tmpPath);
                report(false, {}, 0,
                       QStringLiteral("Could not run 'tar' to create the backup."));
            });
    proc->start(QStringLiteral("tar"), args);
}

void Client::restoreBackup(const QString& archive, const QVector<Target>& targets,
                           LogFn log,
                           std::function<void(int, const QString&)> done)
{
    auto staging = std::make_shared<QTemporaryDir>();
    if (!staging->isValid()) {
        done(0, QStringLiteral("Could not create a temporary folder."));
        return;
    }
    auto called = std::make_shared<bool>(false);
    auto* proc = new QProcess(this);
    connect(proc, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished), this,
            [proc, staging, targets, log, done, called](int code, QProcess::ExitStatus) {
                proc->deleteLater();
                if (*called)
                    return;
                *called = true;
                if (code != 0) {
                    done(0, QStringLiteral("Could not read the backup archive."));
                    return;
                }
                QFile mf(staging->path() + QStringLiteral("/manifest.json"));
                if (!mf.open(QIODevice::ReadOnly)) {
                    done(0, QStringLiteral("This backup has no readable manifest."));
                    return;
                }
                const QByteArray raw = mf.readAll();
                mf.close();
                QJsonParseError perr{};
                const QJsonDocument pdoc = QJsonDocument::fromJson(raw, &perr);
                if (perr.error != QJsonParseError::NoError || !pdoc.isObject()) {
                    done(0, QStringLiteral("This backup has no readable manifest."));
                    return;
                }
                const QJsonObject manifest = pdoc.object();

                QHash<QString, QString> byLabel;
                for (const Target& t : targets)
                    byLabel.insert(t.label, t.path);
                QHash<QString, QString> destFor;
                for (const QJsonValue& ev :
                     manifest.value(QStringLiteral("entries")).toArray()) {
                    const QJsonObject e = ev.toObject();
                    const QString label = e.value(QStringLiteral("label")).toString();
                    QString dest = byLabel.value(label);
                    if (dest.isEmpty()
                        && e.value(QStringLiteral("kind")).toString()
                            == QLatin1String("custom")
                        && !e.value(QStringLiteral("path")).toString().isEmpty())
                        dest = e.value(QStringLiteral("path")).toString();
                    if (dest.isEmpty()) {
                        if (log)
                            log(QStringLiteral("Skipped '%1': its folder can't be "
                                               "located now.")
                                    .arg(e.value(QStringLiteral("name"))
                                             .toVariant()
                                             .toString()));
                        continue;
                    }
                    destFor.insert(label, dest);
                }

                int count = 0;
                QDirIterator it(staging->path(),
                                QDir::Files | QDir::NoDotAndDotDot | QDir::System,
                                QDirIterator::Subdirectories);
                while (it.hasNext()) {
                    const QString src = it.next();
                    const QFileInfo sfi(src);
                    if (sfi.isSymLink())
                        continue;
                    const QString rel =
                        QDir(staging->path()).relativeFilePath(src);
                    const int slash = rel.indexOf(QLatin1Char('/'));
                    const QString label =
                        slash >= 0 ? rel.left(slash) : rel;
                    const QString sub =
                        slash >= 0 ? rel.mid(slash + 1) : QString();
                    if (label == QLatin1String("manifest.json") || sub.isEmpty())
                        continue;
                    const QString base = destFor.value(label);
                    if (base.isEmpty())
                        continue;
                    const QString dest = safeDest(base, sub);
                    if (dest.isEmpty())
                        continue;
                    QDir().mkpath(QFileInfo(dest).absolutePath());
                    const QString tmp = dest + QStringLiteral(".wlm-tmp");
                    QFile::remove(tmp);
                    if (!QFile::copy(src, tmp)) {
                        QFile::remove(tmp);
                        continue;
                    }
                    QFile::remove(dest);
                    if (!QFile::rename(tmp, dest)) {
                        QFile::remove(tmp);
                        continue;
                    }
                    setFileTimes(
                        dest,
                        static_cast<double>(sfi.lastModified().toMSecsSinceEpoch())
                            / 1000.0);
                    ++count;
                }
                done(count, {});
            });
    connect(proc, &QProcess::errorOccurred, this,
            [proc, staging, done, called](QProcess::ProcessError e) {
                if (e != QProcess::FailedToStart)
                    return;
                proc->deleteLater();
                if (*called)
                    return;
                *called = true;
                done(0, QStringLiteral("Could not read the backup archive."));
            });
    proc->start(QStringLiteral("tar"),
                {QStringLiteral("-xzf"), archive, QStringLiteral("-C"),
                 staging->path()});
}

} // namespace gogsaves
