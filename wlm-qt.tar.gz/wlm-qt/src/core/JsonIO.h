#pragma once

#include <QJsonObject>
#include <QString>

// Small helpers for reading/writing the JSON config files. Writing is atomic
// (temp file + rename) so a crash mid-write cannot corrupt a config - this
// matches the behaviour of save_dialog_size() in the Python original.
namespace jsonio {

// Returns an empty object if the file is missing or unreadable/invalid.
QJsonObject readObject(const QString& path);

// Writes `obj` as pretty-printed JSON using an atomic replace. Returns false on
// any I/O error.
bool writeObjectAtomic(const QString& path, const QJsonObject& obj);

} // namespace jsonio
