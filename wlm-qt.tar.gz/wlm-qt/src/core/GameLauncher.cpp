#include "core/GameLauncher.h"

#include "core/HudConfig.h"
#include "core/Paths.h"
#include "core/ProcessUtils.h"

#include <QFile>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonObject>
#include <QProcess>
#include <QRegularExpression>
#include <QTextStream>

namespace {

constexpr int kMaxLogBufferLines = 5000;

QString stripAnsi(QString text)
{
    static const QRegularExpression re(QStringLiteral("\\x1B\\[[0-9;?]*[ -/]*[@-~]"));
    text.remove(re);
    return text;
}

QString buildVulkanHudEnvPrefix()
{
    return hudconfig::buildVulkanHudEnvPrefix(hudconfig::load());
}

QString buildGalliumHudEnvPrefix()
{
    return hudconfig::buildGalliumHudEnvPrefix(hudconfig::load());
}

} // namespace

GameLauncher::GameLauncher(QObject* parent)
    : QObject(parent)
{
}

GameLauncher::~GameLauncher() = default;

QString GameLauncher::logFilePath(const QString& name) const
{
    return paths::logs() + QLatin1Char('/') + name + QStringLiteral(".log");
}

bool GameLauncher::launch(const QString& name, const QString& scriptPath,
                          const QString& launchMode, QString* error)
{
    // Build program + arguments for the chosen launch mode.
    QString program = QStringLiteral("bash");
    QStringList args;

    if (launchMode == QLatin1String("GalliumHUD")) {
        args << QStringLiteral("-c")
             << QStringLiteral("%1 \"%2\"").arg(buildGalliumHudEnvPrefix(), scriptPath);
    } else if (launchMode == QLatin1String("VulkanHUD")) {
        args << QStringLiteral("-c")
             << QStringLiteral("%1 \"%2\"").arg(buildVulkanHudEnvPrefix(), scriptPath);
    } else if (launchMode == QLatin1String("MangoHud-GL")) {
        args << QStringLiteral("-c")
             << QStringLiteral("mangohud --dlsym \"%1\"").arg(scriptPath);
    } else if (launchMode == QLatin1String("Mangohud")) {
        args << QStringLiteral("-c")
             << QStringLiteral("mangohud \"%1\"").arg(scriptPath);
    } else {
        args << scriptPath; // Normal
    }

    return launchCommand(name, program, args, procutil::cleanEnvironment(),
                         QFileInfo(scriptPath).absolutePath(), error);
}

bool GameLauncher::launchCommand(const QString& name, const QString& program,
                                 const QStringList& args, const QProcessEnvironment& env,
                                 const QString& workingDir, QString* error)
{
    auto entry = std::make_shared<Entry>();
    entry->logPath = logFilePath(name);
    entry->log = std::make_unique<QFile>(entry->logPath);
    entry->log->open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate);

    entry->proc = std::make_unique<QProcess>();
    entry->proc->setProcessChannelMode(QProcess::MergedChannels);
    entry->proc->setProcessEnvironment(env);
    if (!workingDir.isEmpty())
        entry->proc->setWorkingDirectory(workingDir);

    entry->proc->start(program, args);
    if (!entry->proc->waitForStarted(5000)) {
        if (error)
            *error = QStringLiteral("Could not start '%1': %2").arg(program, entry->proc->errorString());
        if (entry->log && entry->log->isOpen())
            entry->log->close();
        return false;
    }

    m_entries.insert(name, entry);

    QProcess* proc = entry->proc.get();
    connect(proc, &QProcess::readyReadStandardOutput, this, [this, entry, name] {
        onReadyRead(*entry, name);
    });
    connect(proc, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished), this,
            [this, entry, name](int exitCode, QProcess::ExitStatus) {
                onFinished(*entry, name, exitCode);
            });
    connect(proc, &QProcess::errorOccurred, this, [this, entry, name](QProcess::ProcessError e) {
        if (e == QProcess::FailedToStart)
            onFinished(*entry, name, -1);
    });

    // Drain anything already buffered.
    onReadyRead(*entry, name);
    return true;
}

void GameLauncher::onReadyRead(Entry& entry, const QString& name)
{
    if (!entry.proc)
        return;

    QString text = QString::fromUtf8(entry.proc->readAllStandardOutput());
    text = stripAnsi(text);
    text.replace(QLatin1String("\r\n"), QLatin1String("\n"));
    text.replace(QLatin1Char('\r'), QLatin1Char('\n'));
    if (text.isEmpty())
        return;

    if (entry.log && entry.log->isOpen()) {
        QTextStream out(entry.log.get());
        out << text;
        out.flush();
        entry.log->flush();
    }

    for (const QString& line : text.split(QLatin1Char('\n')))
        entry.buffer.append(line);
    while (entry.buffer.size() > kMaxLogBufferLines)
        entry.buffer.removeFirst();

    emit outputAppended(name, text);
}

void GameLauncher::onFinished(Entry& entry, const QString& name, int exitCode)
{
    if (entry.finished)
        return;
    entry.finished = true;
    entry.exitCode = exitCode;

    const QString footer =
        QStringLiteral("\n[launcher] Process exited (code %1).\n").arg(exitCode);
    if (entry.log && entry.log->isOpen()) {
        QTextStream out(entry.log.get());
        out << footer;
        out.flush();
        entry.log->close();
    }
    entry.buffer.append(footer);

    emit outputAppended(name, footer);
    emit processFinished(name, exitCode);
}

bool GameLauncher::isRunning(const QString& name) const
{
    auto it = m_entries.constFind(name);
    if (it == m_entries.constEnd())
        return false;
    const Entry& e = *it.value();
    return e.proc && e.proc->state() == QProcess::Running;
}

bool GameLauncher::hasEntry(const QString& name) const
{
    return m_entries.contains(name);
}

bool GameLauncher::isFinished(const QString& name) const
{
    auto it = m_entries.constFind(name);
    if (it == m_entries.constEnd())
        return true;
    return it.value()->finished;
}

QStringList GameLauncher::buffer(const QString& name) const
{
    auto it = m_entries.constFind(name);
    if (it == m_entries.constEnd())
        return {};
    return it.value()->buffer;
}
