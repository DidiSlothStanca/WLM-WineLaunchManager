#pragma once

#include "core/Theme.h"

#include <QList>
#include <QObject>
#include <QString>

class QApplication;
class QPalette;

// Owns the theme catalogue and applies the active theme to the whole app
// (palette + global stylesheet). Emits themeChanged() so widgets can refresh.
class ThemeManager : public QObject {
    Q_OBJECT
public:
    explicit ThemeManager(QObject* parent = nullptr);

    // All themes, in display order (matches the Python THEMES ordering).
    static const QList<Theme>& themes();

    // Look a theme up by id; falls back to "default" when unknown.
    static const Theme& byId(const QString& id);

    const Theme& current() const { return m_current; }
    QString currentId() const { return m_current.id; }

    // Apply a theme by id and remember it as current.
    void apply(const QString& id);

    // Re-apply the current theme (e.g. after a font change).
    void reapply();

    // Global UI zoom in percent (10..200, 100 = normal). Scales the stylesheet
    // font sizes so the whole interface grows/shrinks live.
    int fontScalePercent() const { return m_fontScalePercent; }
    void setFontScalePercent(int percent);

signals:
    void themeChanged(const QString& id);

private:
    static QPalette buildPalette(const Theme& t);
    static QString buildStyleSheet(const Theme& t, int fontScalePercent);

    Theme m_current;
    int m_fontScalePercent = 100;
};
