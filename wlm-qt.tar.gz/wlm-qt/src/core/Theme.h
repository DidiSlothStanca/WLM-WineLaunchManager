#pragma once

#include <QColor>
#include <QString>

// A theme is a flat set of named colours. Field names and default values are
// ported 1:1 from the THEMES dict in launcher.py.
struct Theme {
    QString id;
    QString name;

    QColor primary;
    QColor secondary;
    QColor accent;
    QColor highlight;
    QColor text;
    QColor textSecondary;
    QColor buttonText;
    QColor success;
    QColor warning;
    QColor danger;
    QColor cardBg;
    QColor border;
    QColor buttonBg;
    QColor buttonFg;
    QColor treeBg;
    QColor treeFg;
    QColor treeHighlight;
    QColor treeHighlightText;
    QColor textBackground;
};

// Blend two colours: t=0 -> c1, t=1 -> c2. Port of mix_color().
QColor mixColor(const QColor& c1, const QColor& c2, double t);

// Pick a dark or light foreground that reads best on `bg`. Port of readable_on().
QColor readableOn(const QColor& bg,
                  const QColor& dark = QColor(QStringLiteral("#0b0d14")),
                  const QColor& light = QColor(QStringLiteral("#ffffff")));
