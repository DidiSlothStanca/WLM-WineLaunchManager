#include "core/ThemeManager.h"

#include <QApplication>
#include <QHash>
#include <QPalette>

namespace {

Theme makeTheme(const QString& id, const QString& name,
                const char* primary, const char* secondary, const char* accent,
                const char* highlight, const char* text, const char* textSecondary,
                const char* buttonText, const char* success, const char* warning,
                const char* danger, const char* cardBg, const char* border,
                const char* buttonBg, const char* buttonFg, const char* treeBg,
                const char* treeFg, const char* treeHighlight, const char* treeHighlightText,
                const char* textBackground)
{
    Theme t;
    t.id = id;
    t.name = name;
    t.primary = QColor(QLatin1String(primary));
    t.secondary = QColor(QLatin1String(secondary));
    t.accent = QColor(QLatin1String(accent));
    t.highlight = QColor(QLatin1String(highlight));
    t.text = QColor(QLatin1String(text));
    t.textSecondary = QColor(QLatin1String(textSecondary));
    t.buttonText = QColor(QLatin1String(buttonText));
    t.success = QColor(QLatin1String(success));
    t.warning = QColor(QLatin1String(warning));
    t.danger = QColor(QLatin1String(danger));
    t.cardBg = QColor(QLatin1String(cardBg));
    t.border = QColor(QLatin1String(border));
    t.buttonBg = QColor(QLatin1String(buttonBg));
    t.buttonFg = QColor(QLatin1String(buttonFg));
    t.treeBg = QColor(QLatin1String(treeBg));
    t.treeFg = QColor(QLatin1String(treeFg));
    t.treeHighlight = QColor(QLatin1String(treeHighlight));
    t.treeHighlightText = QColor(QLatin1String(treeHighlightText));
    t.textBackground = QColor(QLatin1String(textBackground));
    return t;
}

// Token substitution avoids fragile QString::arg(%1..%9) chains when the same
// colour appears many times in the stylesheet.
QString substitute(QString sheet, const QHash<QString, QString>& vars)
{
    for (auto it = vars.constBegin(); it != vars.constEnd(); ++it)
        sheet.replace(it.key(), it.value());
    return sheet;
}

} // namespace

const QList<Theme>& ThemeManager::themes()
{
    static const QList<Theme> list = {
        makeTheme("default", "Default (Dark Blue)",
                  "#11131f", "#181b2b", "#232844", "#5b7cfa", "#eef0fa", "#9aa1c0",
                  "#ffffff", "#34d399", "#fbbf24", "#f87171", "#1f2336", "#2c3150",
                  "#272c47", "#e6e9f8", "#171a2a", "#e6e9f8", "#5b7cfa", "#ffffff",
                  "#141726"),
        makeTheme("dark", "Dark",
                  "#0e0e12", "#16161c", "#26262f", "#a78bfa", "#f1f1f5", "#9b9bab",
                  "#14101f", "#2dd4bf", "#fbbf24", "#f87171", "#1d1d25", "#2c2c38",
                  "#26262f", "#ececf3", "#16161c", "#ececf3", "#a78bfa", "#14101f",
                  "#121217"),
        makeTheme("light", "Light",
                  "#eef0f6", "#ffffff", "#e3e6f0", "#4f6df5", "#1b1f33", "#5f6680",
                  "#ffffff", "#0f9d74", "#d97706", "#d93a3a", "#ffffff", "#d5d9e6",
                  "#e4e7f1", "#1b1f33", "#ffffff", "#1b1f33", "#4f6df5", "#ffffff",
                  "#ffffff"),
        makeTheme("pinky", "Pinky",
                  "#1f1220", "#2a1a2c", "#4a2c4d", "#f472b6", "#fdf2f8", "#d8b4d0",
                  "#2a0f22", "#c084fc", "#fbcfe8", "#fb7185", "#35223a", "#523559",
                  "#41284a", "#fdf2f8", "#2a1a2c", "#fdf2f8", "#f472b6", "#2a0f22",
                  "#241524"),
        makeTheme("zombie", "Zombie Green",
                  "#0f1d12", "#15281a", "#1f3a25", "#7ddc8a", "#ecf8ee", "#9cc3a2",
                  "#0a2410", "#a3e635", "#facc15", "#ff6b4a", "#1b3322", "#2d5036",
                  "#244230", "#ecf8ee", "#15281a", "#ecf8ee", "#7ddc8a", "#0a2410",
                  "#112016"),
        makeTheme("nord", "Nord",
                  "#272c36", "#2e3440", "#3b4252", "#88c0d0", "#eceff4", "#a3acc0",
                  "#1f2530", "#a3be8c", "#ebcb8b", "#bf616a", "#353c4a", "#434c5e",
                  "#3b4252", "#eceff4", "#2e3440", "#eceff4", "#88c0d0", "#1f2530",
                  "#2a303b"),
        makeTheme("midnight", "Midnight (OLED)",
                  "#000000", "#0b0b0f", "#1a1a22", "#22d3ee", "#f5f5f7", "#8d8d99",
                  "#001418", "#4ade80", "#fbbf24", "#f87171", "#111116", "#23232c",
                  "#1a1a22", "#f0f0f4", "#08080c", "#f0f0f4", "#22d3ee", "#001418",
                  "#0b0b0f"),
    };
    return list;
}

const Theme& ThemeManager::byId(const QString& id)
{
    const QList<Theme>& list = themes();
    for (const Theme& t : list) {
        if (t.id == id)
            return t;
    }
    return list.first(); // "default"
}

ThemeManager::ThemeManager(QObject* parent)
    : QObject(parent)
    , m_current(byId(QStringLiteral("default")))
{
}

void ThemeManager::apply(const QString& id)
{
    m_current = byId(id);
    reapply();
    emit themeChanged(m_current.id);
}

void ThemeManager::reapply()
{
    if (!qApp)
        return;
    qApp->setPalette(buildPalette(m_current));
    qApp->setStyleSheet(buildStyleSheet(m_current, m_fontScalePercent));
}

void ThemeManager::setFontScalePercent(int percent)
{
    const int clamped = qBound(10, percent, 200);
    if (clamped == m_fontScalePercent)
        return;
    m_fontScalePercent = clamped;
    reapply();
}

QPalette ThemeManager::buildPalette(const Theme& t)
{
    QPalette p;
    p.setColor(QPalette::Window, t.primary);
    p.setColor(QPalette::WindowText, t.text);
    p.setColor(QPalette::Base, t.textBackground);
    p.setColor(QPalette::AlternateBase, t.secondary);
    p.setColor(QPalette::Text, t.text);
    p.setColor(QPalette::Button, t.buttonBg);
    p.setColor(QPalette::ButtonText, t.buttonFg);
    p.setColor(QPalette::Highlight, t.highlight);
    p.setColor(QPalette::HighlightedText, t.buttonText);
    p.setColor(QPalette::ToolTipBase, t.cardBg);
    p.setColor(QPalette::ToolTipText, t.text);
    p.setColor(QPalette::PlaceholderText, t.textSecondary);
    p.setColor(QPalette::Disabled, QPalette::Text, t.textSecondary);
    p.setColor(QPalette::Disabled, QPalette::ButtonText, mixColor(t.buttonFg, t.primary, 0.55));
    p.setColor(QPalette::Disabled, QPalette::WindowText, t.textSecondary);
    return p;
}

QString ThemeManager::buildStyleSheet(const Theme& t, int fontScalePercent)
{
    const double s = qBound(10, fontScalePercent, 200) / 100.0;
    const auto fontPx = [s](double base) {
        return QString::number(qMax(5, qRound(base * s)));
    };
    const QHash<QString, QString> v = {
        {QStringLiteral("@primary@"), t.primary.name()},
        {QStringLiteral("@secondary@"), t.secondary.name()},
        {QStringLiteral("@accent@"), t.accent.name()},
        {QStringLiteral("@highlight@"), t.highlight.name()},
        {QStringLiteral("@text@"), t.text.name()},
        {QStringLiteral("@muted@"), t.textSecondary.name()},
        {QStringLiteral("@buttonText@"), t.buttonText.name()},
        {QStringLiteral("@success@"), t.success.name()},
        {QStringLiteral("@warning@"), t.warning.name()},
        {QStringLiteral("@danger@"), t.danger.name()},
        {QStringLiteral("@card@"), t.cardBg.name()},
        {QStringLiteral("@border@"), t.border.name()},
        {QStringLiteral("@btn@"), t.buttonBg.name()},
        {QStringLiteral("@btnFg@"), t.buttonFg.name()},
        {QStringLiteral("@tree@"), t.treeBg.name()},
        {QStringLiteral("@treeFg@"), t.treeFg.name()},
        {QStringLiteral("@treeHi@"), t.treeHighlight.name()},
        {QStringLiteral("@treeHiText@"), t.treeHighlightText.name()},
        {QStringLiteral("@field@"), t.textBackground.name()},
        {QStringLiteral("@btnHover@"), mixColor(t.buttonBg, t.highlight, 0.22).name()},
        {QStringLiteral("@btnPressed@"), mixColor(t.buttonBg, t.highlight, 0.40).name()},
        {QStringLiteral("@btnDisabledBg@"), mixColor(t.buttonBg, t.primary, 0.60).name()},
        {QStringLiteral("@btnDisabledFg@"), mixColor(t.buttonFg, t.primary, 0.55).name()},
        // Zoomable font sizes (base 13 / 12 / 20 / 15 / 11 px at 100%).
        {QStringLiteral("@fontBase@"), fontPx(13)},
        {QStringLiteral("@fontSmall@"), fontPx(12)},
        {QStringLiteral("@fontMenu@"), fontPx(20)},
        {QStringLiteral("@fontTitle@"), fontPx(15)},
        {QStringLiteral("@fontSection@"), fontPx(11)},
    };

    static const char* kTemplate = R"QSS(
QWidget {
    background-color: @primary@;
    color: @text@;
    font-size: @fontBase@px;
}
QMainWindow, QDialog { background-color: @primary@; }

QLabel { background: transparent; }
QLabel[muted="true"] { color: @muted@; }

QFrame#Card {
    background-color: @card@;
    border: 1px solid @border@;
    border-radius: 10px;
}
QFrame#Toolbar {
    background-color: @secondary@;
    border-bottom: 1px solid @border@;
}
QFrame#Footer {
    background-color: @secondary@;
    border-top: 1px solid @border@;
}

QPushButton {
    background-color: @btn@;
    color: @btnFg@;
    border: 1px solid @btn@;
    border-radius: 8px;
    padding: 7px 14px;
}
QPushButton:hover  { background-color: @btnHover@; border-color: @btnHover@; color: @btnFg@; }
QPushButton:pressed{ background-color: @btnPressed@; }
QPushButton:disabled { background-color: @btnDisabledBg@; color: @btnDisabledFg@; }

QPushButton#Accent {
    background-color: @highlight@;
    color: @buttonText@;
    border-color: @highlight@;
}
QPushButton#Accent:hover { background-color: @btnHover@; border-color: @highlight@; }

QPushButton#SmallAccent {
    background-color: @highlight@;
    color: @buttonText@;
    border: 1px solid @highlight@;
    border-radius: 6px;
    padding: 4px 8px;
    font-size: @fontSmall@px;
}
QPushButton#SmallAccent:hover { background-color: @btnHover@; border-color: @highlight@; }
QPushButton#SmallAccent:pressed { background-color: @btnPressed@; }

QPushButton#Danger {
    background-color: @danger@;
    color: @buttonText@;
    border-color: @danger@;
}
QPushButton#Danger:hover {
    background-color: @btnHover@;
    border-color: @danger@;
}
QPushButton#Danger:pressed {
    background-color: @btnPressed@;
}

QToolButton#MenuToggle {
    background: transparent;
    border: none;
    border-radius: 10px;
    padding: 6px;
    color: @text@;
    font-size: @fontMenu@px;
    font-weight: bold;
}
QToolButton#MenuToggle:hover {
    background-color: @btnHover@;
}
QToolButton#MenuToggle:pressed {
    background-color: @btnPressed@;
}
QToolButton#MenuToggle:checked {
    background-color: @btnHover@;
}

QWidget#SideScrim { background-color: rgba(0, 0, 0, 0.35); }

QFrame#SidePanel {
    background-color: @secondary@;
    border-right: 1px solid @border@;
}
QScrollArea#SideScroll {
    background: transparent;
    border: none;
}
QScrollArea#SideScroll > QWidget#qt_scrollarea_viewport {
    background: transparent;
}
QWidget#SideScrollContent {
    background: transparent;
}
QLabel#SideTitle {
    color: @text@;
    font-size: @fontTitle@px;
    font-weight: bold;
    padding: 2px 4px 6px 4px;
}
QLabel#SideSection {
    color: @muted@;
    font-size: @fontSection@px;
    font-weight: bold;
    letter-spacing: 1px;
    padding: 10px 4px 2px 4px;
}
QPushButton#SideItem {
    background: transparent;
    color: @text@;
    border: none;
    border-radius: 8px;
    text-align: left;
    padding: 9px 12px;
}
QPushButton#SideItem:hover {
    background-color: @btnHover@;
    color: @text@;
}
QPushButton#SideItem:pressed {
    background-color: @btnPressed@;
    color: @text@;
}

QLineEdit, QComboBox, QSpinBox {
    background-color: @field@;
    color: @text@;
    border: 1px solid @border@;
    border-radius: 8px;
    padding: 6px 10px;
    selection-background-color: @highlight@;
    selection-color: @buttonText@;
}
QLineEdit:focus, QComboBox:focus { border: 1px solid @highlight@; }
QComboBox::drop-down { border: none; width: 22px; }
QComboBox::down-arrow {
    image: none;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-top: 6px solid @text@;
    width: 0;
    height: 0;
    margin-right: 6px;
}
QComboBox::down-arrow:on {
    border-top: none;
    border-bottom: 6px solid @text@;
}
QComboBox QAbstractItemView {
    background-color: @field@;
    color: @text@;
    border: 1px solid @border@;
    selection-background-color: @highlight@;
    selection-color: @buttonText@;
}

QTableWidget {
    background-color: @tree@;
    color: @treeFg@;
    border: 1px solid @border@;
    border-radius: 8px;
    outline: none;
    gridline-color: @border@;
}
QTableWidget::item {
    padding: 6px 8px;
    border: none;
}
QTableWidget::item:selected {
    background-color: @treeHi@;
    color: @treeHiText@;
}
QTableWidget::item:hover {
    background-color: @btnHover@;
}
QTableWidget::item:selected:hover {
    background-color: @treeHi@;
}
QHeaderView::section {
    background-color: @secondary@;
    color: @muted@;
    border: none;
    border-bottom: 1px solid @border@;
    padding: 6px 8px;
}
QProgressBar {
    background-color: @field@;
    color: @text@;
    border: 1px solid @border@;
    border-radius: 4px;
    text-align: center;
}
QProgressBar::chunk {
    background-color: @highlight@;
    border-radius: 3px;
}

QLabel[cover="true"] {
    border: 2px solid transparent;
    border-radius: 8px;
}
QLabel[cover="true"]:hover {
    border: 2px solid @highlight@;
    background-color: @btnHover@;
}
QLabel[cover="true"]:focus {
    border: 2px solid @highlight@;
    outline: none;
}

QCheckBox, QRadioButton {
    spacing: 8px;
    color: @text@;
    background: transparent;
}
QCheckBox::indicator, QRadioButton::indicator {
    width: 18px;
    height: 18px;
    border: 2px solid @border@;
    border-radius: 4px;
    background: @field@;
}
QRadioButton::indicator {
    border-radius: 9px;
}
QCheckBox::indicator:hover, QRadioButton::indicator:hover {
    border-color: @highlight@;
}
QCheckBox::indicator:checked {
    background: @highlight@;
    border-color: @highlight@;
    image: none;
}
QCheckBox::indicator:checked::after {
    content: "";
}
QRadioButton::indicator:checked {
    background: @highlight@;
    border-color: @highlight@;
    border: 5px solid @highlight@;
    background: @field@;
}
QCheckBox::indicator:disabled, QRadioButton::indicator:disabled {
    border-color: @btnDisabledBg@;
    background: @btnDisabledBg@;
}

QListWidget, QTreeWidget, QTableWidget {
    background-color: @tree@;
    color: @treeFg@;
    border: 1px solid @border@;
    border-radius: 8px;
    outline: none;
}
QListWidget::item { padding: 6px 8px; border-radius: 6px; }
QListWidget::item:selected,
QTreeWidget::item:selected,
QTableWidget::item:selected {
    background-color: @treeHi@;
    color: @treeHiText@;
}
QHeaderView::section {
    background-color: @secondary@;
    color: @muted@;
    border: none;
    border-bottom: 1px solid @border@;
    padding: 6px 8px;
}

QScrollBar:vertical { background: transparent; width: 10px; margin: 2px; }
QScrollBar::handle:vertical { background: @border@; border-radius: 5px; min-height: 30px; }
QScrollBar::handle:vertical:hover { background: @highlight@; }
QScrollBar:horizontal { background: transparent; height: 10px; margin: 2px; }
QScrollBar::handle:horizontal { background: @border@; border-radius: 5px; min-width: 30px; }
QScrollBar::handle:horizontal:hover { background: @highlight@; }
QScrollBar::add-line, QScrollBar::sub-line { height: 0; width: 0; }
QScrollBar::add-page, QScrollBar::sub-page { background: transparent; }

QSlider::groove:horizontal {
    height: 6px;
    background: @field@;
    border: 1px solid @border@;
    border-radius: 3px;
}
QSlider::sub-page:horizontal {
    background: @highlight@;
    border-radius: 3px;
}
QSlider::add-page:horizontal {
    background: @field@;
    border-radius: 3px;
}
QSlider::handle:horizontal {
    background: @text@;
    border: 1px solid @highlight@;
    width: 14px;
    margin: -6px 0;
    border-radius: 7px;
}
QSlider::handle:horizontal:hover {
    background: @highlight@;
}

QSplitter::handle { background-color: @border@; }
QSplitter::handle:hover { background-color: @highlight@; }

QStatusBar { background-color: @secondary@; color: @muted@; }

QToolTip {
    background-color: @card@;
    color: @text@;
    border: 1px solid @border@;
    padding: 4px;
}
)QSS";

    return substitute(QString::fromUtf8(kTemplate), v);
}
