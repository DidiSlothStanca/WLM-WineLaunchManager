#include "core/DialogSizes.h"

#include "core/JsonIO.h"
#include "core/Paths.h"

#include <QApplication>
#include <QEvent>
#include <QJsonObject>
#include <QJsonValue>
#include <QRegularExpression>
#include <QScreen>
#include <QTimer>
#include <QWidget>

namespace dialogsizes {

std::optional<QSize> load(const QString& key)
{
    const QJsonObject obj = jsonio::readObject(paths::dialogSizes());
    if (obj.isEmpty())
        return std::nullopt;

    const QJsonValue val = obj.value(key);
    if (!val.isString())
        return std::nullopt;

    static const QRegularExpression re(QStringLiteral("^(\\d{3,5})x(\\d{3,5})$"));
    const QRegularExpressionMatch m = re.match(val.toString());
    if (!m.hasMatch())
        return std::nullopt;
    return QSize(m.captured(1).toInt(), m.captured(2).toInt());
}

void save(const QString& key, const QSize& size)
{
    QJsonObject obj = jsonio::readObject(paths::dialogSizes());
    obj.insert(key, QStringLiteral("%1x%2").arg(size.width()).arg(size.height()));
    jsonio::writeObjectAtomic(paths::dialogSizes(), obj);
}

} // namespace dialogsizes

DialogSizeKeeper::DialogSizeKeeper(QWidget* dialog, QString key, QSize defaultSize,
                                   QSize minSize, QWidget* parent)
    : QObject(dialog)
    , m_dialog(dialog)
    , m_key(std::move(key))
    , m_timer(new QTimer(this))
{
    Q_UNUSED(parent);

    const QScreen* screen = dialog->screen() ? dialog->screen() : QApplication::primaryScreen();
    const QRect avail = screen ? screen->availableGeometry() : QRect(0, 0, 1920, 1080);
    const int maxW = qMax(320, avail.width() - 20);
    const int maxH = qMax(240, avail.height() - 90);

    const int minW = qMin(minSize.width(), maxW);
    const int minH = qMin(minSize.height(), maxH);

    const QSize want = dialogsizes::load(m_key).value_or(defaultSize);
    const int w = qMax(minW, qMin(want.width(), maxW));
    const int h = qMax(minH, qMin(want.height(), maxH));
    m_size = QSize(w, h);

    dialog->setMinimumSize(minW, minH);
    dialog->resize(m_size);

    centerOnParent();
    // The window manager sometimes shifts the dialog when it first appears;
    // re-centre a couple of times shortly after.
    for (int delay : {30, 150, 400})
        QTimer::singleShot(delay, this, &DialogSizeKeeper::centerOnParent);

    // Only start recording resizes once the initial layout has settled.
    QTimer::singleShot(800, this, [this] { m_ready = true; });

    m_timer->setSingleShot(true);
    m_timer->setInterval(500);
    connect(m_timer, &QTimer::timeout, this, &DialogSizeKeeper::persist);

    dialog->installEventFilter(this);
}

void DialogSizeKeeper::centerOnParent()
{
    if (!m_dialog)
        return;

    const QWidget* parent = m_dialog->parentWidget();
    const QScreen* screen = m_dialog->screen() ? m_dialog->screen() : QApplication::primaryScreen();
    const QRect avail = screen ? screen->availableGeometry() : QRect(0, 0, 1920, 1080);

    const int cw = m_dialog->width() > 1 ? m_dialog->width() : m_size.width();
    const int ch = m_dialog->height() > 1 ? m_dialog->height() : m_size.height();

    int cx, cy;
    if (parent && parent->isVisible()) {
        const QRect pg = parent->frameGeometry();
        cx = pg.x() + pg.width() / 2;
        cy = pg.y() + pg.height() / 2;
    } else {
        cx = avail.x() + avail.width() / 2;
        cy = avail.y() + avail.height() / 2;
    }

    const int x = qBound(avail.left(), cx - cw / 2, avail.right() - cw - 10);
    const int y = qBound(avail.top() + 10, cy - ch / 2, avail.bottom() - ch - 70);
    m_dialog->move(x, y);
}

void DialogSizeKeeper::persist()
{
    dialogsizes::save(m_key, m_size);
}

bool DialogSizeKeeper::eventFilter(QObject* obj, QEvent* ev)
{
    if (obj != m_dialog)
        return QObject::eventFilter(obj, ev);

    switch (ev->type()) {
    case QEvent::Resize: {
        if (!m_ready)
            break;
        const QSize s = m_dialog->size();
        if (s == m_size || s.width() < 100 || s.height() < 100)
            break;
        m_size = s;
        m_timer->start();
        break;
    }
    case QEvent::Close:
        // Persist a pending resize if the dialog is closed before the debounce.
        if (m_timer->isActive()) {
            m_timer->stop();
            persist();
        }
        break;
    default:
        break;
    }
    return QObject::eventFilter(obj, ev);
}
