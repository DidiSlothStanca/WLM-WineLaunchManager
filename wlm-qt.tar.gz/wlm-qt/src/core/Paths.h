#pragma once

#include <QString>

// Central place for every file/folder the app uses. Mirrors the paths defined at
// the top of the Python launcher.py so both apps share the same ~/wlm data
// directory (config, icons, prefixes, proton builds, ...).
namespace paths {

// ---- Directories -----------------------------------------------------------
QString root();                 // ~/wlm
QString icons();                // ~/wlm/icons
QString bashlaunch();           // ~/wlm/bashlaunch (one .sh per game shortcut)
QString covers();               // ~/wlm/covers
QString logs();                 // ~/wlm/logs
QString protonGE();             // ~/wlm/protonge
QString protonGEPrefixes();     // ~/wlm/protonprefixes
QString protonCachyOS();        // ~/wlm/protoncachyos
QString protonCachyOSPrefixes();// ~/wlm/protoncachyosprefixes
QString winePrefixes();         // ~/wlm/wineprefixes
QString gogCovers();            // ~/wlm/gog_covers
QString gogDownloads();         // ~/wlm/gog_downloads
QString gogGames();             // ~/wlm/gog_games

// ---- Config files ----------------------------------------------------------
QString themeConfig();          // ~/wlm/theme_config.json
QString windowConfig();         // ~/wlm/window_config.json
QString dialogSizes();          // ~/wlm/dialog_sizes.json
QString runnerConfig();         // ~/wlm/runner_config.json
QString prefixLocationConfig(); // ~/wlm/prefix_location_config.json
QString prefixRegistry();       // ~/wlm/prefix_registry.json
QString libraryViewConfig();    // ~/wlm/library_view.json
QString envConfig();            // ~/wlm/env_config.yaml
QString gogConfig();            // ~/wlm/gog_config.json
QString gogAuth();              // ~/wlm/gog_auth.json
QString gogUi();                // ~/wlm/gog_ui.json
QString gogCloudCache();        // ~/wlm/gog_cloud_cache.json
QString saveFolders();          // ~/wlm/save_folders.json
QString saveBackups();          // ~/wlm/save_backups (created lazily)
QString downloadHistory();      // ~/wlm/download_history.json
QString gogDownloadJobs();      // ~/wlm/gog_downloads.json

// Create every directory above if missing (called once at startup).
void ensureDirectories();

} // namespace paths
