#pragma once

#include <QJsonObject>
#include <QString>

// Prefix bookkeeping shared by the runner dialog and (later) the Prefix
// Configuration Manager. Ports the prefix-related helpers from launcher.py.
namespace prefixreg {

// Default base directory for new prefixes of a given runner key
// ("wine" / "protonge" / "protoncachyos").
QString defaultRoot(const QString& runnerKey);

// Next sequential prefix code (GAME001, GAME002, ...) for a runner.
QString generateNextPrefixCode(const QString& runnerKey);

// Base directory where NEW prefixes of this runner are created (custom location
// if still valid, otherwise the WLM default).
QString getPrefixBaseDir(const QString& runnerKey);
void setPrefixBaseDir(const QString& runnerKey, const QString& path);
void resetPrefixBaseDir(const QString& runnerKey);

// Global registry of every prefix ever created/used, keyed "runner:CODE".
QJsonObject loadRegistry();
void saveRegistry(const QJsonObject& reg);

void recordPrefixUsage(const QString& runnerKey, const QString& prefixCode,
                       const QString& prefixPath, const QString& protonName = {},
                       const QString& protonPath = {});
void updateRegistryPrefixPath(const QString& runnerKey, const QString& prefixCode,
                              const QString& newPath);

} // namespace prefixreg
