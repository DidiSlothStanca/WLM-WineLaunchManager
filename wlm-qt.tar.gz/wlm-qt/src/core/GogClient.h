#pragma once

#include "core/GogAuth.h"
#include "core/GogConfig.h"

#include <QJsonDocument>
#include <QObject>
#include <QString>
#include <QUrlQuery>
#include <QVector>

#include <functional>

class QNetworkAccessManager;

namespace gog {

struct Game {
    QString id;
    QString title;
    QString platforms;
    QString image;
};

struct InstallerFile {
    QString downlink;
    qint64 size = 0;
};

struct Installer {
    QString id;
    QString os;
    QString language;
    QString languageName;
    QString version;
    qint64 totalSize = 0;
    QVector<InstallerFile> files;
};

// Async GOG API client (event-driven, like the rest of the port). Wraps the
// urllib calls from gog_store.py: token exchange/refresh, the owned-library
// listing, installer metadata and downlink resolution.
class GogClient : public QObject {
    Q_OBJECT
public:
    using JsonCb = std::function<void(const QJsonDocument&, const QString&, bool authError)>;

    explicit GogClient(QObject* parent = nullptr);

    // Exchange the login `code` for tokens, then fetch the username. Mirrors
    // login_with_code(). `cb(ok, error)`.
    void exchangeCode(const Config& cfg, const QString& code,
                      std::function<void(bool ok, const QString& err)> cb);

    // Ensure a usable access token, refreshing it when nearly expired.
    // cb(token, error, authError).
    void ensureToken(const Config& cfg,
                     std::function<void(const QString& token, const QString& err,
                                        bool authError)> cb);

    // Owned-library listing (paged, sorted by title).
    void fetchLibrary(const Config& cfg,
                      std::function<void(const QVector<Game>&, const QString& err,
                                         bool authError)> cb);

    // Installer metadata for a product, filtered by config os/language.
    void fetchInstallers(const Config& cfg, const QString& productId,
                         std::function<void(const QVector<Installer>&, const QString& err,
                                            bool authError)> cb);

    // Turn a file entry's `downlink` into a temporary CDN URL.
    void resolveDownlink(const Config& cfg, const QString& downlink,
                         std::function<void(const QString& url, const QString& err,
                                            bool authError)> cb);

    // Low-level JSON GET (used by GogDownloader too).
    void getJson(const Config& cfg, const QString& url, const QString& token,
                 const JsonCb& cb);

private:
    void tokenRequest(const Config& cfg, const QUrlQuery& params, const Auth& keep,
                      std::function<void(bool ok, const Auth& auth, const QString& err,
                                         bool authError)> cb);

    QNetworkAccessManager* m_nam;
};

} // namespace gog
