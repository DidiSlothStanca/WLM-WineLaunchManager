#pragma once

#include <QProcessEnvironment>

// Helpers for spawning external programs (wine, proton, xdg-open, ...).
namespace procutil {

// Returns a copy of the current environment that is safe to hand to child
// processes. When WLM itself runs from inside an AppImage, the runtime sets
// LD_LIBRARY_PATH to its own bundled libs; children inherit it and then fail
// to find system libraries. Drop it in that case. Port of get_clean_subprocess_env().
QProcessEnvironment cleanEnvironment();

} // namespace procutil
