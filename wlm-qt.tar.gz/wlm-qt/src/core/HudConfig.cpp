#include "core/HudConfig.h"
#include "core/JsonIO.h"
#include "core/Paths.h"

#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QRegularExpression>
#include <QStringList>

namespace hudconfig {
namespace {

static const QStringList kDefaultVkMetrics = {
    QStringLiteral("fps")
};

static const QStringList kDefaultGlMetrics = {
    QStringLiteral("fps"),
    QStringLiteral("cpu"),
    QStringLiteral("GPU-load")
};

QStringList toStringList(const QJsonArray& arr)
{
    QStringList out;
    for (const QJsonValue& v : arr) {
        if (v.isString()) {
            const QString s = v.toString().trimmed();
            if (!s.isEmpty())
                out << s;
        }
    }
    return out;
}

QJsonArray toJsonArray(const QStringList& lst)
{
    QJsonArray arr;
    for (const QString& s : lst)
        arr.append(s);
    return arr;
}

QStringList normalizeVk(const QStringList& m)
{
    if (m.isEmpty())
        return kDefaultVkMetrics;
    // Python tidak filter ketat, cukup trim kosong; kita buang kosong
    QStringList out;
    for (const QString& s : m) {
        const QString t = s.trimmed();
        if (!t.isEmpty())
            out << t;
    }
    return out.isEmpty() ? kDefaultVkMetrics : out;
}

QStringList normalizeGl(const QStringList& m)
{
    if (m.isEmpty())
        return kDefaultGlMetrics;
    QStringList out;
    for (const QString& s : m) {
        const QString t = s.trimmed();
        if (!t.isEmpty())
            out << t;
    }
    return out.isEmpty() ? kDefaultGlMetrics : out;
}

QString normalizeScale(const QString& s, const QString& def = QStringLiteral("1"))
{
    QString t = s.trimmed();
    return t.isEmpty() ? def : t;
}

} // namespace

HudConfig load()
{
    HudConfig cfg;
    const QJsonObject root = jsonio::readObject(paths::root() + QStringLiteral("/hud_config.json"));
    if (root.contains(QStringLiteral("vulkan_hud")) && root.value(QStringLiteral("vulkan_hud")).isObject()) {
        const QJsonObject vk = root.value(QStringLiteral("vulkan_hud")).toObject();
        cfg.vulkanHud.metrics = normalizeVk(toStringList(vk.value(QStringLiteral("metrics")).toArray()));
        cfg.vulkanHud.scale = normalizeScale(vk.value(QStringLiteral("scale")).toString(), QStringLiteral("1"));
    } else {
        cfg.vulkanHud.metrics = kDefaultVkMetrics;
        cfg.vulkanHud.scale = QStringLiteral("1");
    }
    if (root.contains(QStringLiteral("gallium_hud")) && root.value(QStringLiteral("gallium_hud")).isObject()) {
        const QJsonObject gl = root.value(QStringLiteral("gallium_hud")).toObject();
        cfg.galliumHud.metrics = normalizeGl(toStringList(gl.value(QStringLiteral("metrics")).toArray()));
        cfg.galliumHud.scale = normalizeScale(gl.value(QStringLiteral("scale")).toString(), QStringLiteral("1"));
    } else {
        cfg.galliumHud.metrics = kDefaultGlMetrics;
        cfg.galliumHud.scale = QStringLiteral("1");
    }
    return cfg;
}

void save(const HudConfig& cfg)
{
    const QString path = paths::root() + QStringLiteral("/hud_config.json");
    QJsonObject root = jsonio::readObject(path);
    QJsonObject vk;
    vk.insert(QStringLiteral("metrics"), toJsonArray(cfg.vulkanHud.metrics));
    vk.insert(QStringLiteral("scale"), cfg.vulkanHud.scale);
    root.insert(QStringLiteral("vulkan_hud"), vk);
    QJsonObject gl;
    gl.insert(QStringLiteral("metrics"), toJsonArray(cfg.galliumHud.metrics));
    gl.insert(QStringLiteral("scale"), cfg.galliumHud.scale);
    root.insert(QStringLiteral("gallium_hud"), gl);
    jsonio::writeObjectAtomic(path, root);
}

std::optional<QPoint> loadWindowPosition()
{
    const QJsonObject root = jsonio::readObject(paths::root() + QStringLiteral("/hud_config.json"));
    const QString pos = root.value(QStringLiteral("window_position")).toString().trimmed();
    // Skema Python: string geometri X11 "+x+y" (x/y bisa negatif).
    static const QRegularExpression re(QStringLiteral("^([+-]?\\d+)([+-]\\d+)$"));
    const QRegularExpressionMatch m = re.match(pos);
    if (!m.hasMatch())
        return std::nullopt;
    return QPoint(m.captured(1).toInt(), m.captured(2).toInt());
}

void saveWindowPosition(const QPoint& pos)
{
    const QString path = paths::root() + QStringLiteral("/hud_config.json");
    QJsonObject root = jsonio::readObject(path);
    QString value = QString::number(pos.x());
    if (pos.x() >= 0)
        value.prepend(QLatin1Char('+'));
    value += QLatin1Char(pos.y() >= 0 ? '+' : '-');
    value += QString::number(qAbs(pos.y()));
    root.insert(QStringLiteral("window_position"), value);
    jsonio::writeObjectAtomic(path, root);
}

QString buildVulkanHudEnvPrefix(const HudConfig& cfg)
{
    // "DXVK_HUD=..." - metrik dipisah koma; 'scale=' hanya ditambahkan kalau bukan 1.
    QStringList parts;
    for (const QString& m : cfg.vulkanHud.metrics) {
        const QString t = m.trimmed();
        if (!t.isEmpty())
            parts << t;
    }
    if (parts.isEmpty())
        parts = kDefaultVkMetrics;

    QString scale = cfg.vulkanHud.scale.trimmed();
    if (scale.isEmpty())
        scale = QStringLiteral("1");
    if (scale != QLatin1String("1"))
        parts << QStringLiteral("scale=%1").arg(scale);

    return QStringLiteral("DXVK_HUD=") + parts.join(QLatin1Char(','));
}

QString buildGalliumHudEnvPrefix(const HudConfig& cfg)
{
    // "GALLIUM_HUD=..." - metrik dipisah '+'; scale lewat variabel terpisah
    // GALLIUM_HUD_SCALE (sama seperti Python).
    QStringList parts;
    for (const QString& m : cfg.galliumHud.metrics) {
        const QString t = m.trimmed();
        if (!t.isEmpty())
            parts << t;
    }
    if (parts.isEmpty())
        parts = kDefaultGlMetrics;

    QString scale = cfg.galliumHud.scale.trimmed();
    if (scale.isEmpty())
        scale = QStringLiteral("1");

    QString env = QStringLiteral("GALLIUM_HUD=") + parts.join(QLatin1Char('+'));
    if (scale != QLatin1String("1"))
        env += QStringLiteral(" GALLIUM_HUD_SCALE=") + scale;
    return env;
}

} // namespace hudconfig
