#include "core/CoverFetcher.h"

#include "core/CoverStore.h"
#include "core/Paths.h"

#include <QFile>
#include <QImage>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QRegularExpression>
#include <QUrl>
#include <QUrlQuery>

namespace {

constexpr int kMaxJsonBytes = 2 * 1024 * 1024;
constexpr int kMaxImageBytes = 8 * 1024 * 1024;
constexpr int kSearchTimeoutMs = 10000;
constexpr int kImageTimeoutMs = 15000;

const char* kUserAgent = "Mozilla/5.0 (X11; Linux x86_64) WineLaunchManager";

QUrl catalogUrl(const QString& title)
{
    QUrl url(QStringLiteral("https://catalog.gog.com/v1/catalog"));
    QUrlQuery q;
    q.addQueryItem(QStringLiteral("limit"), QStringLiteral("10"));
    q.addQueryItem(QStringLiteral("order"), QStringLiteral("desc:score"));
    q.addQueryItem(QStringLiteral("productType"), QStringLiteral("in:game,pack"));
    q.addQueryItem(QStringLiteral("query"), QStringLiteral("like:") + title);
    q.addQueryItem(QStringLiteral("page"), QStringLiteral("1"));
    q.addQueryItem(QStringLiteral("countryCode"), QStringLiteral("US"));
    q.addQueryItem(QStringLiteral("locale"), QStringLiteral("en-US"));
    q.addQueryItem(QStringLiteral("currencyCode"), QStringLiteral("USD"));
    url.setQuery(q);
    return url;
}

QUrl embedUrl(const QString& title)
{
    QUrl url(QStringLiteral("https://embed.gog.com/games/ajax/filtered"));
    QUrlQuery q;
    q.addQueryItem(QStringLiteral("mediaType"), QStringLiteral("game"));
    q.addQueryItem(QStringLiteral("search"), title);
    url.setQuery(q);
    return url;
}

QString embedImageUrl(QString image)
{
    image = image.trimmed();
    if (image.isEmpty())
        return {};
    if (image.startsWith(QStringLiteral("//")))
        image = QStringLiteral("https:") + image;
    else if (!image.startsWith(QStringLiteral("http")))
        image = QStringLiteral("https://images.gog.com/") + image.mid(image.startsWith('/') ? 1 : 0);
    image.remove(QRegularExpression(QStringLiteral("\\.(?:jpe?g|png|webp)$")));
    return image + QStringLiteral("_product_tile_398.jpg");
}

} // namespace

CoverFetcher::CoverFetcher(covers::CoverStore* store, QObject* parent)
    : QObject(parent)
    , m_store(store)
    , m_net(new QNetworkAccessManager(this))
{
}

void CoverFetcher::ensure(const QString& name, bool force, const QString& gogId)
{
    if (name.isEmpty())
        return;
    if (m_queued.contains(name))
        return;
    m_queued.insert(name);
    m_queue.enqueue({name, force, gogId});
    if (!m_busy)
        startNext();
}

void CoverFetcher::startNext()
{
    if (m_queue.isEmpty()) {
        m_busy = false;
        return;
    }
    m_busy = true;
    m_job = m_queue.dequeue();

    const QString name = m_job.name;
    const QString gogId = m_job.gogId;

    if (m_job.force) {
        m_store->clearMiss(name);
        m_store->clearOffline();
    } else if (m_store->has(name)) {
        finishJob(name, true);
        return;
    }

    // Reuse the cover the GOG Store already fetched for this game. This works
    // offline and avoids a title search that misses sanitized script names.
    if (!gogId.isEmpty() && useCachedGogCover(gogId, name))
        return;

    if (!m_job.force) {
        if (m_store->recentMiss(name)) {
            finishJob(name, false);
            return;
        }
        if (m_store->offline()) {
            finishJob(name, false);
            return;
        }
    }

    beginSearch();
}

void CoverFetcher::beginSearch()
{
    const QString name = m_job.name;
    m_queries.clear();
    m_queries << name;
    const QString simple = covers::normalizeTitle(name);
    if (!simple.isEmpty() && simple != name.toLower())
        m_queries << simple;
    m_queryIndex = 0;
    m_bestUrl.clear();
    m_bestTitle.clear();
    m_bestScore = 0.0;

    trySource(0);
}

void CoverFetcher::finishJob(const QString& name, bool hasCover)
{
    m_queued.remove(name);
    emit coverReady(name, hasCover);
    // Continue with the next queued job (deferred so callers can react first).
    QMetaObject::invokeMethod(this, &CoverFetcher::startNext, Qt::QueuedConnection);
}

void CoverFetcher::trySource(int sourceIndex)
{
    if (sourceIndex > 1) {
        nextQuery();
        return;
    }
    const QString query = m_queries.at(m_queryIndex);
    const QString name = m_job.name;
    querySource(sourceIndex, query, [this, sourceIndex](const QList<QPair<QString, QString>>& results,
                                                        bool offline, bool error) {
        if (offline) {
            m_store->markOffline();
            if (m_job.force)
                emit statusMessage(
                    tr("No internet connection - cover not downloaded."), true);
            finishJob(m_job.name, m_store->has(m_job.name));
            return;
        }
        if (error) {
            trySource(sourceIndex + 1);
            return;
        }
        if (results.isEmpty()) {
            trySource(sourceIndex + 1);
            return;
        }
        evaluate(results);
        if (m_bestScore >= covers::kMatchThreshold) {
            downloadImage(m_bestUrl);
            return;
        }
        nextQuery();
    });
}

void CoverFetcher::nextQuery()
{
    ++m_queryIndex;
    if (m_queryIndex < m_queries.size())
        trySource(0);
    else
        finalizeMiss();
}

void CoverFetcher::evaluate(const QList<QPair<QString, QString>>& results)
{
    for (const auto& r : results) {
        const double score = covers::titleSimilarity(m_job.name, r.first);
        if (!r.second.isEmpty() && score > m_bestScore) {
            m_bestScore = score;
            m_bestUrl = r.second;
            m_bestTitle = r.first;
        }
    }
}

void CoverFetcher::finalizeMiss()
{
    m_store->recordMiss(m_job.name, m_bestScore);
    finishJob(m_job.name, false);
}

void CoverFetcher::downloadImage(const QString& url)
{
    const QString name = m_job.name;
    const QString matched = m_bestTitle;
    const double score = m_bestScore;
    get(QUrl(url), kMaxImageBytes, kImageTimeoutMs,
        [this, name, matched, score](const QByteArray& data, bool offline, bool error) {
            if (offline) {
                m_store->markOffline();
                finishJob(name, m_store->has(name));
                return;
            }
            if (error) {
                finishJob(name, m_store->has(name));
                return;
            }
            const QImage img = QImage::fromData(data);
            if (img.isNull()) {
                finishJob(name, m_store->has(name));
                return;
            }
            QString err;
            if (m_store->saveImage(name, img, &err)) {
                m_store->recordHit(name, matched, score);
                finishJob(name, true);
            } else {
                finishJob(name, m_store->has(name));
            }
        });
}

// Copy the cover the GOG Store already downloaded (~/wlm/gog_covers/<gogId>.jpg)
// into this game's cover slot. Returns true when a cover was found and stored
// (the job is finished); false when there is nothing cached to reuse.
bool CoverFetcher::useCachedGogCover(const QString& gogId, const QString& name)
{
    const QStringList exts = { QStringLiteral(".jpg"), QStringLiteral(".png") };
    for (const QString& ext : exts) {
        const QString path = paths::gogCovers() + QLatin1Char('/') + gogId + ext;
        if (!QFile::exists(path))
            continue;
        const QImage img(path);
        if (img.isNull())
            continue;
        QString err;
        if (m_store->saveImage(name, img, &err)) {
            m_store->recordHit(name, name, 1.0);
            finishJob(name, true);
            return true;
        }
    }
    return false;
}

void CoverFetcher::querySource(
    int sourceIndex, const QString& query,
    std::function<void(const QList<QPair<QString, QString>>&, bool, bool)> cb)
{
    const bool catalog = (sourceIndex == 0);
    const QUrl url = catalog ? catalogUrl(query) : embedUrl(query);
    get(url, kMaxJsonBytes, kSearchTimeoutMs,
        [this, cb, catalog](const QByteArray& data, bool offline, bool error) {
            if (offline || error) {
                cb({}, offline, error);
                return;
            }
            QJsonParseError perr{};
            const QJsonDocument doc = QJsonDocument::fromJson(data, &perr);
            if (perr.error != QJsonParseError::NoError || !doc.isObject()) {
                cb({}, false, true);
                return;
            }
            const QJsonArray products = doc.object().value(QStringLiteral("products")).toArray();
            QList<QPair<QString, QString>> out;
            for (const QJsonValue& v : products) {
                const QJsonObject p = v.toObject();
                const QString title = p.value(QStringLiteral("title")).toString();
                if (title.isEmpty())
                    continue;
                if (catalog) {
                    const QString h = p.value(QStringLiteral("coverHorizontal")).toString();
                    const QString vert = p.value(QStringLiteral("coverVertical")).toString();
                    const QString u = !h.isEmpty() ? h : vert;
                    if (!u.isEmpty())
                        out.append({title, u});
                } else {
                    const QString u = embedImageUrl(p.value(QStringLiteral("image")).toString());
                    if (!u.isEmpty())
                        out.append({title, u});
                }
            }
            cb(out, false, false);
        });
}

void CoverFetcher::get(const QUrl& url, int limitBytes, int timeoutMs,
                       std::function<void(const QByteArray&, bool, bool)> cb)
{
    QNetworkRequest req{url};
    req.setHeader(QNetworkRequest::UserAgentHeader, QString::fromLatin1(kUserAgent));
    req.setRawHeader("Accept", "application/json, image/*;q=0.9, */*;q=0.5");
    req.setTransferTimeout(timeoutMs);

    QNetworkReply* reply = m_net->get(req);
    connect(reply, &QNetworkReply::finished, this, [reply, limitBytes, cb] {
        reply->deleteLater();
        const QNetworkReply::NetworkError netErr = reply->error();
        const int httpStatus =
            reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        if (netErr != QNetworkReply::NoError) {
            // HTTP 4xx/5xx is a server answer (FetchError); the rest is offline.
            const bool serverAnswer = httpStatus >= 400;
            cb({}, !serverAnswer, serverAnswer);
            return;
        }
        const QByteArray data = reply->readAll();
        if (data.size() > limitBytes) {
            cb({}, false, true);
            return;
        }
        cb(data, false, false);
    });
}
