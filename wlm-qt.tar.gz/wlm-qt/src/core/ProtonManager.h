#pragma once

#include <QList>
#include <QObject>
#include <QPair>
#include <QSet>
#include <QString>

class QNetworkAccessManager;

// One downloadable Proton build asset.
struct ProtonRelease {
    QString tag;
    QString name;        // release title (GE) / release_name (CachyOS)
    QString publishedAt; // yyyy-MM-dd
    QString assetName;
    QString downloadUrl;
    qint64 size = 0;
    // Convenience fields for Proton-CachyOS:
    QString variant;   // Native / SLR / Standalone
    QString archLabel; // human architecture label
    QString archKey;   // v1..v4 / znverN / arm64 / empty
};

// CPU microarchitecture profile (ported from detect_cpu_profile()).
struct CpuProfile {
    QString machine;
    QString vendor;
    QString text;
    QSet<QString> flags;
    int level = 0; // 0 unknown, 1..4 x86-64 level
};

namespace protonutil {

CpuProfile detectCpuProfile();

// (label, key); key is empty when unknown (mirrors proton_asset_arch()).
QPair<QString, QString> assetArch(const QString& assetName);

// 1 = compatible, 0 = incompatible, -1 = unknown (mirrors proton_arch_compat()).
int archCompat(const QString& key, const CpuProfile& cpu);

int archRank(const QString& key);
QString variantLabel(const QString& assetName);
QString stripArchiveSuffix(const QString& name);
QString humanSize(qint64 bytes);

} // namespace protonutil

// Fetches Proton release lists from GitHub. Async, lives on the main thread.
class ProtonManager : public QObject {
    Q_OBJECT
public:
    explicit ProtonManager(QObject* parent = nullptr);

    // Fetch releases. cachyos=false -> Proton GE (one .tar.gz per release);
    // cachyos=true -> Proton-CachyOS (one row per archive asset).
    void fetchReleases(bool cachyos, int limit = 100);

signals:
    void releasesReady(const QList<ProtonRelease>& releases);
    void fetchFailed(const QString& error);

private:
    QNetworkAccessManager* m_nam;
};
