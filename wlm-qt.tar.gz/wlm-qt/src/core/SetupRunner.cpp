#include "core/SetupRunner.h"

#include "core/InstallWatch.h"
#include "core/ProcessUtils.h"
#include "core/Proton.h"
#include "core/Shortcut.h"

#include <QDateTime>
#include <QFileInfo>
#include <QProcess>
#include <QTimer>

namespace {

constexpr int kPollIntervalMs = 2000;

// Lepas proses installer supaya tidak ikut mati kalau SetupRunner dihancurkan
// (installer GOG bisa saja masih terbuka setelah game terdeteksi).
void detachProcess(QProcess* proc)
{
    if (!proc)
        return;
    proc->setParent(nullptr);
    proc->disconnect(); // jangan kirim signal lagi ke SetupRunner
    QObject::connect(proc, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
                     proc, &QObject::deleteLater);
}

} // namespace

SetupRunner::SetupRunner(QObject* parent)
    : QObject(parent)
{
}

SetupRunner::~SetupRunner()
{
    if (m_proc && m_proc->state() != QProcess::NotRunning) {
        detachProcess(m_proc);
        m_proc = nullptr;
    }
}

bool SetupRunner::start(const QString& exePath, const RunnerChoice& choice,
                        const QStringList& extraArgs, const QString& gameId, QString* error)
{
    if (exePath.isEmpty() || !QFileInfo::exists(exePath)) {
        if (error)
            *error = tr("Installer not found: %1").arg(exePath);
        return false;
    }

    m_gameId = gameId;
    m_driveC = installwatch::driveCFor(choice);
    m_started = static_cast<double>(QDateTime::currentMSecsSinceEpoch()) / 1000.0;
    m_done = false;

    QProcessEnvironment env = procutil::cleanEnvironment();
    const shortcut::LaunchOptions opts = shortcut::parseLaunchOptions(choice.launchOptions);
    for (const auto& kv : opts.envVars)
        env.insert(kv.first, kv.second);

    QString program;
    QStringList args;
    if (choice.runner == QLatin1String("protonge")
        || choice.runner == QLatin1String("protoncachyos")) {
        if (choice.prefixPath.isEmpty()) {
            if (error)
                *error = tr("No prefix was selected for the installer.");
            return false;
        }
        if (choice.protonPath.isEmpty()) {
            if (error)
                *error = tr("No Proton build was selected for the installer.");
            return false;
        }
        env.insert(QStringLiteral("STEAM_COMPAT_DATA_PATH"), choice.prefixPath);
        env.insert(QStringLiteral("STEAM_COMPAT_CLIENT_INSTALL_PATH"),
                   Proton::findSteamInstallPath());
        program = choice.protonPath;
        args << QStringLiteral("run") << exePath;
    } else {
        if (!choice.prefixPath.isEmpty())
            env.insert(QStringLiteral("WINEPREFIX"), choice.prefixPath);
        program = QStringLiteral("wine");
        args << exePath;
    }
    args << opts.extraArgs << extraArgs;

    auto* proc = new QProcess(this);
    m_proc = proc;
    proc->setProcessChannelMode(QProcess::MergedChannels);
    proc->setProcessEnvironment(env);
    proc->setWorkingDirectory(QFileInfo(exePath).absolutePath());
    // Output dibuang tapi tetap dibaca, supaya pipe tidak penuh dan installer
    // tidak macet (Python memakai stdout=DEVNULL).
    connect(proc, &QProcess::readyReadStandardOutput, proc, [proc] {
        proc->readAllStandardOutput();
    });

    proc->start(program, args);
    if (!proc->waitForStarted(5000)) {
        if (error)
            *error = tr("Could not start '%1': %2").arg(program, proc->errorString());
        proc->deleteLater();
        m_proc = nullptr;
        return false;
    }

    m_timer = new QTimer(this);
    m_timer->setInterval(kPollIntervalMs);
    connect(m_timer, &QTimer::timeout, this, &SetupRunner::poll);

    emit started();
    poll(); // cek pertama jalan segera, seperti loop pertama wait_for_install()
    if (!m_done)
        m_timer->start();
    return true;
}

bool SetupRunner::isRunning() const
{
    return m_proc && m_proc->state() == QProcess::Running;
}

void SetupRunner::poll()
{
    if (m_done)
        return;

    const bool running = isRunning();
    std::optional<installwatch::GogGameFound> found;
    try {
        found = installwatch::findGoggame(m_driveC, m_gameId, m_started, running);
    } catch (...) {
        found.reset(); // scan error -> coba lagi di tick berikutnya
    }

    if (found)
        finish(found);
    else if (!running)
        finish(std::nullopt);
}

void SetupRunner::finish(const std::optional<installwatch::GogGameFound>& found)
{
    if (m_done)
        return;
    m_done = true;
    if (m_timer)
        m_timer->stop();

    SetupResult res;
    res.driveC = m_driveC;
    res.found = found;

    // exitCode tetap nullopt kalau game terdeteksi saat installer masih jalan.
    if (m_proc && m_proc->state() == QProcess::NotRunning)
        res.exitCode = m_proc->exitStatus() == QProcess::NormalExit ? m_proc->exitCode() : -1;

    if (!res.found && res.exitCode && *res.exitCode == 0) {
        try {
            res.candidates = installwatch::findCandidates(m_driveC, m_started);
        } catch (...) {
            res.candidates.clear();
        }
    }

    if (m_proc && m_proc->state() != QProcess::NotRunning) {
        detachProcess(m_proc);
        m_proc = nullptr;
    }

    emit finished(res);
}
