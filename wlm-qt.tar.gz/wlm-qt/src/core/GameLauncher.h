#pragma once

#include <QHash>
#include <QObject>
#include <QProcessEnvironment>
#include <QString>
#include <QStringList>

#include <memory>

class QFile;
class QProcess;

// Runs game launch scripts and streams their combined stdout/stderr.
//
// Replaces the pty + thread plumbing from launcher.py's run_script() /
// stream_output() / poll_log_queues(). Output is captured through QProcess
// (merged channels) and forwarded to any open LogWindow via outputAppended().
class GameLauncher : public QObject {
    Q_OBJECT
public:
    explicit GameLauncher(QObject* parent = nullptr);
    ~GameLauncher() override;

    // Start `scriptPath` with the given launch mode
    // (Normal/GalliumHUD/VulkanHUD/MangoHud-GL/Mangohud). Returns false and sets
    // *error on failure.
    bool launch(const QString& name, const QString& scriptPath,
                const QString& launchMode, QString* error = nullptr);

    // Run an arbitrary command (used for winetricks etc.) with a custom
    // environment, streaming output under `name`.
    bool launchCommand(const QString& name, const QString& program, const QStringList& args,
                       const QProcessEnvironment& env, const QString& workingDir = QString(),
                       QString* error = nullptr);

    bool isRunning(const QString& name) const;
    bool hasEntry(const QString& name) const;
    bool isFinished(const QString& name) const;
    QStringList buffer(const QString& name) const;
    QString logFilePath(const QString& name) const;

signals:
    void outputAppended(const QString& name, const QString& text);
    void processFinished(const QString& name, int exitCode);

private:
    struct Entry {
        std::unique_ptr<QProcess> proc;
        std::unique_ptr<QFile> log;
        QString logPath;
        QStringList buffer;
        bool finished = false;
        int exitCode = -1;
    };

    static constexpr int kMaxLogBufferLines = 5000;

    void onReadyRead(Entry& entry, const QString& name);
    void onFinished(Entry& entry, const QString& name, int exitCode);

    QHash<QString, std::shared_ptr<Entry>> m_entries;
};
