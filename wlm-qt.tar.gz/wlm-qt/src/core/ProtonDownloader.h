#pragma once

#include <QElapsedTimer>
#include <QObject>
#include <QString>

class QFile;
class QNetworkAccessManager;
class QNetworkReply;

// Downloads a URL to a file with PAUSE/RESUME support (Range requests). Mirrors
// download_url_pausable() from launcher.py: pausing closes the connection so
// servers do not time it out, and resuming re-opens it from the last byte.
class ProtonDownloader : public QObject {
    Q_OBJECT
public:
    explicit ProtonDownloader(QObject* parent = nullptr);
    ~ProtonDownloader() override;

    void start(const QString& url, const QString& destPath, qint64 totalSize);
    void setPaused(bool paused);
    bool isPaused() const { return m_paused; }

signals:
    void line(const QString& text);
    void progress(qint64 downloaded, qint64 total);
    void finished(const QString& destPath, qint64 downloaded);
    void failed(const QString& error);

private:
    void beginRequest();
    void onReadyRead();
    void onReplyFinished();
    void reportProgress();

    QNetworkAccessManager* m_nam;
    QNetworkReply* m_reply = nullptr;
    QFile* m_file = nullptr;

    QString m_url;
    QString m_dest;
    qint64 m_total = 0;
    qint64 m_downloaded = 0;
    bool m_paused = false;
    bool m_done = false;
    bool m_statusChecked = false;
    QElapsedTimer m_lastReport;
};
