#include "core/Paths.h"

#include <QDir>

namespace paths {

namespace {
QString rootDir()
{
    return QDir::homePath() + QStringLiteral("/wlm");
}

QString file(const QString& name)
{
    return rootDir() + QLatin1Char('/') + name;
}
} // namespace

QString root()                  { return rootDir(); }
QString icons()                 { return file(QStringLiteral("icons")); }
QString bashlaunch()            { return file(QStringLiteral("bashlaunch")); }
QString covers()                { return file(QStringLiteral("covers")); }
QString logs()                  { return file(QStringLiteral("logs")); }
QString protonGE()              { return file(QStringLiteral("protonge")); }
QString protonGEPrefixes()      { return file(QStringLiteral("protonprefixes")); }
QString protonCachyOS()         { return file(QStringLiteral("protoncachyos")); }
QString protonCachyOSPrefixes() { return file(QStringLiteral("protoncachyosprefixes")); }
QString winePrefixes()          { return file(QStringLiteral("wineprefixes")); }
QString gogCovers()             { return file(QStringLiteral("gog_covers")); }
QString gogDownloads()          { return file(QStringLiteral("gog_downloads")); }
QString gogGames()              { return file(QStringLiteral("gog_games")); }

QString themeConfig()           { return file(QStringLiteral("theme_config.json")); }
QString windowConfig()          { return file(QStringLiteral("window_config.json")); }
QString dialogSizes()           { return file(QStringLiteral("dialog_sizes.json")); }
QString runnerConfig()          { return file(QStringLiteral("runner_config.json")); }
QString prefixLocationConfig()  { return file(QStringLiteral("prefix_location_config.json")); }
QString prefixRegistry()        { return file(QStringLiteral("prefix_registry.json")); }
QString libraryViewConfig()     { return file(QStringLiteral("library_view.json")); }
QString envConfig()             { return file(QStringLiteral("env_config.yaml")); }
QString gogConfig()             { return file(QStringLiteral("gog_config.json")); }
QString gogAuth()               { return file(QStringLiteral("gog_auth.json")); }

QString gogUi()                { return file(QStringLiteral("gog_ui.json")); }
QString gogCloudCache()        { return file(QStringLiteral("gog_cloud_cache.json")); }
QString saveFolders()          { return file(QStringLiteral("save_folders.json")); }
QString saveBackups()          { return file(QStringLiteral("save_backups")); }
QString downloadHistory()      { return file(QStringLiteral("download_history.json")); }
QString gogDownloadJobs()      { return file(QStringLiteral("gog_downloads.json")); }

void ensureDirectories()
{
    const QString dirs[] = {
        root(), icons(), bashlaunch(), covers(), logs(),
        protonGE(), protonGEPrefixes(), protonCachyOS(),
        protonCachyOSPrefixes(), winePrefixes(),
    };
    for (const QString& d : dirs)
        QDir().mkpath(d);
}

} // namespace paths
