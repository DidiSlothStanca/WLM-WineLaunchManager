#pragma once

#define WLM_VERSION "0.4.7-Beta"
#define WLM_DEVELOPER "Opensource OS Gathering Republic"
#define WLM_DEVELOPER_ABBR "OOGR"
#define WLM_MAINTAINER "Didi Sloth Stanca"
