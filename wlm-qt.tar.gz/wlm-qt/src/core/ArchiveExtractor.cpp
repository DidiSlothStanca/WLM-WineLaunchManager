#include "core/ArchiveExtractor.h"

#include <QDir>
#include <QFileInfo>
#include <QProcess>

ArchiveExtractor::ArchiveExtractor(QObject* parent)
    : QObject(parent)
{
}

QString ArchiveExtractor::stripArchiveSuffix(const QString& name)
{
    static const QStringList suffixes = {
        QStringLiteral(".tar.gz"), QStringLiteral(".tar.xz"),
        QStringLiteral(".tgz"), QStringLiteral(".zip"),
    };
    for (const QString& s : suffixes) {
        if (name.toLower().endsWith(s))
            return name.left(name.size() - s.size());
    }
    return name;
}

void ArchiveExtractor::extract(const QString& archivePath, const QString& targetDir)
{
    m_archive = archivePath;
    m_target = targetDir;

    if (!QFileInfo::exists(m_archive)) {
        emit finished(false, tr("Archive not found: %1").arg(m_archive));
        return;
    }
    if (!QDir().mkpath(m_target)) {
        emit finished(false, tr("Could not create target directory: %1").arg(m_target));
        return;
    }

    m_beforeEntries = QDir(m_target).entryList(QDir::Dirs | QDir::Files | QDir::NoDotAndDotDot);

    const bool isZip = m_archive.toLower().endsWith(QLatin1String(".zip"));
    emit line(tr("Extracting %1 to %2 ...").arg(QFileInfo(m_archive).fileName(), m_target));

    m_proc = new QProcess(this);
    if (isZip) {
        m_proc->setProgram(QStringLiteral("unzip"));
        m_proc->setArguments({QStringLiteral("-o"), m_archive, QStringLiteral("-d"), m_target});
    } else {
        m_proc->setProgram(QStringLiteral("tar"));
        m_proc->setArguments({QStringLiteral("-xf"), m_archive, QStringLiteral("-C"), m_target});
    }

    connect(m_proc, &QProcess::readyReadStandardOutput, this, [this] {
        const QString out = QString::fromUtf8(m_proc->readAllStandardOutput()).trimmed();
        if (!out.isEmpty())
            emit line(out);
    });
    connect(m_proc, &QProcess::readyReadStandardError, this, [this] {
        const QString err = QString::fromUtf8(m_proc->readAllStandardError()).trimmed();
        if (!err.isEmpty())
            emit line(err);
    });
    connect(m_proc, &QProcess::errorOccurred, this, [this](QProcess::ProcessError error) {
        if (error == QProcess::FailedToStart) {
            emit finished(false, tr("Could not start the extraction program (%1). "
                                    "Please make sure tar/unzip is installed.")
                                  .arg(m_proc->program()));
        }
    });
    connect(m_proc, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished), this,
            [this](int exitCode, QProcess::ExitStatus) {
                if (exitCode != 0) {
                    emit finished(false, tr("Extraction failed (exit code %1).").arg(exitCode));
                    return;
                }
                finishPostProcess();
            });

    m_proc->start();
}

void ArchiveExtractor::finishPostProcess()
{
    QDir target(m_target);
    const QStringList after = target.entryList(QDir::Dirs | QDir::Files | QDir::NoDotAndDotDot);

    QStringList newTop;
    for (const QString& name : after) {
        if (!m_beforeEntries.contains(name))
            newTop.append(name);
    }

    if (newTop.size() != 1) {
        const QString wrapperName = stripArchiveSuffix(QFileInfo(m_archive).fileName());
        const QString wrapperDir = wrapperName.isEmpty() ? QStringLiteral("proton") : wrapperName;
        if (!QDir().mkpath(target.filePath(wrapperDir))) {
            emit finished(false, tr("Could not create wrapper folder: %1").arg(wrapperDir));
            return;
        }
        for (const QString& name : newTop) {
            const QString src = target.filePath(name);
            if (src == target.filePath(wrapperDir) || !QFileInfo::exists(src))
                continue;
            target.rename(name, wrapperDir + QLatin1Char('/') + name);
        }
    }

    emit finished(true, QString());
}
