#include "core/WindowState.h"

#include "core/JsonIO.h"
#include "core/Paths.h"

#include <QApplication>
#include <QCloseEvent>
#include <QEvent>
#include <QJsonObject>
#include <QJsonValue>
#include <QMoveEvent>
#include <QRegularExpression>
#include <QResizeEvent>
#include <QScreen>
#include <QTimer>
#include <QWidget>

namespace windowstate {

namespace {
constexpr const char* kDialogsKey = "dialogs";
} // namespace

DialogGeometry load(const QString& key)
{
    const QJsonObject obj = jsonio::readObject(paths::windowConfig());
    if (obj.isEmpty())
        return {};

    const QJsonObject dialogs = obj.value(QLatin1String(kDialogsKey)).toObject();
    if (dialogs.isEmpty())
        return {};

    const QJsonObject entry = dialogs.value(key).toObject();
    if (entry.isEmpty())
        return {};

    DialogGeometry g;
    const QString sz = entry.value(QStringLiteral("size")).toString();
    static const QRegularExpression re(QStringLiteral("^(\\d{3,5})x(\\d{3,5})$"));
    if (re.match(sz).hasMatch())
        g.size = sz;

    g.maximized = entry.value(QStringLiteral("maximized")).toBool(false);
    return g;
}

void save(const QString& key, const DialogGeometry& g)
{
    QJsonObject obj = jsonio::readObject(paths::windowConfig());
    QJsonObject dialogs = obj.value(QLatin1String(kDialogsKey)).toObject();

    QJsonObject entry;
    entry.insert(QStringLiteral("size"), g.size);
    entry.insert(QStringLiteral("maximized"), g.maximized);

    dialogs.insert(key, entry);
    obj.insert(QLatin1String(kDialogsKey), dialogs);
    jsonio::writeObjectAtomic(paths::windowConfig(), obj);
}

} // namespace windowstate

WindowStateHelper::WindowStateHelper(QWidget* dialog, QString key, QSize defaultSize,
                                     QSize minSize, QWidget* parent)
    : QObject(dialog)
    , m_dialog(dialog)
    , m_key(std::move(key))
    , m_defaultSize(std::move(defaultSize))
    , m_minSize(std::move(minSize))
{
    Q_UNUSED(parent);

    // Qt::Window gives the dialog a real title bar. The hints ensure the window
    // manager draws minimize / maximize / close buttons.
    dialog->setWindowFlags(dialog->windowFlags() | Qt::Window
                           | Qt::WindowMinMaxButtonsHint
                           | Qt::WindowCloseButtonHint
                           | Qt::WindowSystemMenuHint);

    applyInitial();

    // Persist geometry changes (debounced) and on close.
    m_timer = new QTimer(this);
    m_timer->setSingleShot(true);
    m_timer->setInterval(500);
    connect(m_timer, &QTimer::timeout, this, &WindowStateHelper::persist);

    dialog->installEventFilter(this);
}

void WindowStateHelper::applyInitial()
{
    const windowstate::DialogGeometry g = windowstate::load(m_key);

    const QScreen* screen =
        m_dialog->screen() ? m_dialog->screen() : QApplication::primaryScreen();
    const QRect avail =
        screen ? screen->availableGeometry() : QRect(0, 0, 1920, 1080);
    const int maxW = qMax(320, avail.width() - 20);
    const int maxH = qMax(240, avail.height() - 90);

    const int minW = qMin(m_minSize.width(), maxW);
    const int minH = qMin(m_minSize.height(), maxH);

    const int w = qMax(minW, qMin(g.size.contains('x')
        ? QRegularExpression(QStringLiteral("^(\\d+)x(\\d+)$"))
              .match(g.size).captured(1).toInt()
        : m_defaultSize.width(), maxW));
    const int h = qMax(minH, qMin(g.size.contains('x')
        ? QRegularExpression(QStringLiteral("^(\\d+)x(\\d+)$"))
              .match(g.size).captured(2).toInt()
        : m_defaultSize.height(), maxH));

    m_dialog->setMinimumSize(minW, minH);
    m_dialog->resize(w, h);

    if (g.maximized)
        m_dialog->setWindowState(Qt::WindowMaximized);
}

void WindowStateHelper::persist()
{
    if (!m_dialog)
        return;
    windowstate::DialogGeometry g;
    if (!m_dialog->isMaximized()) {
        g.size = QStringLiteral("%1x%2").arg(m_dialog->width()).arg(m_dialog->height());
    } else {
        g.size = QStringLiteral("%1x%2").arg(m_dialog->normalGeometry().width())
                                        .arg(m_dialog->normalGeometry().height());
    }
    g.maximized = m_dialog->isMaximized();
    windowstate::save(m_key, g);
}

bool WindowStateHelper::eventFilter(QObject* obj, QEvent* ev)
{
    if (obj != m_dialog)
        return QObject::eventFilter(obj, ev);

    switch (ev->type()) {
    case QEvent::Resize: {
        if (m_dialog->isMaximized() || m_dialog->isFullScreen())
            break;
        const QSize s = m_dialog->size();
        if (s.width() < 100 || s.height() < 100)
            break;
        m_timer->start();
        break;
    }
    case QEvent::Move:
        if (!m_dialog->isMaximized() && !m_dialog->isFullScreen())
            m_timer->start();
        break;
    case QEvent::WindowStateChange:
        m_timer->start();
        break;
    case QEvent::Close:
        if (m_timer->isActive()) {
            m_timer->stop();
            persist();
        }
        break;
    default:
        break;
    }
    return QObject::eventFilter(obj, ev);
}
