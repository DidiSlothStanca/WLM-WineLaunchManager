#include "core/GogClient.h"

#include <QDateTime>
#include <QJsonArray>
#include <QJsonObject>
#include <QJsonParseError>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QUrl>

#include <memory>

namespace gog {

namespace {

Installer parseInstaller(const QJsonObject& obj)
{
    Installer ins;
    ins.id = obj.value(QStringLiteral("id")).toVariant().toString();
    ins.os = obj.value(QStringLiteral("os")).toString();
    ins.language = obj.value(QStringLiteral("language")).toString();
    ins.languageName = obj.value(QStringLiteral("language_full")).toString();
    ins.version = obj.value(QStringLiteral("version")).toString();
    ins.totalSize = static_cast<qint64>(obj.value(QStringLiteral("total_size")).toDouble());
    const QJsonArray files = obj.value(QStringLiteral("files")).toArray();
    for (const QJsonValue& fv : files) {
        const QJsonObject f = fv.toObject();
        InstallerFile file;
        file.downlink = f.value(QStringLiteral("downlink")).toString();
        file.size = static_cast<qint64>(f.value(QStringLiteral("size")).toDouble());
        if (!file.downlink.isEmpty())
            ins.files.append(file);
    }
    return ins;
}

} // namespace

GogClient::GogClient(QObject* parent)
    : QObject(parent)
    , m_nam(new QNetworkAccessManager(this))
{
}

void GogClient::getJson(const Config& cfg, const QString& url, const QString& token,
                        const JsonCb& cb)
{
    QNetworkRequest req{QUrl(url)};
    req.setHeader(QNetworkRequest::UserAgentHeader, cfg.userAgent);
    req.setAttribute(QNetworkRequest::RedirectPolicyAttribute,
                     QNetworkRequest::NoLessSafeRedirectPolicy);
    if (!token.isEmpty())
        req.setRawHeader("Authorization", "Bearer " + token.toUtf8());

    QNetworkReply* reply = m_nam->get(req);
    connect(reply, &QNetworkReply::finished, this, [reply, cb] {
        reply->deleteLater();
        const int status = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        if (reply->error() != QNetworkReply::NoError) {
            if (status == 401)
                cb({}, QStringLiteral("GOG rejected the session (HTTP 401). Please log in again."),
                   true);
            else if (status > 0)
                cb({}, QStringLiteral("GOG returned HTTP %1.").arg(status), false);
            else
                cb({}, QStringLiteral("Could not reach GOG: %1").arg(reply->errorString()), false);
            return;
        }
        const QByteArray data = reply->readAll();
        QJsonParseError perr{};
        const QJsonDocument doc = QJsonDocument::fromJson(data, &perr);
        if (perr.error != QJsonParseError::NoError) {
            cb({}, QStringLiteral("GOG returned an unexpected response."), false);
            return;
        }
        cb(doc, QString(), false);
    });
}

void GogClient::tokenRequest(
    const Config& cfg, const QUrlQuery& params, const Auth& keep,
    std::function<void(bool ok, const Auth& auth, const QString& err, bool authError)> cb)
{
    QUrlQuery q = params;
    q.addQueryItem(QStringLiteral("client_id"), cfg.clientId);
    q.addQueryItem(QStringLiteral("client_secret"), cfg.clientSecret);
    const QString url = cfg.tokenUrl + QLatin1Char('?') + q.toString(QUrl::FullyEncoded);

    getJson(cfg, url, QString(),
            [keep, cb](const QJsonDocument& doc, const QString& err, bool authError) {
                if (!err.isEmpty()) {
                    cb(false, keep, err, authError);
                    return;
                }
                const QJsonObject obj = doc.object();
                const QString access = obj.value(QStringLiteral("access_token")).toString();
                if (access.isEmpty()) {
                    cb(false, keep, QStringLiteral("GOG did not return an access token."), false);
                    return;
                }
                Auth a = keep;
                a.accessToken = access;
                const QString refresh = obj.value(QStringLiteral("refresh_token")).toString();
                if (!refresh.isEmpty())
                    a.refreshToken = refresh;
                const QString uid = obj.value(QStringLiteral("user_id")).toString();
                if (!uid.isEmpty())
                    a.userId = uid;
                double expiresIn = obj.value(QStringLiteral("expires_in")).toDouble(3600.0);
                if (expiresIn <= 0)
                    expiresIn = 3600.0;
                a.expiresAt = QDateTime::currentSecsSinceEpoch() + static_cast<qint64>(expiresIn);
                saveAuth(a);
                cb(true, a, QString(), false);
            });
}

void GogClient::exchangeCode(const Config& cfg, const QString& code,
                             std::function<void(bool ok, const QString& err)> cb)
{
    QUrlQuery q;
    q.addQueryItem(QStringLiteral("grant_type"), QStringLiteral("authorization_code"));
    q.addQueryItem(QStringLiteral("code"), code);
    q.addQueryItem(QStringLiteral("redirect_uri"), cfg.redirectUri);

    tokenRequest(cfg, q, Auth{},
                 [this, cfg, cb](bool ok, const Auth& auth, const QString& err, bool) {
                     if (!ok) {
                         cb(false, err);
                         return;
                     }
                     getJson(cfg, cfg.userdataUrl, auth.accessToken,
                             [auth, cb](const QJsonDocument& doc, const QString& uerr, bool) {
                                 Auth updated = auth;
                                 if (uerr.isEmpty()) {
                                     const QJsonObject info = doc.object();
                                     QString name =
                                         info.value(QStringLiteral("username")).toString();
                                     if (name.isEmpty())
                                         name = info.value(QStringLiteral("email")).toString();
                                     updated.username = name;
                                 }
                                 saveAuth(updated);
                                 cb(true, QString());
                             });
                 });
}

void GogClient::ensureToken(
    const Config& cfg,
    std::function<void(const QString& token, const QString& err, bool authError)> cb)
{
    const Auth auth = loadAuth();
    if (auth.refreshToken.isEmpty()) {
        cb(QString(), QStringLiteral("Not logged in."), true);
        return;
    }
    const qint64 now = QDateTime::currentSecsSinceEpoch();
    if (!auth.accessToken.isEmpty() && auth.expiresAt - 60 > now) {
        cb(auth.accessToken, QString(), false);
        return;
    }

    QUrlQuery q;
    q.addQueryItem(QStringLiteral("grant_type"), QStringLiteral("refresh_token"));
    q.addQueryItem(QStringLiteral("refresh_token"), auth.refreshToken);
    tokenRequest(cfg, q, auth, [cb](bool ok, const Auth& updated, const QString&, bool) {
        if (!ok) {
            clearAuth();
            cb(QString(), QStringLiteral("Session expired. Please log in again."), true);
            return;
        }
        cb(updated.accessToken, QString(), false);
    });
}

void GogClient::fetchLibrary(
    const Config& cfg,
    std::function<void(const QVector<Game>&, const QString& err, bool authError)> cb)
{
    ensureToken(cfg, [this, cfg, cb](const QString& token, const QString& err, bool authError) {
        if (!err.isEmpty()) {
            cb({}, err, authError);
            return;
        }
        auto games = std::make_shared<QVector<Game>>();
        auto fetchPage = std::make_shared<std::function<void(int, int)>>();
        *fetchPage = [this, cfg, token, cb, games, fetchPage](int page, int) {
            QUrlQuery q;
            q.addQueryItem(QStringLiteral("mediaType"), QStringLiteral("1"));
            q.addQueryItem(QStringLiteral("sortBy"), QStringLiteral("title"));
            q.addQueryItem(QStringLiteral("page"), QString::number(page));
            const QString url = cfg.libraryUrl + QLatin1Char('?')
                + q.toString(QUrl::FullyEncoded);
            getJson(cfg, url, token,
                    [cb, games, fetchPage, page](const QJsonDocument& doc, const QString& gerr,
                                                 bool gAuthError) {
                        if (!gerr.isEmpty()) {
                            cb({}, gerr, gAuthError);
                            return;
                        }
                        const QJsonObject obj = doc.object();
                        const int totalPages = qMax(1, obj.value(QStringLiteral("totalPages")).toInt(1));
                        const QJsonArray products = obj.value(QStringLiteral("products")).toArray();
                        for (const QJsonValue& pv : products) {
                            const QJsonObject p = pv.toObject();
                            Game g;
                            g.id = p.value(QStringLiteral("id")).toVariant().toString();
                            g.title = p.value(QStringLiteral("title")).toString();
                            const QJsonObject works = p.value(QStringLiteral("worksOn")).toObject();
                            QStringList names;
                            if (works.value(QStringLiteral("Windows")).toBool())
                                names << QStringLiteral("Windows");
                            if (works.value(QStringLiteral("Mac")).toBool())
                                names << QStringLiteral("Mac");
                            if (works.value(QStringLiteral("Linux")).toBool())
                                names << QStringLiteral("Linux");
                            g.platforms = names.join(QStringLiteral(", "));
                            g.image = p.value(QStringLiteral("image")).toString();
                            games->append(g);
                        }
                        if (page < totalPages)
                            (*fetchPage)(page + 1, totalPages);
                        else
                            cb(*games, QString(), false);
                    });
        };
        (*fetchPage)(1, 1);
    });
}

void GogClient::fetchInstallers(
    const Config& cfg, const QString& productId,
    std::function<void(const QVector<Installer>&, const QString& err, bool authError)> cb)
{
    ensureToken(cfg, [this, cfg, productId, cb](const QString& token, const QString& err,
                                                bool authError) {
        if (!err.isEmpty()) {
            cb({}, err, authError);
            return;
        }
        QString url = cfg.productUrl;
        url.replace(QStringLiteral("{id}"), productId);
        url += QStringLiteral("?expand=downloads&locale=en-US");
        getJson(cfg, url, token,
                [cfg, cb](const QJsonDocument& doc, const QString& gerr, bool gAuthError) {
                    if (!gerr.isEmpty()) {
                        cb({}, gerr, gAuthError);
                        return;
                    }
                    const QJsonArray installers = doc.object()
                                                      .value(QStringLiteral("downloads"))
                                                      .toObject()
                                                      .value(QStringLiteral("installers"))
                                                      .toArray();
                    const QString wantOs = cfg.os.trimmed().toLower();
                    const QString wantLang = cfg.language.trimmed().toLower();
                    QVector<Installer> all;
                    QVector<Installer> filtered;
                    for (const QJsonValue& iv : installers) {
                        const Installer ins = parseInstaller(iv.toObject());
                        all.append(ins);
                        const bool okOs = wantOs.isEmpty() || ins.os.toLower() == wantOs;
                        const bool okLang = wantLang.isEmpty()
                            || ins.language.toLower() == wantLang;
                        if (okOs && okLang)
                            filtered.append(ins);
                    }
                    cb(filtered.isEmpty() ? all : filtered, QString(), false);
                });
    });
}

void GogClient::resolveDownlink(
    const Config& cfg, const QString& downlink,
    std::function<void(const QString& url, const QString& err, bool authError)> cb)
{
    ensureToken(cfg, [this, cfg, downlink, cb](const QString& token, const QString& err,
                                               bool authError) {
        if (!err.isEmpty()) {
            cb(QString(), err, authError);
            return;
        }
        getJson(cfg, downlink, token,
                [cb](const QJsonDocument& doc, const QString& gerr, bool gAuthError) {
                    if (!gerr.isEmpty()) {
                        cb(QString(), gerr, gAuthError);
                        return;
                    }
                    const QString url =
                        doc.object().value(QStringLiteral("downlink")).toString();
                    if (url.isEmpty()) {
                        cb(QString(), QStringLiteral("GOG did not return a download link."), false);
                        return;
                    }
                    cb(url, QString(), false);
                });
    });
}

} // namespace gog
