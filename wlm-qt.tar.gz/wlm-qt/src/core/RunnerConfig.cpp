#include "core/RunnerConfig.h"

#include "core/JsonIO.h"
#include "core/Paths.h"
#include "core/Shortcut.h"

#include <QJsonValue>

QJsonObject RunnerChoice::toJson() const
{
    QJsonObject o;
    o.insert(QStringLiteral("runner"), runner);
    if (!prefixCode.isEmpty())  o.insert(QStringLiteral("prefix_code"), prefixCode);
    if (!prefixPath.isEmpty())  o.insert(QStringLiteral("prefix_path"), prefixPath);
    if (!protonName.isEmpty())  o.insert(QStringLiteral("proton_name"), protonName);
    if (!protonPath.isEmpty())  o.insert(QStringLiteral("proton_path"), protonPath);
    o.insert(QStringLiteral("launch_options"), launchOptions);
    o.insert(QStringLiteral("comment"), comment);
    if (!source.isEmpty())      o.insert(QStringLiteral("source"), source);
    if (!gogId.isEmpty())       o.insert(QStringLiteral("gog_id"), gogId);
    return o;
}

RunnerChoice RunnerChoice::fromJson(const QJsonObject& obj)
{
    RunnerChoice c;
    c.runner = obj.value(QStringLiteral("runner")).toString(QStringLiteral("wine"));
    c.prefixCode = obj.value(QStringLiteral("prefix_code")).toString();
    c.prefixPath = obj.value(QStringLiteral("prefix_path")).toString();
    c.protonName = obj.value(QStringLiteral("proton_name")).toString();
    c.protonPath = obj.value(QStringLiteral("proton_path")).toString();
    c.launchOptions = obj.value(QStringLiteral("launch_options")).toString();
    c.comment = obj.value(QStringLiteral("comment")).toString();
    c.source = obj.value(QStringLiteral("source")).toString();
    c.gogId = obj.value(QStringLiteral("gog_id")).toString();
    return c;
}

namespace runnerconfig {

QJsonObject load()
{
    return jsonio::readObject(paths::runnerConfig());
}

void save(const QJsonObject& cfg)
{
    jsonio::writeObjectAtomic(paths::runnerConfig(), cfg);
}

RunnerChoice get(const QString& name)
{
    const QJsonObject cfg = load();
    const QJsonValue v = cfg.value(name);
    if (v.isObject())
        return RunnerChoice::fromJson(v.toObject());
    return {};
}

void set(const QString& name, const RunnerChoice& choice)
{
    QJsonObject cfg = load();
    cfg.insert(name, choice.toJson());
    save(cfg);
}

void remove(const QString& name)
{
    QJsonObject cfg = load();
    if (cfg.contains(name)) {
        cfg.remove(name);
        save(cfg);
    }
}

void rename(const QString& oldName, const QString& newName)
{
    QJsonObject cfg = load();
    if (cfg.contains(oldName)) {
        const QJsonValue v = cfg.take(oldName);
        cfg.insert(newName, v);
        save(cfg);
    }
}

GameSource gameSource(const QString& name)
{
    GameSource result;
    const QJsonObject cfg = load();
    const QJsonValue v = cfg.value(name);
    const QJsonObject entry = v.isObject() ? v.toObject() : QJsonObject{};

    if (entry.value(QStringLiteral("source")).toString() == QLatin1String("gog")) {
        result.source = QStringLiteral("gog");
        result.gogId = entry.value(QStringLiteral("gog_id")).toString();
        return result;
    }

    const QString scriptPath = paths::bashlaunch() + QStringLiteral("/") + name + QStringLiteral(".sh");
    const QString exe = shortcut::extractExePath(scriptPath);
    if (!exe.isEmpty()) {
        const QString gid = shortcut::detectGogId(exe);
        if (!gid.isEmpty()) {
            result.source = QStringLiteral("gog");
            result.gogId = gid;
        }
    }
    return result;
}

} // namespace runnerconfig
