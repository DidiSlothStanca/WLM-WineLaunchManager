#pragma once

#include "core/GogConfig.h"

#include <QJsonObject>
#include <QString>

// Port of gog_store.py's auth handling: the ~/wlm/gog_auth.json store, the
// login URL builder, and extract_code(). Token exchange / refresh happen in
// GogClient (they need the network); this file only owns persistence and the
// pure helpers, so both apps read/write the exact same file (mode 0600).
namespace gog {

struct Auth {
    QString accessToken;
    QString refreshToken;
    QString userId;
    QString username;
    qint64 expiresAt = 0; // Unix seconds

    bool loggedIn() const { return !refreshToken.isEmpty(); }
    // True when the access token still has > 60 s of life (Python's margin).
    bool tokenValid(qint64 nowSecs) const
    {
        return !accessToken.isEmpty() && expiresAt - 60 > nowSecs;
    }

    QJsonObject toJson() const;
    static Auth fromJson(const QJsonObject&);
};

Auth loadAuth(const QString& path = QString());
void saveAuth(const Auth& auth, const QString& path = QString()); // chmod 0600
void clearAuth(const QString& path = QString());

// https://auth.gog.com/auth?client_id=..&redirect_uri=..
QString loginUrl(const Config& cfg);

// Extract the OAuth code from a redirect URL or a bare code. Empty when the
// text is neither. Mirrors extract_code().
QString extractCode(const QString& text);

} // namespace gog
