#include "core/DownloadManager.h"

#include "core/JsonIO.h"
#include "core/Paths.h"
#include "core/RunnerConfig.h"

#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QJsonObject>
#include <QJsonValue>
#include <QJsonArray>
#include <QRegularExpression>

DownloadManager* DownloadManager::s_instance = nullptr;

DownloadManager::DownloadManager(QObject* parent)
    : QObject(parent)
{
    load();
}

DownloadManager::~DownloadManager()
{
    if (s_instance == this)
        s_instance = nullptr;
}

DownloadManager* DownloadManager::instance()
{
    if (!s_instance)
        s_instance = new DownloadManager();
    return s_instance;
}

int DownloadManager::startDownload(const QString& title, const QString& category,
                                     qint64 totalSize, const QString& destPath)
{
    Item item;
    item.id = m_nextId++;
    item.title = title;
    item.category = category;
    item.totalSize = totalSize;
    item.status = Status::Queued;
    item.startedAt = QDateTime::currentDateTime();
    item.destPath = destPath;
    m_items.prepend(item);
    save();
    emit itemAdded(item);
    return item.id;
}

void DownloadManager::updateProgress(int id, int progress, qint64 downloaded, qint64 total)
{
    for (Item& item : m_items) {
        if (item.id != id)
            continue;
        item.progress = progress;
        item.downloadedSize = downloaded;
        if (total > 0)
            item.totalSize = total;
        if (item.status == Status::Queued)
            item.status = Status::Downloading;
        save();
        emit itemUpdated(item);
        return;
    }
}

void DownloadManager::pauseDownload(int id)
{
    for (Item& item : m_items) {
        if (item.id != id)
            continue;
        if (item.status == Status::Downloading || item.status == Status::Queued) {
            item.status = Status::Paused;
            save();
            emit itemUpdated(item);
        }
        return;
    }
}

void DownloadManager::resumeDownload(int id)
{
    for (Item& item : m_items) {
        if (item.id != id)
            continue;
        if (item.status == Status::Paused) {
            item.status = Status::Downloading;
            save();
            emit itemUpdated(item);
        }
        return;
    }
}

void DownloadManager::cancelDownload(int id)
{
    for (Item& item : m_items) {
        if (item.id != id)
            continue;
        if (item.status == Status::Downloading || item.status == Status::Paused
            || item.status == Status::Queued) {
            item.status = Status::Cancelled;
            item.finishedAt = QDateTime::currentDateTime();
            // Delete partial files (.part) in the download directory.
            QDir dir(item.destPath);
            if (dir.exists()) {
                const auto partFiles = dir.entryInfoList({"*.part"}, QDir::Files);
                for (const QFileInfo& fi : partFiles) {
                    QFile::remove(fi.absoluteFilePath());
                }
            }
            save();
            emit itemUpdated(item);
            // Emit cancel signal so connected downloaders can abort.
            emit cancelRequested(id);
        }
        return;
    }
}

void DownloadManager::markCompleted(int id)
{
    for (Item& item : m_items) {
        if (item.id != id)
            continue;
        item.status = Status::Completed;
        item.progress = 100;
        item.finishedAt = QDateTime::currentDateTime();
        save();
        emit itemUpdated(item);
        return;
    }
}

void DownloadManager::markFailed(int id, const QString& error)
{
    for (Item& item : m_items) {
        if (item.id != id)
            continue;
        item.status = Status::Failed;
        item.error = error;
        item.finishedAt = QDateTime::currentDateTime();
        save();
        emit itemUpdated(item);
        return;
    }
}

void DownloadManager::removeItem(int id)
{
    for (int i = 0; i < m_items.size(); ++i) {
        if (m_items[i].id == id) {
            m_items.removeAt(i);
            save();
            emit itemRemoved(id);
            return;
        }
    }
}

void DownloadManager::clearFinished()
{
    bool changed = false;
    for (int i = m_items.size() - 1; i >= 0; --i) {
        const Status s = m_items[i].status;
        if (s == Status::Completed || s == Status::Failed || s == Status::Cancelled) {
            m_items.removeAt(i);
            changed = true;
        }
    }
    if (changed) {
        save();
    }
}

void DownloadManager::resetNextId()
{
    // Find the highest ID in remaining items and set nextId to max + 1.
    int maxId = 0;
    for (const Item& item : m_items) {
        if (item.id > maxId)
            maxId = item.id;
    }
    m_nextId = maxId + 1;
    save();
}

QVector<DownloadManager::Item> DownloadManager::items() const
{
    return m_items;
}

QVector<DownloadManager::Item> DownloadManager::activeItems() const
{
    QVector<Item> result;
    for (const Item& item : m_items) {
        if (item.status == Status::Downloading || item.status == Status::Paused
            || item.status == Status::Queued)
            result.append(item);
    }
    return result;
}

bool DownloadManager::hasActive() const
{
    for (const Item& item : m_items) {
        if (item.status == Status::Downloading || item.status == Status::Paused
            || item.status == Status::Queued)
            return true;
    }
    return false;
}

void DownloadManager::load()
{
    m_items.clear();
    const QJsonObject obj = jsonio::readObject(paths::downloadHistory());
    if (!obj.contains(QLatin1String("downloads")))
        return;

    const QJsonValue arr = obj.value(QLatin1String("downloads"));
    if (!arr.isArray())
        return;

    for (const QJsonValue& v : arr.toArray()) {
        const QJsonObject o = v.toObject();
        if (o.isEmpty())
            continue;
        Item item;
        item.id = o.value(QStringLiteral("id")).toInt();
        item.title = o.value(QStringLiteral("title")).toString();
        item.category = o.value(QStringLiteral("category")).toString();
        static const QStringList kStatuses = {"queued", "downloading", "paused",
                                              "completed", "failed", "cancelled"};
        const QString st = o.value(QStringLiteral("status")).toString();
        const int si = kStatuses.indexOf(st);
        item.status = si >= 0 ? static_cast<Status>(si) : Status::Queued;
        item.totalSize = o.value(QStringLiteral("totalSize")).toVariant().toLongLong();
        item.downloadedSize = o.value(QStringLiteral("downloadedSize")).toVariant().toLongLong();
        item.progress = o.value(QStringLiteral("progress")).toInt();
        item.error = o.value(QStringLiteral("error")).toString();
        item.destPath = o.value(QStringLiteral("destPath")).toString();
        // New fields for auto-install.
        item.startSetupAfterDownload = o.value(QStringLiteral("startSetupAfterDownload")).toBool(false);
        if (o.contains(QStringLiteral("runnerChoice"))) {
            const QJsonObject rc = o.value(QStringLiteral("runnerChoice")).toObject();
            item.runnerChoice = RunnerChoice::fromJson(rc);
        }
        // Parse ISO date strings.
        const QString started = o.value(QStringLiteral("startedAt")).toString();
        const QString finished = o.value(QStringLiteral("finishedAt")).toString();
        item.startedAt = QDateTime::fromString(started, Qt::ISODate);
        item.finishedAt = QDateTime::fromString(finished, Qt::ISODate);
        m_items.append(item);
        if (item.id >= m_nextId)
            m_nextId = item.id + 1;
    }
}

void DownloadManager::save() const
{
    QJsonObject obj;
    QJsonArray arr;
    for (const Item& item : m_items) {
        QJsonObject o;
        static const char* kStatuses[] = {"queued", "downloading", "paused",
                                          "completed", "failed", "cancelled"};
        o.insert(QStringLiteral("id"), item.id);
        o.insert(QStringLiteral("title"), item.title);
        o.insert(QStringLiteral("category"), item.category);
        o.insert(QStringLiteral("status"), QLatin1String(kStatuses[static_cast<int>(item.status)]));
        o.insert(QStringLiteral("totalSize"), static_cast<double>(item.totalSize));
        o.insert(QStringLiteral("downloadedSize"), static_cast<double>(item.downloadedSize));
        o.insert(QStringLiteral("progress"), item.progress);
        o.insert(QStringLiteral("error"), item.error);
        o.insert(QStringLiteral("destPath"), item.destPath);
        o.insert(QStringLiteral("startSetupAfterDownload"), item.startSetupAfterDownload);
        if (item.startSetupAfterDownload && !item.runnerChoice.runner.isEmpty()) {
            o.insert(QStringLiteral("runnerChoice"), item.runnerChoice.toJson());
        }
        if (item.startedAt.isValid())
            o.insert(QStringLiteral("startedAt"), item.startedAt.toString(Qt::ISODate));
        if (item.finishedAt.isValid())
            o.insert(QStringLiteral("finishedAt"), item.finishedAt.toString(Qt::ISODate));
        arr.append(o);
    }
    obj.insert(QStringLiteral("downloads"), arr);
    jsonio::writeObjectAtomic(paths::downloadHistory(), obj);
}
