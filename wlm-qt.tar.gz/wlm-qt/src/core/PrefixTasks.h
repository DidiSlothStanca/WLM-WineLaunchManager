#pragma once

#include "core/PrefixOps.h"

#include <QJsonObject>
#include <QList>
#include <QObject>
#include <QString>
#include <QStringList>

class QProcess;

// Async prefix backup (tar.gz + manifest.json), restore, and folder move. All are
// event-driven (system `tar` via QProcess, file ops on the main thread) and
// cancellable, mirroring run_backup_worker / run_restore_worker / move logic.
class BackupTask : public QObject {
    Q_OBJECT
public:
    explicit BackupTask(QObject* parent = nullptr);
    void start(const prefixops::PrefixInfo& entry,
               const QList<prefixops::GameBackupInfo>& games, const QString& destPath,
               qint64 totalBytes);
    void cancel();

signals:
    void line(const QString& text);
    void progress(int percent); // < 0 -> indeterminate
    void finished(bool ok, const QString& error, bool cancelled);

private:
    QProcess* m_proc = nullptr;
    bool m_cancelled = false;
    QString m_dest;
    QString m_tmpManifest;
};

class RestoreTask : public QObject {
    Q_OBJECT
public:
    explicit RestoreTask(QObject* parent = nullptr);
    void start(const QString& archivePath, const QJsonObject& manifest, const QString& runner,
               const QString& prefixCode, const QString& targetPrefixPath,
               const QString& gamesDestBase, qint64 totalBytes);
    void cancel();

signals:
    void line(const QString& text);
    void progress(int percent);
    void finished(bool ok, const QString& error, bool cancelled);

private:
    void finishRestore();
    void cleanupStaging();

    QProcess* m_proc = nullptr;
    bool m_cancelled = false;
    QString m_archive;
    QJsonObject m_manifest;
    QString m_runner;
    QString m_prefixCode;
    QString m_targetPrefix;
    QString m_gamesDestBase;
    QString m_staging;
};

class MoveTask : public QObject {
    Q_OBJECT
public:
    explicit MoveTask(QObject* parent = nullptr);
    void start(const QString& oldPath, const QString& newPath, const QString& runner,
               const QString& code);

    // Recursively copy a file or directory (dst is overwritten/merged).
    static bool copyRecursive(const QString& src, const QString& dst, QString* error);

signals:
    void line(const QString& text);
    void finished(bool ok, const QString& error, const QStringList& relinked);

private:
    static bool moveDirectory(const QString& oldPath, const QString& newPath, QString* error);
};
