#pragma once

#include "core/RunnerConfig.h"

#include <QJsonObject>
#include <QList>
#include <QPair>
#include <QString>
#include <QStringList>

// Helpers for the per-game bashlaunch scripts and the Steam-style launch options.
// Ports the corresponding functions from launcher.py.
namespace shortcut {

// shlex.quote() equivalent: return a shell-safe representation of `s`.
QString shellQuote(const QString& s);

// Keep only letters/digits/space/underscore/hyphen and trim (used for script names).
QString sanitizeName(const QString& name);

struct LaunchOptions {
    QList<QPair<QString, QString>> envVars;
    QStringList extraArgs;
};

// Parse a Steam-like launch options string. See parse_launch_options().
LaunchOptions parseLaunchOptions(const QString& launchOptions);

// Read the .exe path from an existing script (wine line or proton run line).
QString extractExePath(const QString& scriptPath);

// Read the working folder from the 'cd "..."' line (expected on line 2).
QString extractFolderPath(const QString& scriptPath);

// Rebuild the script contents from a runner choice (a JSON object with keys
// runner/prefix_path/proton_path/launch_options/comment).
QString buildScriptContent(const QString& folderPath, const QString& exePath,
                           const QJsonObject& choice);

// Detect a GOG product id from goggame-<id>.info near the exe (up to 4 levels up).
QString detectGogId(const QString& exePath);

// Tambah game ke daftar launcher TANPA dialog: tulis script .sh + runner config +
// ikon (dipotong persegi 250px seperti Change Icon). Port of add_game_shortcut().
// Nama yang dipakai otomatis diberi angka kalau sudah dipakai game lain; kalau
// script yang ada menunjuk exe yang sama (mis. install ulang) entri lama dipakai
// ulang. Mengembalikan nama script final (tanpa .sh).
QString addGameShortcut(const QString& name, const QString& exePath,
                        const RunnerChoice& choice, const QString& iconPath = QString(),
                        const QString& workDir = QString());

} // namespace shortcut
