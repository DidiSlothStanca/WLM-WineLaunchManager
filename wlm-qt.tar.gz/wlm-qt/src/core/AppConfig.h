#pragma once

#include <QPoint>
#include <QSize>
#include <QString>

// Persisted main-window geometry. Field semantics mirror window_config.json:
// size "WxH", position "+X+Y", maximized flag, and the library/detail splitter
// position ("sash", i.e. the left panel width in pixels).
struct WindowGeometry {
    QString size = QStringLiteral("1000x720");
    QString position;            // empty when unknown
    bool maximized = false;
    int sash = -1;               // -1 = not saved
    int zoom = 100;              // UI zoom percent (10..200, 100 = normal)

    QSize toSize() const;
    bool hasPosition() const;
    QPoint toPoint() const;      // only valid when hasPosition()
};

// Reads/writes the small JSON config files the Python launcher uses
// (theme_config.json + window_config.json). Keeps them byte-compatible so both
// apps can run against the same ~/wlm directory.
class AppConfig {
public:
    // Load theme + window geometry from disk (never throws; missing/corrupt
    // files simply fall back to defaults).
    void load();

    QString theme() const { return m_theme; }
    void setTheme(const QString& id) { m_theme = id; }
    void saveTheme() const;

    const WindowGeometry& window() const { return m_window; }
    void setWindow(const WindowGeometry& g) { m_window = g; }
    void saveWindow() const;

private:
    QString m_theme = QStringLiteral("default");
    WindowGeometry m_window;
};
