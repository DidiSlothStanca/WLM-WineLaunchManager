# Wine Launch Manager — Qt/C++ port

A C++ port of the Python/Tkinter **Wine Launch Manager (WLM)** launcher, built
with **Qt 6 (Widgets)** and **QtWebEngine** (for the embedded GOG login/store
views that the Python version did with `pywebview`).

The original Python sources remain in the parent directory (`../launcher.py`,
`../gog_store.py`, …) and are the reference for behaviour. This port keeps the
same `~/wlm` data directory and configuration files, so the two can coexist.

## Why a port?

The Python version is ~12 600 lines and does a lot of subprocess/PTY/archive
work where interpreter overhead and the Tk UI become the bottleneck. C++/Qt
gives a native, faster UI and much cheaper process handling.

## Requirements

- CMake ≥ 3.21
- A C++20 compiler
- Qt 6 (Core, Gui, Widgets, Network)
- Qt 6 WebEngineWidgets + WebChannel (optional; enables embedded web views)

On Debian/Ubuntu:

```bash
sudo apt install build-essential cmake ninja-build zlib1g-dev \
    qt6-base-dev qt6-webengine-dev libqt6webchannel6-dev
```

## Build & run

```bash
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build
./build/wlm-qt
```

Version flag:

```bash
./build/wlm-qt --version
```

## Project layout

```
src/
  main.cpp                  entry point, --version handling, app metadata
  core/
    Paths.*                 ~/wlm directory & file layout (shared with Python)
    JsonIO.*                atomic JSON read/write for config files
    Theme.*                 Theme struct + colour helpers (mix_color, readable_on)
    ThemeManager.*          7 themes + palette/stylesheet application
    AppConfig.*             theme_config.json + window_config.json
    DialogSizes.*           dialog_sizes.json + rememberDialogSize helper
    EnvConfig.*             env_config.yaml (tiny YAML reader/writer)
    ProcessUtils.*          clean child-process environment (AppImage fix)
    Shortcut.*              bashlaunch script parse/build + launch-option parsing
    Proton.*                Proton build discovery + Steam client path
    RunnerConfig.*          per-game runner choice (runner_config.json)
    PrefixRegistry.*        prefix codes, base dirs, prefix_registry.json
    GameLauncher.*          QProcess game launching, logs, live output
    ProtonManager.*         GitHub release fetch + CPU/arch matching
    ArchiveExtractor.*      async tar/unzip extraction (folder wrapping)
    ProtonDownloader.*      resumable download with pause/resume
    PrefixOps.*             prefix scan/link/relink + backup-info helpers
    PrefixTasks.*           async backup/restore/move (tar + manifest.json)
    CoverStore.*            cover-art store (covers/<name>.jpg + index.json) & title matching
    CoverFetcher.*          async GOG cover lookup/download (event-driven QNetwork)
    GogConfig.*             gog_config.json (public Galaxy client + endpoints, same schema)
    GogAuth.*               gog_auth.json (0600), login URL + OAuth code parsing
    GogClient.*             async GOG API (token refresh, owned library, installers, downlinks)
    GogDownloader.*         sequential resumable installer download (setup files)
    InstallWatch.*          install_watch.py path helpers (drive_c lookup, case-insensitive resolve)
    SetupRunner.*           run an installer via Wine/Proton and watch for the new game
    GogSaves.*              save backup/restore (tar.gz + manifest.json) + GOG cloud saves
    Version.h               version / developer / maintainer strings
  ui/
    MainWindow.*            main window shell (toolbar, library/detail, footer)
    LibraryGrid.*           cover-card grid view (lazy load, fetch covers, context menu)
    RunnerDialog.*          runner/prefix picker (ask_runner_choice)
    LogWindow.*             live/last game log viewer
    TaskLogWindow.*         progress log window (pause/cancel)
    ProtonDownloadDialog.*  Proton GE/CachyOS release browser
    PrefixManagerDialog.*   Prefix Configuration Manager
    WinetricksDialog.*      common Winetricks verbs picker
    RestoreBackupDialog.*   restore destination chooser
    GogLoginDialog.*        embedded GOG login (QtWebEngine) + manual code fallback
    GogStoreDialog.*        GOG Store: account, owned library, installer download
    GogCoverGrid.*          async cover-card grid for the store (cached gog_covers/<id>.jpg)
    SaveManagerDialog.*     Save Manager: local backups + GOG cloud check/download
    HudConfigDialog.*       Config HUD (DXVK_HUD / GALLIUM_HUD metrics + size)
    AddShortcutDialog.*     candidate exe picker after a non-GOG setup finishes
```

## Port status

- [x] **Stage 0 — Scaffold**: build system, paths, config, theming, window shell.
- [x] **Stage 1 — Game library & shortcuts**:
  - `bashlaunch/*.sh` parsed (exe/folder), build/rebuild with runner + launch options
  - Library list (search, A-Z/Z-A sort, source column), detail card (icon, source, location, modified, size)
  - Add / Remove / Rename / Change Icon / Open Folder / Play / Logs
  - Runner dialog: Wine (isolated prefix optional) / Proton GE / Proton-CachyOS + prefix registry
  - Launch via `GameLauncher` (QProcess, merged output, `logs/<game>.log`) + live `LogWindow`
  - Launch modes: Normal / GalliumHUD / VulkanHUD / MangoHud-GL / Mangohud
- [x] **Stage 2 — Proton GE / Proton-CachyOS download & install**:
  - GitHub release browser (async, `QNetworkManager`) for both GE (one `.tar.gz`/release) and CachyOS (per-variant: Native/SLR/Standalone)
  - CPU microarchitecture detection (`/proc/cpuinfo`) + per-build Compatible / Recommended / Not compatible verdicts
  - Resumable download with Pause/Resume (`Range` requests), live progress + task log window
  - Archive extraction (`tar`/`unzip`) with the same single-folder wrapping rule as Python
  - Menu actions: Extract Proton GE/CachyOS Archive..., Download Online..., Open Folder
- [x] **Stage 3 — Prefix management**:
  - Prefix Configuration Manager: lists every known prefix (runner, code, game(s),
    Proton version, location) with Refresh + Show Logs
  - Per-prefix tools: Winecfg / Explorer / Uninstaller / Winetricks (wine prefix,
    or Proton `run` / `WINEPREFIX=…/pfx` + Proton's wine binary)
  - Open Folder, Move Prefix (folder move + relink every script + registry update)
  - Backup Apps / Restore Apps via `tar` + `manifest.json` (same layout as Python),
    with a cancellable progress window; restore re-creates scripts + runner config
  - Remove Apps: deletes the prefix folder + all linked launcher entries, warning
    which games live inside the prefix (their files are removed too)
  - Add Game now links to an existing prefix (`find_owning_prefix`) when the .exe
    lives inside one; menu "Prefix Configuration Manager..." + "winecfg" wired
- [x] **Stage 4 — Cover art + grid/library views**:
  - `game_covers.py` ported: title normalisation + `difflib`-equivalent similarity
    (edition stripping, accent folding, sequel-number penalty) — verified to match
    Python's scores exactly
  - `covers/<name>.jpg` store with the same `index.json` schema (auto/manual/miss,
    score, matched, ts) + 7-day miss retry and 60 s offline backoff
  - Async GOG cover search (catalog endpoint + embed fallback) and JPEG download via
    `QNetworkAccessManager` (no blocking); supports manual cover, re-download, remove
  - Grid view: lazy cover cards with title + GOG/Non-GOG tag, centre-cropped covers,
    game-icon / first-letter fallbacks, selection border synced with the list
  - Grid/List toggle + card-size combo (Small/Medium/Large) persisted in
    `~/wlm/library_view.json` (same schema as Python), "Fetch Covers" for the library
- [x] **Stage 5 — GOG Store + embedded login browser (QtWebEngine)**:
  - `gog_store.py` auth/API ported: same `~/wlm/gog_config.json` defaults and schema,
    `~/wlm/gog_auth.json` written mode 0600, OAuth `code` extraction + token
    exchange/refresh via `QNetworkAccessManager` (auto-refresh 60 s before expiry,
    401 → "log in again" and the saved login is cleared)
  - Embedded login window: real GOG auth page in a `QWebEngineView`; the redirect that
    carries `code` is detected automatically. Manual fallback (paste the redirect
    URL / code, or open the page in the system browser) when needed — the
    `gog_login_browser.py` equivalent. Uses an off-the-record profile, a normal
    Chrome user agent (Google blocks UAs that say "QtWebEngine"), and redirects
    popups (`window.open` / `target=_blank` sign-in windows) into the same view so
    the first window is never closed/covered; the dialog also raises itself in
    front of the window that opened it
  - Store window: account state (Login / Logout / Refresh), owned-library listing
    (paged by title) with search, list view + cover-card grid (async covers cached in
    `~/wlm/gog_covers/<id>.jpg`, lazily loaded for visible cards), same view default
    from `gog_config.json`
  - **Download Setup**: fetches installer metadata (filtered by `os`/`language`),
    lets you pick an installer, and downloads its files (resumable `Range` + `.part`,
    progress/cancel) into `~/wlm/gog_downloads/<game>/`
  - **Install**: once the download finishes, the installer can be run right away with
    the chosen Wine/Proton runner; the newly installed game is detected (see Stage 7's
    `install_watch` port), the Cached GOG cover is used as its icon and a launcher
    shortcut is added automatically (with `source: "gog"` + product id)
  - Open Games Folder / Open Setup Folder shortcut buttons
  - _Deferred (reported in-app):_ Direct Download (Galaxy chunk content system) —
    setup files are downloaded and can be installed/run manually or via the install flow
- [x] **Stage 6 — Save Manager (local + GOG cloud)**:
  - `gog_saves.py` ported: Save-folder discovery from `goggame-*.info` cloud
    locations + macros (`<?DOCUMENTS?>`, `<?SAVED_GAMES?>`, …, and `<?INSTALL?>`),
    plus user-added custom folders (`save_folders.json`)
  - Local backups: `tar -czhf` into `~/wlm/save_backups/<game>/<stamp>_<note>.tar.gz`
    with the same `manifest.json` schema; restore extracts to a temp dir and copies
    with `.wlm-tmp` + rename, preserving mtime (backup/restore cross-compatible with
    the Python version). "Backup Now" / "Restore..." / "Delete" / "Open Backups Folder"
  - GOG cloud: **Check Cloud** compares cloud vs local (nothing changed),
    **Download & Overwrite** fetches new/changed files, and **Upload to Cloud**
    pushes local saves to the cloud (gzip + `Etag`/`X-Object-Meta-LocalLastModified`
    like GOG Galaxy; unchanged files are skipped via md5 of the gzip body).
    Credentials come from `gog_auth.json` + the build manifest
    (`gog_cloud_cache.json` secrets), locations from `remote-config.gog.com`,
    file list/download/upload from `cloudstorage.gog.com` (gzip handled). Local
    saves are auto-backed-up (`before-cloud-download`) before a download
    overwrites them and a "keep newer local?" choice is offered.
  - Opened from **Saves...** in the Play (runner) dialog when the game already has a
    prefix; the window size/state is saved in `gog_ui.json` section `"saves"`
- [x] **Stage 7 — Install watch + HUD config**:
  - `install_watch.py` ported (`core/InstallWatch.*`): GOG detection via
    `goggame-*.info` (freshest-playTask / `isPrimary` scoring, case-insensitive path
    resolve, "uninstaller written" completion check while the installer runs) and
    non-GOG candidate detection (`ctime`/`mtime` freshness, junk/redist filtering,
    largest-first). `SetupRunner` runs an installer via Wine/Proton (launch options,
    clean env, Proton `STEAM_COMPAT_*`) and polls the prefix non-blockingly
  - **Install Apps...** toolbar button: pick a `.exe`, choose the runner/prefix, run
    the setup, then add the detected game automatically (GOG info) or confirm a
    candidate exe via the "Add Shortcut" dialog (name + exe + Browse Other)
  - **Config HUD** dialog: checklists + size for `VulkanHUD` (DXVK_HUD) and
    `GalliumHUD` (GALLIUM_HUD), Save / Reset to Defaults / Close, saved to
    `~/wlm/hud_config.json` with the same schema as Python (incl. `window_position`
    as `"+x+y"`); `GameLauncher` builds the HUD env from that file

## Config compatibility

`~/wlm/theme_config.json`, `window_config.json`, `dialog_sizes.json`,
`env_config.yaml`, `library_view.json`, `gog_config.json`, `gog_auth.json` and
`hud_config.json` are read/written with the same schema as the Python launcher,
so the two can share the same data directory (the GOG store window size is stored
in `dialog_sizes.json`
as `gog_store` rather than Python's `gog_ui.json`). `gog_ui.json` is still written
for the Save Manager window (`"saves"` section), and the save files
(`gog_cloud_cache.json`, `save_folders.json`, `save_backups/`) keep the Python
schema/format, so backups and cloud caches are interchangeable between both apps.
