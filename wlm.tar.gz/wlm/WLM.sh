#!/bin/bash
cd ~/wlm
python3 launcher.py &
